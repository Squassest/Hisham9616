// class-compare.js — مقارنة الشعب
function renderClassCompare() {
  const el = document.getElementById('classCompareContent');
  if (!el) return;
  el.innerHTML = `<div class="card"><div class="card-b" style="padding:40px;text-align:center">
    <i class="fas fa-balance-scale" style="font-size:48px;opacity:.2;display:block;margin-bottom:14px"></i>
    <h3 style="margin-bottom:8px">مقارنة الشعب</h3>
    <p style="color:var(--txt2);margin-bottom:20px">اختر شعبتين أو أكثر لمقارنة أداء الطلاب والحضور</p>
    ${_renderClassCompareContent()}
  </div></div>`;
}

function _renderClassCompareContent() {
  const sems = STATE.sections.filter(s=>s.semester===STATE.currentSem);
  if (!sems.length) return `<p style="color:var(--txt3)">لا توجد شعب في الفصل الحالي</p>`;
  return sems.map(sec => {
    const sub = getSubject(sec.subject_id);
    const cnt = (sec.student_ids||[]).length;
    return `<div style="display:inline-flex;align-items:center;gap:8px;padding:8px 14px;background:var(--bg);border:1.5px solid var(--border);border-radius:10px;margin:4px;font-size:13px">
      <span style="font-weight:700">${esc(sec.name)}</span>
      <span style="color:var(--txt3)">${esc(sub?.name||'—')}</span>
      <span class="badge b-blue" style="font-size:10px">${cnt} طالب</span>
    </div>`;
  }).join('');
}
