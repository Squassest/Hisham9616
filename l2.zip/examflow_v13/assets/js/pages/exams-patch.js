// exams-patch.js v1 — تعديلات على نظام الامتحانات
// يُحمَّل بعد exams.js ليُعيد تعريف الدوال المطلوبة

// ══ Override: saveExam مع إشعارات المراقبين ══════════════════
const _origSaveExam = window.saveExam;
window.saveExam = async function() {
  const data = _getExamFormData ? _getExamFormData() : null;
  if (!data) return;

  const errors = typeof _checkConflicts === 'function' ? _checkConflicts(data, STATE._editExamId) : [];
  if (errors.length) {
    const warnDiv = document.getElementById('conflictWarnings');
    const listDiv = document.getElementById('conflictList');
    if (warnDiv) warnDiv.style.display = 'block';
    if (listDiv) listDiv.innerHTML = errors.map(e=>`<div style="margin-bottom:4px">${e}</div>`).join('');
    if (!confirm(`⚠️ يوجد ${errors.length} تعارض:\n\n${errors.join('\n')}\n\nهل تريد الحفظ رغم ذلك؟`)) return;
  }

  const btn = document.getElementById('saveExamBtn');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> جارٍ الحفظ...'; }

  try {
    // تهيئة حالات المراقبين
    const proctor_statuses = {};
    (data.proctor_ids || []).forEach(pid => {
      proctor_statuses[pid] = 'pending';
    });
    data.proctor_statuses = proctor_statuses;

    const payload = Serialize.exam(data);
    let examId;

    if (STATE._editExamId) {
      await SB.update('exams', STATE._editExamId, payload);
      examId = STATE._editExamId;
      const idx = STATE.exams.findIndex(e=>e.id===STATE._editExamId);
      if (idx>=0) STATE.exams[idx] = { ...STATE.exams[idx], ...Hydrate.exam(payload) };
      toast('✓ تم تحديث الامتحان','success');
      await SB.logAction('تعديل امتحان','exams', getSubject(data.subject_id)?.name||'');
      if (typeof _syncExamBookings === 'function') await _syncExamBookings(STATE._editExamId, data);
    } else {
      const res = await SB.insert('exams', payload);
      examId = res?.id;
      STATE.exams.push(Hydrate.exam(res));
      toast('✓ تمت إضافة الامتحان','success');
      await SB.logAction('إضافة امتحان','exams', getSubject(data.subject_id)?.name||'');
      if (typeof _syncExamBookings === 'function' && examId) await _syncExamBookings(examId, data);
    }

    // ══ إرسال إشعارات للمراقبين ══════════════════════════════
    if (examId) {
      await _sendProctorNotifications(examId, data, !!STATE._editExamId);
    }

    closeMo('addExamMo');
    renderExams();
  } catch(e) {
    toast('خطأ: '+e.message,'error');
    if (btn) { btn.disabled=false; btn.innerHTML=`<i class="fas fa-save"></i> ${STATE._editExamId?'تحديث':'حفظ الامتحان'}`; }
  }
};

// إرسال إشعارات المراقبين عند إنشاء/تحديث امتحان
async function _sendProctorNotifications(examId, examData, isUpdate=false) {
  const sub  = getSubject(examData.subject_id);
  const subName = sub?.name || '—';
  const proctorIds = examData.proctor_ids || [];
  if (!proctorIds.length) return;

  const notifTitle = isUpdate
    ? `🔔 تحديث في امتحان: ${subName}`
    : `🎓 تم تعيينك مراقباً في امتحان: ${subName}`;
  const notifBody = `التاريخ: ${examData.date} · الوقت: ${examData.time?.slice(0,5)} · النوع: ${examData.type==='final'?'نهائي':examData.type==='midterm'?'منتصف':'اختبار'}`;

  // جمع رؤساء الأقسام الفريدة للمراقبين
  const deptHeadsNotified = new Set();

  for (const pid of proctorIds) {
    const proctor = getProfile(pid);
    if (!proctor) continue;

    // إشعار للمراقب
    try {
      await SB.insert('notifications', {
        user_id:    pid,
        type:       isUpdate ? 'exam_updated' : 'proctor_assigned',
        title:      notifTitle,
        body:       notifBody,
        exam_id:    examId,
        is_read:    false,
        created_at: new Date().toISOString()
      });
    } catch(e) { console.warn('[notif proctor]', e.message); }

    // إشعار لرئيس قسم المراقب (مرة واحدة لكل قسم)
    const deptId = proctor.dept_id;
    if (deptId && !deptHeadsNotified.has(deptId)) {
      const head = STATE.profiles.find(p => p.role === 'dept_head' && p.dept_id === deptId);
      if (head && head.id !== STATE.currentUser?.id) {
        try {
          await SB.insert('notifications', {
            user_id:    head.id,
            type:       'dept_proctor_assigned',
            title:      `إشعار: مراقبة لأحد أعضاء قسمك`,
            body:       `${proctor.name?.split(' ').slice(0,2).join(' ')} مُكلَّف بمراقبة: ${subName} · ${examData.date}`,
            exam_id:    examId,
            is_read:    false,
            created_at: new Date().toISOString()
          });
        } catch(e) { console.warn('[notif head]', e.message); }
      }
      deptHeadsNotified.add(deptId);
    }
  }
}

// ══ Override: قسم المراقبين في نموذج الامتحان — إضافة زر طلب خارجي ══

// إضافة زر "طلب مراقب من قسم آخر" في منطقة المراقبين
const _origAutoSuggest = window._autoSuggestProctors;
window._renderProctorsSectionHeader = function() {
  return `
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px">
      <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px">
        <i class="fas fa-user-tie" style="margin-left:5px;color:var(--purple2)"></i>المراقبون
        <span style="font-size:9.5px;font-weight:400;margin-right:6px">(x/3 = عدد مرات المراقبة · 🔴 وصل الحد)</span>
      </div>
      <button class="btn bo btn-xs" onclick="_autoSuggestProctors()" title="اقتراح تلقائي">
        <i class="fas fa-magic" style="color:var(--teal)"></i> اقتراح
      </button>
      <button class="btn btn-xs" style="background:var(--purple2)15;color:var(--purple2);border:1px solid var(--purple2)30;font-size:11px"
              onclick="_requestCrossDeptProctor()" title="طلب مراقب من قسم آخر">
        <i class="fas fa-people-arrows"></i> طلب من قسم آخر
      </button>
    </div>`;
};

// فتح نافذة طلب مراقب من قسم آخر من داخل نموذج الامتحان
window._requestCrossDeptProctor = function() {
  const subjId = parseInt(document.getElementById('exSubj')?.value);
  const date   = document.getElementById('exDate')?.value;
  if (!subjId || !date) {
    toast('اختر المادة والتاريخ أولاً', 'warning');
    return;
  }

  const me = STATE.currentUser;
  const otherDepts = STATE.departments.filter(d => d.id !== me?.dept_id);

  const mo = _getMo('quickCrossReqMo');
  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-people-arrows" style="color:var(--purple2)"></i> طلب مراقب من قسم آخر</h2>
      <button class="md-close" onclick="closeMo('quickCrossReqMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="background:var(--bg);border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:12.5px;color:var(--txt2)">
        <i class="fas fa-info-circle" style="color:var(--purple2)"></i>
        سيتم إرسال الطلب لرئيس القسم المستهدف. <strong>يجب حفظ الامتحان أولاً</strong> حتى يُربط الطلب به.
      </div>
      <div class="field"><label class="field-lbl">القسم المستهدف <span class="req">*</span></label>
        <select id="qcrDept">
          <option value="">— اختر قسماً —</option>
          ${otherDepts.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}
        </select></div>
      <div class="field"><label class="field-lbl">ملاحظات</label>
        <textarea id="qcrNotes" rows="2" placeholder="أي متطلبات..." style="width:100%;resize:vertical"></textarea></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('quickCrossReqMo')">إلغاء</button>
      <button class="btn bp" onclick="_saveQuickCrossReq(${subjId},'${date}')">
        <i class="fas fa-paper-plane"></i> إرسال الطلب
      </button>
    </div>
  </div>`;
  showMo('quickCrossReqMo');
};

window._saveQuickCrossReq = async function(subjId, date) {
  const targetDept = parseInt(document.getElementById('qcrDept')?.value);
  const notes      = document.getElementById('qcrNotes')?.value || '';
  const me         = STATE.currentUser;
  if (!targetDept) return toast('اختر القسم المستهدف','warning');

  // إيجاد الامتحان الموجود أو استخدام examId مؤقت (سيُحدَّث لاحقاً)
  const subName = getSubject(subjId)?.name || '—';

  try {
    const res = await SB.insert('cross_dept_requests', {
      exam_id:             null, // سيُحدَّث عند حفظ الامتحان
      requesting_dept_id:  me.dept_id,
      target_dept_id:      targetDept,
      requested_by:        me.id,
      status:              'pending',
      notes:               `المادة: ${subName} · التاريخ: ${date}\n${notes}`,
      created_at:          new Date().toISOString()
    });
    STATE.crossDeptRequests.push(res);

    // إشعار لرئيس القسم المستهدف
    const deptHead = STATE.profiles.find(p => p.role === 'dept_head' && p.dept_id === targetDept);
    if (deptHead) {
      await SB.insert('notifications', {
        user_id:    deptHead.id,
        type:       'cross_dept_request',
        title:      'طلب مراقب من قسم ' + (getDept(me.dept_id)?.name || '—'),
        body:       `للمادة: ${subName} بتاريخ ${date}`,
        is_read:    false,
        created_at: new Date().toISOString()
      });
    }

    toast('تم إرسال الطلب ✓ · سيصل ردّ رئيس القسم عبر الإشعارات', 'success');
    closeMo('quickCrossReqMo');
    UI?._updateAllBadges?.();
  } catch(e) { toast(e.message,'error'); }
};
