// ═══════════════════════════════════════════════════════════════
//  exams.js — إدارة الامتحانات (النسخة المطورة v5)
// ═══════════════════════════════════════════════════════════════

let _examFilter = 'all';
function setEF(f, el) {
  _examFilter = f;
  document.querySelectorAll('#examTabs .tab').forEach(t => t.classList.remove('active'));
  el?.classList.add('active');
  renderExams();
}

// ═══════════════════════════════════════════════════════════════
//  سجل امتحانات المراقب — يظهر فقط الامتحانات المرتبطة به
// ═══════════════════════════════════════════════════════════════
function _renderProctorExamsPage() {
  const uid  = STATE.currentUser?.id;
  const now  = new Date();

  // كل امتحانات المراقب (كل الفصول — للسجل)
  // ✅ فقط الامتحانات الموافق عليها — المعلّقة لا تظهر للمراقب
  const allMyExams = STATE.exams
    .filter(e => (e.proctor_ids||[]).includes(uid) && e.approval_status !== 'pending' && e.approval_status !== 'rejected')
    .sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  // الفصل الحالي
  const semExams = allMyExams.filter(e => e.semester === STATE.currentSem);

  // تحديث عنوان الصفحة
  const tEl = document.getElementById('tbTitle');
  if (tEl) tEl.textContent = '📋 سجل الامتحانات';

  // مسح أزرار الأكشن (المراقب لا يضيف امتحانات)
  setHTML('examsActs', '');

  // تحليل سريع
  const active   = semExams.filter(e => examStatus(e) === 'active');
  const upcoming = semExams.filter(e => examStatus(e) === 'upcoming');
  const done     = semExams.filter(e => examStatus(e) === 'completed');
  const pending  = semExams.filter(e => (e.proctor_statuses||{})[uid]==='pending');

  // تحديث شارة الزر
  UI._updateExamAlertBadge?.();

  const el = document.getElementById('examsList');
  if (!el) return;

  // بناء الواجهة
  el.innerHTML = `

    <!-- إشعار جارٍ الآن -->
    ${active.length ? active.map(e => {
      const sub  = getSubject(e.subject_id);
      const rp   = e.room_proctors||{};
      const myRid= (e.room_ids||[]).find(rid=>{const a=rp[String(rid)];return a&&a.includes(uid);});
      const myRoomName = myRid ? getRoom(myRid)?.name : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join('، ');
      const start = new Date(`${e.date}T${e.time}`);
      const remMs = Math.max(0, start.getTime()+(e.duration+(e.extra_time||0))*60000 - now.getTime());
      const remMin= Math.floor(remMs/60000);
      const remSec= Math.floor((remMs%60000)/1000);
      const pct   = Math.min(100,Math.round((1-remMs/((e.duration+(e.extra_time||0))*60000))*100));
      return `<div style="padding:18px 20px;background:linear-gradient(135deg,#064e3b,#065f46);border-radius:16px;margin-bottom:14px;border:2px solid rgba(16,185,129,.4);box-shadow:0 4px 20px rgba(16,185,129,.2)">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
          <span style="width:10px;height:10px;border-radius:50%;background:#34d399;animation:pulse 1s infinite;display:inline-block"></span>
          <span style="font-size:13px;font-weight:800;color:#6ee7b7">جارٍ الآن</span>
        </div>
        <div style="font-size:18px;font-weight:900;color:white;margin-bottom:6px">${esc(sub?.name||'—')}</div>
        <div style="font-size:12.5px;color:#a7f3d0;margin-bottom:12px;display:flex;gap:14px;flex-wrap:wrap">
          ${myRoomName?`<span><i class="fas fa-door-open"></i> ${esc(myRoomName)}</span>`:''}
          <span><i class="fas fa-clock"></i> ${fmtTime(e.time)}</span>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <span style="font-size:11px;color:#6ee7b7">الوقت المتبقي</span>
          <span id="pex-timer-${e.id}" style="font-size:24px;font-weight:900;color:#34d399;font-family:'Cairo',monospace">${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}</span>
        </div>
        <div style="height:6px;background:rgba(255,255,255,.15);border-radius:3px;overflow:hidden">
          <div id="pex-pbar-${e.id}" style="height:100%;width:${pct}%;background:${pct>80?'#ef4444':pct>50?'#fbbf24':'#34d399'};border-radius:3px;transition:width 1s linear"></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:12px">
          <button class="btn btn-sm" style="flex:1;background:rgba(255,255,255,.15);color:white;border:1.5px solid rgba(255,255,255,.3)"
            onclick="openAttendance(${e.id})">
            <i class="fas fa-clipboard-check"></i> تسجيل الحضور
          </button>
          <button class="btn btn-sm" style="background:rgba(52,211,153,.25);color:#6ee7b7;border:1.5px solid rgba(52,211,153,.35)"
            onclick="UI.showPage('live')">
            <i class="fas fa-tv"></i> شاشة حية
          </button>
        </div>
      </div>`;
    }).join('') : ''}

    <!-- إشعار امتحانات قادمة خلال 24 ساعة -->
    ${(()=>{
      const soon24 = upcoming.filter(e=>{
        const ms = new Date(`${e.date}T${e.time}`) - now;
        return ms>0 && ms<=24*3600*1000;
      });
      if (!soon24.length) return '';
      return `<div style="padding:14px 16px;background:var(--gold)12;border-radius:12px;border:1.5px solid var(--gold)40;margin-bottom:14px">
        <div style="font-size:12.5px;font-weight:800;color:var(--gold);margin-bottom:8px">
          <i class="fas fa-hourglass-half" style="margin-left:5px"></i>
          امتحانات خلال 24 ساعة القادمة (${soon24.length})
        </div>
        ${soon24.map(e=>{
          const sub = getSubject(e.subject_id);
          const diffMs  = Math.max(0,new Date(`${e.date}T${e.time}`)-now);
          const diffH   = Math.floor(diffMs/3600000);
          const diffMin = Math.floor((diffMs%3600000)/60000);
          return `<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--gold)20">
            <i class="fas fa-fire" style="color:var(--gold);flex-shrink:0"></i>
            <div style="flex:1;font-weight:700;font-size:13px">${esc(sub?.name||'—')}</div>
            <span style="font-size:11.5px;color:var(--gold);font-weight:700">${diffH?diffH+'س ':''} ${diffMin} دق</span>
          </div>`;
        }).join('')}
      </div>`;
    })()}

    <!-- تعيينات تنتظر قبول -->
    ${pending.length ? `
    <div style="padding:12px 16px;background:var(--red2)08;border-radius:12px;border:1.5px solid var(--red2)30;margin-bottom:14px">
      <div style="font-size:12.5px;font-weight:800;color:var(--red2);margin-bottom:8px">
        <i class="fas fa-bell" style="margin-left:5px"></i>
        تعيينات تنتظر قبولك (${pending.length})
      </div>
      ${pending.map(e=>{
        const sub=getSubject(e.subject_id);
        return `<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--red2)15">
          <div style="flex:1">
            <div style="font-weight:700;font-size:13px">${esc(sub?.name||'—')}</div>
            <div style="font-size:11.5px;color:var(--txt2)">${fmtDate(e.date)} · ${fmtTime(e.time)}</div>
          </div>
          <button class="btn btn-xs" style="background:var(--green2);color:white;border:none"
            onclick="proctorAcceptAssignment(${e.id})"><i class="fas fa-check"></i> قبول</button>
          <button class="btn btn-xs" style="background:var(--red2)15;color:var(--red2);border:1px solid var(--red2)30"
            onclick="proctorRejectAssignment(${e.id})"><i class="fas fa-times"></i></button>
        </div>`;
      }).join('')}
    </div>` : ''}

    <!-- إحصاءات سريعة -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
      <div style="padding:12px;background:var(--card);border-radius:12px;text-align:center;border:1.5px solid var(--border)">
        <div style="font-size:22px;font-weight:900;color:var(--primary2)">${upcoming.length}</div>
        <div style="font-size:11px;color:var(--txt3)">قادمة</div>
      </div>
      <div style="padding:12px;background:var(--card);border-radius:12px;text-align:center;border:1.5px solid var(--border)">
        <div style="font-size:22px;font-weight:900;color:var(--green2)">${active.length}</div>
        <div style="font-size:11px;color:var(--txt3)">جارية</div>
      </div>
      <div style="padding:12px;background:var(--card);border-radius:12px;text-align:center;border:1.5px solid var(--border)">
        <div style="font-size:22px;font-weight:900;color:var(--txt3)">${done.length}</div>
        <div style="font-size:11px;color:var(--txt3)">منتهية</div>
      </div>
    </div>

    <!-- تبويبات الفلترة -->
    <div class="tabs" id="proctorExamTabs" style="margin-bottom:12px">
      <div class="tab active" onclick="_filterProctorExams('all',this)">الكل (${semExams.length})</div>
      <div class="tab" onclick="_filterProctorExams('upcoming',this)">قادمة (${upcoming.length})</div>
      <div class="tab" onclick="_filterProctorExams('active',this)">جارية (${active.length})</div>
      <div class="tab" onclick="_filterProctorExams('completed',this)">منتهية (${done.length})</div>
      ${allMyExams.filter(e=>e.semester!==STATE.currentSem).length?`<div class="tab" onclick="_filterProctorExams('history',this)">السجل الكامل</div>`:''}
    </div>

    <!-- قائمة الامتحانات -->
    <div id="proctorExamList">
      ${_buildProctorExamList(semExams, uid, now)}
    </div>
  `;

  // تشغيل عدادات الامتحانات الجارية
  active.forEach(e => _startProctorExamTimer(e));
}

let _proctorExamFilter = 'all';
function _filterProctorExams(filter, el) {
  _proctorExamFilter = filter;
  document.querySelectorAll('#proctorExamTabs .tab').forEach(t=>t.classList.remove('active'));
  el?.classList.add('active');
  const uid = STATE.currentUser?.id;
  const now = new Date();
  let exams;
  if (filter === 'history') {
    exams = STATE.exams.filter(e=>(e.proctor_ids||[]).includes(uid))
      .sort((a,b)=>new Date(`${b.date}T${b.time}`)-new Date(`${a.date}T${a.time}`));
  } else {
    exams = STATE.exams.filter(e=>(e.proctor_ids||[]).includes(uid)&&e.semester===STATE.currentSem);
    if (filter !== 'all') exams = exams.filter(e=>examStatus(e)===filter);
    exams.sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`));
  }
  const listEl = document.getElementById('proctorExamList');
  if (listEl) listEl.innerHTML = _buildProctorExamList(exams, uid, now);
}

function _buildProctorExamList(exams, uid, now) {
  if (!exams.length) return `<div style="padding:40px;text-align:center;color:var(--txt3)">
    <i class="fas fa-calendar-check" style="font-size:36px;opacity:.25;display:block;margin-bottom:12px"></i>
    لا توجد امتحانات في هذه الفئة
  </div>`;

  const typeColors = {final:'#2563eb',midterm:'#d97706',quiz:'#0891b2',makeup:'#7c3aed'};

  return exams.map(e => {
    const sub   = getSubject(e.subject_id);
    const st    = examStatus(e);
    const rp    = e.room_proctors||{};
    const myRid = (e.room_ids||[]).find(rid=>{const a=rp[String(rid)];return a&&a.includes(uid);});
    const myRoomName = myRid ? getRoom(myRid)?.name : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join('، ');
    const rsSecs = myRid ? ((e.room_sections||{})[String(myRid)]||[]) : (e.section_ids||[]);
    const studCount = rsSecs.reduce((acc,sid)=>{const s=getSection(sid);return acc+(s?.student_ids||[]).length;},0);
    const atts  = STATE.attendance[e.id]||{};
    const presentCnt = rsSecs.reduce((acc,sid)=>{
      const s=getSection(sid);
      return acc+(s?.student_ids||[]).filter(stid=>atts[stid]==='present'||atts[stid]==='late').length;
    },0);
    const pstat = (e.proctor_statuses||{})[uid];
    const semLabel = STATE.semesters.find(s=>s.code===e.semester)?.label||e.semester;
    const c = typeColors[e.type]||'#2563eb';

    return `<div style="background:var(--card);border-radius:14px;border:1.5px solid var(--border);margin-bottom:10px;overflow:hidden;transition:all .2s"
      onmouseover="this.style.boxShadow='0 6px 20px rgba(0,0,0,.1)';this.style.transform='translateY(-1px)'"
      onmouseout="this.style.boxShadow='';this.style.transform=''">
      <div style="height:3px;background:${c}${st==='completed'?'60':''}"></div>
      <div style="padding:14px 16px">
        <div style="display:flex;align-items:start;gap:12px">
          <div style="width:44px;height:44px;border-radius:12px;background:${c}15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-${e.type==='final'?'star':e.type==='midterm'?'bookmark':e.type==='quiz'?'pen-alt':'redo'}" style="color:${c};font-size:18px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:900;font-size:15px;margin-bottom:4px">${esc(sub?.name||'—')}</div>
            <div style="font-size:12px;color:var(--txt2);display:flex;gap:12px;flex-wrap:wrap;margin-bottom:5px">
              <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)}</span>
              <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}د)</span>
              ${myRoomName?`<span style="color:var(--teal)"><i class="fas fa-door-open"></i> ${esc(myRoomName)}</span>`:''}
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
              ${getTypeBadge(e.type)}
              ${getStatusBadge(st)}
              ${e.semester!==STATE.currentSem?`<span class="badge" style="background:var(--txt3)20;color:var(--txt3);font-size:10px">${esc(semLabel)}</span>`:''}
              ${pstat==='pending'?`<span class="badge b-red" style="font-size:10px"><i class="fas fa-bell" style="font-size:9px"></i> تنتظر قبولك</span>`:''}
              ${studCount>0?`<span class="badge b-blue" style="font-size:10px"><i class="fas fa-users"></i> ${studCount} طالب في قاعتي</span>`:''}
              ${st==='completed'&&studCount>0?`<span class="badge" style="background:var(--green2)15;color:var(--green2);font-size:10px">${presentCnt}/${studCount} حضر</span>`:''}
            </div>
          </div>
          ${st==='active'?`
          <div style="display:flex;gap:5px;flex-shrink:0">
            <button class="btn btn-sm" style="background:var(--teal);color:white;border:none"
              onclick="openAttendance(${e.id})" title="تسجيل الحضور">
              <i class="fas fa-clipboard-check"></i>
            </button>
            <button class="btn btn-sm" style="background:var(--green2);color:white;border:none"
              onclick="openCountdown(${e.id})" title="شاشة المراقبة الحية">
              <i class="fas fa-tv"></i>
            </button>
          </div>`:''}
        </div>
        ${e.notes?`<div style="margin-top:8px;padding:7px 10px;background:var(--bg);border-radius:8px;font-size:11.5px;color:var(--txt2);border-right:3px solid ${c}">
          <i class="fas fa-sticky-note" style="color:${c};margin-left:4px"></i>${esc(e.notes)}</div>`:''}
      </div>
    </div>`;
  }).join('');
}

function _startProctorExamTimer(e) {
  const now  = new Date();
  const end  = new Date(`${e.date}T${e.time}`).getTime() + (e.duration+(e.extra_time||0))*60000;
  const tick = () => {
    const remMs  = Math.max(0, end - Date.now());
    const remMin = Math.floor(remMs/60000);
    const remSec = Math.floor((remMs%60000)/1000);
    const pct    = Math.min(100,Math.round((1-remMs/((e.duration+(e.extra_time||0))*60000))*100));
    const tEl = document.getElementById(`pex-timer-${e.id}`);
    const pEl = document.getElementById(`pex-pbar-${e.id}`);
    if (tEl) tEl.textContent = `${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}`;
    if (pEl) { pEl.style.width=pct+'%'; pEl.style.background=pct>80?'#ef4444':pct>50?'#fbbf24':'#34d399'; }
    if (remMs <= 0) clearInterval(_pExTimers[e.id]);
  };
  if (!window._pExTimers) window._pExTimers = {};
  clearInterval(_pExTimers[e.id]);
  _pExTimers[e.id] = setInterval(tick, 1000);
}

// ── الواجهة الرئيسية ──────────────────────────────────────────
function renderExams() {
  // ✅ زر إنشاء الامتحان للمسؤول والمنسق فقط
  if (canCreateExam()) {
    setHTML('examsActs', `
      <div style="display:flex;gap:8px;align-items:center">
        <button class="btn bp btn-sm" onclick="openAddExam()">
          <i class="fas fa-plus"></i> امتحان جديد
        </button>
        ${canReviewExam() ? `
          <button class="btn bo btn-sm" onclick="openExamReviewQueue()" id="examReviewQueueBtn" style="position:relative">
            <i class="fas fa-clipboard-check"></i> مراجعة المعلّقة
            <span id="examPendingBadge" style="display:none;position:absolute;top:-6px;left:-6px;background:var(--red2);color:white;font-size:9.5px;font-weight:900;padding:2px 6px;border-radius:9px;min-width:18px;text-align:center"></span>
          </button>
        ` : ''}
      </div>`);
    // تحديث شارة المعلّقة
    setTimeout(_updateExamReviewBadge, 100);
  } else {
    setHTML('examsActs', '');
  }

  // المراقب: عرض خاص — سجل امتحاناته فقط
  if (isProctor()) {
    _renderProctorExamsPage();
    return;
  }

  let exams = STATE.exams.filter(e => e.semester === STATE.currentSem);

  // ✅ الامتحانات المعلّقة (في انتظار الموافقة):
  //   - تختفي تماماً من العرض العام (للمراقبين، المنسقين، رئيس القسم)
  //   - المسؤول يراها في طابور المراجعة المنفصل (openExamReviewQueue)
  //   - المنسق المُنشئ يرى امتحاناته المعلّقة (للتمييز البصري فقط)
  exams = exams.filter(e => {
    if (e.approval_status !== 'pending') return true;
    // مسؤول؟ تظهر مع علامة معلّق
    if (isAdmin()) return true;
    // المنسق المُنشئ؟ يرى امتحاناته
    if (isCoord() && e.approval_by === STATE.currentUser?.id) return true;
    // باقي الأدوار: لا تظهر حتى الموافقة
    return false;
  });

  // الامتحانات المرفوضة لا تظهر إلا للمسؤول والمُنشئ
  exams = exams.filter(e => {
    if (e.approval_status !== 'rejected') return true;
    if (isAdmin()) return true;
    if (isCoord() && e.approval_by === STATE.currentUser?.id) return true;
    return false;
  });

  // رئيس القسم يرى فقط امتحانات قسمه
  if (isDeptHead()) {
    const myDeptSubjectIds = STATE.subjects.filter(s => s.dept_id === STATE.currentUser?.dept_id).map(s=>s.id);
    exams = exams.filter(e => myDeptSubjectIds.includes(e.subject_id));
  }
  const q = (document.getElementById('examSrch')?.value || '').toLowerCase();
  if (q) exams = exams.filter(e => {
    const sub = getSubject(e.subject_id);
    return sub?.name.toLowerCase().includes(q) || e.date.includes(q);
  });
  if (_examFilter !== 'all') exams = exams.filter(e => examStatus(e) === _examFilter);
  exams.sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  const el = document.getElementById('examsList');
  if (!el) return;

  if (!exams.length) {
    el.innerHTML = `<div style="padding:60px 20px;text-align:center">
      <div style="font-size:56px;margin-bottom:16px">📋</div>
      <div style="font-size:18px;font-weight:800;margin-bottom:8px">لا توجد امتحانات</div>
      <div style="color:var(--txt2);margin-bottom:20px">جرّب تغيير الفلتر أو الفصل الدراسي</div>
      ${canCreateExam()?`<button class="btn bp" onclick="openAddExam()"><i class="fas fa-plus"></i> إضافة أول امتحان</button>`:''}
    </div>`;
    return;
  }

  el.innerHTML = exams.map(e => _buildExamCard(e)).join('');

  // تشغيل العدادات
  exams.forEach(e => {
    if (examStatus(e) === 'active' || examStatus(e) === 'upcoming') {
      _startCardTimer(e);
    }
  });
}

function _buildExamCard(e) {
  const sub    = getSubject(e.subject_id);
  const status = examStatus(e);
  const rooms  = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
  // المراقبون مع حالتهم
  const proctorStatuses = e.proctor_statuses || {};
  const proctData = (e.proctor_ids||[]).map(id => {
    const p   = getProfile(id);
    const pst = proctorStatuses[id] || 'pending';
    return p ? { ...p, _pst: pst } : null;
  }).filter(Boolean);
  const confirmedCount = proctData.filter(p => p._pst === 'accepted').length;
  const pendingCount   = proctData.filter(p => p._pst === 'pending').length;
  const rejectedCount  = proctData.filter(p => p._pst === 'rejected').length;
  const sections=(e.section_ids||[]).map(id=>getSection(id)?.name).filter(Boolean);
  const isLocked = status === 'active';

  const typeColors = { final:'#2563eb', midterm:'#d97706', quiz:'#0891b2', makeup:'#7c3aed' };
  const statusGradients = {
    active:    'linear-gradient(135deg,#064e3b,#065f46)',
    upcoming:  'linear-gradient(135deg,#1e3a5f,#1e40af)',
    completed: 'linear-gradient(135deg,#1e293b,#334155)'
  };

  // Calculate time for card
  const start = new Date(`${e.date}T${e.time}`);
  const end   = new Date(start.getTime() + (e.duration+(e.extra_time||0))*60000);
  const now   = new Date();

  let timerHtml = '';
  if (status === 'active') {
    const remMs  = Math.max(0, end - now);
    const remMin = Math.floor(remMs/60000);
    const remSec = Math.floor((remMs%60000)/1000);
    const pct    = Math.min(100, Math.round((1 - remMs/((e.duration+(e.extra_time||0))*60000))*100));
    timerHtml = `
      <div style="margin-top:14px;padding:14px 16px;background:rgba(16,185,129,.1);border:1.5px solid rgba(16,185,129,.3);border-radius:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <span style="font-size:12px;font-weight:700;color:#6ee7b7"><i class="fas fa-circle" style="font-size:8px;margin-left:5px;animation:pulse 1s infinite"></i>الوقت المتبقي</span>
          <span id="card-timer-${e.id}" style="font-family:'Cairo',sans-serif;font-size:22px;font-weight:900;color:#34d399">${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}</span>
        </div>
        <div style="height:5px;background:rgba(255,255,255,.1);border-radius:3px;overflow:hidden">
          <div id="card-pbar-${e.id}" style="height:100%;width:${pct}%;background:${pct>80?'#ef4444':pct>50?'#fbbf24':'#34d399'};border-radius:3px;transition:width 1s linear"></div>
        </div>
      </div>`;
  } else if (status === 'upcoming') {
    const diffMs  = Math.max(0, start - now);
    const diffH   = Math.floor(diffMs/3600000);
    const diffMin = Math.floor((diffMs%3600000)/60000);
    timerHtml = `
      <div style="margin-top:12px;padding:10px 14px;background:rgba(37,99,235,.1);border:1.5px solid rgba(37,99,235,.25);border-radius:10px;display:flex;align-items:center;gap:10px">
        <i class="fas fa-hourglass-start" style="color:#93c5fd;font-size:14px"></i>
        <span style="font-size:13px;color:#93c5fd">يبدأ بعد: </span>
        <span id="card-timer-${e.id}" style="font-family:'Cairo',sans-serif;font-size:16px;font-weight:900;color:#60a5fa">${diffH?diffH+'س ':''} ${diffMin} دق</span>
      </div>`;
  }

  const canModify = !isLocked || canEdit();
  const canFullEdit = !isLocked && canEdit();

  return `
  <div class="exam-card" id="examcard-${e.id}" style="background:var(--card);border-radius:16px;border:1.5px solid var(--border);margin-bottom:14px;overflow:hidden;transition:all .25s;box-shadow:0 2px 8px rgba(0,0,0,.06)"
    onmouseover="this.style.boxShadow='0 8px 28px rgba(0,0,0,.12)';this.style.transform='translateY(-2px)'"
    onmouseout="this.style.boxShadow='0 2px 8px rgba(0,0,0,.06)';this.style.transform=''">

    <!-- شريط اللون العلوي -->
    <div style="height:4px;background:${typeColors[e.type]||'var(--primary2)'}${status==='completed'?'80':''}"></div>

    <div style="padding:18px 20px">
      <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
        <!-- أيقونة النوع -->
        <div style="width:48px;height:48px;border-radius:14px;background:${typeColors[e.type]||'var(--primary2)'}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas ${e.type==='final'?'fa-star':e.type==='midterm'?'fa-bookmark':e.type==='quiz'?'fa-pen-alt':'fa-redo'}" style="color:${typeColors[e.type]};font-size:20px"></i>
        </div>

        <!-- المعلومات الأساسية -->
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
            <span style="font-size:16px;font-weight:900">${sub?.name || '—'}</span>
            ${sub?.code?`<span style="font-size:11px;color:var(--txt3);background:var(--bg);padding:2px 8px;border-radius:20px">${sub.code}</span>`:''}
            ${getTypeBadge(e.type)}
            ${getStatusBadge(status)}
            ${isLocked?`<span class="badge b-red" style="font-size:10px"><i class="fas fa-lock" style="font-size:8px;margin-left:3px"></i>جارٍ</span>`:''}
            ${e.approval_status==='pending'?`<span class="badge" style="background:var(--gold)25;color:var(--gold);font-size:10px;border:1px solid var(--gold)45;font-weight:800"><i class="fas fa-clock" style="font-size:8px;margin-left:3px"></i>بانتظار الموافقة</span>`:''}
            ${e.approval_status==='rejected'?`<span class="badge b-red" style="font-size:10px"><i class="fas fa-ban" style="font-size:8px;margin-left:3px"></i>مرفوض</span>`:''}
          </div>

          <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:12.5px;color:var(--txt2)">
            <span><i class="fas fa-calendar" style="color:var(--primary2);margin-left:4px"></i>${fmtDate(e.date)}</span>
            <span><i class="fas fa-clock" style="color:var(--gold);margin-left:4px"></i>${fmtTime(e.time)} — ${_timeEnd(e.time, e.duration+(e.extra_time||0))}</span>
            <span><i class="fas fa-hourglass" style="color:var(--teal);margin-left:4px"></i>${e.duration} دق</span>
            <span><i class="fas fa-trophy" style="color:var(--gold);margin-left:4px"></i>${calcPoints(e)} نقطة للمراقب</span>
            ${_isAutoHoliday(e.date)?`<span style="color:var(--red2)"><i class="fas fa-umbrella-beach" style="margin-left:4px"></i>عطلة</span>`:''}
          </div>

          ${rooms.length?`<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap">
            ${rooms.map(r=>`<span style="font-size:11.5px;padding:3px 10px;background:var(--teal)12;color:var(--teal);border-radius:20px;border:1px solid var(--teal)25"><i class="fas fa-door-open" style="margin-left:3px;font-size:10px"></i>${r}</span>`).join('')}
          </div>`:''}

          <!-- المراقبون مع حالة التأكيد -->
          ${proctData.length?`
          <div style="margin-top:8px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;flex-wrap:wrap">
              <span style="font-size:10.5px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px">
                <i class="fas fa-users" style="margin-left:4px"></i>المراقبون (${proctData.length})
              </span>
              ${confirmedCount>0?`<span style="display:inline-flex;align-items:center;gap:3px;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;background:var(--green2)15;color:var(--green2);border:1px solid var(--green2)30">
                <i class="fas fa-check-circle" style="font-size:9px"></i>${confirmedCount} مؤكد
              </span>`:''}
              ${pendingCount>0?`<span style="display:inline-flex;align-items:center;gap:3px;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;background:var(--gold)15;color:var(--gold2);border:1px solid var(--gold)30">
                <i class="fas fa-hourglass" style="font-size:9px"></i>${pendingCount} بانتظار
              </span>`:''}
              ${rejectedCount>0?`<span style="display:inline-flex;align-items:center;gap:3px;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;background:var(--red2)12;color:var(--red2);border:1px solid var(--red2)25">
                <i class="fas fa-times-circle" style="font-size:9px"></i>${rejectedCount} رفض
              </span>`:''}
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:5px">
              ${proctData.map(p => {
                const pstColor = p._pst==='accepted'?'var(--green2)':p._pst==='rejected'?'var(--red2)':'var(--gold2)';
                const pstIcon  = p._pst==='accepted'?'fa-check-circle':p._pst==='rejected'?'fa-times-circle':'fa-hourglass';
                const dept = STATE.departments.find(d=>d.id===p.dept_id);
                return `<div style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px 4px 7px;
                  background:${pstColor}10;border:1.5px solid ${pstColor}30;border-radius:20px;
                  font-size:11px;font-weight:700;color:${pstColor}">
                  <i class="fas ${pstIcon}" style="font-size:9.5px"></i>
                  <span style="color:var(--txt)">${esc(p.name?.split(' ').slice(0,2).join(' '))}</span>
                  ${dept?`<span style="font-size:9.5px;opacity:.6">· ${esc(dept.name?.substring(0,10))}</span>`:''}
                </div>`;
              }).join('')}
            </div>
          </div>`:''}

          ${sections.length?`<div style="margin-top:5px;font-size:11px;color:var(--txt3)">
            <i class="fas fa-layer-group" style="margin-left:4px"></i>${sections.join('، ')}
          </div>`:''}
        </div>

        <!-- الأزرار -->
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end;flex-shrink:0">
          ${status==='active'?`
            <button class="btn btn-sm" style="background:linear-gradient(135deg,var(--green),#059669);color:white;border:none;font-weight:700;gap:6px" onclick="openCountdown(${e.id})">
              <i class="fas fa-tv"></i> فتح الشاشة
            </button>
          `:''}
          <div style="display:flex;gap:5px;flex-wrap:wrap">
            ${canFullEdit?`<button class="btn bo btn-xs" onclick="openEditExam(${e.id})" title="تعديل"><i class="fas fa-edit"></i></button>`:''}
            ${isLocked && (isAdmin()||isCoord())?`
              <button class="btn btn-xs" style="background:var(--gold)20;color:var(--gold);border:1px solid var(--gold)40" onclick="_addTimeFromCard(${e.id})" title="وقت إضافي"><i class="fas fa-plus"></i> وقت</button>
            `:''}
            <button class="btn bo btn-xs" onclick="exportExamPDF(${e.id})" title="تصدير PDF"><i class="fas fa-file-pdf" style="color:var(--red2)"></i></button>
            ${status==='completed'?`<button class="btn btn-xs" style="background:var(--purple-bg);color:var(--purple);border:1px solid var(--purple)30" onclick="UI.showPage('digital-seal')" title="ختم رقمي"><i class="fas fa-stamp"></i></button>`:''}
            ${canEdit()&&(isAdmin()||isCoord())&&status==='active'?`<button class="btn btn-xs" style="background:var(--gold)15;color:var(--gold);border:1px solid var(--gold)40" onclick="openCountdown(${e.id});setTimeout(()=>_openMonNotifPanel(${e.id}),500)" title="إرسال إشعار للشاشة"><i class="fas fa-bell"></i></button>`:''}
            ${canEdit()&&isAdmin()&&!isLocked?`<button class="btn bd btn-xs" onclick="deleteExam(${e.id})" title="حذف"><i class="fas fa-trash"></i></button>`:''}
          </div>
            <button class="btn bo btn-xs" onclick="openExamQR(${e.id})" title="QR Code"><i class="fas fa-qrcode" style="color:var(--teal)"></i></button>
          </div>
          ${(status==='active'||status==='upcoming')&&(e.proctor_ids||[]).includes(STATE.currentUser?.id)?`
            <button class="btn btn-xs" style="background:var(--teal);color:white;border-color:var(--teal)" onclick="openAttendance(${e.id})">
              <i class="fas fa-clipboard-check"></i> حضور
            </button>
          `:''}
        </div>
      </div>

      ${timerHtml}

      ${e.notes?`<div style="margin-top:10px;padding:8px 12px;background:var(--bg);border-radius:8px;font-size:12px;color:var(--txt2);border-right:3px solid var(--border2)"><i class="fas fa-sticky-note" style="margin-left:5px;color:var(--txt3)"></i>${e.notes}</div>`:''}

      ${isProctor()&&(e.proctor_ids||[]).includes(STATE.currentUser?.id)?_buildProctorRoomPanel(e):''}
    </div>
  </div>`;
}

// لوحة المراقب: يرى قاعته — يُظهر الطلاب فقط إذا كان المراقب مرتبطاً بمادة الامتحان عبر staff_ids
function _buildProctorRoomPanel(e) {
  const uid = STATE.currentUser?.id;
  const rp  = e.room_proctors || {};
  const rs  = e.room_sections || {};

  // إيجاد القاعات المرتبطة بهذا المراقب
  const myRooms = (e.room_ids||[]).filter(rid => {
    const assigned = rp[String(rid)];
    if (!assigned || !assigned.length) return (e.proctor_ids||[]).includes(uid);
    return assigned.includes(uid);
  });

  if (!myRooms.length) return '';

  // فحص ارتباط المراقب بمادة الامتحان عبر staff_ids
  const mySubjectIds = new Set(getProctorScopeSubjects().map(s => s.id));
  const isLinkedToSubject = mySubjectIds.has(e.subject_id);

  const panels = myRooms.map(rid => {
    const room = getRoom(rid);
    if (!room) return '';

    // الشعب المرتبطة بهذه القاعة
    const secIds = rs[String(rid)] || (e.section_ids||[]);
    const sections = secIds.map(sid => getSection(sid)).filter(Boolean);

    // الحضور
    const atts = STATE.attendance[e.id] || {};

    // إذا لم يكن مرتبطاً بالمادة → يرى القاعة فقط دون قائمة الطلاب
    if (!isLinkedToSubject) {
      return `<div style="border:1.5px solid var(--teal)30;border-radius:12px;background:var(--teal)05;padding:14px;margin-bottom:10px">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:36px;height:36px;border-radius:10px;background:var(--teal)15;display:flex;align-items:center;justify-content:center">
            <i class="fas fa-door-open" style="color:var(--teal);font-size:16px"></i>
          </div>
          <div>
            <div style="font-weight:800;font-size:14px">${esc(room.name)}</div>
            <div style="font-size:11px;color:var(--txt3)">${sections.map(s=>esc(s.name)).join('، ')}</div>
          </div>
        </div>
        <div style="padding:8px 10px;background:var(--gold)10;border-radius:8px;border:1px solid var(--gold)25;font-size:11.5px;color:var(--gold)">
          <i class="fas fa-shield-alt" style="margin-left:5px"></i>مراقب في هذه القاعة — لا تُعرض بيانات الطلاب لأن المادة غير مرتبطة بحسابك مباشرة
        </div>
      </div>`;
    }

    // المراقب مرتبط بالمادة → يرى طلاب شُعبه فقط
    const linkedSections = sections.filter(sec => mySubjectIds.has(sec.subject_id));
    const students = [];
    linkedSections.forEach(sec => {
      (sec.student_ids||[]).forEach(stid => {
        const st = STATE.students.find(s => s.id === stid);
        if (st && !students.find(x => x.id === stid)) students.push(st);
      });
    });

    return `<div style="border:1.5px solid var(--teal)30;border-radius:12px;background:var(--teal)05;padding:14px;margin-bottom:10px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
        <div style="width:36px;height:36px;border-radius:10px;background:var(--teal)15;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-door-open" style="color:var(--teal);font-size:16px"></i>
        </div>
        <div><div style="font-weight:800;font-size:14px">${esc(room.name)}</div>
          <div style="font-size:11px;color:var(--txt3)">${students.length} طالب في شُعبي · ${linkedSections.map(s=>esc(s.name)).join('، ')}</div>
        </div>
      </div>
      ${students.length ? `
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:6px;max-height:200px;overflow-y:auto">
          ${students.map(st => {
            const att = atts[st.id];
            const attColor = att==='present'?'var(--green2)':att==='absent'?'var(--red2)':att==='late'?'var(--gold)':'var(--txt3)';
            const attIcon  = att==='present'?'fa-check-circle':att==='absent'?'fa-times-circle':att==='late'?'fa-clock':'fa-circle';
            return `<div style="display:flex;align-items:center;gap:6px;padding:7px 10px;background:var(--card);border-radius:8px;border:1px solid var(--border);cursor:pointer"
              onclick="_openStudentHistory(${st.id},'${esc(st.name?.replace(/'/g,''))||''}')">
              <i class="fas ${attIcon}" style="color:${attColor};font-size:12px;flex-shrink:0"></i>
              <div style="min-width:0">
                <div style="font-size:11.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(st.name?.split(' ').slice(0,2).join(' ')||'—')}</div>
                <div style="font-size:10px;color:var(--txt3)">${esc(st.stud_id||'')}</div>
              </div>
            </div>`;
          }).join('')}
        </div>
      ` : `<div style="font-size:12px;color:var(--txt3);text-align:center;padding:10px">لا يوجد طلاب في شُعبك بهذه القاعة</div>`}
    </div>`;
  }).join('');

  if (!panels) return '';

  return `<div style="margin-top:14px">
    <div style="font-size:11.5px;font-weight:800;color:var(--teal);margin-bottom:8px">
      <i class="fas fa-chalkboard-teacher" style="margin-left:5px"></i>قاعتي في هذا الامتحان
    </div>
    ${panels}
  </div>`;
}

// ── عداد على البطاقة ─────────────────────────────────────────
const _cardTimerIntervals = {};
function _startCardTimer(e) {
  if (_cardTimerIntervals[e.id]) clearInterval(_cardTimerIntervals[e.id]);
  const status = examStatus(e);

  _cardTimerIntervals[e.id] = setInterval(() => {
    const timerEl = document.getElementById(`card-timer-${e.id}`);
    const pbarEl  = document.getElementById(`card-pbar-${e.id}`);
    if (!timerEl) { clearInterval(_cardTimerIntervals[e.id]); return; }

    const start = new Date(`${e.date}T${e.time}`);
    const end   = new Date(start.getTime() + (e.duration+(e.extra_time||0))*60000);
    const now   = new Date();
    const st    = examStatus(e);

    if (st === 'active') {
      const remMs  = Math.max(0, end - now);
      const remMin = Math.floor(remMs/60000);
      const remSec = Math.floor((remMs%60000)/1000);
      const pct    = Math.min(100,Math.round((1-remMs/((e.duration+(e.extra_time||0))*60000))*100));
      timerEl.textContent = `${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}`;
      timerEl.style.color = remMin<5?'#f87171':remMin<15?'#fbbf24':'#34d399';
      if (pbarEl) {
        pbarEl.style.width = pct+'%';
        pbarEl.style.background = pct>80?'#ef4444':pct>50?'#fbbf24':'#34d399';
      }
      if (remMs <= 0) { clearInterval(_cardTimerIntervals[e.id]); renderExams(); }
    } else if (st === 'upcoming') {
      const diffMs  = Math.max(0, start - now);
      const diffH   = Math.floor(diffMs/3600000);
      const diffMin = Math.floor((diffMs%3600000)/60000);
      timerEl.textContent = `${diffH?diffH+'س ':''} ${diffMin} دق`;
      if (diffMs <= 0) { clearInterval(_cardTimerIntervals[e.id]); renderExams(); }
    }
  }, 1000);
}

function _timeEnd(startTime, totalMins) {
  if (!startTime) return '';
  const [h,m] = startTime.split(':').map(Number);
  const total = h*60+m+totalMins;
  const hh = Math.floor(total/60)%24;
  const mm = total%60;
  const ap = hh<12?'ص':'م';
  return `${hh%12||12}:${String(mm).padStart(2,'0')} ${ap}`;
}

function _addTimeFromCard(examId) {
  const moId = 'addTimeCardMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo=document.createElement('div');mo.className='mo';mo.id=moId;document.body.appendChild(mo); }
  mo.innerHTML = `<div class="md" style="max-width:320px;text-align:center">
    <div class="md-hd"><h2><i class="fas fa-plus-circle" style="color:var(--gold)"></i> إضافة وقت</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button></div>
    <div class="md-bd">
      <p style="font-size:13px;color:var(--txt2);margin-bottom:16px">أضف وقتاً إضافياً للامتحان الجاري</p>
      <div style="display:flex;gap:8px;justify-content:center;margin-bottom:16px;flex-wrap:wrap">
        ${[5,10,15,20,30].map(m=>`<button class="btn bo" onclick="document.getElementById('addTimeCardVal').value=${m}" style="min-width:50px">${m}</button>`).join('')}
      </div>
      <input type="number" id="addTimeCardVal" value="10" min="1" max="120"
        style="width:100%;padding:12px;text-align:center;font-size:24px;font-weight:900;border:1.5px solid var(--border);border-radius:10px">
      <div style="font-size:12px;color:var(--txt3);margin-top:6px">دقائق</div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" style="background:var(--gold);border-color:var(--gold)" onclick="_applyExtraTimeCard(${examId},'${moId}')">
        <i class="fas fa-plus"></i> تطبيق
      </button>
    </div>
  </div>`;
  requestAnimationFrame(()=>mo.classList.add('open'));
}

async function _applyExtraTimeCard(examId, moId) {
  const mins = parseInt(document.getElementById('addTimeCardVal')?.value||0);
  if (!mins || mins < 1) { toast('أدخل عدد دقائق صحيح','error'); return; }
  const e = getExam(examId);
  if (!e) return;
  try {
    const newExtra = (e.extra_time||0)+mins;
    await dbUpdate('exams', examId, {extra_time: newExtra});
    e.extra_time = newExtra;
    closeMo(moId);
    renderExams();
    toast(`✓ تمت إضافة ${mins} دقيقة للامتحان`,'success');
    await addLog('إضافة وقت إضافي','exam',getSubject(e.subject_id)?.name||'');
  } catch(err) { toast('خطأ: '+err.message,'error'); }
}

// ── إرسال إشعار للامتحان ─────────────────────────────────────
function openSendNotifToExam(examId) {
  const e = getExam(examId);
  if (!e) return;
  const mo = _getMo('sendNotifExamMo');
  const allCount = STATE.profiles.filter(p=>p.active).length;
  mo.innerHTML = `<div class="md" style="max-width:460px">
    <div class="md-hd">
      <h2><i class="fas fa-bell" style="color:var(--gold)"></i> إرسال إشعار</h2>
      <button class="md-close" onclick="closeMo('sendNotifExamMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="padding:10px 14px;background:var(--gold)10;border:1px solid var(--gold)30;border-radius:9px;margin-bottom:16px;font-size:12.5px">
        <i class="fas fa-file-alt" style="margin-left:6px;color:var(--gold)"></i>
        <b>${getSubject(e.subject_id)?.name||'—'}</b> · ${fmtDate(e.date)} ${fmtTime(e.time)}
      </div>
      <div class="field">
        <label class="field-lbl">نص الإشعار <span class="req">*</span></label>
        <input type="text" id="notifTitle" placeholder="مثال: تأجيل الامتحان 15 دقيقة" style="font-size:14px">
      </div>
      <div class="field">
        <label class="field-lbl">تفاصيل إضافية</label>
        <textarea id="notifBody" rows="3" placeholder="تفاصيل اختيارية..."></textarea>
      </div>
      <div style="padding:12px 14px;background:var(--primary-bg);border-radius:10px;border:1.5px solid var(--primary)20;display:flex;align-items:center;gap:10px">
        <i class="fas fa-users" style="color:var(--primary2);font-size:18px"></i>
        <div>
          <div style="font-weight:700;font-size:13px">سيُرسَل لجميع المستخدمين</div>
          <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">${allCount} مستخدم نشط في النظام</div>
        </div>
        <i class="fas fa-check-circle" style="color:var(--green);margin-right:auto;font-size:16px"></i>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('sendNotifExamMo')">إلغاء</button>
      <button class="btn bp" style="background:var(--gold);border-color:var(--gold)" onclick="doSendExamNotif(${examId})">
        <i class="fas fa-paper-plane"></i> إرسال للجميع
      </button>
    </div>
  </div>`;
  showMo('sendNotifExamMo');
}

async function doSendExamNotif(examId) {
  const title = document.getElementById('notifTitle')?.value?.trim();
  const body  = document.getElementById('notifBody')?.value?.trim();
  if (!title) { toast('اكتب نص الإشعار','error'); return; }

  // ✅ إغلاق النافذة فوراً
  closeMo('sendNotifExamMo');

  // ✅ إضافة إشعار لشاشة الامتحان فقط (لا يُرسَل للمستخدمين)
  if (!STATE.monitorNotifications) STATE.monitorNotifications = [];
  STATE.monitorNotifications.push({
    title, body: body||'', exam_id: examId, created_at: new Date().toISOString()
  });

  // ✅ تحديث قائمة الإشعارات في الشاشة إن كانت مفتوحة
  const npEl = document.getElementById('monNotifPanel');
  if (npEl) npEl.innerHTML = _buildMonNotifList();

  // ✅ عرض الإشعار بشكل فوري بملء الشاشة إن كانت مفتوحة
  if (document.getElementById('ctOv')?.classList.contains('open')) {
    if (typeof _showFullscreenAlert === 'function') _showFullscreenAlert(title, body);
  }

  toast('✓ تم إرسال الإشعار إلى الشاشة', 'success');
}

// ── فتح نافذة الإضافة ────────────────────────────────────────
// ── كشف تلقائي ليوم العطلة (الجمعة/السبت) ─────────────────────
function _isAutoHoliday(dateStr) {
  if (!dateStr) return false;
  const d = new Date(dateStr + 'T12:00:00');
  const day = d.getDay(); // 0=أحد ... 5=جمعة، 6=سبت
  return day === 5 || day === 6;
}

// حساب نقاط الامتحان بناءً على الإعدادات
// ✅ يعمل حتى لو لم تُحمَّل settings — يستخدم قيماً افتراضية معقولة
function _calcExamPoints(examData) {
  if (!examData) return 1;
  const time = examData.time || '09:00';
  // قبول كل من '08:30' و '08:30:00'
  const h = parseInt(String(time).split(':')[0]) || 9;

  // قيم افتراضية إذا لم تُحمَّل الإعدادات
  const s = STATE.settings || {};
  const ptsMorning   = parseFloat(s.pts_morning   ?? 1);    // قبل 14:00
  const ptsAfternoon = parseFloat(s.pts_afternoon ?? 1.5);  // 14-18
  const ptsEvening   = parseFloat(s.pts_evening   ?? 2);    // بعد 18
  const ptsHoliday   = parseFloat(s.pts_holiday   ?? 1);
  const ptsLong      = parseFloat(s.pts_long      ?? 0.5);
  const ptsFinal     = parseFloat(s.pts_final_bonus ?? 0.5);

  const isHoliday = examData.is_holiday ?? (typeof _isAutoHoliday==='function' ? _isAutoHoliday(examData.date) : false);
  const duration  = parseInt(examData.duration) || 0;

  let pts = h < 14 ? ptsMorning : h < 18 ? ptsAfternoon : ptsEvening;
  if (isHoliday)              pts += ptsHoliday;
  if (duration > 120)         pts += ptsLong;
  if (examData.type === 'final') pts += ptsFinal;

  // تقريب لرقم عشري واحد
  return Math.round(pts * 10) / 10;
}

// تحديث شارة النقاط وشارة العطلة في نموذج الامتحان
function _updateExamPointsPreview() {
  const date = document.getElementById('exDate')?.value;
  const time = document.getElementById('exTime')?.value || '09:00';
  const type = document.getElementById('exType')?.value || 'final';
  const isHol = _isAutoHoliday(date);

  // شارة العطلة
  const holBadge = document.getElementById('holidayDetectBadge');
  const holIcon  = document.getElementById('holidayIcon');
  const holLabel = document.getElementById('holidayLabel');
  if (holBadge && holIcon && holLabel) {
    if (isHol) {
      holBadge.style.borderColor = 'var(--red2)40';
      holBadge.style.background  = 'var(--red2)08';
      holIcon.style.color        = 'var(--red2)';
      holIcon.className          = 'fas fa-umbrella-beach';
      holLabel.textContent       = '⚠️ يوم عطلة (اكتُشف تلقائياً)';
      holLabel.style.color       = 'var(--red2)';
    } else {
      holBadge.style.borderColor = 'var(--border)';
      holBadge.style.background  = 'var(--bg)';
      holIcon.style.color        = 'var(--green2)';
      holIcon.className          = 'fas fa-calendar-check';
      holLabel.textContent       = 'يوم عمل عادي';
      holLabel.style.color       = 'var(--txt2)';
    }
  }

  // شارة النقاط
  const ptsEl = document.getElementById('examPointsVal');
  if (ptsEl) {
    const pts = _calcExamPoints({ date, time, type, is_holiday: isHol });
    ptsEl.textContent = pts + (pts === 1 ? ' نقطة' : ' نقاط');
  }
}

// تصفية الشعب عند تغيير المادة
function _onExamSubjChange(subjId) {
  // 1) تحديث الشعب
  const container = document.getElementById('sectionsCheckContainer');
  if (container) {
    const semester = STATE.currentSem;
    if (!subjId) {
      container.innerHTML = '<div style="color:var(--txt3);font-size:12px;padding:8px">اختر المادة أولاً لتظهر شعبها</div>';
    } else {
      const filtered = STATE.sections.filter(s => s.semester === semester && s.subject_id == subjId);
      if (!filtered.length) {
        container.innerHTML = '<div style="color:var(--txt3);font-size:12px;padding:8px">لا توجد شعب مرتبطة بهذه المادة في الفصل الحالي</div>';
      } else {
        container.innerHTML = filtered.map(s => {
          const subj = getSubject(s.subject_id);
          return `<label class="exam-check-item" id="lbl-sec-${s.id}">
            <input type="checkbox" id="scb_${s.id}" onchange="_updateCheckLabel(this,'lbl-sec-${s.id}');_refreshRoomAssignment()">
            <i class="fas fa-layer-group" style="color:var(--gold);font-size:13px"></i>
            <span style="font-weight:600">${s.name}</span>
            <span style="color:var(--txt3);font-size:10.5px">${subj?.name||''}</span>
            <span class="badge b-blue" style="font-size:9px">${(s.student_ids||[]).length} طالب</span>
          </label>`;
        }).join('');
      }
    }
  }

  // 2) فلترة المراقبين بناء على قسم المادة
  const subj = STATE.subjects.find(s => s.id == subjId);
  const subjDeptId = subj?.dept_id || null;
  const procsContainer = document.getElementById('procsCheckContainer');
  if (procsContainer && subjDeptId) {
    // إعادة بناء قائمة المراقبين مع تمييز مراقبي نفس القسم
    const editId = STATE._editExamId;
    const exam = editId ? getExam(editId) : null;
    const _allProctors = STATE.profiles.filter(u => u.role === 'proctor' && u.active)
      .sort((a, b) => {
        // مراقبو نفس القسم أولاً
        const aInDept = a.dept_id == subjDeptId ? 0 : 1;
        const bInDept = b.dept_id == subjDeptId ? 0 : 1;
        if (aInDept !== bInDept) return aInDept - bInDept;
        return semCount(a.id) - semCount(b.id);
      });

    const deptName = STATE.departments.find(d => d.id == subjDeptId)?.name || '';

    const _buildProcItem = p => {
      const sc = semCount(p.id);
      const overLimit = sc >= 3;
      const checked = exam && (exam.proctor_ids||[]).includes(p.id) ? 'checked' : '';
      const pDeptName = p.dept_id ? (STATE.departments.find(d=>d.id===p.dept_id)?.name||'') : '';
      const inSubjDept = p.dept_id == subjDeptId;
      return `<label class="exam-check-item${overLimit?' limit-warn':''}${inSubjDept?' same-dept-proctor':''}" id="lbl-proc-${p.id}"
        style="${overLimit?'opacity:.55':''}${inSubjDept?';border-color:var(--primary2)40;background:var(--primary)04':''}" title="${pDeptName}">
        <input type="checkbox" id="pcb_${p.id}" ${checked} ${overLimit&&!checked?'disabled':''} onchange="_updateCheckLabel(this,'lbl-proc-${p.id}');_refreshRoomAssignment()">
        <i class="fas fa-user-tie" style="color:${inSubjDept?'var(--primary2)':'var(--purple2)'};font-size:12px"></i>
        <span style="font-weight:600;font-size:12.5px">${p.name?.split(' ').slice(0,2).join(' ')}</span>
        ${inSubjDept?`<span class="badge b-blue" style="font-size:8px">نفس القسم</span>`:''}
        <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9px">${sc}/3</span>
      </label>`;
    };

    const sameDeptProctors = _allProctors.filter(p => p.dept_id == subjDeptId);
    const otherProctors    = _allProctors.filter(p => p.dept_id != subjDeptId);

    let html = '';
    if (sameDeptProctors.length) {
      html += `<div style="margin-bottom:10px">
        <div style="font-size:10.5px;font-weight:800;color:var(--primary2);padding:5px 10px;background:var(--primary)08;border-radius:7px;margin-bottom:6px;display:flex;align-items:center;gap:6px;border:1px solid var(--primary2)20">
          <i class="fas fa-star" style="font-size:10px"></i> مراقبو قسم المادة: ${esc(deptName)} (${sameDeptProctors.length})
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;padding-right:8px">${sameDeptProctors.map(_buildProcItem).join('')}</div>
      </div>`;
    }
    if (otherProctors.length) {
      const deptGroups = {};
      otherProctors.forEach(p => {
        const key = p.dept_id ? String(p.dept_id) : '__none__';
        if (!deptGroups[key]) deptGroups[key] = [];
        deptGroups[key].push(p);
      });
      html += `<div style="margin-bottom:6px">
        <div style="font-size:10.5px;font-weight:800;color:var(--txt3);padding:4px 10px;background:var(--bg);border-radius:7px;margin-bottom:6px">
          <i class="fas fa-users" style="margin-left:4px"></i> أقسام أخرى (${otherProctors.length})
        </div>`;
      STATE.departments.filter(d => d.id != subjDeptId).forEach(dept => {
        const group = deptGroups[String(dept.id)];
        if (!group?.length) return;
        html += `<div style="margin-bottom:8px">
          <div style="font-size:10px;color:var(--txt3);padding:3px 8px;margin-bottom:4px;display:flex;align-items:center;gap:5px">
            <span style="width:7px;height:7px;border-radius:50%;background:${dept.color||'var(--primary2)'};display:inline-block"></span>
            ${dept.name} (${group.length})
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;padding-right:8px">${group.map(_buildProcItem).join('')}</div>
        </div>`;
      });
      const noDept = deptGroups['__none__'];
      if (noDept?.length) html += `<div style="display:flex;flex-wrap:wrap;gap:6px;padding-right:8px">${noDept.map(_buildProcItem).join('')}</div>`;
      html += '</div>';
    }
    if (!_allProctors.length) html = '<div style="color:var(--txt3);font-size:12px;padding:8px">لا يوجد مراقبون</div>';
    procsContainer.innerHTML = html;

    // تحديث مؤشر الفلترة
    const filterHint = document.getElementById('proctorFilterHint');
    if (filterHint) {
      filterHint.innerHTML = deptName
        ? `<span style="font-size:10.5px;color:var(--primary2)"><i class="fas fa-filter"></i> يظهر مراقبو قسم "<b>${esc(deptName)}</b>" أولاً</span>`
        : '';
    }
  }

  _updateExamPointsPreview();
  _refreshRoomAssignment();
}


// ═══════════════════════════════════════════════════════════════
//  نظام Tag Picker الاحترافي لربط القاعات بالمراقبين والشعب
// ═══════════════════════════════════════════════════════════════

if (!window._examRoomState) window._examRoomState = {};

function _initRoomState(room, existingRP, existingRS, globalProcs) {
  if (window._examRoomState[room.id] !== undefined) return;
  const saved = existingRP[String(room.id)] || [];
  window._examRoomState[room.id] = {
    proctors: saved.length ? [...saved] : [...globalProcs.map(p => p.id)],
    sections: [...(existingRS[String(room.id)] || [])]
  };
}

function _refreshRoomAssignment() {
  const container = document.getElementById('roomAssignContainer');
  if (!container) return;
  const selectedRooms = STATE.rooms.filter(r => document.getElementById(`rcb_${r.id}`)?.checked);
  if (!selectedRooms.length) {
    window._examRoomState = {};
    container.innerHTML = `<div style="color:var(--txt3);font-size:12.5px;padding:16px;text-align:center;display:flex;align-items:center;justify-content:center;gap:8px">
      <i class="fas fa-arrow-up" style="opacity:.4"></i>اختر قاعة أو أكثر لتخصيص المراقبين والشعب لكل قاعة
    </div>`;
    return;
  }
  const globalProcs = STATE.profiles.filter(p =>
    p.role === 'proctor' && p.active && document.getElementById(`pcb_${p.id}`)?.checked
  );
  const examId = STATE._editExamId;
  const exam = examId ? getExam(examId) : null;
  const existingRP = exam?.room_proctors || {};
  const existingRS = exam?.room_sections || {};
  selectedRooms.forEach(r => _initRoomState(r, existingRP, existingRS, globalProcs));
  Object.keys(window._examRoomState).forEach(rid => {
    if (!selectedRooms.find(r => String(r.id) === String(rid))) delete window._examRoomState[rid];
  });
  container.innerHTML = selectedRooms.map(room => _buildRoomPickerBlock(room)).join('');
}

function _buildRoomPickerBlock(room) {
  const info = typeof getRoomTypeInfo === 'function' ? getRoomTypeInfo(room.type) : {icon:'fa-door-open',color:'var(--teal)'};
  const st = window._examRoomState[room.id] || {proctors:[], sections:[]};
  const allProctors = STATE.profiles.filter(p => p.role === 'proctor' && p.active);
  const currentSubjId = document.getElementById('exSubj')?.value;
  const allSections = STATE.sections.filter(s =>
    s.semester === STATE.currentSem && (!currentSubjId || s.subject_id == currentSubjId)
  );
  const selProctors = st.proctors.map(id => allProctors.find(p => p.id === id)).filter(Boolean);
  const selSections = st.sections.map(id => allSections.find(s => s.id === id)).filter(Boolean);
  const availProctors = allProctors.filter(p => !st.proctors.includes(p.id));
  const availSections = allSections.filter(s => !st.sections.includes(s.id));
  const totalStudents = selSections.reduce((a, s) => a + (s.student_ids||[]).length, 0);

  const procChips = selProctors.map(p => {
    const sc = semCount(p.id);
    const col = sc >= 3 ? 'var(--red2)' : sc >= 2 ? 'var(--gold)' : 'var(--purple2)';
    return `<span style="display:inline-flex;align-items:center;gap:5px;padding:5px 10px 5px 7px;
        background:${col}12;border:1.5px solid ${col}35;border-radius:20px;font-size:12px;font-weight:700;color:${col};white-space:nowrap">
      <i class="fas fa-user-tie" style="font-size:10px;opacity:.8"></i>
      ${esc(p.name?.split(' ').slice(0,2).join(' '))}
      <span style="font-size:9.5px;opacity:.6">(${sc}/3)</span>
      <button onclick="event.stopPropagation();_removeRoomProctor(${room.id},'${p.id}')"
        style="border:none;background:${col}25;color:${col};cursor:pointer;font-size:9px;
        width:16px;height:16px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;
        transition:background .15s" onmouseover="this.style.background='${col}50'" onmouseout="this.style.background='${col}25'">
        <i class="fas fa-times"></i>
      </button>
    </span>`;
  }).join('');

  const secChips = selSections.map(s => {
    const cnt = (s.student_ids||[]).length;
    return `<span style="display:inline-flex;align-items:center;gap:5px;padding:5px 10px 5px 7px;
        background:var(--gold)12;border:1.5px solid var(--gold)35;border-radius:20px;font-size:12px;font-weight:700;color:var(--gold);white-space:nowrap">
      <i class="fas fa-layer-group" style="font-size:10px;opacity:.8"></i>
      ${esc(s.name)}
      <span style="font-size:9.5px;opacity:.6">(${cnt}ط)</span>
      <button onclick="event.stopPropagation();_removeRoomSection(${room.id},${s.id})"
        style="border:none;background:var(--gold)25;color:var(--gold);cursor:pointer;font-size:9px;
        width:16px;height:16px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;
        transition:background .15s" onmouseover="this.style.background='var(--gold)55'" onmouseout="this.style.background='var(--gold)25'">
        <i class="fas fa-times"></i>
      </button>
    </span>`;
  }).join('');

  const procDropHTML = availProctors.length
    ? `<div style="padding:6px 12px;font-size:10px;font-weight:800;color:var(--txt3);background:var(--bg);border-bottom:1px solid var(--border);letter-spacing:.5px">اضغط على المراقب للإضافة ↓</div>` +
      availProctors.map(p => {
        const sc = semCount(p.id);
        return `<div onclick="event.stopPropagation();_addRoomProctor(${room.id},'${p.id}')"
          style="display:flex;align-items:center;gap:9px;padding:9px 14px;cursor:pointer;transition:background .12s;border-bottom:1px solid var(--border)"
          onmouseover="this.style.background='var(--purple2)08'" onmouseout="this.style.background=''">
          <div style="width:32px;height:32px;border-radius:9px;background:var(--purple2)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-user-tie" style="color:var(--purple2);font-size:13px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:12.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(p.name?.split(' ').slice(0,3).join(' '))}</div>
            <div style="font-size:10px;color:var(--txt3)">${p.emp_id||''}</div>
          </div>
          <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9px">${sc}/3</span>
          <i class="fas fa-plus-circle" style="color:var(--purple2);font-size:14px;flex-shrink:0"></i>
        </div>`;
      }).join('')
    : `<div style="padding:16px;text-align:center;color:var(--txt3);font-size:12px">
        <i class="fas fa-check-circle" style="color:var(--green2);margin-left:5px"></i>تم اختيار جميع المراقبين
      </div>`;

  const secDropHTML = availSections.length
    ? `<div style="padding:6px 12px;font-size:10px;font-weight:800;color:var(--txt3);background:var(--bg);border-bottom:1px solid var(--border);letter-spacing:.5px">اضغط على الشعبة للإضافة ↓</div>` +
      availSections.map(s => {
        const cnt = (s.student_ids||[]).length;
        return `<div onclick="event.stopPropagation();_addRoomSection(${room.id},${s.id})"
          style="display:flex;align-items:center;gap:9px;padding:9px 14px;cursor:pointer;transition:background .12s;border-bottom:1px solid var(--border)"
          onmouseover="this.style.background='var(--gold)08'" onmouseout="this.style.background=''">
          <div style="width:32px;height:32px;border-radius:9px;background:var(--gold)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-layer-group" style="color:var(--gold);font-size:13px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:12.5px;font-weight:700">${esc(s.name)}</div>
            <div style="font-size:10px;color:var(--txt3)">${cnt} طالب</div>
          </div>
          <i class="fas fa-plus-circle" style="color:var(--gold);font-size:14px;flex-shrink:0"></i>
        </div>`;
      }).join('')
    : `<div style="padding:16px;text-align:center;color:var(--txt3);font-size:12px">
        ${currentSubjId?'تم اختيار جميع الشعب المتاحة':'اختر المادة الدراسية أولاً'}
      </div>`;

  return `<div id="ra-${room.id}" style="border:1.5px solid var(--border);border-radius:14px;background:var(--card);margin-bottom:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05)">
    <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:${info.color}08;border-bottom:1.5px solid ${info.color}20">
      <div style="width:40px;height:40px;border-radius:11px;background:${info.color}20;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas ${info.icon}" style="color:${info.color};font-size:17px"></i>
      </div>
      <div style="flex:1">
        <div style="font-weight:900;font-size:14px">${esc(room.name)}</div>
        <div style="font-size:11px;color:var(--txt3);display:flex;gap:10px;flex-wrap:wrap;margin-top:2px">
          <span>سعة ${room.cap}</span>
          ${selProctors.length?`<span style="color:var(--purple2)">${selProctors.length} مراقب</span>`:''}
          ${selSections.length?`<span style="color:var(--gold)">${selSections.length} شعبة · ${totalStudents} طالب</span>`:''}
        </div>
      </div>
    </div>
    <div style="padding:14px 16px">
      <div style="margin-bottom:16px">
        <div style="font-size:11px;font-weight:800;color:var(--purple2);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
          <span><i class="fas fa-user-tie" style="margin-left:5px;opacity:.8"></i>المراقبون</span>
          <span style="font-size:10px;color:var(--txt3);font-weight:500">${selProctors.length} / ${allProctors.length}</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;min-height:30px;margin-bottom:8px">
          ${procChips || `<span style="font-size:12px;color:var(--txt3);opacity:.6;padding:3px 0">لم يُختر مراقب بعد</span>`}
        </div>
        <div style="position:relative">
          <button onclick="event.stopPropagation();_togglePicker('proc-dd-${room.id}')"
            style="display:flex;align-items:center;justify-content:center;gap:7px;padding:7px 14px;width:100%;
            border:1.5px dashed var(--purple2)50;border-radius:9px;background:transparent;
            color:var(--purple2);font-size:12.5px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit"
            onmouseover="this.style.background='var(--purple2)08';this.style.borderStyle='solid'"
            onmouseout="this.style.background='transparent';this.style.borderStyle='dashed'">
            <i class="fas fa-plus-circle"></i> إضافة مراقب
            ${availProctors.length?`<span class="badge" style="background:var(--purple2);color:white;font-size:9.5px">${availProctors.length}</span>`:''}
          </button>
          <div id="proc-dd-${room.id}" style="display:none;position:absolute;top:calc(100% + 5px);right:0;left:0;z-index:200;
            background:var(--card);border:1.5px solid var(--border);border-radius:11px;
            box-shadow:0 12px 32px rgba(0,0,0,.15);max-height:240px;overflow-y:auto">
            ${procDropHTML}
          </div>
        </div>
      </div>
      <div>
        <div style="font-size:11px;font-weight:800;color:var(--gold);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
          <span><i class="fas fa-layer-group" style="margin-left:5px;opacity:.8"></i>الشعب</span>
          <span style="font-size:10px;color:var(--txt3);font-weight:500">${selSections.length} شعبة · ${totalStudents} طالب</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;min-height:30px;margin-bottom:8px">
          ${secChips || `<span style="font-size:12px;color:var(--txt3);opacity:.6;padding:3px 0">لم تُختر شعبة بعد</span>`}
        </div>
        <div style="position:relative">
          <button onclick="event.stopPropagation();_togglePicker('sec-dd-${room.id}')"
            style="display:flex;align-items:center;justify-content:center;gap:7px;padding:7px 14px;width:100%;
            border:1.5px dashed var(--gold)60;border-radius:9px;background:transparent;
            color:var(--gold);font-size:12.5px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit"
            onmouseover="this.style.background='var(--gold)10';this.style.borderStyle='solid'"
            onmouseout="this.style.background='transparent';this.style.borderStyle='dashed'">
            <i class="fas fa-plus-circle"></i> إضافة شعبة
            ${availSections.length?`<span class="badge" style="background:var(--gold);color:white;font-size:9.5px">${availSections.length}</span>`:''}
          </button>
          <div id="sec-dd-${room.id}" style="display:none;position:absolute;top:calc(100% + 5px);right:0;left:0;z-index:200;
            background:var(--card);border:1.5px solid var(--border);border-radius:11px;
            box-shadow:0 12px 32px rgba(0,0,0,.15);max-height:240px;overflow-y:auto">
            ${secDropHTML}
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function _togglePicker(ddId) {
  document.querySelectorAll('[id^="proc-dd-"],[id^="sec-dd-"]').forEach(el => {
    if (el.id !== ddId) el.style.display = 'none';
  });
  const dd = document.getElementById(ddId);
  if (!dd) return;
  const willOpen = dd.style.display === 'none' || !dd.style.display;
  dd.style.display = willOpen ? 'block' : 'none';
  if (willOpen) {
    const handler = e => {
      const wrap = dd.parentElement;
      if (wrap && !wrap.contains(e.target)) {
        dd.style.display = 'none';
        document.removeEventListener('click', handler);
      }
    };
    setTimeout(() => document.addEventListener('click', handler), 0);
  }
}

function _addRoomProctor(roomId, procId) {
  if (!window._examRoomState[roomId]) window._examRoomState[roomId] = {proctors:[], sections:[]};
  const st = window._examRoomState[roomId];
  if (!st.proctors.includes(procId)) st.proctors.push(procId);
  _rerenderRoomBlock(roomId);
}

function _removeRoomProctor(roomId, procId) {
  if (!window._examRoomState[roomId]) return;
  window._examRoomState[roomId].proctors = window._examRoomState[roomId].proctors.filter(id => id !== procId);
  _rerenderRoomBlock(roomId);
}

function _addRoomSection(roomId, secId) {
  const dupRid = Object.keys(window._examRoomState).find(rid =>
    String(rid) !== String(roomId) && (window._examRoomState[rid]?.sections||[]).includes(secId)
  );
  if (dupRid) {
    const dupRoom = STATE.rooms.find(r => String(r.id) === String(dupRid));
    toast(`⚠️ هذه الشعبة موجودة بالفعل في قاعة: "${dupRoom?.name||'أخرى'}" — لا يمكن تكرارها`, 'warning', 4000);
    return;
  }
  if (!window._examRoomState[roomId]) window._examRoomState[roomId] = {proctors:[], sections:[]};
  const st = window._examRoomState[roomId];
  if (!st.sections.includes(secId)) st.sections.push(secId);
  _rerenderRoomBlock(roomId);
}

function _removeRoomSection(roomId, secId) {
  if (!window._examRoomState[roomId]) return;
  window._examRoomState[roomId].sections = window._examRoomState[roomId].sections.filter(id => id !== secId);
  _rerenderRoomBlock(roomId);
}

function _rerenderRoomBlock(roomId) {
  const room = STATE.rooms.find(r => String(r.id) === String(roomId));
  if (!room) return;
  const block = document.getElementById(`ra-${roomId}`);
  if (!block) return;
  const tmp = document.createElement('div');
  tmp.innerHTML = _buildRoomPickerBlock(room);
  block.replaceWith(tmp.firstElementChild);
}

// openAddExam و openEditExam مُعرَّفتان في exam-wizard.js

// تحقق من الوقت — ينبّه إذا كان الوقت في الماضي لليوم نفسه
function _validateExamTimeDate() {
  const dateEl = document.getElementById('exDate');
  const timeEl = document.getElementById('exTime');
  if (!dateEl || !timeEl) return;
  const today   = new Date().toISOString().split('T')[0];
  const nowTime = new Date().toTimeString().slice(0,5);
  if (dateEl.value === today && timeEl.value && timeEl.value < nowTime) {
    timeEl.style.borderColor = 'var(--gold)';
    timeEl.title = '⚠️ الوقت المختار في الماضي';
  } else {
    timeEl.style.borderColor = '';
    timeEl.title = '';
  }
}

// ── التحقق من التعارضات ──────────────────────────────────────
function _checkConflicts(data, editId) {
  const newStart = new Date(`${data.date}T${data.time}`);
  const newEnd   = new Date(newStart.getTime() + (data.duration+(data.extra_time||0))*60000);
  const errors   = [];

  STATE.exams
    .filter(e => e.id !== editId && e.date === data.date)
    .forEach(e => {
      const eStart = new Date(`${e.date}T${e.time}`);
      const eEnd   = new Date(eStart.getTime() + (e.duration+(e.extra_time||0))*60000);
      const overlaps = newStart < eEnd && newEnd > eStart;
      if (!overlaps) return;

      const sub = getSubject(e.subject_id);

      // تعارض القاعات
      (data.room_ids||[]).forEach(rid => {
        if ((e.room_ids||[]).includes(rid)) {
          errors.push(`⚠️ تعارض قاعة: "${getRoom(rid)?.name}" محجوزة لـ "${sub?.name}" ${fmtTime(e.time)} — ${fmtTime(e.time)}`);
        }
      });

      // تعارض المراقبين
      (data.proctor_ids||[]).forEach(pid => {
        if ((e.proctor_ids||[]).includes(pid)) {
          errors.push(`⚠️ تعارض مراقب: "${getProfile(pid)?.name?.split(' ').slice(0,2).join(' ')}" مكلّف بـ "${sub?.name}" في نفس الوقت`);
        }
      });
    });

  // الحد الأقصى للمراقبة
  (data.proctor_ids||[]).forEach(pid => {
    const count = STATE.exams
      .filter(e => e.id !== editId && e.semester === data.semester && (e.proctor_ids||[]).includes(pid))
      .length;
    if (count >= 3) {
      errors.push(`⚠️ تجاوز الحد: "${getProfile(pid)?.name?.split(' ').slice(0,2).join(' ')}" راقب ${count} مرة هذا الفصل (الحد 3)`);
    }
  });

  return errors;
}

// ── اقتراح القاعات والمراقبين ────────────────────────────────
function _suggestRooms(date, time, duration, extra, excludeId) {
  if (!date || !time) return [];
  const start = new Date(`${date}T${time}`);
  const end   = new Date(start.getTime() + (duration+(extra||0))*60000);

  return STATE.rooms.filter(r => {
    return !STATE.exams.some(e => {
      if (e.id === excludeId) return false;
      if (e.date !== date) return false;
      if (!(e.room_ids||[]).includes(r.id)) return false;
      const eS = new Date(`${e.date}T${e.time}`);
      const eE = new Date(eS.getTime()+(e.duration+(e.extra_time||0))*60000);
      return start < eE && end > eS;
    });
  });
}

function _suggestProctors(date, time, duration, extra, excludeId, semester) {
  if (!date || !time) return [];
  const start = new Date(`${date}T${time}`);
  const end   = new Date(start.getTime() + (duration+(extra||0))*60000);

  return STATE.profiles.filter(p => p.role==='proctor' && p.active).map(p => {
    const semCount_ = STATE.exams
      .filter(e=>e.id!==excludeId && e.semester===semester && (e.proctor_ids||[]).includes(p.id))
      .length;
    const busy = STATE.exams.some(e => {
      if (e.id===excludeId) return false;
      if (e.date!==date) return false;
      if (!(e.proctor_ids||[]).includes(p.id)) return false;
      const eS = new Date(`${e.date}T${e.time}`);
      const eE = new Date(eS.getTime()+(e.duration+(e.extra_time||0))*60000);
      return start < eE && end > eS;
    });
    return { ...p, _semCount: semCount_, _busy: busy, _overLimit: semCount_ >= 3 };
  }).sort((a,b) => a._semCount - b._semCount);
}

// ── بناء مودال الإضافة/التعديل ───────────────────────────────
function _buildExamModal(exam) {
  let mo = document.getElementById('addExamMo');
  if (!mo) { mo=document.createElement('div');mo.className='mo';mo.id='addExamMo';document.body.appendChild(mo); }

  const isEdit   = !!exam;
  const today    = new Date().toISOString().split('T')[0];
  const nowTime  = new Date().toTimeString().slice(0,5);
  const semester = STATE.currentSem;

  const roomsHTML = STATE.rooms.map(r => {
    const info = typeof getRoomTypeInfo==='function'?getRoomTypeInfo(r.type):{icon:'fa-door-open',color:'var(--teal)'};
    const checked = isEdit && (exam.room_ids||[]).includes(r.id) ? 'checked' : '';
    return `<label class="exam-check-item" id="lbl-room-${r.id}">
      <input type="checkbox" id="rcb_${r.id}" ${checked} onchange="_updateCheckLabel(this,'lbl-room-${r.id}');_refreshRoomAssignment()">
      <i class="fas ${info.icon}" style="color:${info.color};font-size:13px"></i>
      <span style="font-weight:600">${r.name}</span>
      <span style="color:var(--txt3);font-size:10.5px">${r.cap}م</span>
    </label>`;
  }).join('') || '<div style="color:var(--txt3);font-size:12px;padding:8px">لم تُضاف قاعات بعد</div>';

  // --- بناء قائمة المراقبين مُجمَّعة حسب الأقسام ---
  const _allProctors = STATE.profiles
    .filter(u=>u.role==='proctor'&&u.active)
    .sort((a,b) => semCount(a.id) - semCount(b.id));

  const _buildProcItem = p => {
    const sc = semCount(p.id);
    const overLimit = sc >= 3;
    const checked = isEdit && (exam.proctor_ids||[]).includes(p.id) ? 'checked' : '';
    const deptName = p.dept_id ? (STATE.departments.find(d=>d.id===p.dept_id)?.name||'') : '';
    return `<label class="exam-check-item${overLimit?' limit-warn':''}" id="lbl-proc-${p.id}" style="${overLimit?'opacity:.55':''}" title="${deptName}">
      <input type="checkbox" id="pcb_${p.id}" ${checked} ${overLimit&&!checked?'disabled':''} onchange="_updateCheckLabel(this,'lbl-proc-${p.id}');_refreshRoomAssignment()">
      <i class="fas fa-user-tie" style="color:var(--purple2);font-size:12px"></i>
      <span style="font-weight:600;font-size:12.5px">${p.name?.split(' ').slice(0,2).join(' ')}</span>
      <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9px">${sc}/3</span>
    </label>`;
  };

  const _deptGroups = {};
  _allProctors.forEach(p => {
    const key = p.dept_id ? String(p.dept_id) : '__none__';
    if (!_deptGroups[key]) _deptGroups[key] = [];
    _deptGroups[key].push(p);
  });

  let procsHTML = '';
  if (!_allProctors.length) {
    procsHTML = '<div style="color:var(--txt3);font-size:12px;padding:8px">لا يوجد مراقبون</div>';
  } else {
    STATE.departments.forEach(dept => {
      const group = _deptGroups[String(dept.id)];
      if (!group?.length) return;
      procsHTML += `<div style="margin-bottom:10px">
        <div style="font-size:10.5px;font-weight:800;color:var(--txt3);padding:4px 10px;background:var(--bg);border-radius:7px;margin-bottom:6px;display:flex;align-items:center;gap:6px">
          <span style="width:8px;height:8px;border-radius:50%;background:${dept.color||'var(--primary2)'};display:inline-block;flex-shrink:0"></span>
          ${dept.name} <span style="opacity:.7;font-weight:400">(${group.length})</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;padding-right:8px">${group.map(_buildProcItem).join('')}</div>
      </div>`;
    });
    const noDept = _deptGroups['__none__'];
    if (noDept?.length) {
      procsHTML += `<div style="margin-bottom:6px">
        <div style="font-size:10.5px;font-weight:800;color:var(--txt3);padding:4px 10px;background:var(--bg);border-radius:7px;margin-bottom:6px">
          <i class="fas fa-inbox" style="color:var(--txt3);margin-left:4px"></i> لم يُضاف لقسم (${noDept.length})
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;padding-right:8px">${noDept.map(_buildProcItem).join('')}</div>
      </div>`;
    }
  }

  // الشعب الدراسية — تصفية حسب المادة المختارة (أو كل الشعب للفصل إذا لم تُختر مادة بعد)
  const _selectedSubjId = isEdit ? exam.subject_id : null;
  const _buildSectionsHTML = (subjId) => {
    const filtered = STATE.sections
      .filter(s => s.semester === semester && (!subjId || s.subject_id == subjId));
    if (!filtered.length) return '<div style="color:var(--txt3);font-size:12px;padding:8px">لا توجد شعب مرتبطة بهذه المادة</div>';
    return filtered.map(s => {
      const subj = getSubject(s.subject_id);
      const checked = isEdit && (exam.section_ids||[]).includes(s.id) ? 'checked' : '';
      return `<label class="exam-check-item" id="lbl-sec-${s.id}">
        <input type="checkbox" id="scb_${s.id}" ${checked} onchange="_updateCheckLabel(this,'lbl-sec-${s.id}')">
        <i class="fas fa-layer-group" style="color:var(--gold);font-size:13px"></i>
        <span style="font-weight:600">${s.name}</span>
        <span style="color:var(--txt3);font-size:10.5px">${subj?.name||''}</span>
        <span class="badge b-blue" style="font-size:9px">${(s.student_ids||[]).length} طالب</span>
      </label>`;
    }).join('');
  };
  const sectionsHTML = _buildSectionsHTML(_selectedSubjId);

  // حساب نقاط المراقب التقديرية
  const _previewDate = isEdit ? exam.date : today;
  const _previewTime = isEdit ? exam.time : nowTime;
  const _previewType = isEdit ? exam.type : 'final';
  const _previewIsHoliday = _isAutoHoliday(_previewDate);
  const _previewPts = _calcExamPoints({ date:_previewDate, time:_previewTime, type:_previewType, is_holiday:_previewIsHoliday });

  mo.innerHTML = `<div class="md" style="max-width:700px">
    <div class="md-hd">
      <h2>
        <div style="width:32px;height:32px;border-radius:9px;background:var(--primary)20;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-${isEdit?'edit':'plus-circle'}" style="color:var(--primary2)"></i>
        </div>
        ${isEdit?'تعديل الامتحان':'امتحان جديد'}
      </h2>
      <button class="md-close" onclick="closeMo('addExamMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:0">

      <!-- قسم 1: المعلومات الأساسية -->
      <div style="padding:18px 22px;border-bottom:1px solid var(--border)">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px">
          <i class="fas fa-info-circle" style="margin-left:5px;color:var(--primary2)"></i>المعلومات الأساسية
        </div>
        <div class="g2">
          <div class="field" style="grid-column:1/-1">
            <label class="field-lbl">المادة الدراسية <span class="req">*</span></label>
            <select id="exSubj" style="font-size:13.5px;height:44px" onchange="_onExamSubjChange(this.value)">
              <option value="">— اختر المادة —</option>
              ${STATE.subjects.map(s=>`<option value="${s.id}" ${isEdit&&exam.subject_id==s.id?'selected':''}>${s.name}${s.code?' ('+s.code+')':''}</option>`).join('')}
            </select>
          </div>
          <div class="field">
            <label class="field-lbl">نوع الامتحان</label>
            <select id="exType" style="height:44px" onchange="_updateExamPointsPreview()">
              ${[['final','📋 نهائي'],['midterm','📝 منتصف الفصل'],['quiz','📄 اختبار'],['makeup','🔄 إعادة']].map(([v,l])=>`<option value="${v}" ${isEdit&&exam.type===v?'selected':''}>${l}</option>`).join('')}
            </select>
          </div>
          <div class="field">
            <label class="field-lbl">التاريخ <span class="req">*</span></label>
            <input type="date" id="exDate" value="${isEdit?exam.date:today}" style="height:44px" onchange="_updateExamPointsPreview();_validateExamTimeDate()">
          </div>
          <div class="field">
            <label class="field-lbl">وقت البدء <span class="req">*</span></label>
            <input type="time" id="exTime" value="${isEdit?exam.time:nowTime}"
              style="height:44px" onchange="_updateExamPointsPreview();_validateExamTimeDate()">
          </div>
          <div class="field">
            <label class="field-lbl">مدة الامتحان</label>
            <div style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap">
              ${[['60','ساعة'],['90','90 دق'],['120','ساعتان'],['180','3 ساعات']].map(([v,l])=>`
                <button type="button" class="btn bo btn-xs dur-preset" data-val="${v}"
                  onclick="_setDurPreset(${v})"
                  style="font-size:11px;${(isEdit?exam.duration:120)==parseInt(v)?'background:var(--primary2);color:white;border-color:var(--primary2)':''}">
                  ${l}
                </button>`).join('')}
              <button type="button" class="btn bo btn-xs dur-preset" data-val="manual"
                onclick="_setDurPreset('manual')"
                style="font-size:11px">
                <i class="fas fa-edit" style="font-size:10px"></i> يدوي
              </button>
            </div>
            <input type="number" id="exDur" value="${isEdit?exam.duration:120}" min="30" max="480"
              style="height:44px" oninput="_updateExamPointsPreview();_clearDurPresets()">
          </div>
        </div>

        <!-- مؤشر اكتشاف العطلة ونقاط المراقب -->
        <div id="examMetaRow" style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:stretch">
          <div id="holidayDetectBadge" style="flex:1;min-width:160px;padding:10px 14px;border-radius:10px;border:1.5px solid var(--border);background:var(--bg);display:flex;align-items:center;gap:8px;font-size:12.5px">
            <i class="fas fa-calendar-check" style="color:var(--txt3);font-size:15px" id="holidayIcon"></i>
            <span id="holidayLabel" style="font-weight:600">—</span>
          </div>
          <div id="proctorPointsBadge" style="flex:1;min-width:160px;padding:10px 14px;border-radius:10px;border:1.5px solid var(--gold)40;background:var(--gold)08;display:flex;align-items:center;gap:8px;font-size:12.5px">
            <i class="fas fa-trophy" style="color:var(--gold);font-size:15px"></i>
            <div>
              <div style="font-size:10px;color:var(--txt3);margin-bottom:1px">نقاط المراقب</div>
              <div style="font-weight:900;color:var(--gold);font-size:17px" id="examPointsVal">${_previewPts}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- قسم 2: القاعات -->
      <div style="padding:16px 22px;border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
          <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px">
            <i class="fas fa-door-open" style="margin-left:5px;color:var(--teal)"></i>القاعات
          </div>
          <button class="btn bo btn-xs" onclick="_autoSuggestRooms()" title="اقتراح تلقائي">
            <i class="fas fa-magic" style="color:var(--teal)"></i> اقتراح
          </button>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:7px" id="roomsCheckContainer">${roomsHTML}</div>
        <div id="roomsConflictHint" style="margin-top:6px;font-size:11.5px;color:var(--red2)"></div>
      </div>

      <!-- قسم 3: الشعب -->
      <div style="padding:16px 22px;border-bottom:1px solid var(--border)">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">
          <i class="fas fa-layer-group" style="margin-left:5px;color:var(--gold)"></i>الشعب الدراسية
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:7px" id="sectionsCheckContainer">${sectionsHTML}</div>
      </div>

      <!-- قسم 3.5: تخصيص كل قاعة -->
      <div style="padding:16px 22px;border-bottom:1px solid var(--border)">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">
          <i class="fas fa-link" style="margin-left:5px;color:var(--primary2)"></i>ربط المراقبين والشعب بكل قاعة
          <span style="font-size:9.5px;font-weight:400;margin-right:6px;color:var(--txt3)">(خصص مراقبًا وشُعبًا لكل قاعة على حدة)</span>
        </div>
        <div id="roomAssignContainer">
          <div style="color:var(--txt3);font-size:12px;padding:10px;text-align:center"><i class="fas fa-arrow-up" style="margin-left:6px"></i>اختر قاعة أو أكثر لتخصيص المراقبين والشعب لكل قاعة</div>
        </div>
      </div>

      <!-- قسم 4: المراقبون (عام - اختياري) -->
      <div style="padding:16px 22px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
          <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px">
            <i class="fas fa-user-tie" style="margin-left:5px;color:var(--purple2)"></i>مراقبون إضافيون (اختياري)
            <span style="font-size:9.5px;font-weight:400;margin-right:6px">(x/3 = عدد مرات المراقبة · 🔴 وصل الحد)</span>
          </div>
          <button class="btn bo btn-xs" onclick="_autoSuggestProctors()" title="اقتراح تلقائي">
            <i class="fas fa-magic" style="color:var(--purple2)"></i> اقتراح
          </button>
        </div>
        <div id="proctorFilterHint" style="margin-bottom:8px"></div>
        <div style="display:flex;flex-wrap:wrap;gap:7px" id="procsCheckContainer">${procsHTML}</div>
        <div id="procsConflictHint" style="margin-top:6px;font-size:11.5px;color:var(--red2)"></div>
      </div>

      <!-- قسم 5: الملاحظات -->
      <div style="padding:14px 22px;border-top:1px solid var(--border)">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">
          <i class="fas fa-sticky-note" style="margin-left:5px;color:var(--txt3)"></i>ملاحظات
        </div>
        <textarea id="exNotes" rows="3" placeholder="ملاحظات تظهر للمراقبين في شاشة الامتحان..." style="resize:vertical;width:100%">${isEdit?(exam.notes||''):''}</textarea>
      </div>

    </div>

    <!-- تحذيرات التعارض -->
    <div id="conflictWarnings" style="display:none;padding:12px 22px;background:var(--red2)10;border-top:1px solid var(--red2)30">
      <div style="font-weight:700;font-size:12.5px;color:var(--red2);margin-bottom:6px"><i class="fas fa-exclamation-triangle" style="margin-left:5px"></i>تحذيرات</div>
      <div id="conflictList" style="font-size:12px;color:var(--txt2)"></div>
    </div>

    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('addExamMo')">إلغاء</button>
      <button class="btn bo" onclick="_checkAndPreview()" id="previewExamBtn">
        <i class="fas fa-eye"></i> فحص التعارضات
      </button>
      <button class="btn bp" onclick="saveExam()" id="saveExamBtn">
        <i class="fas fa-save"></i> ${isEdit?'تحديث':'حفظ الامتحان'}
      </button>
    </div>
  </div>`;
  requestAnimationFrame(() => {
    // إعادة تهيئة حالة القاعات عند كل فتح للنموذج
    window._examRoomState = {};
    _updateExamPointsPreview();
    _refreshRoomAssignment();
    const subjVal = document.getElementById('exSubj')?.value;
    if (subjVal) setTimeout(() => _onExamSubjChange(subjVal), 50);
  });
}

function _setDurPreset(val) {
  const input = document.getElementById('exDur');
  if (!input) return;
  if (val === 'manual') {
    input.focus();
    input.select();
    document.querySelectorAll('.dur-preset').forEach(b => {
      b.style.background = '';
      b.style.color = '';
      b.style.borderColor = '';
      if (b.getAttribute('data-val') === 'manual') {
        b.style.background = 'var(--primary2)';
        b.style.color = 'white';
        b.style.borderColor = 'var(--primary2)';
      }
    });
    return;
  }
  input.value = val;
  document.querySelectorAll('.dur-preset').forEach(b => {
    const isActive = b.getAttribute('data-val') === String(val);
    b.style.background = isActive ? 'var(--primary2)' : '';
    b.style.color = isActive ? 'white' : '';
    b.style.borderColor = isActive ? 'var(--primary2)' : '';
  });
  _updateExamPointsPreview();
}

function _clearDurPresets() {
  document.querySelectorAll('.dur-preset').forEach(b => {
    b.style.background = '';
    b.style.color = '';
    b.style.borderColor = '';
  });
}

function _updateCheckLabel(cb, lblId) {
  const lbl = document.getElementById(lblId);
  if (!lbl) return;
  if (cb.checked) {
    lbl.style.borderColor = 'var(--primary2)';
    lbl.style.background  = 'var(--primary)08';
  } else {
    lbl.style.borderColor = 'var(--border)';
    lbl.style.background  = '';
  }
}

function _autoSuggestRooms() {
  const date  = document.getElementById('exDate')?.value;
  const time  = document.getElementById('exTime')?.value;
  const dur   = parseInt(document.getElementById('exDur')?.value||120);
  const extra = 0; // لا يوجد وقت إضافي في النموذج المحدّث
  if (!date||!time) { toast('أدخل التاريخ والوقت أولاً','warning'); return; }

  const available = _suggestRooms(date,time,dur,extra,STATE._editExamId);
  // Select first available
  STATE.rooms.forEach(r => {
    const cb = document.getElementById(`rcb_${r.id}`);
    if (cb) {
      const avail = available.find(ar=>ar.id===r.id);
      cb.checked = !!avail && available.indexOf(avail) < 2;
      _updateCheckLabel(cb, `lbl-room-${r.id}`);
    }
  });
  const hint = document.getElementById('roomsConflictHint');
  if (hint) hint.textContent = available.length > 0 ? `✓ ${available.length} قاعة متاحة في هذا الوقت` : '⚠️ لا توجد قاعات متاحة في هذا الوقت';
}

function _autoSuggestProctors() {
  const date  = document.getElementById('exDate')?.value;
  const time  = document.getElementById('exTime')?.value;
  const dur   = parseInt(document.getElementById('exDur')?.value||120);
  const extra = 0; // لا يوجد وقت إضافي في النموذج المحدّث
  if (!date||!time) { toast('أدخل التاريخ والوقت أولاً','warning'); return; }

  const suggestions = _suggestProctors(date,time,dur,extra,STATE._editExamId,STATE.currentSem);
  const available   = suggestions.filter(p=>!p._busy && !p._overLimit);

  // Select first 2 available with lowest count
  let selected = 0;
  STATE.profiles.filter(p=>p.role==='proctor'&&p.active).forEach(p => {
    const cb = document.getElementById(`pcb_${p.id}`);
    if (!cb) return;
    const sugg = available.find(s=>s.id===p.id);
    cb.checked = !!sugg && selected < 2 && !!(selected += 1);
    _updateCheckLabel(cb, `lbl-proc-${p.id}`);
  });
  const hint = document.getElementById('procsConflictHint');
  if (hint) hint.textContent = `✓ ${available.length} مراقب متاح في هذا الوقت (${suggestions.filter(p=>p._overLimit).length} وصل حده)`;
}

function _checkAndPreview() {
  const data = _getExamFormData();
  if (!data) return;
  const errors = _checkConflicts(data, STATE._editExamId);
  const warnDiv = document.getElementById('conflictWarnings');
  const listDiv = document.getElementById('conflictList');
  if (!warnDiv || !listDiv) return;
  if (errors.length) {
    listDiv.innerHTML = errors.map(e=>`<div style="margin-bottom:6px;display:flex;gap:8px;align-items:flex-start"><i class="fas fa-exclamation-circle" style="color:var(--red2);margin-top:2px;flex-shrink:0"></i><span>${e}</span></div>`).join('');
    warnDiv.style.display = 'block';
    // Scroll to warning inside modal
    warnDiv.scrollIntoView({ behavior:'smooth', block:'nearest' });
    toast(`⚠️ ${errors.length} تعارض — راجع التحذيرات في النموذج`, 'warning', 5000);
  } else {
    warnDiv.style.display = 'none';
    toast('✓ لا توجد تعارضات، يمكنك الحفظ', 'success');
  }
}

function _getExamFormData() {
  const subjId = parseInt(document.getElementById('exSubj')?.value);
  const date   = document.getElementById('exDate')?.value;
  const time   = document.getElementById('exTime')?.value;
  const type   = document.getElementById('exType')?.value;
  if (!subjId||!date||!time||!type) { toast('يرجى ملء الحقول المطلوبة','error'); return null; }

  const dur     = parseInt(document.getElementById('exDur')?.value||120);
  const room_ids    = STATE.rooms.filter(r=>document.getElementById(`rcb_${r.id}`)?.checked).map(r=>r.id);
  const proctor_ids = STATE.profiles.filter(p=>p.role==='proctor'&&document.getElementById(`pcb_${p.id}`)?.checked).map(p=>p.id);
  // section_ids: من checkboxes أو من مجموع الشعب في القاعات
  const fromCheckboxes = STATE.sections.filter(s=>document.getElementById(`scb_${s.id}`)?.checked).map(s=>s.id);
  const fromRoomState  = [...new Set(Object.values(window._examRoomState||{}).flatMap(rs=>rs.sections||[]))];
  const section_ids    = [...new Set([...fromCheckboxes, ...fromRoomState])];
  const is_holiday = _isAutoHoliday(date);

  // قراءة بيانات القاعات من نظام Tag Picker (_examRoomState)
  const room_proctors = {};
  const room_sections = {};
  room_ids.forEach(rid => {
    const rs = window._examRoomState?.[rid];
    if (rs) {
      room_proctors[String(rid)] = rs.proctors || [];
      room_sections[String(rid)] = rs.sections || [];
    }
  });

  // دمج كل مراقبي القاعات في proctor_ids للتوافق مع النظام القديم
  // دمج كل مراقبي القاعات في proctor_ids للتوافق مع النظام القديم
  const allRoomProctors = [...new Set(Object.values(room_proctors).flat())];
  const mergedProctors = [...new Set([...proctor_ids, ...allRoomProctors])];

  return { subject_id:subjId, semester:STATE.currentSem, date, time, type,
    duration:dur, extra_time:0, max_grade:100,
    notes:document.getElementById('exNotes')?.value?.trim()||'',
    is_holiday,
    room_ids, proctor_ids:mergedProctors, section_ids, room_sections, room_proctors };
}

async function saveExam() {
  const data = _getExamFormData();
  if (!data) return;

  // تحقق من التعارضات
  const errors = _checkConflicts(data, STATE._editExamId);
  if (errors.length) {
    const warnDiv = document.getElementById('conflictWarnings');
    const listDiv = document.getElementById('conflictList');
    if (warnDiv) warnDiv.style.display='block';
    if (listDiv) listDiv.innerHTML = errors.map(e=>`<div style="margin-bottom:4px">${e}</div>`).join('');
    toast(`يوجد ${errors.length} تعارض — راجع التحذيرات أو تأكد من المتابعة`,'warning');
    // السماح بالحفظ رغم التحذير بعد تأكيد
    if (!confirm(`⚠️ يوجد ${errors.length} تعارض:\n\n${errors.join('\n')}\n\nهل تريد الحفظ رغم ذلك؟`)) return;
  }

  const btn = document.getElementById('saveExamBtn');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> جارٍ الحفظ...'; }

  try {
    const payload = Serialize.exam(data);
    if (STATE._editExamId) {
      const res = await dbUpdate('exams', STATE._editExamId, payload);
      const idx = STATE.exams.findIndex(e=>e.id===STATE._editExamId);
      if (idx>=0) STATE.exams[idx] = {...STATE.exams[idx], ...payload};
      toast('✓ تم تحديث الامتحان','success');
      await addLog('تعديل امتحان','exam',getSubject(data.subject_id)?.name||'');
      // تحديث حجوزات القاعات المرتبطة
      await _syncExamBookings(STATE._editExamId, data);
    } else {
      const res = await dbInsert('exams', payload);
      const newId = res?.id || res;
      toast('✓ تمت إضافة الامتحان','success');
      await addLog('إضافة امتحان','exam',getSubject(data.subject_id)?.name||'');
      // إنشاء حجوزات القاعات تلقائياً
      if (newId) await _syncExamBookings(newId, data);
      // إرسال إشعار إيميل
      if (typeof EmailService !== 'undefined') {
        try { await EmailService.sendNewExamNotif({...data, id: newId}); } catch(e){}
      }
    }
    closeMo('addExamMo');
    renderExams();
  } catch (e) {
    toast('خطأ: '+e.message,'error');
    if (btn) { btn.disabled=false; btn.innerHTML=`<i class="fas fa-save"></i> ${STATE._editExamId?'تحديث':'حفظ الامتحان'}`; }
  }
}

// ── ربط الامتحانات بحجوزات القاعات تلقائياً ────────────────────
async function _syncExamBookings(examId, examData) {
  try {
    const rooms   = examData.room_ids || [];
    const date    = examData.date;
    const start   = examData.time?.slice(0,5) || '08:00';
    const durMin  = (examData.duration||60) + (examData.extra_time||0);
    const endH    = new Date(new Date(`${date}T${start}`).getTime() + durMin*60000);
    const end     = `${String(endH.getHours()).padStart(2,'0')}:${String(endH.getMinutes()).padStart(2,'0')}`;
    const sub     = getSubject(examData.subject_id);
    const title   = `🎓 امتحان: ${sub?.name||'—'}`;
    const newStart = new Date(`${date}T${start}`);
    const newEnd   = new Date(`${date}T${end}`);

    // حذف الحجوزات القديمة لهذا الامتحان
    const oldBks = STATE.bookings.filter(b => b.exam_id === examId);
    for (const b of oldBks) {
      await SB.del('bookings', b.id);
      STATE.bookings = STATE.bookings.filter(x => x.id !== b.id);
    }

    const conflicts = [];

    // إنشاء حجز لكل قاعة مع التحقق من التعارض
    for (const roomId of rooms) {
      // فحص تعارض الحجوزات الموجودة
      const roomConflict = STATE.bookings.find(b => {
        if (b.room_id != roomId || b.exam_id == examId) return false;
        if (b.date !== date) return false;
        const bS = new Date(`${b.date}T${(b.start_time||'00:00').slice(0,5)}`);
        const bE = new Date(`${b.date}T${(b.end_time||'23:59').slice(0,5)}`);
        return newStart < bE && newEnd > bS;
      });
      // فحص تعارض الامتحانات الأخرى في نفس القاعة
      const examConflict = STATE.exams.find(e => {
        if (e.id == examId) return false;
        if (!(e.room_ids||[]).includes(roomId)) return false;
        if (e.date !== date) return false;
        const eS = new Date(`${e.date}T${e.time}`);
        const eE = new Date(eS.getTime()+(e.duration+(e.extra_time||0))*60000);
        return newStart < eE && newEnd > eS;
      });

      if (roomConflict || examConflict) {
        const conflictName = roomConflict?.title || getSubject(examConflict?.subject_id)?.name || 'حجز آخر';
        conflicts.push(`⚠️ القاعة "${getRoom(roomId)?.name}" متعارضة مع: ${conflictName}`);
        continue; // تخطي هذه القاعة
      }

      const payload = {
        room_id:    roomId,
        exam_id:    examId,
        booked_by:  STATE.currentUser?.id,
        title,
        purpose:    'exam',
        date,
        start_time: start + ':00',
        end_time:   end   + ':00',
        notes:      `تم الإنشاء تلقائياً — امتحان: ${sub?.name||'—'}`,
        status:     'confirmed'
      };
      try {
        const res = await SB.insert('bookings', payload);
        if (res) STATE.bookings.push(Hydrate.booking(res));
      } catch(err) { console.warn('[syncBookings]', err.message); }
    }

    if (conflicts.length) {
      toast(`⚠️ تعارض في ${conflicts.length} قاعة — لم يُضَف حجزها:\n${conflicts.join('\n')}`, 'warning', 6000);
    }
  } catch(e) { console.error('[_syncExamBookings]', e); }
}

async function deleteExam(id) {
  if (!isAdmin()) { toast('حذف الامتحانات متاح لمسؤول النظام فقط','error'); return; }
  const e = getExam(id);
  if (examStatus(e)==='active') { toast('لا يمكن حذف امتحان جارٍ','error'); return; }
  confirmDelete(`حذف امتحان "${getSubject(e?.subject_id)?.name||''}"؟`, async()=>{
    try {
      await dbDelete('exams',id);
      renderExams();
      toast('تم الحذف','info');
      await addLog('حذف امتحان','exam');
    } catch { toast('فشل الحذف','error'); }
  });
}

function _getMo(id) {
  let mo=document.getElementById(id);
  if(!mo){mo=document.createElement('div');mo.className='mo';mo.id=id;document.body.appendChild(mo);}
  return mo;
}

// ═══════════════════════════════════════════════════════════════
//  FEATURE: QR Code للامتحانات
// ═══════════════════════════════════════════════════════════════
function openExamQR(examId) {
  const e   = getExam(examId);
  const sub = getSubject(e?.subject_id);
  if (!e) return;

  const mo = document.getElementById('examQrMo') || (() => {
    const m = document.createElement('div'); m.className='mo'; m.id='examQrMo'; document.body.appendChild(m); return m;
  })();

  // QR يؤدي لصفحة تقرير حي
  const reportUrl = `${location.origin}${location.pathname}#exam-report-${e.id}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(reportUrl)}&color=1e40af&bgcolor=f8fafc`;

  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-qrcode" style="color:var(--teal)"></i> QR Code الامتحان</h2>
      <button class="md-close" onclick="closeMo('examQrMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="text-align:center">
      <div style="padding:14px;background:#f8fafc;border-radius:14px;display:inline-block;margin-bottom:16px;border:2px solid var(--border)">
        <img src="${qrUrl}" alt="QR" style="width:240px;height:240px;display:block"
             onerror="this.src='';this.parentElement.innerHTML='<div style=padding:40px;color:var(--txt3)><i class=fas fa-qrcode style=font-size:60px></i></div>'">
      </div>
      <div style="font-size:15px;font-weight:800;margin-bottom:6px">${sub?.name||'—'}</div>
      <div style="font-size:13px;color:var(--txt2);margin-bottom:4px"><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)} · ${fmtTime(e.time)}</div>
      <div style="font-size:13px;color:var(--txt2);margin-bottom:16px"><i class="fas fa-hourglass" style="color:var(--gold)"></i> ${e.duration} دقيقة</div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
        <button class="btn bp btn-sm" onclick="openExamLiveReport(${e.id})">
          <i class="fas fa-chart-line"></i> فتح تقرير حي
        </button>
        <button class="btn bo btn-sm" onclick="_printExamQR('${qrUrl}','${(sub?.name||'').replace(/'/g,'')}','${e.date}','${e.time}')">
          <i class="fas fa-print"></i> طباعة
        </button>
        <a href="${qrUrl}" download="exam-qr-${e.id}.png" class="btn bo btn-sm">
          <i class="fas fa-download"></i> تحميل
        </a>
      </div>
      <div style="margin-top:14px;padding:10px;background:var(--primary-bg);border-radius:8px;font-size:11.5px;color:var(--txt2)">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        مسح QR يفتح صفحة تقرير الحضور الحي للامتحان
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('examQrMo')">إغلاق</button>
    </div>
  </div>`;
  showMo('examQrMo');
}

// فتح تقرير الامتحان الحي في نافذة جديدة
function openExamLiveReport(examId) {
  const e   = getExam(examId);
  const sub = getSubject(e?.subject_id);
  if (!e) return;

  const rooms   = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
  const procts  = (e.proctor_ids||[]).map(id=>getProfile(id)?.name).filter(Boolean);
  const studs   = _getExamStudentsList(e);
  const atts    = STATE.attendance[examId] || {};
  const present = studs.filter(s=>atts[s.id]==='present'||atts[s.id]==='late');
  const absent  = studs.filter(s=>atts[s.id]==='absent');
  const unmarked= studs.filter(s=>!atts[s.id]);

  const typeLabels = { final:'نهائي', midterm:'منتصف الفصل', quiz:'اختبار', makeup:'إعادة' };
  const status = examStatus(e);
  const statusLabel = status==='active'?'🟢 جارٍ الآن':status==='upcoming'?'🔵 قادم':'✅ منتهٍ';

  const w = window.open('','_blank','width=900,height=700');
  w.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head>
    <meta charset="UTF-8">
    <title>تقرير الامتحان — ${sub?.name||'—'}</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Cairo',sans-serif;background:#f1f5f9;color:#1e293b;padding:24px;direction:rtl}
      .header{background:linear-gradient(135deg,#1e3a5f,#1e40af);color:white;border-radius:16px;padding:28px 32px;margin-bottom:24px;display:flex;align-items:center;gap:20px}
      .header img{height:70px;object-fit:contain;background:white;border-radius:12px;padding:8px 14px}
      .header-info h1{font-size:22px;font-weight:900;margin-bottom:4px}
      .header-info .meta{font-size:13px;opacity:.8;margin-top:4px}
      .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;margin-bottom:24px}
      .card{background:white;border-radius:12px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.07)}
      .card .val{font-size:36px;font-weight:900;margin-bottom:4px}
      .card .lbl{font-size:12px;color:#64748b}
      .section{background:white;border-radius:14px;padding:20px;margin-bottom:18px;box-shadow:0 2px 8px rgba(0,0,0,.07)}
      .section h3{font-size:14px;font-weight:800;color:#475569;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #f1f5f9;display:flex;align-items:center;gap:8px}
      .stud-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px}
      .stud-item{display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:9px;border:1px solid #e2e8f0}
      .stud-item.present{background:#f0fdf4;border-color:#86efac}
      .stud-item.absent{background:#fef2f2;border-color:#fca5a5}
      .stud-item.unmarked{background:#f8fafc;border-color:#e2e8f0}
      .badge{padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700}
      .b-green{background:#dcfce7;color:#15803d}
      .b-red{background:#fee2e2;color:#dc2626}
      .b-gray{background:#f1f5f9;color:#64748b}
      .refresh-btn{position:fixed;top:20px;left:20px;background:#1e40af;color:white;border:none;padding:10px 18px;border-radius:10px;cursor:pointer;font-family:'Cairo',sans-serif;font-size:13px;font-weight:700;display:flex;align-items:center;gap:6px;box-shadow:0 4px 14px rgba(30,64,175,.3)}
      @media print{.refresh-btn{display:none}}
    </style>
  </head><body>
    <button class="refresh-btn" onclick="location.reload()"><i class="fas fa-sync-alt"></i> تحديث</button>
    <div class="header">
      <img src="https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png" onerror="this.style.display='none'">
      <div class="header-info">
        <div style="font-size:12px;opacity:.7;margin-bottom:6px">تقرير امتحان حي · ExamFlow</div>
        <h1>${sub?.name||'—'} <span style="font-size:14px;opacity:.75">(${typeLabels[e.type]||e.type})</span></h1>
        <div class="meta">📅 ${e.date} &nbsp;|&nbsp; 🕐 ${e.time} &nbsp;|&nbsp; ⏱ ${e.duration} دقيقة</div>
        <div class="meta" style="margin-top:4px">${statusLabel}</div>
        ${rooms.length?`<div class="meta" style="margin-top:4px">🏛 ${rooms.join(' · ')}</div>`:''}
        ${procts.length?`<div class="meta" style="margin-top:3px">👤 ${procts.join(' · ')}</div>`:''}
      </div>
    </div>
    <div class="cards">
      <div class="card"><div class="val" style="color:#3b82f6">${studs.length}</div><div class="lbl">إجمالي الطلاب</div></div>
      <div class="card"><div class="val" style="color:#22c55e">${present.length}</div><div class="lbl">حاضر</div></div>
      <div class="card"><div class="val" style="color:#ef4444">${absent.length}</div><div class="lbl">غائب</div></div>
      <div class="card"><div class="val" style="color:#f59e0b">${unmarked.length}</div><div class="lbl">لم يُسجَّل</div></div>
      <div class="card"><div class="val" style="color:#8b5cf6">${studs.length?Math.round(present.length/studs.length*100):0}%</div><div class="lbl">نسبة الحضور</div></div>
    </div>
    ${present.length?`<div class="section">
      <h3><i class="fas fa-check-circle" style="color:#22c55e"></i> الحاضرون (${present.length})</h3>
      <div class="stud-grid">${present.map(s=>`<div class="stud-item present">
        <div style="width:30px;height:30px;border-radius:8px;background:#22c55e;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0">${(s.name||'').split(' ').map(x=>x[0]).slice(0,2).join('')}</div>
        <div><div style="font-weight:700;font-size:12.5px">${s.name}</div><div style="font-size:11px;color:#64748b">${s.stud_id||''}</div></div>
        <span class="badge b-green" style="margin-right:auto">حاضر</span>
      </div>`).join('')}</div></div>`:''}
    ${absent.length?`<div class="section">
      <h3><i class="fas fa-times-circle" style="color:#ef4444"></i> الغائبون (${absent.length})</h3>
      <div class="stud-grid">${absent.map(s=>`<div class="stud-item absent">
        <div style="width:30px;height:30px;border-radius:8px;background:#ef4444;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0">${(s.name||'').split(' ').map(x=>x[0]).slice(0,2).join('')}</div>
        <div><div style="font-weight:700;font-size:12.5px">${s.name}</div><div style="font-size:11px;color:#64748b">${s.stud_id||''}</div></div>
        <span class="badge b-red" style="margin-right:auto">غائب</span>
      </div>`).join('')}</div></div>`:''}
    ${unmarked.length?`<div class="section">
      <h3><i class="fas fa-question-circle" style="color:#f59e0b"></i> لم يُسجَّل بعد (${unmarked.length})</h3>
      <div class="stud-grid">${unmarked.map(s=>`<div class="stud-item unmarked">
        <div style="width:30px;height:30px;border-radius:8px;background:#94a3b8;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0">${(s.name||'').split(' ').map(x=>x[0]).slice(0,2).join('')}</div>
        <div><div style="font-weight:700;font-size:12.5px">${s.name}</div><div style="font-size:11px;color:#64748b">${s.stud_id||''}</div></div>
        <span class="badge b-gray" style="margin-right:auto">—</span>
      </div>`).join('')}</div></div>`:''}
    <div style="text-align:center;margin-top:24px;font-size:11.5px;color:#94a3b8">
      تاريخ التقرير: ${new Date().toLocaleString('ar-SA')} · ExamFlow v10
    </div>
  </body></html>`);
  w.document.close();
}

function _printExamQR(qrUrl, subName, date, time) {
  const w = window.open('','_blank','width=520,height=680');
  w.document.write(`<!DOCTYPE html><html dir="rtl"><head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@700;900&display=swap" rel="stylesheet">
    <style>
      body{font-family:'Cairo',sans-serif;text-align:center;padding:30px 24px;direction:rtl;background:#f8fafc}
      .header{display:flex;align-items:center;justify-content:center;gap:14px;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid #e2e8f0}
      .header img{height:56px;object-fit:contain;background:white;border-radius:10px;padding:6px 12px;box-shadow:0 2px 8px rgba(0,0,0,.12)}
      .uni{font-size:11px;color:#64748b;text-align:right;line-height:1.5}
      .uni b{display:block;font-size:13px;color:#1e293b}
      .qr-wrap{background:white;border-radius:16px;padding:16px;display:inline-block;box-shadow:0 4px 16px rgba(0,0,0,.1);border:1.5px solid #e2e8f0;margin:8px 0 16px}
      .title{font-size:20px;font-weight:900;margin:8px 0 6px;color:#1e293b}
      .meta{font-size:13px;color:#64748b;margin:4px 0}
      .footer{margin-top:16px;font-size:11.5px;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:12px}
      @media print{body{background:white}}
    </style>
  </head><body>
    <div class="header">
      <img src="https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png" onerror="this.style.display='none'">
      <div class="uni"><b>جامعة السلطان قابوس</b>Sultan Qaboos University<br>كلية التمريض · College of Nursing</div>
    </div>
    <div class="qr-wrap">
      <img src="${qrUrl}" width="210" height="210" style="display:block">
    </div>
    <div class="title">${subName}</div>
    <div class="meta">📅 ${date}</div>
    <div class="meta">🕐 ${time}</div>
    <div class="footer">
      امسح الكود للاطلاع على تقرير الامتحان الحي<br>
      <span style="color:#3b82f6;font-weight:700">ExamFlow v10</span>
    </div>
    <script>window.onload=()=>{window.print();}<\/script>
  </body></html>`);
  w.document.close();
}

// ═══════════════════════════════════════════════════════════════
//  طابور مراجعة الامتحانات (المسؤول فقط)
// ═══════════════════════════════════════════════════════════════
function _updateExamReviewBadge() {
  const badge = document.getElementById('examPendingBadge');
  if (!badge || !canReviewExam()) return;
  const cnt = STATE.exams.filter(e => e.approval_status === 'pending' && e.semester === STATE.currentSem).length;
  if (cnt > 0) {
    badge.textContent = cnt;
    badge.style.display = 'flex';
  } else {
    badge.style.display = 'none';
  }
}

function openExamReviewQueue() {
  if (!canReviewExam()) { toast('غير مصرح','error'); return; }

  const pending = STATE.exams
    .filter(e => e.approval_status === 'pending' && e.semester === STATE.currentSem)
    .sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  const moId = 'examReviewMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:760px;max-height:92vh;display:flex;flex-direction:column">
    <div class="md-hd">
      <h2><i class="fas fa-clipboard-check" style="color:var(--purple2)"></i> مراجعة الامتحانات المعلّقة</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:16px 20px;overflow-y:auto;flex:1">
      ${!pending.length ? `<div style="padding:50px 20px;text-align:center;color:var(--txt3)">
        <i class="fas fa-check-double" style="font-size:48px;color:var(--green2);opacity:.4;display:block;margin-bottom:14px"></i>
        <h3 style="margin-bottom:6px;font-size:16px;color:var(--green2)">لا توجد امتحانات بانتظار المراجعة</h3>
        <p style="font-size:13px">جميع الامتحانات تمت مراجعتها.</p>
      </div>` : `
        <div style="padding:11px 14px;background:var(--gold)08;border-radius:9px;border:1px solid var(--gold)25;margin-bottom:14px;font-size:12.5px;color:var(--txt2)">
          <i class="fas fa-info-circle" style="color:var(--gold);margin-left:5px"></i>
          <b>${pending.length}</b> امتحان أنشأها المنسقون ينتظر موافقتك. عند الموافقة يُبلَّغ المراقبون تلقائياً.
        </div>
        ${pending.map(_buildReviewExamCard).join('')}
      `}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إغلاق</button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

function _buildReviewExamCard(e) {
  const sub = getSubject(e.subject_id);
  const dept = sub ? STATE.departments.find(d => d.id === sub.dept_id) : null;
  const creator = STATE.profiles.find(p => p.id === e.created_by) ||
                  STATE.profiles.find(p => p.id === e.approval_by);
  const rooms = (e.room_ids||[]).map(id => getRoom(id)?.name).filter(Boolean);
  const procCount = (e.proctor_ids||[]).length;
  const secCount  = (e.section_ids||[]).length;
  const studCount = (e.section_ids||[]).reduce((acc,sid) => {
    const s = STATE.sections.find(x => x.id === sid);
    return acc + (s?.student_ids?.length||0);
  },0);
  const typeLabels = { final:'📋 نهائي', midterm:'📝 منتصف', quiz:'📄 اختبار', makeup:'🔄 إعادة' };

  return `<div style="margin-bottom:12px;border:1.5px solid var(--gold)35;border-radius:12px;background:var(--card);overflow:hidden">
    <div style="padding:12px 16px;background:var(--gold)08;border-bottom:1px solid var(--gold)25;display:flex;align-items:center;gap:10px">
      <i class="fas fa-clock" style="color:var(--gold)"></i>
      <div style="flex:1">
        <div style="font-weight:800;font-size:14px">${esc(sub?.name||'—')}${sub?.code?` · ${esc(sub.code)}`:''}</div>
        <div style="font-size:11px;color:var(--txt3);margin-top:2px">${dept?esc(dept.name)+' · ':''}${typeLabels[e.type]||e.type}</div>
      </div>
      <span class="badge" style="background:var(--gold)25;color:var(--gold);font-size:10.5px;font-weight:800">معلّق</span>
    </div>
    <div style="padding:14px 16px">
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:11px">
        <div style="padding:9px 11px;background:var(--bg);border-radius:9px">
          <div style="font-size:10px;color:var(--txt3);font-weight:700;margin-bottom:3px"><i class="fas fa-calendar"></i> التاريخ</div>
          <div style="font-size:13px;font-weight:800">${fmtDate(e.date)}</div>
        </div>
        <div style="padding:9px 11px;background:var(--bg);border-radius:9px">
          <div style="font-size:10px;color:var(--txt3);font-weight:700;margin-bottom:3px"><i class="fas fa-clock"></i> الوقت</div>
          <div style="font-size:13px;font-weight:800">${fmtTime(e.time)} · ${e.duration} دق</div>
        </div>
        <div style="padding:9px 11px;background:var(--bg);border-radius:9px">
          <div style="font-size:10px;color:var(--txt3);font-weight:700;margin-bottom:3px"><i class="fas fa-door-open"></i> القاعات</div>
          <div style="font-size:12.5px;font-weight:700">${rooms.length?esc(rooms.join('، ')):'—'}</div>
        </div>
        <div style="padding:9px 11px;background:var(--bg);border-radius:9px">
          <div style="font-size:10px;color:var(--txt3);font-weight:700;margin-bottom:3px"><i class="fas fa-users"></i> التغطية</div>
          <div style="font-size:12.5px;font-weight:700">${procCount} مراقب · ${secCount} شعبة · ${studCount} طالب</div>
        </div>
      </div>
      ${creator?`<div style="font-size:11.5px;color:var(--txt3);margin-bottom:11px;padding:7px 11px;background:var(--primary)05;border-radius:7px;border-right:3px solid var(--primary2)40">
        <i class="fas fa-user-edit" style="margin-left:4px"></i> أنشأه: <b>${esc(creator.name||'—')}</b>
      </div>`:''}
      ${e.notes?`<div style="font-size:11.5px;color:var(--txt2);margin-bottom:11px;padding:7px 11px;background:var(--bg);border-radius:7px">
        <i class="fas fa-comment" style="margin-left:4px;color:var(--txt3)"></i> ملاحظات: ${esc(e.notes)}
      </div>`:''}
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn bp btn-sm" onclick="_approveExam(${e.id})" style="flex:1;min-width:130px;background:var(--green2);border-color:var(--green2)">
          <i class="fas fa-check"></i> موافقة وإرسال للمراقبين
        </button>
        <button class="btn bo btn-sm" onclick="openEditExam(${e.id});closeMo('examReviewMo')">
          <i class="fas fa-edit"></i> تعديل قبل الموافقة
        </button>
        <button class="btn bd btn-sm" onclick="_rejectExam(${e.id})">
          <i class="fas fa-times"></i> رفض
        </button>
      </div>
    </div>
  </div>`;
}

async function _approveExam(examId) {
  const e = STATE.exams.find(x => x.id === examId);
  if (!e) return;
  if (!canReviewExam()) { toast('غير مصرح','error'); return; }

  try {
    const updates = {
      approval_status: 'approved',
      approval_by: STATE.currentUser?.id,
      approval_at: new Date().toISOString(),
      approval_notes: ''
    };
    await dbUpdate('exams', examId, updates);
    Object.assign(e, updates);

    // ✅ إخطار المراقبين الآن
    const proctorIds = e.proctor_ids || [];
    if (proctorIds.length) {
      const sub = getSubject(e.subject_id);
      const endT = (typeof _wizCalcEnd === 'function')
        ? _wizCalcEnd(e.date, e.time, e.duration)
        : '';
      const rn = (e.room_ids||[]).map(rid => getRoom(rid)?.name).filter(Boolean);
      await addNotif(proctorIds, '⚡ تعيين مراقبة جديد',
        `تم تعيينك مراقباً لـ "${sub?.name||'—'}" · ${fmtDate(e.date)} ${fmtTime(e.time)}${endT?'—'+fmtTime(endT):''} · ${rn.join('، ')}`,
        'exam'
      );
    }

    // ✅ إخطار المُنشئ بالموافقة
    if (e.created_by && e.created_by !== STATE.currentUser?.id) {
      const sub = getSubject(e.subject_id);
      await addNotif([e.created_by], '✓ تمت الموافقة على الامتحان',
        `الامتحان "${sub?.name||'—'}" بتاريخ ${fmtDate(e.date)} تمت الموافقة عليه ونُشر للمراقبين.`,
        'success'
      );
    }

    await addLog('موافقة على امتحان', 'exam', getSubject(e.subject_id)?.name||'');
    toast(`✓ تمت الموافقة — أُبلغ ${proctorIds.length} مراقب`, 'success');
    closeMo('examReviewMo');
    renderExams();
    UI._updateAllBadges?.();

    if (typeof EmailService !== 'undefined') {
      try { await EmailService.sendNewExamNotif(e); } catch {}
    }
  } catch(err) {
    toast('خطأ: ' + err.message, 'error');
  }
}

async function _rejectExam(examId) {
  const e = STATE.exams.find(x => x.id === examId);
  if (!e) return;
  if (!canReviewExam()) { toast('غير مصرح','error'); return; }

  // اطلب سبب الرفض
  const moId = 'rejectReasonMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
  mo.innerHTML = `<div class="md" style="max-width:430px">
    <div class="md-hd">
      <h2><i class="fas fa-times-circle" style="color:var(--red2)"></i> سبب الرفض</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px">
      <p style="font-size:13px;margin-bottom:11px">سيُرسَل سبب الرفض للمنسق ليتمكّن من تعديل الامتحان أو الاستفسار.</p>
      <textarea id="rejReason" rows="4" placeholder="مثال: تعارض مع امتحان آخر، يرجى تأجيله..." style="width:100%"></textarea>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bd" onclick="_doRejectExam(${examId},'${moId}')"><i class="fas fa-times"></i> تأكيد الرفض</button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _doRejectExam(examId, moId) {
  const reason = document.getElementById('rejReason')?.value?.trim() || '';
  const e = STATE.exams.find(x => x.id === examId);
  if (!e) return;

  try {
    const updates = {
      approval_status: 'rejected',
      approval_by: STATE.currentUser?.id,
      approval_at: new Date().toISOString(),
      approval_notes: reason
    };
    await dbUpdate('exams', examId, updates);
    Object.assign(e, updates);

    if (e.created_by) {
      const sub = getSubject(e.subject_id);
      await addNotif([e.created_by], '⛔ رُفض الامتحان',
        `الامتحان "${sub?.name||'—'}" بتاريخ ${fmtDate(e.date)} رُفض${reason?' — السبب: '+reason:''}.`,
        'warning'
      );
    }

    await addLog('رفض امتحان', 'exam', getSubject(e.subject_id)?.name||'');
    toast('تم رفض الامتحان وإبلاغ المنسق','info');
    closeMo(moId);
    closeMo('examReviewMo');
    renderExams();
    UI._updateAllBadges?.();
  } catch(err) {
    toast('خطأ: ' + err.message, 'error');
  }
}
