// ═══════════════════════════════════════════════════════════════
//  calendar.js — التقويم التفاعلي المحسّن v7
// ═══════════════════════════════════════════════════════════════

let _calYear  = new Date().getFullYear();
let _calMonth = new Date().getMonth();
let _calView  = 'month'; // 'month' | 'week' | 'list'
let _calFilterDept   = '';
let _calFilterType   = '';
let _calFilterRoom   = '';
let _calBrowseMode   = false; // وضع التصفح فقط (بدون حجز)

const MONTHS_AR = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const MONTHS_EN = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAYS_AR   = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
const DAYS_EN   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const CAL_COLORS = {
  final:   { bg:'rgba(219,234,254,.6)', border:'#3b82f6', text:'#1d4ed8', ar:'نهائي',  en:'Final'   },
  midterm: { bg:'rgba(254,243,199,.6)', border:'#f59e0b', text:'#b45309', ar:'منتصف',  en:'Midterm' },
  quiz:    { bg:'rgba(209,250,229,.6)', border:'#10b981', text:'#065f46', ar:'اختبار', en:'Quiz'    },
  makeup:  { bg:'rgba(237,233,254,.6)', border:'#8b5cf6', text:'#5b21b6', ar:'إعادة',  en:'Makeup'  },
};

function renderCalendar() {
  const calEl = document.getElementById('calendarContent');
  if (!calEl) return;
  const now     = new Date();
  const today   = now.toISOString().split('T')[0];
  const isAr    = typeof I18N !== 'undefined' ? I18N.isAr() : true;
  const months  = isAr ? MONTHS_AR : MONTHS_EN;
  const days    = isAr ? DAYS_AR   : DAYS_EN;

  // إضافة أزرار الإعدادات والفلاتر في أعلى الصفحة
  _buildCalendarActions();

  // تطبيق فلاتر الأقسام والأنواع والغرف
  const visibleRooms = _getCalVisibleRooms();
  let filteredExams = STATE.exams.filter(e => {
    if (_calFilterType && e.type !== _calFilterType) return false;
    if (_calFilterDept) {
      const subj = STATE.subjects.find(s => s.id === e.subject_id);
      if (!subj || String(subj.dept_id) !== String(_calFilterDept)) return false;
    }
    if (_calFilterRoom) {
      if (!(e.room_ids||[]).map(String).includes(String(_calFilterRoom))) return false;
    }
    return true;
  });

  const examMap = {};
  filteredExams.forEach(e => {
    if (!examMap[e.date]) examMap[e.date] = [];
    examMap[e.date].push(e);
  });

  // خط الفلاتر
  const filterBar = `<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:14px;padding:10px 12px;background:var(--card);border-radius:12px;border:1px solid var(--border)">
    <i class="fas fa-filter" style="color:var(--txt3);font-size:12px"></i>
    <select style="height:32px;font-size:12px;min-width:120px" onchange="_setCalFilter('type',this.value)">
      <option value="">كل الأنواع</option>
      <option value="final" ${_calFilterType==='final'?'selected':''}>نهائي</option>
      <option value="midterm" ${_calFilterType==='midterm'?'selected':''}>منتصف الفصل</option>
      <option value="quiz" ${_calFilterType==='quiz'?'selected':''}>اختبار</option>
      <option value="makeup" ${_calFilterType==='makeup'?'selected':''}>إعادة</option>
    </select>
    <select style="height:32px;font-size:12px;min-width:120px" onchange="_setCalFilter('dept',this.value)">
      <option value="">كل الأقسام</option>
      ${STATE.departments.map(d=>`<option value="${d.id}" ${String(_calFilterDept)===String(d.id)?'selected':''}>${esc(d.name)}</option>`).join('')}
    </select>
    <select style="height:32px;font-size:12px;min-width:120px" onchange="_setCalFilter('room',this.value)">
      <option value="">كل القاعات</option>
      ${(()=>{const vis=_getCalVisibleRooms();return vis.map(r=>`<option value="${r.id}" ${String(_calFilterRoom)===String(r.id)?'selected':''}>${esc(r.name)}</option>`).join('');})()}
    </select>
    ${(_calFilterType||_calFilterDept||_calFilterRoom)?`<button class="btn bo btn-xs" onclick="_clearCalFilters()"><i class="fas fa-times"></i> مسح الفلاتر</button>`:''}
    <div style="margin-right:auto;display:flex;gap:6px">
      <button class="btn ${_calView==='month'?'bp':'bo'} btn-xs" onclick="_setCalView('month')"><i class="fas fa-calendar"></i></button>
      <button class="btn ${_calView==='week'?'bp':'bo'} btn-xs" onclick="_setCalView('week')"><i class="fas fa-calendar-week"></i></button>
      <button class="btn ${_calView==='list'?'bp':'bo'} btn-xs" onclick="_setCalView('list')"><i class="fas fa-list"></i></button>
    </div>
    <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;white-space:nowrap">
      <input type="checkbox" ${_calBrowseMode?'checked':''} onchange="_calBrowseMode=this.checked;renderCalendar()">
      <span>وضع التصفح فقط</span>
    </label>
  </div>`;

  if (_calView === 'list') {
    calEl.innerHTML = filterBar + _buildListView(filteredExams, isAr);
    return;
  }
  if (_calView === 'week') {
    calEl.innerHTML = filterBar + _buildWeekView(now, filteredExams, today, isAr, months, days);
    return;
  }

  calEl.innerHTML = filterBar + `
    <div style="display:grid;grid-template-columns:1fr 290px;gap:18px;align-items:start" id="calMainGrid">
      <!-- Calendar -->
      <div class="card" style="padding:20px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
          <button class="btn bo" style="width:36px;height:36px;padding:0" onclick="_calNav(-1)">
            <i class="fas fa-chevron-${isAr?'right':'left'}"></i>
          </button>
          <div style="text-align:center">
            <div style="font-size:20px;font-weight:900">${months[_calMonth]} ${_calYear}</div>
            <div style="font-size:11.5px;color:var(--txt3);margin-top:2px">
              ${(()=>{const m=`${_calYear}-${String(_calMonth+1).padStart(2,'0')}`;const n=filteredExams.filter(e=>e.date.startsWith(m)).length;return n?`${n} ${isAr?'امتحان هذا الشهر':'exams this month'}`:'';})()}
            </div>
          </div>
          <button class="btn bo" style="width:36px;height:36px;padding:0" onclick="_calNav(1)">
            <i class="fas fa-chevron-${isAr?'left':'right'}"></i>
          </button>
        </div>

        <!-- Day headers -->
        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:4px">
          ${days.map((d,i)=>`<div style="text-align:center;font-size:10.5px;font-weight:700;color:${i===5||i===6?'var(--red2)':'var(--txt3)'};padding:4px 0;background:var(--bg);border-radius:5px">${d}</div>`).join('')}
        </div>

        <!-- Day cells -->
        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px" id="calGrid">
          ${_buildBigGrid(_calYear, _calMonth, examMap, today, isAr)}
        </div>

        <!-- Legend -->
        <div style="display:flex;gap:12px;margin-top:14px;padding-top:12px;border-top:1px solid var(--border);font-size:11px;flex-wrap:wrap">
          ${Object.entries(CAL_COLORS).map(([k,c])=>`<span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:3px;background:${c.border}"></span>${isAr?c.ar:c.en}</span>`).join('')}
        </div>
      </div>

      <!-- Sidebar -->
      <div style="display:flex;flex-direction:column;gap:12px">
        <button class="btn bp" onclick="_jumpToToday()" style="height:40px">
          <i class="fas fa-crosshairs"></i> ${isAr?'اليوم':'Today'}
        </button>
        ${(isAdmin()||isCoord())?`
        <button class="btn bo" onclick="_openCalRoomSettings()" style="height:36px;font-size:12px">
          <i class="fas fa-cog" style="color:var(--teal)"></i> إعدادات القاعات
        </button>`:''}
        <div class="card" style="padding:14px">
          <div style="font-weight:700;font-size:13px;margin-bottom:12px"><i class="fas fa-chart-bar" style="color:var(--primary2);margin-inline-end:6px"></i>${isAr?'هذا الشهر':'This Month'}</div>
          ${_buildMonthStats(_calYear, _calMonth, isAr, filteredExams)}
        </div>
        ${_buildStatusSidebar(now, isAr, filteredExams)}
      </div>
    </div>
    <div id="calDayDetail" style="margin-top:14px;display:none"></div>
    <div class="mo" id="calExamMo"></div>
    <div class="mo" id="calDayMo"></div>
  `;

  // Responsive
  const grid = document.getElementById('calMainGrid');
  const fix = () => { if (grid) grid.style.gridTemplateColumns = window.innerWidth < 760 ? '1fr' : '1fr 290px'; };
  fix(); window.addEventListener('resize', fix, {passive:true});
}

function _buildBigGrid(year, month, examMap, today, isAr) {
  const firstDay = new Date(year, month, 1).getDay();
  const days     = new Date(year, month+1, 0).getDate();
  let html = '';

  for (let i=0; i<firstDay; i++) html += `<div style="min-height:82px;border-radius:8px"></div>`;

  for (let d=1; d<=days; d++) {
    const ds     = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday= ds === today;
    const exams  = examMap[ds] || [];
    const dow    = new Date(ds).getDay();
    const isWknd = dow===5 || dow===6;

    const pills = exams.slice(0,3).map(e => {
      const c   = CAL_COLORS[e.type] || CAL_COLORS.final;
      const sub = getSubject(e.subject_id);
      const nm  = (sub?.name||'—').split(' ').slice(0,2).join(' ');
      return `<div onclick="event.stopPropagation();_openCalExam(${e.id})"
        title="${sub?.name||'—'} — ${fmtTime(e.time)}"
        style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:4px;margin-top:2px;
               background:${c.bg};color:${c.text};border:1px solid ${c.border}50;
               overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;line-height:1.4"
        onmouseover="this.style.opacity=.7" onmouseout="this.style.opacity=1">
        ${fmtTime(e.time)} ${nm.length>11?nm.slice(0,9)+'…':nm}
      </div>`;
    }).join('');
    const more = exams.length>3 ? `<div style="font-size:9px;color:var(--txt3);cursor:pointer;text-align:center;margin-top:2px" onclick="showCalDayModal('${ds}')">+${exams.length-3} ${isAr?'أكثر':'more'}</div>` : '';

    html += `<div onclick="showCalDayModal('${ds}')"
      style="min-height:82px;border-radius:8px;padding:4px;cursor:${exams.length||isToday?'pointer':'default'};
             background:${isToday?'var(--primary2)':isWknd?'var(--bg)':'var(--card)'};
             border:1.5px solid ${isToday?'var(--primary2)':exams.length?'var(--primary2)25':'var(--border)'};
             box-shadow:${exams.length&&!isToday?'0 1px 4px rgba(0,0,0,.05)':'none'};
             transition:all .15s"
      onmouseover="if(!${isToday})this.style.boxShadow='0 4px 12px rgba(0,0,0,.09)';this.style.transform='translateY(-1px)'"
      onmouseout="this.style.boxShadow='${exams.length&&!isToday?'0 1px 4px rgba(0,0,0,.05)':'none'}';this.style.transform=''">
      <div style="font-size:11.5px;font-weight:${isToday?900:700};color:${isToday?'white':isWknd?'var(--red2)':'var(--txt1)'};text-align:center;margin-bottom:1px">${d}</div>
      ${pills}${more}
    </div>`;
  }
  return html;
}

function _openCalExam(examId) {
  const e    = getExam(examId); if (!e) return;
  const sub  = getSubject(e.subject_id);
  const rooms= (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
  const prts = (e.proctor_ids||[]).map(id=>getProfile(id)?.name?.split(' ').slice(0,2).join(' ')).filter(Boolean);
  const secs = (e.section_ids||[]).map(id=>getSection(id)?.name).filter(Boolean);
  const c    = CAL_COLORS[e.type]||CAL_COLORS.final;
  const isAr = typeof I18N !== 'undefined' ? I18N.isAr() : true;
  const st   = examStatus(e);

  let mo = document.getElementById('calExamMo');
  if (!mo) { mo=document.createElement('div');mo.className='mo';mo.id='calExamMo';document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:500px">
    <div class="md-hd" style="background:${c.bg};border-bottom:2px solid ${c.border}30">
      <h2 style="color:${c.text}">
        <span style="width:32px;height:32px;background:${c.border};color:white;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas ${e.type==='final'?'fa-star':e.type==='midterm'?'fa-bookmark':e.type==='quiz'?'fa-pen-alt':'fa-redo'}" style="font-size:13px"></i>
        </span>
        ${sub?.name||'—'}
      </h2>
      <button class="md-close" onclick="closeMo('calExamMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px">
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
        ${getTypeBadge(e.type)} ${getStatusBadge(st)}
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
        ${[
          ['fa-calendar','var(--primary2)',isAr?'التاريخ':'Date',fmtDate(e.date)],
          ['fa-clock','var(--gold)',isAr?'الوقت':'Time',fmtTime(e.time)],
          ['fa-hourglass','var(--teal)',isAr?'المدة':'Duration',e.duration+(isAr?' دق':' min')+(e.extra_time?` +${e.extra_time}`:'')],
          ['fa-star','var(--purple2)',isAr?'الدرجة':'Grade',String(e.max_grade||100)],
        ].map(([ic,col,lbl,val])=>`
          <div style="padding:10px;background:var(--bg);border-radius:9px;text-align:center">
            <div style="font-size:9.5px;color:var(--txt3);margin-bottom:3px"><i class="fas ${ic}" style="color:${col}"></i> ${lbl}</div>
            <div style="font-size:13px;font-weight:800;color:var(--txt1)">${val}</div>
          </div>`).join('')}
      </div>
      ${rooms.length?`<div style="margin-bottom:10px"><div style="font-size:11px;color:var(--txt3);font-weight:700;margin-bottom:5px"><i class="fas fa-door-open" style="color:var(--teal)"></i> ${isAr?'القاعات':'Rooms'}</div><div style="display:flex;gap:6px;flex-wrap:wrap">${rooms.map(r=>`<span style="padding:3px 10px;background:var(--teal)12;color:var(--teal);border-radius:20px;border:1px solid var(--teal)25;font-size:11.5px">${r}</span>`).join('')}</div></div>`:''}
      ${prts.length?`<div style="margin-bottom:10px"><div style="font-size:11px;color:var(--txt3);font-weight:700;margin-bottom:5px"><i class="fas fa-user-tie" style="color:var(--purple2)"></i> ${isAr?'المراقبون':'Proctors'}</div><div style="font-size:12.5px;color:var(--txt2)">${prts.join(' ، ')}</div></div>`:''}
      ${secs.length?`<div style="margin-bottom:10px"><div style="font-size:11px;color:var(--txt3);font-weight:700;margin-bottom:5px"><i class="fas fa-layer-group" style="color:var(--gold)"></i> ${isAr?'الشعب':'Sections'}</div><div style="font-size:12.5px;color:var(--txt2)">${secs.join(' ، ')}</div></div>`:''}
      ${e.notes?`<div style="padding:10px 12px;background:var(--gold)10;border:1px solid var(--gold)30;border-radius:9px;font-size:12.5px;color:var(--txt2)"><i class="fas fa-sticky-note" style="color:var(--gold);margin-inline-end:5px"></i>${e.notes}</div>`:''}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('calExamMo')"><i class="fas fa-times"></i> ${isAr?'إغلاق':'Close'}</button>
      <button class="btn bo" onclick="closeMo('calExamMo');exportExamPDF(${e.id})"><i class="fas fa-file-pdf" style="color:var(--red2)"></i> PDF</button>
      ${canEdit()?`<button class="btn bo" onclick="closeMo('calExamMo');UI.showPage('exams');setTimeout(()=>openEditExam(${e.id}),300)"><i class="fas fa-edit"></i> ${isAr?'تعديل':'Edit'}</button>`:''}
    </div>
  </div>`;
  showMo('calExamMo');
}

function showCalDay(dateStr) {
  const panel  = document.getElementById('calDayDetail'); if (!panel) return;
  const isAr   = typeof I18N !== 'undefined' ? I18N.isAr() : true;
  const dayExms= STATE.exams.filter(e=>e.date===dateStr).sort((a,b)=>a.time?.localeCompare(b.time));
  if (!dayExms.length) { panel.style.display='none'; return; }
  panel.style.display='block';
  panel.innerHTML=`<div class="card" style="padding:18px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <div style="font-weight:800;font-size:14px"><i class="fas fa-calendar-day" style="color:var(--primary2);margin-inline-end:7px"></i>${isAr?'امتحانات':'Exams:'} ${fmtDate(dateStr)} <span class="badge b-blue">${dayExms.length}</span></div>
      <button class="btn bo btn-xs" onclick="document.getElementById('calDayDetail').style.display='none'"><i class="fas fa-times"></i></button>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px">
      ${dayExms.map(e=>{
        const sub=getSubject(e.subject_id);const c=CAL_COLORS[e.type]||CAL_COLORS.final;
        const rooms=(e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
        const prts=(e.proctor_ids||[]).map(id=>getProfile(id)?.name?.split(' ').slice(0,2).join(' ')).filter(Boolean);
        return `<div onclick="_openCalExam(${e.id})" style="padding:14px;border-radius:10px;background:var(--bg);border-top:3px solid ${c.border};border:1.5px solid ${c.border}30;border-top:3px solid ${c.border};cursor:pointer;transition:all .15s" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform=''">
          <div style="font-weight:800;font-size:13px;margin-bottom:6px">${sub?.name||'—'}</div>
          <div style="font-size:11.5px;color:var(--txt2);display:flex;gap:10px;flex-wrap:wrap">
            <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}${isAr?'د':'m'})</span>
            ${rooms.length?`<span><i class="fas fa-door-open" style="color:var(--teal)"></i> ${rooms.join(', ')}</span>`:''}
          </div>
          ${prts.length?`<div style="font-size:11px;color:var(--txt3);margin-top:4px"><i class="fas fa-user-tie" style="color:var(--purple2)"></i> ${prts.join(', ')}</div>`:''}
        </div>`;
      }).join('')}
    </div>
  </div>`;
  panel.scrollIntoView({behavior:'smooth',block:'nearest'});
}

function _buildMonthStats(year, month, isAr=true, examsPool) {
  const ms=`${year}-${String(month+1).padStart(2,'0')}`;
  const pool = examsPool || STATE.exams;
  const me=pool.filter(e=>e.date.startsWith(ms));
  if(!me.length) return `<div style="color:var(--txt3);font-size:12px;text-align:center;padding:8px">${isAr?'لا يوجد':'No exams'}</div>`;
  const by={final:0,midterm:0,quiz:0,makeup:0};
  me.forEach(e=>{if(by[e.type]!==undefined)by[e.type]++;});
  return `<div style="display:grid;grid-template-columns:1fr 1fr;gap:7px">
    <div style="padding:10px;border-radius:8px;background:var(--primary)10;text-align:center;grid-column:1/-1">
      <div style="font-size:22px;font-weight:900;color:var(--primary2)">${me.length}</div>
      <div style="font-size:10.5px;color:var(--txt2)">${isAr?'إجمالي':'Total'}</div>
    </div>
    ${Object.entries(by).filter(([,c])=>c>0).map(([t,n])=>{const c=CAL_COLORS[t];return `<div style="padding:8px;border-radius:8px;background:${c.bg};text-align:center"><div style="font-size:18px;font-weight:900;color:${c.text}">${n}</div><div style="font-size:10px;color:${c.text}">${isAr?c.ar:c.en}</div></div>`;}).join('')}
  </div>`;
}

function _buildUpcomingList(now, isAr=true) {
  const up=STATE.exams.filter(e=>new Date(`${e.date}T${e.time}`)>=now).sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`)).slice(0,7);
  if(!up.length) return `<div style="color:var(--txt3);font-size:12px;text-align:center;padding:8px">${isAr?'لا يوجد':'None'}</div>`;
  const tod=now.toISOString().split('T')[0];
  return up.map(e=>{const sub=getSubject(e.subject_id);const c=CAL_COLORS[e.type]||CAL_COLORS.final;
    return `<div onclick="_openCalExam(${e.id})" style="display:flex;gap:8px;padding:8px;border-radius:8px;margin-bottom:5px;cursor:pointer;background:var(--bg);border:1px solid var(--border);transition:all .15s" onmouseover="this.style.background='var(--primary-bg)'" onmouseout="this.style.background='var(--bg)'">
      <div style="width:4px;border-radius:2px;background:${c.border};flex-shrink:0"></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${sub?.name||'—'}</div>
        <div style="font-size:10.5px;color:var(--txt3)">${e.date===tod?`<b style="color:var(--gold)">${isAr?'اليوم':'Today'}</b>`:fmtDate(e.date)} · ${fmtTime(e.time)}</div>
      </div>
    </div>`;}).join('');
}

function _buildStatusSidebar(now, isAr=true, examsPool) {
  const pool = examsPool || STATE.exams;
  const todayStr = now.toISOString().split('T')[0];

  const active   = pool.filter(e => examStatus(e) === 'active').slice(0,3);
  const upcoming = pool.filter(e => examStatus(e) === 'upcoming').sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`)).slice(0,3);
  const completed= pool.filter(e => examStatus(e) === 'completed').sort((a,b) => new Date(`${b.date}T${b.time}`) - new Date(`${a.date}T${a.time}`)).slice(0,3);

  function examCard(e, borderColor) {
    const sub = getSubject(e.subject_id);
    return `<div onclick="_openCalExam(${e.id})" style="display:flex;gap:8px;padding:8px 10px;border-radius:8px;margin-bottom:5px;cursor:pointer;background:var(--bg);border:1px solid var(--border);transition:all .15s" onmouseover="this.style.transform='translateX(-2px)'" onmouseout="this.style.transform=''">
      <div style="width:3px;border-radius:2px;background:${borderColor};flex-shrink:0;align-self:stretch"></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${sub?.name||'—'}</div>
        <div style="font-size:10px;color:var(--txt3)">${fmtDate(e.date)} · ${fmtTime(e.time)}</div>
      </div>
      <i class="fas fa-chevron-left" style="font-size:9px;color:var(--txt3);align-self:center;flex-shrink:0"></i>
    </div>`;
  }

  const sections = [];

  if (active.length) {
    sections.push(`<div class="card" style="padding:14px;border-right:3px solid var(--green2)">
      <div style="font-weight:700;font-size:12.5px;margin-bottom:8px;display:flex;align-items:center;gap:7px">
        <span style="width:8px;height:8px;border-radius:50%;background:var(--green2);animation:pulse 1.2s infinite"></span>
        ${isAr?'جارية الآن':'Live Now'}
        <span class="badge b-green" style="font-size:9px">${active.length}</span>
      </div>
      ${active.map(e=>examCard(e,'#10b981')).join('')}
    </div>`);
  }

  if (upcoming.length) {
    sections.push(`<div class="card" style="padding:14px">
      <div style="font-weight:700;font-size:12.5px;margin-bottom:8px;display:flex;align-items:center;gap:7px;color:var(--txt1)">
        <i class="fas fa-clock" style="color:var(--primary2);font-size:12px"></i>
        ${isAr?'القادمة':'Upcoming'}
        <span class="badge b-blue" style="font-size:9px">${upcoming.length}</span>
      </div>
      ${upcoming.map(e=>examCard(e,'#3b82f6')).join('')}
    </div>`);
  }

  if (completed.length) {
    sections.push(`<div class="card" style="padding:14px">
      <div style="font-weight:700;font-size:12.5px;margin-bottom:8px;display:flex;align-items:center;gap:7px;color:var(--txt2)">
        <i class="fas fa-check-circle" style="color:var(--txt3);font-size:12px"></i>
        ${isAr?'المنتهية':'Completed'}
        <span class="badge b-gray" style="font-size:9px">${completed.length}</span>
      </div>
      ${completed.map(e=>examCard(e,'#94a3b8')).join('')}
    </div>`);
  }

  return sections.join('') || `<div class="card" style="padding:14px;text-align:center;color:var(--txt3);font-size:12px">
    <i class="fas fa-calendar" style="font-size:20px;margin-bottom:8px;display:block;opacity:.3"></i>
    ${isAr?'لا توجد امتحانات':'No exams found'}
  </div>`;
}

// ── Day Detail Modal (shown when clicking a day cell) ──────────────────
function showCalDayModal(dateStr) {
  if (_calBrowseMode) return; // وضع التصفح - لا فتح تفاصيل
  const isAr = typeof I18N !== 'undefined' ? I18N.isAr() : true;
  const visibleRooms = _getCalVisibleRooms ? _getCalVisibleRooms() : STATE.rooms;
  const roomIds = new Set(visibleRooms.map(r=>r.id));
  const dayExms = STATE.exams.filter(e=>{
    if (e.date !== dateStr) return false;
    if (_calFilterType && e.type !== _calFilterType) return false;
    if (_calFilterDept) { const s=STATE.subjects.find(x=>x.id===e.subject_id); if(!s||String(s.dept_id)!==String(_calFilterDept)) return false; }
    if (_calFilterRoom && !(e.room_ids||[]).map(String).includes(String(_calFilterRoom))) return false;
    return true;
  }).sort((a,b)=>a.time?.localeCompare(b.time));

  let mo = document.getElementById('calDayMo');
  if (!mo) { mo=document.createElement('div'); mo.className='mo'; mo.id='calDayMo'; document.body.appendChild(mo); }

  if (!dayExms.length) return;

  mo.innerHTML = `<div class="md" style="max-width:580px">
    <div class="md-hd" style="padding:18px 22px">
      <h2><i class="fas fa-calendar-day" style="color:var(--primary2)"></i> ${isAr?'امتحانات':'Exams:'} ${fmtDate(dateStr)}</h2>
      <button class="md-close" onclick="closeMo('calDayMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:14px 20px">
      <div style="display:flex;flex-direction:column;gap:10px">
        ${dayExms.map(e => {
          const sub=getSubject(e.subject_id);
          const c=CAL_COLORS[e.type]||CAL_COLORS.final;
          const rooms=(e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
          const prts=(e.proctor_ids||[]).map(id=>getProfile(id)?.name?.split(' ').slice(0,2).join(' ')).filter(Boolean);
          const st = examStatus(e);
          const stColors = {active:'var(--green2)',upcoming:'var(--primary2)',completed:'var(--txt3)'};
          const stLabels = {active:isAr?'جارٍ':'Live',upcoming:isAr?'قادم':'Upcoming',completed:isAr?'منتهٍ':'Done'};
          return `<div style="padding:14px;border-radius:12px;background:var(--bg);border-top:3px solid ${c.border};border:1.5px solid ${c.border}30;border-top:3px solid ${c.border}">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:8px">
              <div style="flex:1">
                <div style="font-weight:800;font-size:14px;color:var(--txt1)">${sub?.name||'—'}</div>
                ${sub?.code?`<div style="font-size:11px;color:var(--txt3);font-family:monospace">${sub.code}</div>`:''}
              </div>
              <div style="display:flex;gap:5px;flex-shrink:0">
                ${getTypeBadge(e.type)}
                <span class="badge" style="background:${stColors[st]||'var(--border)'}20;color:${stColors[st]||'var(--txt2)'}">
                  ${stLabels[st]||st}
                </span>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:8px">
              <div style="background:var(--card);border-radius:7px;padding:6px 8px;text-align:center">
                <div style="font-size:9px;color:var(--txt3);margin-bottom:2px"><i class="fas fa-clock" style="color:var(--gold)"></i> ${isAr?'الوقت':'Time'}</div>
                <div style="font-size:12px;font-weight:800">${fmtTime(e.time)}</div>
              </div>
              <div style="background:var(--card);border-radius:7px;padding:6px 8px;text-align:center">
                <div style="font-size:9px;color:var(--txt3);margin-bottom:2px"><i class="fas fa-hourglass" style="color:var(--teal)"></i> ${isAr?'المدة':'Duration'}</div>
                <div style="font-size:12px;font-weight:800">${e.duration}${isAr?'د':'m'}</div>
              </div>
              <div style="background:var(--card);border-radius:7px;padding:6px 8px;text-align:center">
                <div style="font-size:9px;color:var(--txt3);margin-bottom:2px"><i class="fas fa-star" style="color:var(--purple2)"></i> ${isAr?'الدرجة':'Grade'}</div>
                <div style="font-size:12px;font-weight:800">${e.max_grade||100}</div>
              </div>
            </div>
            ${rooms.length?`<div style="font-size:11px;color:var(--txt2);margin-bottom:4px"><i class="fas fa-door-open" style="color:var(--teal)"></i> ${rooms.join('، ')}</div>`:''}
            ${prts.length?`<div style="font-size:11px;color:var(--txt2);margin-bottom:4px"><i class="fas fa-user-tie" style="color:var(--purple2)"></i> ${prts.join('، ')}</div>`:''}
            <div style="display:flex;gap:6px;margin-top:8px">
              <button class="btn bo btn-xs" style="flex:1" onclick="closeMo('calDayMo');_openCalExam(${e.id})">
                <i class="fas fa-eye"></i> ${isAr?'التفاصيل':'Details'}
              </button>
              <button class="btn bo btn-xs" style="flex:1" onclick="closeMo('calDayMo');exportExamPDF(${e.id})">
                <i class="fas fa-file-pdf" style="color:var(--red2)"></i> PDF
              </button>
              ${canEdit()?`<button class="btn bo btn-xs" style="flex:1" onclick="closeMo('calDayMo');UI.showPage('exams');setTimeout(()=>openEditExam(${e.id}),300)">
                <i class="fas fa-edit"></i> ${isAr?'تعديل':'Edit'}
              </button>`:''}
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('calDayMo')">
        <i class="fas fa-arrow-right"></i> ${isAr?'رجوع':'Back'}
      </button>
    </div>
  </div>`;
  showMo('calDayMo');
}

function _jumpToToday() {
  const n=new Date(); _calYear=n.getFullYear(); _calMonth=n.getMonth();
  renderCalendar();
  setTimeout(()=>showCalDayModal(n.toISOString().split('T')[0]),200);
}

function _calNav(dir) {
  _calMonth += dir;
  if (_calMonth>11){_calMonth=0;_calYear++;}
  if (_calMonth<0) {_calMonth=11;_calYear--;}
  renderCalendar();
}

// ── الدوال المساعدة الجديدة للتقويم v7 ────────────────────────

function _buildCalendarActions() {
  const actsEl = document.getElementById('calendarActs');
  if (!actsEl) return;
  if (canEdit()) {
    actsEl.innerHTML = `
      <button class="btn bo btn-sm" onclick="_openCalRoomSettings()">
        <i class="fas fa-cog" style="color:var(--teal)"></i> إعدادات القاعات
      </button>
      <button class="btn bp btn-sm" onclick="UI.showPage('exams');setTimeout(openAddExam,200)">
        <i class="fas fa-plus"></i> امتحان جديد
      </button>`;
  }
}

function _getCalVisibleRooms() {
  const hiddenRooms = STATE.settings?.cal_hidden_rooms || [];
  return STATE.rooms.filter(r => !hiddenRooms.includes(r.id));
}

function _setCalFilter(type, val) {
  if (type === 'type') _calFilterType = val;
  if (type === 'dept') _calFilterDept = val;
  if (type === 'room') _calFilterRoom = val;
  renderCalendar();
}

function _clearCalFilters() {
  _calFilterType = '';
  _calFilterDept = '';
  _calFilterRoom = '';
  renderCalendar();
}

function _setCalView(v) {
  _calView = v;
  renderCalendar();
}

function _openCalRoomSettings() {
  if (!isAdmin() && !isCoord()) return;
  const hidden = STATE.settings?.cal_hidden_rooms || [];
  let mo = document.getElementById('calRoomSettingsMo');
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = 'calRoomSettingsMo'; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-cog" style="color:var(--teal)"></i> إعدادات القاعات في التقويم</h2>
      <button class="md-close" onclick="closeMo('calRoomSettingsMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px 22px">
      <div style="font-size:12.5px;color:var(--txt2);margin-bottom:14px">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        اختر القاعات التي تظهر في التقويم العام. القاعات المخفية تُلغى من التقويم فقط ولا تُحذف من النظام.
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${STATE.rooms.map(r => {
          const isVisible = !hidden.includes(r.id);
          const info = typeof getRoomTypeInfo === 'function' ? getRoomTypeInfo(r.type) : {icon:'fa-door-open',color:'var(--teal)'};
          return `<label style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:10px;background:var(--bg);border:1.5px solid var(--border);cursor:pointer">
            <input type="checkbox" id="calrv_${r.id}" ${isVisible?'checked':''} style="accent-color:var(--teal)">
            <i class="fas ${info.icon}" style="color:${info.color};font-size:14px;flex-shrink:0"></i>
            <div style="flex:1">
              <div style="font-weight:700;font-size:13px">${esc(r.name)}</div>
              <div style="font-size:11px;color:var(--txt3)">سعة: ${r.cap} · ${r.type||'—'}</div>
            </div>
            <span style="font-size:11px;color:${isVisible?'var(--green2)':'var(--txt3)'}">${isVisible?'ظاهرة':'مخفية'}</span>
          </label>`;
        }).join('')}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('calRoomSettingsMo')">إلغاء</button>
      <button class="btn bp" onclick="_saveCalRoomSettings()"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('calRoomSettingsMo');
}

async function _saveCalRoomSettings() {
  const hidden = STATE.rooms.filter(r => !document.getElementById(`calrv_${r.id}`)?.checked).map(r => r.id);
  if (!STATE.settings) STATE.settings = {};
  STATE.settings.cal_hidden_rooms = hidden;
  try {
    await SB.upsert('settings', { key: 'cal_hidden_rooms', value: JSON.stringify(hidden) });
    toast('✓ تم حفظ إعدادات القاعات', 'success');
  } catch (e) {
    toast('خطأ في الحفظ: ' + e.message, 'error');
  }
  closeMo('calRoomSettingsMo');
  renderCalendar();
}

// عرض القائمة (List View)
function _buildListView(exams, isAr) {
  const sorted = [...exams].sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));
  if (!sorted.length) return `<div class="card" style="padding:40px;text-align:center;color:var(--txt3)"><i class="fas fa-calendar" style="font-size:32px;opacity:.3;display:block;margin-bottom:10px"></i>لا توجد امتحانات</div>`;

  const groups = {};
  sorted.forEach(e => {
    const m = e.date.slice(0,7);
    if (!groups[m]) groups[m] = [];
    groups[m].push(e);
  });

  return Object.entries(groups).map(([month, exs]) => {
    const [y,m] = month.split('-');
    const label = `${MONTHS_AR[parseInt(m)-1]} ${y}`;
    return `<div style="margin-bottom:20px">
      <div style="font-size:13px;font-weight:800;color:var(--txt2);margin-bottom:10px;padding:6px 12px;background:var(--bg);border-radius:8px;display:flex;align-items:center;gap:8px">
        <i class="fas fa-calendar-alt" style="color:var(--primary2)"></i>${label}
        <span class="badge b-blue" style="font-size:10px">${exs.length}</span>
      </div>
      ${exs.map(e => {
        const sub = getSubject(e.subject_id);
        const c = CAL_COLORS[e.type]||CAL_COLORS.final;
        const rooms = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
        const prts  = (e.proctor_ids||[]).map(id=>getProfile(id)?.name?.split(' ').slice(0,2).join(' ')).filter(Boolean);
        const st    = examStatus(e);
        const dow   = new Date(e.date).getDay();
        const days  = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
        return `<div onclick="_openCalExam(${e.id})" style="display:flex;gap:14px;padding:14px 16px;background:var(--card);border-radius:12px;border:1.5px solid var(--border);margin-bottom:8px;cursor:pointer;transition:all .15s;border-right:4px solid ${c.border}" onmouseover="this.style.transform='translateX(-3px)'" onmouseout="this.style.transform=''">
          <div style="min-width:50px;text-align:center">
            <div style="font-size:22px;font-weight:900;color:${c.text}">${parseInt(e.date.split('-')[2])}</div>
            <div style="font-size:10px;color:var(--txt3)">${days[dow]}</div>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:800;font-size:14px;margin-bottom:4px">${sub?.name||'—'}</div>
            <div style="font-size:12px;color:var(--txt2);display:flex;gap:12px;flex-wrap:wrap">
              <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}د)</span>
              ${rooms.length?`<span><i class="fas fa-door-open" style="color:var(--teal)"></i> ${rooms.join('، ')}</span>`:''}
            </div>
            ${prts.length?`<div style="font-size:11px;color:var(--txt3);margin-top:4px"><i class="fas fa-user-tie" style="color:var(--purple2)"></i> ${prts.join('، ')}</div>`:''}
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
            ${getTypeBadge(e.type)}
            ${getStatusBadge(st)}
          </div>
        </div>`;
      }).join('')}
    </div>`;
  }).join('');
}

// عرض الأسبوع (Week View)
function _buildWeekView(now, exams, today, isAr, months, days) {
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());

  const weekDays = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    weekDays.push(d);
  }

  const examsByDate = {};
  exams.forEach(e => {
    if (!examsByDate[e.date]) examsByDate[e.date] = [];
    examsByDate[e.date].push(e);
  });

  const nav = `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
    <button class="btn bo" onclick="_weekNav(-1)"><i class="fas fa-chevron-right"></i></button>
    <div style="font-weight:800;font-size:15px">${months[startOfWeek.getMonth()]} ${startOfWeek.getFullYear()}</div>
    <button class="btn bo" onclick="_weekNav(1)"><i class="fas fa-chevron-left"></i></button>
  </div>`;

  const grid = `<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:8px">
    ${weekDays.map((d, i) => {
      const ds = d.toISOString().split('T')[0];
      const isToday = ds === today;
      const dayExams = examsByDate[ds] || [];
      const isWknd = i === 5 || i === 6;
      return `<div style="min-height:140px;background:var(--card);border-radius:12px;padding:10px;border:1.5px solid ${isToday?'var(--primary2)':'var(--border)'};${isToday?'box-shadow:0 0 0 3px var(--primary2)20':''}" onclick="${_calBrowseMode?'':''}" >
        <div style="font-size:10.5px;font-weight:800;color:${isToday?'var(--primary2)':isWknd?'var(--red2)':'var(--txt2)'};text-align:center;margin-bottom:6px">
          ${days[i]}
          <div style="font-size:16px;font-weight:${isToday?900:700};margin-top:1px;${isToday?'color:var(--primary2)':''}">${d.getDate()}</div>
        </div>
        ${dayExams.map(e => {
          const c = CAL_COLORS[e.type]||CAL_COLORS.final;
          const sub = getSubject(e.subject_id);
          return `<div onclick="event.stopPropagation();_openCalExam(${e.id})" style="font-size:9px;font-weight:700;padding:3px 5px;border-radius:5px;margin-top:3px;background:${c.bg};color:${c.text};border:1px solid ${c.border}40;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${sub?.name||''}">
            ${fmtTime(e.time)} ${(sub?.name||'').slice(0,12)}
          </div>`;
        }).join('')}
      </div>`;
    }).join('')}
  </div>`;

  return `<div class="card" style="padding:20px">${nav}${grid}</div>`;
}

let _weekOffset = 0;
function _weekNav(dir) {
  // سيتم تحسينها في نسخة قادمة — حالياً تعيد رسم الشهر
  _calNav(dir > 0 ? 0 : 0); renderCalendar();
}
