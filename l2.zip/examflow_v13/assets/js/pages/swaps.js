// ═══════════════════════════════════════════════════════════════
//  swaps.js — طلبات المراقبة والتبادل بين المراقبين
// ═══════════════════════════════════════════════════════════════

function renderSwaps() {
  const el = document.getElementById('swapsContent');
  if (!el) return;

  const uid  = STATE.currentUser?.id;
  const role = STATE.currentUser?.role;
  if (!uid) { el.innerHTML = ''; return; }

  if (role === 'proctor') {
    _renderProctorSwapsPage(el, uid);
  } else {
    _renderAdminSwapsPage(el, uid);
  }
}

// ════════════════════════════════════════
//  واجهة المراقب
// ════════════════════════════════════════
function _renderProctorSwapsPage(el, uid) {
  const now  = new Date();
  const sem  = STATE.currentSem;

  // 1. تعيينات امتحانات تنتظر الرد
  const pendingAssign = STATE.exams.filter(e =>
    e.semester === sem &&
    (e.proctor_ids || []).includes(uid) &&
    (e.proctor_statuses || {})[uid] === 'pending'
  ).sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  // 2. طلبات التبادل الواردة (طرف مستقبِل)
  const incomingSwaps = STATE.swapRequests.filter(r =>
    r.target_id === uid && r.status === 'pending'
  ).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  // 3. طلبات التبادل الصادرة (طرف مُرسِل)
  const outgoingSwaps = STATE.swapRequests.filter(r =>
    r.requester_id === uid
  ).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  // إحصاءات سريعة
  const total = pendingAssign.length + incomingSwaps.length;

  el.innerHTML = `
    <!-- شريط الأدوات -->
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:16px">
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        ${total > 0
          ? `<span style="padding:5px 12px;background:var(--red2)12;border:1.5px solid var(--red2)30;border-radius:20px;font-size:12px;font-weight:700;color:var(--red2)">
               <i class="fas fa-bell" style="margin-left:5px"></i>${total} طلب يحتاج ردك
             </span>`
          : `<span style="padding:5px 12px;background:var(--green2)10;border:1px solid var(--green2)20;border-radius:20px;font-size:12px;color:var(--green2)">
               <i class="fas fa-check-circle" style="margin-left:5px"></i>لا توجد طلبات معلقة
             </span>`
        }
      </div>
      <button class="btn bp btn-sm" onclick="openNewSwapRequest()">
        <i class="fas fa-exchange-alt"></i> طلب تبادل جديد
      </button>
    </div>

    <!-- تعيينات المراقبة المعلقة -->
    ${pendingAssign.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--red2)">
      <div class="card-h">
        <h3><i class="fas fa-bell" style="color:var(--red2)"></i>
          تعيينات تنتظر ردك
          <span class="badge b-red" style="font-size:10px;margin-right:8px">${pendingAssign.length}</span>
        </h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${pendingAssign.map(e => _buildAssignCard(e, uid)).join('')}
      </div>
    </div>` : ''}

    <!-- طلبات التبادل الواردة -->
    ${incomingSwaps.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--gold)">
      <div class="card-h">
        <h3><i class="fas fa-arrow-down" style="color:var(--gold)"></i>
          طلبات التبادل الواردة
          <span class="badge b-gold" style="font-size:10px;margin-right:8px">${incomingSwaps.length}</span>
        </h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${incomingSwaps.map(r => _buildIncomingSwapCard(r, uid)).join('')}
      </div>
    </div>` : ''}

    <!-- طلبات التبادل الصادرة -->
    ${outgoingSwaps.length ? `
    <div class="card" style="margin-bottom:14px">
      <div class="card-h">
        <h3><i class="fas fa-arrow-up" style="color:var(--primary2)"></i>
          طلباتي المُرسَلة (${outgoingSwaps.length})
        </h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${outgoingSwaps.map(r => _buildOutgoingSwapCard(r, uid)).join('')}
      </div>
    </div>` : ''}

    ${!pendingAssign.length && !incomingSwaps.length && !outgoingSwaps.length ? `
    <div style="text-align:center;padding:60px 20px">
      <i class="fas fa-exchange-alt" style="font-size:56px;opacity:.15;display:block;margin-bottom:16px"></i>
      <h3 style="margin-bottom:8px;font-size:18px">لا توجد طلبات</h3>
      <p style="color:var(--txt2);margin-bottom:20px">يمكنك إنشاء طلب تبادل مراقبة مع زميل</p>
      <button class="btn bp" onclick="openNewSwapRequest()">
        <i class="fas fa-plus"></i> طلب تبادل جديد
      </button>
    </div>` : ''}
  `;
}

// ── بطاقة تعيين مراقبة ──────────────────────────────────────
function _buildAssignCard(e, uid) {
  const sub  = getSubject(e.subject_id);
  const rp   = e.room_proctors || {};
  const myRid= (e.room_ids||[]).find(rid => { const a=rp[String(rid)]; return a&&a.includes(uid); });
  const room = myRid ? getRoom(myRid)?.name : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join('، ');
  const typeColors = { final:'#2563eb',midterm:'#d97706',quiz:'#0891b2',makeup:'#7c3aed' };
  const typeLabels = { final:'نهائي',midterm:'منتصف الفصل',quiz:'اختبار',makeup:'تعويضي' };

  return `<div style="padding:14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--red2)20;margin-bottom:10px">
    <div style="display:flex;align-items:start;gap:12px;margin-bottom:10px">
      <div style="width:44px;height:44px;border-radius:12px;background:${typeColors[e.type]||'var(--primary)'}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-file-alt" style="color:${typeColors[e.type]||'var(--primary)'};font-size:19px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:800;font-size:14px;margin-bottom:4px">${esc(sub?.name||'—')}</div>
        <div style="font-size:12px;color:var(--txt2);display:flex;gap:10px;flex-wrap:wrap">
          <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)}</span>
          <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}د)</span>
          ${room?`<span><i class="fas fa-door-open" style="color:var(--teal)"></i> ${esc(room)}</span>`:''}
        </div>
        <div style="margin-top:5px">
          ${getTypeBadge(e.type)}
          <span class="badge b-red" style="font-size:10px;margin-right:5px"><i class="fas fa-hourglass-half"></i> تنتظر ردك</span>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-sm" style="flex:1;background:var(--green2);color:white;border:none;height:40px"
        onclick="proctorAcceptAssignment(${e.id})">
        <i class="fas fa-check"></i> قبول المراقبة
      </button>
      <button class="btn btn-sm" style="flex:1;background:var(--red2)12;color:var(--red2);border:1.5px solid var(--red2)30;height:40px"
        onclick="proctorRejectAssignment(${e.id})">
        <i class="fas fa-times"></i> رفض / طلب بديل
      </button>
    </div>
  </div>`;
}

// ── بطاقة طلب تبادل وارد ──────────────────────────────────
function _buildIncomingSwapCard(r, uid) {
  const requester = getProfile(r.requester_id);
  const exam      = getExam(r.exam_id);
  const sub       = exam ? getSubject(exam.subject_id) : null;

  return `<div style="padding:14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--gold)20;margin-bottom:10px">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <div style="width:40px;height:40px;border-radius:10px;background:${requester?.color||'var(--gold)'}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-user-check" style="color:${requester?.color||'var(--gold)'};font-size:16px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px">${esc(requester?.name||'مراقب')}</div>
        <div style="font-size:11.5px;color:var(--txt2)">يطلب تبادل مراقبة امتحان:
          <strong style="color:var(--txt)">${esc(sub?.name||'—')}</strong>
        </div>
        ${exam ? `<div style="font-size:11px;color:var(--txt3);margin-top:2px">
          ${fmtDate(exam.date)} · ${fmtTime(exam.time)} (${exam.duration}د)
        </div>` : ''}
        ${r.reason ? `<div style="margin-top:6px;padding:6px 10px;background:var(--gold)08;border-radius:7px;font-size:11.5px;border-right:3px solid var(--gold)50">
          <i class="fas fa-comment" style="color:var(--gold);margin-left:4px"></i>${esc(r.reason)}
        </div>` : ''}
      </div>
      <div style="font-size:10px;color:var(--txt3);text-align:center;flex-shrink:0">
        ${fmtDateTime(r.created_at)}
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-sm" style="flex:1;background:var(--green2);color:white;border:none"
        onclick="_acceptSwapRequest(${r.id})">
        <i class="fas fa-check"></i> قبول التبادل
      </button>
      <button class="btn btn-sm" style="flex:1;background:var(--red2)12;color:var(--red2);border:1.5px solid var(--red2)30"
        onclick="_rejectSwapRequest(${r.id})">
        <i class="fas fa-times"></i> رفض
      </button>
    </div>
  </div>`;
}

// ── بطاقة طلب تبادل صادر ──────────────────────────────────
function _buildOutgoingSwapCard(r, uid) {
  const target = getProfile(r.target_id);
  const exam   = getExam(r.exam_id);
  const sub    = exam ? getSubject(exam.subject_id) : null;
  const statusMap = {
    pending:  { lbl:'في الانتظار', cls:'b-gold', icon:'fa-hourglass-half' },
    approved: { lbl:'تم القبول',   cls:'b-green', icon:'fa-check-circle' },
    rejected: { lbl:'تم الرفض',    cls:'b-red',   icon:'fa-times-circle' }
  };
  const st = statusMap[r.status] || statusMap.pending;

  return `<div style="padding:12px 14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--border);margin-bottom:8px;display:flex;align-items:center;gap:12px">
    <div style="width:38px;height:38px;border-radius:10px;background:var(--primary)12;display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <i class="fas fa-arrow-up" style="color:var(--primary);font-size:14px"></i>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:13px">طلب تبادل → ${esc(target?.name?.split(' ').slice(0,2).join(' ')||'—')}</div>
      <div style="font-size:11.5px;color:var(--txt2)">${esc(sub?.name||'—')} · ${exam?fmtDate(exam.date):''}</div>
      ${r.reason?`<div style="font-size:11px;color:var(--txt3);margin-top:2px">${esc(r.reason)}</div>`:''}
      ${r.response&&r.status!=='pending'?`<div style="font-size:11px;color:var(--txt2);margin-top:2px;font-style:italic">ردّ: ${esc(r.response)}</div>`:''}
    </div>
    <div style="flex-shrink:0;text-align:center">
      <span class="badge ${st.cls}" style="font-size:10.5px"><i class="fas ${st.icon}" style="margin-left:4px"></i>${st.lbl}</span>
      ${r.status==='pending'?`<div style="margin-top:5px">
        <button class="btn bd btn-xs" onclick="_cancelSwapRequest(${r.id})">
          <i class="fas fa-trash"></i>
        </button>
      </div>`:''}
    </div>
  </div>`;
}

// ════════════════════════════════════════
//  قبول / رفض تعيين مراقبة
// ════════════════════════════════════════
async function proctorAcceptAssignment(examId) {
  const uid  = STATE.currentUser?.id;
  if (!uid) return;
  try {
    // ✅ تحديث الحالة في الامتحان
    await SB.updateProctorStatus(examId, uid, 'accepted');

    // ✅ منح نقاط الامتحان للمراقب — تُضاف إلى رصيده
    const exam = getExam(examId);
    const earnedPts = (typeof calcPoints === 'function') ? (calcPoints(exam) || 0) : 0;
    if (earnedPts > 0) {
      const me = STATE.profiles.find(p => p.id === uid);
      if (me) {
        const currentPts = parseFloat(me.points) || 0;
        const newPts = Math.round((currentPts + earnedPts) * 10) / 10;
        try {
          await SB.update('profiles', uid, { points: newPts });
          me.points = newPts;
          if (STATE.currentUser) STATE.currentUser.points = newPts;
        } catch (e) {
          console.warn('[points] update failed:', e.message);
        }
      }
    }

    toast(`✓ تم قبول المراقبة${earnedPts>0?` — تمت إضافة ${earnedPts} نقطة`:''}`, 'success', 4000);
    const sub  = getSubject(exam?.subject_id);
    await addLog(`قبول تعيين مراقبة (+${earnedPts} نقطة)`, 'proctor', sub?.name || '');
    // إشعار المنسق/المسؤول
    await _notifyCoordAboutResponse(examId, uid, 'accepted');
    renderSwaps();
    UI.buildNav?.();
    UI.renderCurrentPage?.();
  } catch(e) {
    toast('خطأ: ' + e.message, 'error');
  }
}

async function proctorRejectAssignment(examId) {
  const uid = STATE.currentUser?.id;
  if (!uid) return;
  _openRejectAssignmentModal(examId, uid);
}

function _openRejectAssignmentModal(examId, uid) {
  const e   = getExam(examId);
  const sub = getSubject(e?.subject_id);
  const moId = 'rejectAssignMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-times-circle" style="color:var(--red2)"></i> رفض المراقبة</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="padding:12px 14px;background:var(--bg);border-radius:10px;margin-bottom:14px;font-size:12.5px">
        <strong>${esc(sub?.name||'—')}</strong> · ${fmtDate(e?.date||'')} ${fmtTime(e?.time||'')}
      </div>
      <div class="field">
        <label class="field-lbl">سبب الرفض (اختياري)</label>
        <textarea id="rjReason" rows="3" placeholder="مثال: تعارض مع محاضرة، ظرف طارئ..."></textarea>
      </div>
      <div style="padding:10px 14px;background:var(--gold)08;border-radius:9px;border:1px solid var(--gold)25;font-size:12.5px">
        <i class="fas fa-info-circle" style="color:var(--gold);margin-left:6px"></i>
        سيتلقى المنسق إشعاراً بالرفض ويتم اقتراح مراقب بديل
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bd" onclick="_doRejectAssignment(${examId},'${moId}')">
        <i class="fas fa-times"></i> تأكيد الرفض
      </button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _doRejectAssignment(examId, moId) {
  const uid    = STATE.currentUser?.id;
  const reason = document.getElementById('rjReason')?.value?.trim() || '';
  if (!uid) return;
  try {
    // ✅ إذا كان المراقب قد قَبِل سابقاً ثم رفض — اخصم النقاط التي مُنحت له
    const exam = getExam(examId);
    const wasAccepted = (exam?.proctor_statuses||{})[uid] === 'accepted';
    let deductedPts = 0;
    if (wasAccepted && typeof calcPoints === 'function') {
      deductedPts = calcPoints(exam) || 0;
      if (deductedPts > 0) {
        const me = STATE.profiles.find(p => p.id === uid);
        if (me) {
          const currentPts = parseFloat(me.points) || 0;
          const newPts = Math.max(0, Math.round((currentPts - deductedPts) * 10) / 10);
          try {
            await SB.update('profiles', uid, { points: newPts });
            me.points = newPts;
            if (STATE.currentUser) STATE.currentUser.points = newPts;
          } catch (e) { console.warn('[points] deduct failed:', e.message); }
        }
      }
    }

    await SB.updateProctorStatus(examId, uid, 'rejected');
    closeMo(moId);
    toast(`تم إرسال الرفض${deductedPts>0?` — خُصمت ${deductedPts} نقطة`:''}`, 'info', 4000);
    const sub  = getSubject(exam?.subject_id);
    await addLog(`رفض تعيين مراقبة${deductedPts>0?` (-${deductedPts} نقطة)`:''}`, 'proctor', `${sub?.name||''} — ${reason}`);
    await _notifyCoordAboutResponse(examId, uid, 'rejected', reason);
    renderSwaps();
    UI.buildNav?.();
    UI.renderCurrentPage?.();
  } catch(e) {
    toast('خطأ: ' + e.message, 'error');
  }
}

async function _notifyCoordAboutResponse(examId, proctorId, status, notes='') {
  const exam    = getExam(examId);
  const sub     = getSubject(exam?.subject_id);
  const me      = STATE.currentUser;
  const coords  = STATE.profiles.filter(p =>
    (p.role==='coordinator'||p.role==='admin') && p.active
  );
  const lbl = status==='accepted' ? 'قَبِل المراقبة' : 'رَفَض المراقبة';
  const userIds = coords.map(p=>p.id);
  if (!userIds.length) return;
  const title = `${me?.name?.split(' ').slice(0,2).join(' ')} ${lbl}`;
  const body  = `الامتحان: ${sub?.name||'—'} · ${fmtDate(exam?.date||'')}${notes?` — ${notes}`:''}`;
  await addNotif(userIds, title, body, 'proctor');
}

// ════════════════════════════════════════
//  قبول / رفض طلب تبادل وارد
// ════════════════════════════════════════
// ── مساعد: تحديث swap_request مباشرة بدون .select() لتجنب RLS ──
async function _updateSwapReqNoSelect(id, data) {
  const { error } = await SB.getClient()
    .from('swap_requests')
    .update({ ...data, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw new Error(error.message);
}

async function _acceptSwapRequest(id) {
  const r = STATE.swapRequests.find(x => x.id === id);
  if (!r) return;

  const exam = getExam(r.exam_id);
  if (!exam) { toast('الامتحان غير موجود','error'); return; }

  // ── إعادة فحص: لا يزال هناك ساعتان قبل الامتحان ─────────────
  const startTs = new Date(`${exam.date}T${exam.time}`).getTime();
  const minMs   = SWAP_MIN_HOURS_BEFORE * 60 * 60 * 1000;
  if (startTs - Date.now() < minMs) {
    toast(`فات الأوان — يجب القبول قبل بدء الامتحان بـ ${SWAP_MIN_HOURS_BEFORE} ساعة على الأقل`, 'error', 5000);
    return;
  }
  // ── إعادة فحص: لا تعارض زمني للهدف ────────────────────────
  const meId = STATE.currentUser?.id;
  const start = startTs;
  const end   = startTs + (exam.duration + (exam.extra_time||0)) * 60000;
  const conflict = STATE.exams.find(e => {
    if (e.id === exam.id) return false;
    if (e.date !== exam.date) return false;
    if (!(e.proctor_ids||[]).includes(meId)) return false;
    if ((e.proctor_statuses||{})[meId] === 'rejected') return false;
    const eS = new Date(`${e.date}T${e.time}`).getTime();
    const eE = eS + (e.duration + (e.extra_time||0)) * 60000;
    return start < eE && end > eS;
  });
  if (conflict) {
    const cs = getSubject(conflict.subject_id);
    toast(`لا يمكن القبول — لديك تعارض مع "${cs?.name||'امتحان آخر'}" في نفس الوقت`, 'error', 5000);
    return;
  }

  // النسخ الاحتياطية للحقول للسماح بالاستعادة عند الفشل
  const _origProctors = [...(exam.proctor_ids || [])];
  const _origRoomProctors = JSON.parse(JSON.stringify(exam.room_proctors || {}));
  const _origStatuses = JSON.parse(JSON.stringify(exam.proctor_statuses || {}));

  try {
    // ── تنفيذ التبديل في سجل الامتحان ─────────────────────────
    // 1) استبدال المُرسِل بالهدف في proctor_ids
    const newProctors = _origProctors.filter(pid => pid !== r.requester_id);
    if (!newProctors.includes(r.target_id)) newProctors.push(r.target_id);

    // 2) استبدال في room_proctors (نفس القاعة التي كان يراقبها)
    const newRoomProctors = {};
    Object.entries(_origRoomProctors).forEach(([rid, list]) => {
      const arr = (list || []).filter(pid => pid !== r.requester_id);
      // إذا كان المُرسِل في هذه القاعة، أضف الهدف بدلاً منه
      if ((list || []).includes(r.requester_id) && !arr.includes(r.target_id)) {
        arr.push(r.target_id);
      }
      newRoomProctors[rid] = arr;
    });

    // 3) تحديث الحالات
    const newStatuses = { ..._origStatuses };
    delete newStatuses[r.requester_id];
    newStatuses[r.target_id] = 'accepted';

    // ── تحديث محلي فوري ───────────────────────────────────────
    exam.proctor_ids       = newProctors;
    exam.room_proctors     = newRoomProctors;
    exam.proctor_statuses  = newStatuses;
    r.status   = 'approved';
    r.response = 'تم قبول طلب التبادل وتنفيذه';
    renderSwaps();

    // ── حفظ في DB ──────────────────────────────────────────────
    const { error: examErr } = await SB.getClient().from('exams').update({
      proctor_ids:      newProctors,
      room_proctors:    newRoomProctors,
      proctor_statuses: newStatuses
    }).eq('id', exam.id);
    if (examErr) throw new Error(examErr.message);

    await _updateSwapReqNoSelect(id, { status:'approved', response:'تم قبول طلب التبادل وتنفيذه' });

    // ✅ نقل النقاط: إذا كان المرسل قد قبل الامتحان أصلاً، انقل نقاطه إلى المُستلم
    const wasReqAccepted = _origStatuses[r.requester_id] === 'accepted';
    if (wasReqAccepted && typeof calcPoints === 'function') {
      const transferPts = calcPoints(exam) || 0;
      if (transferPts > 0) {
        try {
          // اخصم من المرسل
          const reqProf = STATE.profiles.find(p => p.id === r.requester_id);
          if (reqProf) {
            const newReqPts = Math.max(0, Math.round(((parseFloat(reqProf.points)||0) - transferPts)*10)/10);
            await SB.update('profiles', r.requester_id, { points: newReqPts });
            reqProf.points = newReqPts;
          }
          // أضف للمُستلم (الحالي)
          const meProf = STATE.profiles.find(p => p.id === meId);
          if (meProf) {
            const newMePts = Math.round(((parseFloat(meProf.points)||0) + transferPts)*10)/10;
            await SB.update('profiles', meId, { points: newMePts });
            meProf.points = newMePts;
            if (STATE.currentUser) STATE.currentUser.points = newMePts;
          }
        } catch (err) { console.warn('[points] swap transfer failed:', err.message); }
      }
    }

    const sub = getSubject(exam.subject_id);
    const me  = STATE.currentUser;
    await addNotif([r.requester_id],
      `${me?.name?.split(' ').slice(0,2).join(' ')} قَبِل طلب التبادل`,
      `امتحان: ${sub?.name||'—'} · ${fmtDate(exam.date)} — تم نقل المراقبة بنجاح`,
      'success'
    );
    // إخطار المنسق/المسؤول للعلم
    const coords = STATE.profiles.filter(p => (p.role==='coordinator'||p.role==='admin') && p.active);
    if (coords.length) {
      await addNotif(coords.map(p=>p.id),
        '🔄 تنفيذ تبادل مراقبة',
        `${getProfile(r.requester_id)?.name||'—'} ↔ ${me?.name||'—'} · ${sub?.name||'—'} · ${fmtDate(exam.date)}`,
        'info'
      );
    }
    await addLog('قبول طلب تبادل مراقبة', 'proctor', sub?.name||'');
    toast('✓ تم قبول طلب التبادل ونقل المراقبة', 'success');
    UI.buildNav?.();
    UI.renderCurrentPage?.();
  } catch(e) {
    // rollback محلي إذا فشل DB
    exam.proctor_ids      = _origProctors;
    exam.room_proctors    = _origRoomProctors;
    exam.proctor_statuses = _origStatuses;
    r.status = 'pending'; r.response = '';
    renderSwaps();
    toast('خطأ في حفظ التبديل: ' + e.message, 'error');
  }
}

async function _rejectSwapRequest(id) {
  const r = STATE.swapRequests.find(x => x.id === id);
  if (!r) return;
  const reason = prompt('سبب الرفض (اختياري):') || '';

  try {
    const resp = reason || 'تم رفض طلب التبادل';

    // ✅ تحديث محلي أولاً
    r.status   = 'rejected';
    r.response = resp;

    renderSwaps();  // تحديث الواجهة فوراً

    // ✅ حفظ في DB بدون .select()
    await _updateSwapReqNoSelect(id, { status:'rejected', response:resp });

    const exam = getExam(r.exam_id);
    const sub  = getSubject(exam?.subject_id);
    const me   = STATE.currentUser;
    await addNotif([r.requester_id],
      `${me?.name?.split(' ').slice(0,2).join(' ')} رَفَض طلب التبادل`,
      `امتحان: ${sub?.name||'—'}${reason?' — '+reason:''}`,
      'warning'
    );
    await addLog('رفض طلب تبادل مراقبة', 'proctor', sub?.name||'');
    toast('تم رفض طلب التبادل', 'info');
    UI.buildNav?.();
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

async function _cancelSwapRequest(id) {
  const r = STATE.swapRequests.find(x => x.id === id);
  if (!r || r.status !== 'pending') return;
  confirmDelete('إلغاء طلب التبادل؟', async () => {
    // ✅ إزالة محلية فوراً
    STATE.swapRequests = STATE.swapRequests.filter(x => x.id !== id);
    renderSwaps();
    try {
      const { error } = await SB.getClient().from('swap_requests').delete().eq('id', id);
      if (error) throw new Error(error.message);
      toast('تم إلغاء الطلب','info');
    } catch(e) {
      // إعادة الطلب محلياً إذا فشل الحذف
      STATE.swapRequests.unshift(r);
      renderSwaps();
      toast('خطأ: '+e.message,'error');
    }
  });
}

// ════════════════════════════════════════
//  إنشاء طلب تبادل جديد
// ════════════════════════════════════════
// ── الحد الأدنى للوقت قبل الامتحان لإرسال طلب تبادل (بالساعات) ──
const SWAP_MIN_HOURS_BEFORE = 2;

/**
 * المراقبون المتاحون كهدف لتبادل امتحان معيَّن:
 *  - مراقبون نشطون فقط
 *  - ليسوا أنا
 *  - ليسوا مُعيَّنين أصلاً في نفس الامتحان
 *  - ليس لديهم تعارض زمني مع وقت الامتحان (لا يراقبون امتحاناً آخر يتقاطع زمنياً)
 */
function _getAvailableSwapTargets(examId, requesterId) {
  const exam = getExam(examId);
  if (!exam) return [];
  const start = new Date(`${exam.date}T${exam.time}`).getTime();
  const end   = start + (exam.duration + (exam.extra_time || 0)) * 60000;

  return STATE.profiles.filter(p =>
    p.role === 'proctor' && p.active && p.id !== requesterId &&
    !(exam.proctor_ids || []).includes(p.id)
  ).map(p => {
    // فحص تعارض المراقبة في امتحان آخر بنفس اليوم
    const conflictExam = STATE.exams.find(e => {
      if (e.id === examId) return false;
      if (e.date !== exam.date) return false;
      if (!(e.proctor_ids||[]).includes(p.id)) return false;
      // تجاهل الحالات المرفوضة
      if ((e.proctor_statuses||{})[p.id] === 'rejected') return false;
      const eS = new Date(`${e.date}T${e.time}`).getTime();
      const eE = eS + (e.duration + (e.extra_time||0)) * 60000;
      return start < eE && end > eS;
    });
    // عدد امتحاناته في الفصل (للحمل)
    const semCount = STATE.exams.filter(e =>
      e.semester === exam.semester && (e.proctor_ids||[]).includes(p.id)
    ).length;
    return { ...p, _conflict: conflictExam, _semCount: semCount };
  })
  // ✅ نُبقي فقط المراقبين بدون تعارض
  .filter(p => !p._conflict)
  // ترتيب: الأقل حملاً أولاً
  .sort((a,b) => a._semCount - b._semCount);
}

/** الامتحانات التي يحقّ للمراقب طلب تبادلها
 *  ✅ تشمل: المعلّقة والمقبولة (أي امتحان معيَّن له ولم يرفضه)
 *  ✅ شرط الوقت: قبل بدء الامتحان بساعتين على الأقل
 *  ✅ تستثني: المرفوضة، المنتهية
 */
function _getEligibleExamsForSwap(uid) {
  const sem = STATE.currentSem;
  const now = Date.now();
  const minMs = SWAP_MIN_HOURS_BEFORE * 60 * 60 * 1000;

  return STATE.exams.filter(e => {
    if (e.semester !== sem) return false;
    if (!(e.proctor_ids||[]).includes(uid)) return false;
    // ✅ يكفي ألا يكون مرفوضاً (أي امتحان معيَّن له ولم يرفضه يَحقّ له طلب تبادله)
    if ((e.proctor_statuses||{})[uid] === 'rejected') return false;
    // ✅ ساعتان على الأقل قبل بدء الامتحان
    const startTs = new Date(`${e.date}T${e.time}`).getTime();
    if (startTs - now < minMs) return false;
    // لا تشمل المنتهية أو الجارية
    const st = examStatus(e);
    if (st === 'completed' || st === 'active') return false;
    return true;
  }).sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));
}

function openNewSwapRequest() {
  const uid  = STATE.currentUser?.id;
  if (!uid) return;

  // ✅ امتحانات يحق طلب تبادلها (مقبولة + قبل البدء بـ ≥ ساعتين)
  const myExams = _getEligibleExamsForSwap(uid);

  const moId = 'newSwapMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-exchange-alt" style="color:var(--primary)"></i> طلب تبادل مراقبة</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="padding:10px 14px;background:var(--primary)08;border-radius:9px;border:1px solid var(--primary)20;font-size:12px;margin-bottom:14px;color:var(--txt2)">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        يُسمح بطلب التبادل لأي امتحان معيَّن لك ولم ترفضه (سواء قبلته أو لا يزال معلّقاً)،
        وقبل بدء الامتحان <b>بساعتين على الأقل</b>،
        ولن يظهر سوى المراقبين <b>المتاحين</b> (دون تعارض في الوقت).
      </div>

      <div class="field">
        <label class="field-lbl">الامتحان الذي تريد التبادل فيه <span class="req">*</span></label>
        <select id="swExam" onchange="_updateSwapTargetProctors()" style="width:100%">
          <option value="">-- اختر الامتحان --</option>
          ${myExams.map(e => {
            const sub = getSubject(e.subject_id);
            return `<option value="${e.id}">${esc(sub?.name||'—')} · ${fmtDate(e.date)} ${fmtTime(e.time)}</option>`;
          }).join('')}
        </select>
        ${!myExams.length
          ? `<div style="margin-top:8px;padding:10px 12px;background:var(--gold)08;border:1px solid var(--gold)25;border-radius:8px;font-size:12px;color:var(--gold)">
               <i class="fas fa-exclamation-triangle" style="margin-left:5px"></i>
               لا توجد امتحانات قابلة للتبادل حالياً (يجب أن يبقى ≥ ساعتين على بدئها وألا تكون مرفوضة).
             </div>`
          : ''}
      </div>

      <div class="field">
        <label class="field-lbl">المراقب البديل المتاح <span class="req">*</span></label>
        <select id="swTarget" style="width:100%" disabled>
          <option value="">-- اختر الامتحان أولاً --</option>
        </select>
        <div id="swTargetHint" style="margin-top:6px;font-size:11.5px;color:var(--txt3)"></div>
      </div>

      <div class="field">
        <label class="field-lbl">سبب الطلب</label>
        <textarea id="swReason" rows="3" placeholder="مثال: تعارض وقت، ظرف طارئ، موعد آخر..."></textarea>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" onclick="_submitSwapRequest('${moId}')">
        <i class="fas fa-paper-plane"></i> إرسال الطلب
      </button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

/** تحديث قائمة المراقبين البدلاء عند اختيار الامتحان */
function _updateSwapTargetProctors() {
  const uid    = STATE.currentUser?.id;
  const examId = parseInt(document.getElementById('swExam')?.value);
  const targetSel = document.getElementById('swTarget');
  const hintEl    = document.getElementById('swTargetHint');
  if (!targetSel) return;

  if (!examId) {
    targetSel.disabled = true;
    targetSel.innerHTML = '<option value="">-- اختر الامتحان أولاً --</option>';
    if (hintEl) hintEl.textContent = '';
    return;
  }

  const available = _getAvailableSwapTargets(examId, uid);

  if (!available.length) {
    targetSel.disabled = true;
    targetSel.innerHTML = '<option value="">لا يوجد مراقب بديل متاح</option>';
    if (hintEl) hintEl.innerHTML = '<i class="fas fa-exclamation-circle" style="color:var(--red2);margin-left:4px"></i> جميع المراقبين الآخرين إما لديهم تعارض زمني أو مُعيَّنون لنفس الامتحان.';
    return;
  }

  targetSel.disabled = false;
  targetSel.innerHTML = '<option value="">-- اختر المراقب --</option>' +
    available.map(p => {
      const dept = STATE.departments.find(d => d.id === p.dept_id);
      const lbl = `${esc(p.name)}${dept ? ' (' + esc(dept.name) + ')' : ''} · حمل ${p._semCount}`;
      return `<option value="${p.id}">${lbl}</option>`;
    }).join('');
  if (hintEl) hintEl.innerHTML = `<i class="fas fa-check-circle" style="color:var(--green2);margin-left:4px"></i> ${available.length} مراقب متاح بدون تعارض.`;
}

async function _submitSwapRequest(moId) {
  const uid     = STATE.currentUser?.id;
  const examId  = parseInt(document.getElementById('swExam')?.value);
  const targetId= document.getElementById('swTarget')?.value;
  const reason  = document.getElementById('swReason')?.value?.trim() || '';

  if (!examId)   { toast('اختر الامتحان أولاً','error'); return; }
  if (!targetId) { toast('اختر المراقب البديل','error'); return; }

  // ✅ إعادة فحص: الامتحان لا يزال مؤهلاً (قد يكون المستخدم بقي في النموذج طويلاً)
  const eligible = _getEligibleExamsForSwap(uid).some(e => e.id === examId);
  if (!eligible) {
    toast('هذا الامتحان لم يعد قابلاً للتبادل (إما أصبح أقل من ساعتين على بدئه، أو لم يعد مقبولاً)', 'error', 5000);
    return;
  }
  // ✅ إعادة فحص: المراقب الهدف لا يزال متاحاً
  const stillAvailable = _getAvailableSwapTargets(examId, uid).some(p => p.id === targetId);
  if (!stillAvailable) {
    toast('المراقب المختار لم يعد متاحاً (تعارض زمني)', 'error');
    _updateSwapTargetProctors();
    return;
  }

  // فحص وجود طلب مكرر
  const dup = STATE.swapRequests.find(r =>
    r.requester_id === uid && r.exam_id === examId &&
    r.target_id === targetId && r.status === 'pending'
  );
  if (dup) { toast('يوجد طلب مشابه معلق بالفعل','warning'); return; }

  try {
    const data = {
      requester_id: uid,
      target_id:    targetId,
      exam_id:      examId,
      status:       'pending',
      reason:       reason,
      response:     '',
      created_at:   new Date().toISOString(),
      updated_at:   new Date().toISOString()
    };
    // ✅ insert بدون .select() لتجنب RLS SELECT failure
    const { data: inserted, error: insErr } = await SB.getClient()
      .from('swap_requests').insert(data).select().maybeSingle();
    if (insErr) throw new Error(insErr.message);
    // إضافة محلية مباشرة (سواء عاد الـ ID أم لا)
    STATE.swapRequests.unshift(inserted || { ...data, id: Date.now() });

    // إشعار المراقب المستهدف
    const exam = getExam(examId);
    const sub  = getSubject(exam?.subject_id);
    const me   = STATE.currentUser;
    await addNotif([targetId],
      `${me?.name?.split(' ').slice(0,2).join(' ')} يطلب تبادل مراقبة`,
      `امتحان: ${sub?.name||'—'} · ${fmtDate(exam?.date||'')}${reason?' — '+reason:''}`,
      'swap'
    );

    await addLog('إرسال طلب تبادل مراقبة','proctor', sub?.name||'');
    closeMo(moId);
    toast('✓ تم إرسال طلب التبادل','success');
    renderSwaps();
    UI.buildNav?.();
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

// ════════════════════════════════════════
//  واجهة المسؤول/المنسق
// ════════════════════════════════════════
function _renderAdminSwapsPage(el, uid) {
  const sem     = STATE.currentSem;
  const pending = STATE.swapRequests.filter(r => r.status === 'pending')
    .sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
  const history = STATE.swapRequests.filter(r => r.status !== 'pending')
    .sort((a,b) => new Date(b.created_at)-new Date(a.created_at)).slice(0,20);

  // تعيينات رافضة في الفصل الحالي تحتاج مراقباً بديلاً
  const rejectedAssign = STATE.exams.filter(e => {
    if (e.semester !== sem) return false;
    const statuses = e.proctor_statuses || {};
    return (e.proctor_ids||[]).some(pid => statuses[pid]==='rejected');
  });

  el.innerHTML = `
    <div class="stats-grid" style="margin-bottom:16px">
      <div class="stat-card">
        <div class="stat-ic ic-gold"><i class="fas fa-hourglass-half"></i></div>
        <div><div class="stat-val">${pending.length}</div><div class="stat-lbl">طلبات معلقة</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-red"><i class="fas fa-user-slash"></i></div>
        <div><div class="stat-val">${rejectedAssign.length}</div><div class="stat-lbl">يحتاج بديلاً</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-blue"><i class="fas fa-exchange-alt"></i></div>
        <div><div class="stat-val">${STATE.swapRequests.length}</div><div class="stat-lbl">إجمالي الطلبات</div></div>
      </div>
    </div>

    ${rejectedAssign.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--red2)">
      <div class="card-h">
        <h3><i class="fas fa-user-slash" style="color:var(--red2)"></i> امتحانات رُفضت مراقبتها (${rejectedAssign.length})</h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${rejectedAssign.map(e => {
          const sub  = getSubject(e.subject_id);
          const rjPs = (e.proctor_ids||[]).filter(pid=>(e.proctor_statuses||{})[pid]==='rejected');
          return `<div style="padding:10px 12px;background:var(--bg);border-radius:10px;border:1px solid var(--red2)20;margin-bottom:8px;display:flex;align-items:center;gap:10px">
            <div style="flex:1;min-width:0">
              <div style="font-weight:700;font-size:13px">${esc(sub?.name||'—')}</div>
              <div style="font-size:11.5px;color:var(--txt2)">${fmtDate(e.date)} · ${fmtTime(e.time)}</div>
              <div style="font-size:11px;color:var(--red2);margin-top:3px">
                ${rjPs.map(pid => `<span class="badge b-red" style="font-size:10px">${esc(getProfile(pid)?.name?.split(' ')[0]||'—')} رفض</span>`).join(' ')}
              </div>
            </div>
            ${canEdit()?`<button class="btn bp btn-xs" onclick="openEditExam(${e.id})">
              <i class="fas fa-user-plus"></i> تعيين بديل
            </button>`:''}
          </div>`;
        }).join('')}
      </div>
    </div>` : ''}

    ${pending.length ? `
    <div class="card" style="margin-bottom:14px">
      <div class="card-h">
        <h3><i class="fas fa-clock" style="color:var(--gold)"></i>
          طلبات التبادل المعلقة (${pending.length})
        </h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${pending.map(r => _buildAdminSwapCard(r)).join('')}
      </div>
    </div>` : ''}

    ${history.length ? `
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-history" style="color:var(--txt3)"></i> السجل (آخر ${history.length})</h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${history.map(r => _buildAdminSwapCard(r, true)).join('')}
      </div>
    </div>` : ''}

    ${!pending.length && !history.length && !rejectedAssign.length ? `
    <div style="text-align:center;padding:60px 20px">
      <i class="fas fa-exchange-alt" style="font-size:56px;opacity:.15;display:block;margin-bottom:14px"></i>
      <h3 style="margin-bottom:6px">لا توجد طلبات</h3>
      <p style="color:var(--txt2)">ستظهر هنا طلبات التبادل بين المراقبين</p>
    </div>` : ''}
  `;
}

function _buildAdminSwapCard(r, isHistory=false) {
  const req  = getProfile(r.requester_id);
  const tgt  = getProfile(r.target_id);
  const exam = getExam(r.exam_id);
  const sub  = exam ? getSubject(exam.subject_id) : null;
  const statusMap = {
    pending:  { lbl:'معلق',     cls:'b-gold' },
    approved: { lbl:'موافق',    cls:'b-green' },
    rejected: { lbl:'مرفوض',   cls:'b-red' }
  };
  const st = statusMap[r.status] || statusMap.pending;

  return `<div style="display:flex;align-items:start;gap:10px;padding:10px 4px;border-bottom:1px solid var(--border)">
    <div style="flex:1;min-width:0">
      <div style="font-size:13px;font-weight:700;margin-bottom:4px">
        ${esc(req?.name?.split(' ').slice(0,2).join(' ')||'—')}
        <i class="fas fa-arrow-left" style="font-size:10px;color:var(--txt3);margin:0 5px"></i>
        ${esc(tgt?.name?.split(' ').slice(0,2).join(' ')||'—')}
      </div>
      <div style="font-size:11.5px;color:var(--txt2)">${esc(sub?.name||'—')} · ${exam?fmtDate(exam.date):''}</div>
      ${r.reason?`<div style="font-size:11px;color:var(--txt3);margin-top:2px">${esc(r.reason)}</div>`:''}
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:5px;flex-shrink:0">
      <span class="badge ${st.cls}" style="font-size:10px">${st.lbl}</span>
      <span style="font-size:10px;color:var(--txt3)">${fmtDateTime(r.created_at)}</span>
    </div>
  </div>`;
}

// ── alias للتوافق مع الكود القديم
function _confirmRejectAssignment(examId) {
  proctorRejectAssignment(examId);
}
