// analytics.js — تحليلات تفاعلية مع رسوم بيانية

let _anaTab = 'overview';
function setAnaTab(tab, el) {
  _anaTab = tab;
  document.querySelectorAll('#anaTabs .tab').forEach(t => t.classList.remove('active'));
  el?.classList.add('active');
  _renderAnaContent();
}

function renderAnalytics() {
  // المراقب يرى إحصاءاته فقط
  if (isProctor()) { _renderProctorAnalytics(); return; }

  // إضافة زر تقرير الفصل PDF
  setTimeout(_addSemesterReportBtn, 200);

  let semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  // رئيس القسم يرى إحصاءات قسمه فقط
  if (isDeptHead()) {
    const mySubjIds = STATE.subjects.filter(s=>s.dept_id===STATE.currentUser?.dept_id).map(s=>s.id);
    semExams = semExams.filter(e=>mySubjIds.includes(e.subject_id));
  }

  setHTML('anaActs', `
    <div class="tabs" id="anaTabs" style="margin:0">
      <div class="tab active" onclick="setAnaTab('overview',this)">نظرة عامة</div>
      <div class="tab" onclick="setAnaTab('attendance',this)">الحضور</div>
      <div class="tab" onclick="setAnaTab('proctors',this)">المراقبون</div>
      <div class="tab" onclick="setAnaTab('exams',this)">الامتحانات</div>
    </div>
    <button class="btn bo btn-sm" onclick="SB.manualSync();renderAnalytics()"><i class="fas fa-sync"></i></button>`);

  setHTML('anaContent', `<div id="anaTabContent"></div>`);
  _renderAnaContent();
}

function _renderAnaContent() {
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const el = document.getElementById('anaTabContent'); if (!el) return;

  if (_anaTab === 'overview')   el.innerHTML = _overviewTab(semExams);
  if (_anaTab === 'attendance') el.innerHTML = _attendanceTab(semExams);
  if (_anaTab === 'proctors')   el.innerHTML = _proctorsTab(semExams);
  if (_anaTab === 'exams')      el.innerHTML = _examsTab(semExams);
}

function _overviewTab(exams) {
  const total   = exams.length;
  const active  = exams.filter(e => examStatus(e) === 'active').length;
  const upcoming= exams.filter(e => examStatus(e) === 'upcoming').length;
  const done    = exams.filter(e => examStatus(e) === 'completed').length;
  const students= STATE.students.filter(s => s.active).length;
  const proctors= STATE.profiles.filter(p => p.role==='proctor'&&p.active).length;

  // نسبة الحضور
  let tp=0, pp=0;
  Object.values(STATE.attendance).forEach(a => {
    Object.values(a).forEach(v => { tp++; if(v==='present') pp++; });
  });
  const attRate = tp>0 ? Math.round(pp/tp*100) : 0;

  // توزيع بالنوع
  const byType = {};
  exams.forEach(e => { byType[e.type]=(byType[e.type]||0)+1; });
  const maxType = Math.max(...Object.values(byType),1);

  // نقاط الدخل
  const insights = _generateInsights(exams, attRate);

  return `
    <div class="stats-grid" style="margin-bottom:20px">
      <div class="stat-card"><div class="stat-ic ic-blue"><i class="fas fa-file-alt"></i></div>
        <div><div class="stat-val">${total}</div><div class="stat-lbl">إجمالي الامتحانات</div></div></div>
      <div class="stat-card"><div class="stat-ic ic-green"><i class="fas fa-user-check"></i></div>
        <div><div class="stat-val">${attRate}%</div><div class="stat-lbl">نسبة الحضور</div></div></div>
      <div class="stat-card"><div class="stat-ic ic-gold"><i class="fas fa-users"></i></div>
        <div><div class="stat-val">${students}</div><div class="stat-lbl">طلاب نشطون</div></div></div>
      <div class="stat-card"><div class="stat-ic ic-purple"><i class="fas fa-user-tie"></i></div>
        <div><div class="stat-val">${proctors}</div><div class="stat-lbl">مراقبون</div></div></div>
    </div>

    <div class="gl" style="align-items:start">
      <div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-h"><h3><i class="fas fa-chart-pie" style="color:var(--primary2)"></i> الامتحانات بالنوع</h3></div>
          <div class="card-b" id="typeChart">
            ${Object.entries(byType).map(([type,count]) => {
              const pct = Math.round(count/total*100);
              const colors = {final:'#ef4444',midterm:'#f59e0b',quiz:'#3b82f6',makeup:'#8b5cf6'};
              return `<div class="chart-row" style="margin-bottom:12px">
                <span class="chart-lbl" style="min-width:80px">${getTypeLabel(type)}</span>
                <div class="chart-track">
                  <div class="chart-fill" style="width:${Math.round(count/Math.max(...Object.values(byType),1)*100)}%;background:${colors[type]||'var(--primary)'}">
                    ${count}
                  </div>
                </div>
                <span style="font-size:11px;color:var(--txt3);min-width:34px;text-align:left">${pct}%</span>
              </div>`;
            }).join('') || emptyState('fa-chart-pie','لا بيانات')}
          </div>
        </div>

        <div class="card">
          <div class="card-h"><h3><i class="fas fa-calendar-alt" style="color:var(--teal)"></i> التوزيع الشهري</h3></div>
          <div class="card-b">
            ${_monthlyChart(exams)}
          </div>
        </div>
      </div>

      <div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-h"><h3><i class="fas fa-lightbulb" style="color:var(--gold)"></i> مقترحات التحسين</h3></div>
          <div class="card-b">
            ${insights.map(i => `
              <div style="display:flex;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
                <div style="width:32px;height:32px;border-radius:8px;background:${i.bg};display:flex;align-items:center;justify-content:center;flex-shrink:0">
                  <i class="fas ${i.icon}" style="color:${i.color};font-size:13px"></i>
                </div>
                <div>
                  <div style="font-weight:700;font-size:12.5px">${i.title}</div>
                  <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">${i.text}</div>
                </div>
              </div>`).join('')}
          </div>
        </div>

        <div class="card">
          <div class="card-h"><h3><i class="fas fa-info-circle" style="color:var(--primary2)"></i> ملخص الفصل</h3></div>
          <div class="card-b">
            ${[['الامتحانات الجارية',active,'var(--green)'],['القادمة',upcoming,'var(--primary2)'],['المنتهية',done,'var(--txt3)']].map(([l,v,c])=>`
              <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
                <span style="font-size:13px;color:var(--txt2)">${l}</span>
                <span style="font-weight:800;font-size:16px;color:${c}">${v}</span>
              </div>`).join('')}
          </div>
        </div>
      </div>
    </div>`;
}

function _attendanceTab(exams) {
  const attData = exams.map(e => {
    const att = STATE.attendance[e.id] || {};
    const total   = Object.keys(att).length;
    const present = Object.values(att).filter(v=>v==='present').length;
    const sub = getSubject(e.subject_id);
    return { name: sub?.name||'—', total, present, rate: total>0?Math.round(present/total*100):null, date: e.date };
  }).filter(d => d.total > 0).sort((a,b) => (a.rate||0)-(b.rate||0));

  const maxPres = Math.max(...attData.map(d=>d.present),1);

  return `
    <div class="card" style="margin-bottom:16px">
      <div class="card-h"><h3><i class="fas fa-chart-bar" style="color:var(--green)"></i> نسب الحضور بالامتحان</h3></div>
      <div class="card-b">
        ${attData.map(d => {
          const col = d.rate>=80?'var(--green)':d.rate>=60?'var(--gold)':'var(--red)';
          return `<div class="chart-row" style="margin-bottom:12px">
            <span class="chart-lbl" style="min-width:100px;font-size:11.5px">${d.name}</span>
            <div class="chart-track">
              <div class="chart-fill" style="width:${d.rate||0}%;background:${col}">${d.present}/${d.total}</div>
            </div>
            <span style="font-size:11.5px;font-weight:700;color:${col};min-width:38px;text-align:left">${d.rate||0}%</span>
          </div>`;
        }).join('') || emptyState('fa-chart-bar','لا توجد بيانات حضور بعد')}
      </div>
    </div>

    <div class="g2">
      <div class="stat-card"><div class="stat-ic ic-green"><i class="fas fa-check-circle"></i></div>
        <div><div class="stat-val">${attData.filter(d=>d.rate>=80).length}</div><div class="stat-lbl">امتحانات بحضور ممتاز (80%+)</div></div></div>
      <div class="stat-card"><div class="stat-ic ic-red"><i class="fas fa-exclamation-circle"></i></div>
        <div><div class="stat-val">${attData.filter(d=>d.rate!==null&&d.rate<60).length}</div><div class="stat-lbl">امتحانات بحضور ضعيف (-60%)</div></div></div>
    </div>`;
}

function _proctorsTab(exams) {
  const proctors = STATE.profiles.filter(p => p.role==='proctor'&&p.active);
  const load = {}; const pts = {}; const byType = {};
  exams.forEach(e => {
    (e.proctor_ids||[]).forEach(pid => {
      load[pid] = (load[pid]||0) + 1;
      pts[pid]  = (pts[pid]||0) + calcPoints(e);
      if (!byType[pid]) byType[pid] = {};
      byType[pid][e.type] = (byType[pid][e.type]||0) + 1;
    });
  });
  const sorted  = [...proctors].sort((a,b) => (load[b.id]||0)-(load[a.id]||0));
  const maxLoad = Math.max(...proctors.map(p=>load[p.id]||0), 1);
  const avgLoad = proctors.length ? (Object.values(load).reduce((s,v)=>s+v,0)/proctors.length).toFixed(1) : 0;
  const maxPts  = Math.max(...proctors.map(p=>pts[p.id]||0), 1);

  // تحليل عدالة التوزيع
  const stdDev = (() => {
    if (!proctors.length) return 0;
    const vals = proctors.map(p=>load[p.id]||0);
    const mean = vals.reduce((s,v)=>s+v,0)/vals.length;
    return Math.sqrt(vals.map(v=>(v-mean)**2).reduce((s,v)=>s+v,0)/vals.length).toFixed(1);
  })();
  const fairnessScore = Math.max(0, 100 - stdDev * 10);
  const fairnessLabel = fairnessScore >= 80 ? 'ممتاز' : fairnessScore >= 60 ? 'جيد' : 'يحتاج تحسين';
  const fairnessColor = fairnessScore >= 80 ? 'var(--green)' : fairnessScore >= 60 ? 'var(--gold)' : 'var(--red)';

  // المراقبون الأكثر طلباً للاستبدال
  const swapRequests = STATE.swapRequests.filter(r => r.semester === STATE.currentSem);
  const swapCount = {};
  swapRequests.forEach(r => {
    if (r.requester_id) swapCount[r.requester_id] = (swapCount[r.requester_id]||0)+1;
  });

  // المراقبون بدون تعيينات
  const unassigned = proctors.filter(p => !load[p.id]);

  return `
    <!-- بطاقات التحليل الذكي -->
    <div class="stats-grid" style="margin-bottom:20px">
      <div class="stat-card">
        <div class="stat-ic ic-blue"><i class="fas fa-users"></i></div>
        <div><div class="stat-val">${proctors.length}</div><div class="stat-lbl">مراقب نشط</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-gold"><i class="fas fa-balance-scale"></i></div>
        <div><div class="stat-val">${avgLoad}</div><div class="stat-lbl">متوسط الحِمل</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic" style="background:${fairnessColor}20;color:${fairnessColor}"><i class="fas fa-chart-line"></i></div>
        <div><div class="stat-val" style="color:${fairnessColor}">${fairnessLabel}</div><div class="stat-lbl">عدالة التوزيع</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-red"><i class="fas fa-user-slash"></i></div>
        <div><div class="stat-val">${unassigned.length}</div><div class="stat-lbl">بدون تعيينات</div></div>
      </div>
    </div>

    ${unassigned.length ? `<div style="padding:12px 16px;background:var(--gold-bg);border-radius:12px;border:1px solid var(--gold);margin-bottom:16px;font-size:13px">
      <i class="fas fa-exclamation-circle" style="color:var(--gold);margin-inline-end:8px"></i>
      <strong>${unassigned.length} مراقبون</strong> لم يُعيَّنوا في أي امتحان هذا الفصل: 
      ${unassigned.slice(0,3).map(p=>`<span class="badge b-gold">${p.name?.split(' ')[0]}</span>`).join(' ')}
      ${unassigned.length>3?`<span class="badge b-gray">+${unassigned.length-3}</span>`:''}
    </div>` : ''}

    <div class="gl" style="align-items:start">
      <!-- ترتيب المراقبين بالنقاط والحِمل -->
      <div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-h">
            <h3><i class="fas fa-trophy" style="color:var(--gold2)"></i> ترتيب المراقبين</h3>
            <div style="display:flex;gap:8px">
              <span class="badge b-blue">بالحمل</span>
              <span class="badge b-gold">بالنقاط</span>
            </div>
          </div>
          <div class="card-b" style="padding:12px 16px">
            ${sorted.slice(0,10).map((p,i) => {
              const cnt   = load[p.id]||0;
              const ptsV  = pts[p.id]||0;
              const sw    = swapCount[p.id]||0;
              const ratio = cnt > 0 ? (ptsV/cnt).toFixed(1) : 0;
              const deptName = p.dept_id ? STATE.departments.find(d=>d.id===p.dept_id)?.name || '' : '';
              return `<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
                <div style="font-size:16px;min-width:26px;text-align:center">${i<3?['🥇','🥈','🥉'][i]:`<span style="color:var(--txt3);font-size:12px">${i+1}</span>`}</div>
                ${userAvatar(p, 34)}
                <div style="flex:1;min-width:0">
                  <div style="font-weight:700;font-size:13px">${p.name?.split(' ').slice(0,2).join(' ')}</div>
                  <div style="font-size:11px;color:var(--txt3)">${deptName||p.emp_id||'—'}</div>
                </div>
                <div style="text-align:center;min-width:44px">
                  <div style="font-size:18px;font-weight:900;color:var(--primary2)">${cnt}</div>
                  <div style="font-size:10px;color:var(--txt3)">امتحان</div>
                </div>
                <div style="text-align:center;min-width:44px">
                  <div style="font-size:18px;font-weight:900;color:var(--gold)">${ptsV}</div>
                  <div style="font-size:10px;color:var(--txt3)">نقطة</div>
                </div>
                ${sw>0?`<span class="badge b-red" title="طلبات الاستبدال">${sw} 🔄</span>`:''}
              </div>`;
            }).join('')}
          </div>
        </div>

        <!-- مؤشر عدالة التوزيع -->
        <div class="card">
          <div class="card-h"><h3><i class="fas fa-balance-scale" style="color:var(--teal)"></i> مؤشر عدالة التوزيع</h3></div>
          <div class="card-b">
            <div style="display:flex;align-items:center;gap:16px;padding:16px 0">
              <div style="width:80px;height:80px;border-radius:50%;border:6px solid ${fairnessColor};display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <div style="text-align:center">
                  <div style="font-size:20px;font-weight:900;color:${fairnessColor}">${Math.round(fairnessScore)}%</div>
                </div>
              </div>
              <div>
                <div style="font-size:16px;font-weight:800;color:${fairnessColor}">${fairnessLabel}</div>
                <div style="font-size:12px;color:var(--txt2);margin-top:4px">الانحراف المعياري: <b>${stdDev}</b></div>
                <div style="font-size:11.5px;color:var(--txt3);margin-top:2px">
                  ${fairnessScore >= 80 ? 'التوزيع متوازن بشكل ممتاز' :
                    fairnessScore >= 60 ? 'يوجد بعض التفاوت في التوزيع' :
                    'يُنصح بإعادة توزيع المراقبين لتحقيق التوازن'}
                </div>
              </div>
            </div>
            <div style="font-size:12px;color:var(--txt2);margin-top:8px">
              ${sorted.slice(0,3).map(p=>`<span style="display:inline-flex;align-items:center;gap:4px;margin-inline-end:8px;margin-bottom:4px">
                ${userAvatar(p,20)} ${p.name?.split(' ')[0]}: <b>${load[p.id]||0}</b>
              </span>`).join('')}
            </div>
          </div>
        </div>
      </div>

      <!-- الرسم البياني ولوحة التحليل -->
      <div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-h"><h3><i class="fas fa-chart-bar" style="color:var(--purple2)"></i> توزيع الأحمال</h3></div>
          <div class="card-b">
            ${sorted.map(p => {
              const cnt = load[p.id]||0;
              const pct = Math.round(cnt/maxLoad*100);
              const isOverloaded  = cnt > avgLoad * 1.5;
              const isUnderloaded = cnt < avgLoad * 0.5 && cnt > 0;
              const barColor = isOverloaded ? 'var(--red)' : isUnderloaded ? 'var(--gold)' : 'var(--purple2)';
              return `<div style="margin-bottom:10px">
                <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
                  <span style="font-size:11.5px;min-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.name?.split(' ').slice(0,2).join(' ')}</span>
                  ${isOverloaded?`<span class="badge b-red" style="font-size:9px">زائد</span>`:''}
                  ${isUnderloaded?`<span class="badge b-gold" style="font-size:9px">قليل</span>`:''}
                </div>
                <div style="display:flex;align-items:center;gap:6px">
                  <div style="flex:1;background:var(--bg);border-radius:4px;height:16px;overflow:hidden">
                    <div style="width:${pct}%;height:100%;background:${barColor};border-radius:4px;transition:width .5s;display:flex;align-items:center;justify-content:flex-end;padding-inline-end:4px">
                      ${cnt>0?`<span style="font-size:10px;color:white;font-weight:700">${cnt}</span>`:''}
                    </div>
                  </div>
                  <span style="font-size:11px;color:var(--txt3);min-width:20px;text-align:left">${pts[p.id]||0}نق</span>
                </div>
              </div>`;
            }).join('') || emptyState('fa-user-tie','لا مراقبون')}
          </div>
        </div>

        <!-- توزيع أنواع الامتحانات -->
        <div class="card">
          <div class="card-h"><h3><i class="fas fa-pie-chart" style="color:var(--teal)"></i> توزيع حسب نوع الامتحان</h3></div>
          <div class="card-b">
            ${sorted.slice(0,6).map(p => {
              const types = byType[p.id] || {};
              const total = Object.values(types).reduce((s,v)=>s+v,0)||1;
              const typeColors = {final:'var(--red)',midterm:'var(--gold)',quiz:'var(--blue)',makeup:'var(--purple)'};
              return `<div style="margin-bottom:12px">
                <div style="font-size:12px;font-weight:700;margin-bottom:5px">${p.name?.split(' ').slice(0,2).join(' ')}</div>
                <div style="display:flex;border-radius:6px;overflow:hidden;height:14px">
                  ${Object.entries(types).map(([type,cnt])=>`<div style="width:${Math.round(cnt/total*100)}%;background:${typeColors[type]||'var(--txt3)'};height:100%" title="${getTypeLabel(type)}: ${cnt}"></div>`).join('')}
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:3px">
                  ${Object.entries(types).map(([type,cnt])=>`<span style="font-size:9.5px;color:${typeColors[type]||'var(--txt3)'}">${getTypeLabel(type)}: ${cnt}</span>`).join('')}
                </div>
              </div>`;
            }).join('') || '<div style="font-size:12px;color:var(--txt3);padding:16px;text-align:center">لا بيانات</div>'}
          </div>
        </div>
      </div>
    </div>`;
}

function _examsTab(exams) {
  const byDate = {};
  exams.forEach(e => {
    const w = e.date?.slice(0,7)||'—';
    byDate[w]=(byDate[w]||0)+1;
  });
  const maxByDate = Math.max(...Object.values(byDate),1);

  return `
    <div class="gl" style="align-items:start">
      <div class="card">
        <div class="card-h"><h3><i class="fas fa-list-alt" style="color:var(--primary2)"></i> جميع الامتحانات</h3></div>
        <div style="max-height:500px;overflow-y:auto">
          ${exams.sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`)).map(e => {
            const sub = getSubject(e.subject_id);
            const st  = examStatus(e);
            const att = STATE.attendance[e.id] || {};
            const total   = Object.keys(att).length;
            const present = Object.values(att).filter(v=>v==='present').length;
            return `<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;border-bottom:1px solid var(--border)">
              <div style="flex:1">
                <div style="font-weight:700;font-size:13px">${sub?.name||'—'}</div>
                <div style="font-size:11px;color:var(--txt2)">${fmtDate(e.date)} ${fmtTime(e.time)} · ${e.duration} دقيقة</div>
              </div>
              ${getStatusBadge(st)}
              ${total>0?`<span style="font-size:11.5px;font-weight:600;color:${present/total>=.8?'var(--green)':'var(--txt3)'}">${present}/${total}</span>`:''}
            </div>`;
          }).join('') || emptyState('fa-file-alt','لا امتحانات')}
        </div>
      </div>
      <div class="card">
        <div class="card-h"><h3><i class="fas fa-calendar-alt" style="color:var(--teal)"></i> التوزيع الشهري</h3></div>
        <div class="card-b">
          ${Object.entries(byDate).sort().map(([m,c]) => `
            <div class="chart-row" style="margin-bottom:12px">
              <span class="chart-lbl" style="min-width:70px;font-size:11px">${m}</span>
              <div class="chart-track"><div class="chart-fill" style="width:${Math.round(c/maxByDate*100)}%;background:var(--teal)">${c}</div></div>
            </div>`).join('') || emptyState('fa-calendar','لا بيانات')}
        </div>
      </div>
    </div>`;
}

function _monthlyChart(exams) {
  const byMonth = {};
  exams.forEach(e => { const m=e.date?.slice(0,7)||'—'; byMonth[m]=(byMonth[m]||0)+1; });
  const max = Math.max(...Object.values(byMonth),1);
  return Object.entries(byMonth).sort().map(([m,c]) => `
    <div class="chart-row" style="margin-bottom:10px">
      <span class="chart-lbl" style="min-width:70px;font-size:11px">${m}</span>
      <div class="chart-track"><div class="chart-fill" style="width:${Math.round(c/max*100)}%;background:var(--teal)">${c}</div></div>
    </div>`).join('') || '<div style="text-align:center;color:var(--txt3);font-size:12px;padding:16px">لا بيانات</div>';
}

function _generateInsights(exams, attRate) {
  const insights = [];
  if (attRate < 70) insights.push({ icon:'fa-exclamation-triangle', color:'var(--red)', bg:'var(--red-bg)', title:'نسبة الحضور منخفضة', text:`نسبة الحضور ${attRate}%. راجع آلية متابعة الطلاب.` });
  if (attRate >= 85) insights.push({ icon:'fa-thumbs-up', color:'var(--green)', bg:'var(--green-bg)', title:'نسبة الحضور ممتازة', text:`${attRate}% من الطلاب يحضرون الامتحانات.` });
  const pendSwaps = STATE.swapRequests.filter(r=>r.status==='pending').length;
  if (pendSwaps > 3) insights.push({ icon:'fa-exchange-alt', color:'var(--gold)', bg:'var(--gold-bg)', title:'طلبات استبدال معلقة', text:`${pendSwaps} طلبات بانتظار الموافقة.` });
  const unassigned = exams.filter(e => !(e.proctor_ids||[]).length && examStatus(e)==='upcoming').length;
  if (unassigned > 0) insights.push({ icon:'fa-user-times', color:'var(--orange)', bg:'#fff7ed', title:'امتحانات بدون مراقبين', text:`${unassigned} امتحانات قادمة لم تُعيَّن لها مراقبون.` });
  if (!insights.length) insights.push({ icon:'fa-check-circle', color:'var(--green)', bg:'var(--green-bg)', title:'الوضع جيد', text:'لا توجد مشكلات تحتاج تدخلاً فورياً.' });
  return insights;
}

// ── إحصاءات المراقب ───────────────────────────────────────────
function _renderProctorAnalytics() {
  const me = STATE.currentUser;
  const myExams = STATE.exams.filter(e => e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(me.id));
  const done     = myExams.filter(e => examStatus(e) === 'completed').length;
  const upcoming = myExams.filter(e => examStatus(e) === 'upcoming').length;

  setHTML('anaActs', '');
  const rows = myExams.map(e => {
    const sub = getSubject(e.subject_id);
    const st  = examStatus(e);
    const col = { upcoming:'var(--primary2)', active:'var(--green)', completed:'var(--txt3)' }[st] || 'var(--txt3)';
    return '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border)">'
      + '<i class="fas fa-file-alt" style="color:' + col + '"></i>'
      + '<div style="flex:1"><div style="font-weight:700;font-size:13px">' + (sub?.name||'—') + '</div>'
      + '<div style="font-size:11px;color:var(--txt2)">' + fmtDate(e.date) + ' · ' + fmtTime(e.time) + '</div></div>'
      + getStatusBadge(st) + '</div>';
  }).join('');

  setHTML('anaContent',
    '<div class="stats-grid" style="margin-bottom:18px">'
    + '<div class="stat-card"><div class="stat-ic ic-blue"><i class="fas fa-clipboard-list"></i></div>'
    + '<div><div class="stat-val">' + myExams.length + '</div><div class="stat-lbl">إجمالي تكليفاتي</div></div></div>'
    + '<div class="stat-card"><div class="stat-ic ic-green"><i class="fas fa-check-circle"></i></div>'
    + '<div><div class="stat-val">' + done + '</div><div class="stat-lbl">امتحانات منتهية</div></div></div>'
    + '<div class="stat-card"><div class="stat-ic ic-gold"><i class="fas fa-clock"></i></div>'
    + '<div><div class="stat-val">' + upcoming + '</div><div class="stat-lbl">امتحانات قادمة</div></div></div>'
    + '</div>'
    + '<div class="card"><div class="card-h"><h3><i class="fas fa-list" style="color:var(--purple2)"></i> تكليفاتي هذا الفصل</h3></div>'
    + '<div class="card-b">' + (rows || '<div style="color:var(--txt3);text-align:center;padding:24px">لا تكليفات في هذا الفصل</div>') + '</div></div>'
  );
}