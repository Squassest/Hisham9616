// notifications.js v11 — الإشعارات الكاملة
// renderNotifications() معرّفة في core/utils.js
// هذا الملف يضيف: تذكيرات الامتحانات + إرسال الإشعارات (للمسؤول)

// ══════════════════════════════════════════════════════════════
//  1. تذكيرات الامتحانات عند الدخول / الداشبورد
// ══════════════════════════════════════════════════════════════
window._showExamReminders = async function() {
  const now = new Date();

  // ── تذكيرات الطالب ──────────────────────────────────────────
  if (STATE._studentUser) {
    const student = STATE._studentUser;
    await _refreshStudentAttendance?.(student.id);
    const { myExams } = _getStudentSemData(student, STATE.currentSem);
    const active = myExams.filter(e => examStatus(e) === 'active');
    const soon   = myExams.filter(e => {
      if (examStatus(e) !== 'upcoming') return false;
      const ms = new Date(`${e.date}T${e.time}`) - now;
      return ms > 0 && ms <= 48 * 3600 * 1000;
    }).sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

    if (active.length) {
      const sub = getSubject(active[0].subject_id);
      toast(`⚡ لديك امتحان جارٍ الآن: ${sub?.name || ''}`, 'warning', 7000);
    }
    soon.forEach((e, i) => {
      setTimeout(() => {
        const sub   = getSubject(e.subject_id);
        const start = new Date(`${e.date}T${e.time}`);
        const hrs   = Math.round((start - now) / 3600000);
        const when  = hrs === 0 ? 'الآن تقريباً' : hrs < 24 ? `خلال ${hrs} ساعة` : 'غداً';
        toast(`📅 امتحان قادم: ${sub?.name || ''} — ${when} (${fmtTime(e.time)})`, 'info', 6000);
      }, (i + (active.length ? 1 : 0)) * 1200);
    });
    return;
  }

  // ── تذكيرات الموظف / المراقب ────────────────────────────────
  const uid = STATE.currentUser?.id;
  if (!uid) return;

  const myExams = STATE.exams.filter(e =>
    (e.proctor_ids || []).includes(uid) && e.semester === STATE.currentSem
  );
  const active = myExams.filter(e => examStatus(e) === 'active');
  const soon   = myExams.filter(e => {
    if (examStatus(e) !== 'upcoming') return false;
    const ms = new Date(`${e.date}T${e.time}`) - now;
    return ms > 0 && ms <= 24 * 3600 * 1000;
  }).sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  if (active.length) {
    const sub = getSubject(active[0].subject_id);
    toast(`⚡ أنت مراقب في امتحان جارٍ: ${sub?.name || ''}`, 'warning', 7000);
  }
  soon.slice(0, 2).forEach((e, i) => {
    setTimeout(() => {
      const sub = getSubject(e.subject_id);
      const hrs = Math.round((new Date(`${e.date}T${e.time}`) - now) / 3600000);
      toast(`📋 مراقبة قادمة: ${sub?.name || ''} — خلال ${hrs} ساعة`, 'info', 5500);
    }, (i + (active.length ? 1 : 0)) * 1200);
  });

  // إشعارات النظام غير المقروءة
  const unread = (STATE.notifications || []).filter(n => !n.read);
  if (unread.length) {
    setTimeout(() => {
      toast(`🔔 لديك ${unread.length} إشعار${unread.length > 1 ? 'ات' : ''} غير مقروء${unread.length > 1 ? 'ة' : ''}`, 'info', 5000);
    }, 3000);
  }
};

// ══════════════════════════════════════════════════════════════
//  2. إرسال الإشعارات — للمسؤول والمنسق فقط
// ══════════════════════════════════════════════════════════════
function openSendNotification() {
  if (!isAdmin() && !isCoord()) { toast('غير مصرح', 'error'); return; }

  const moId = 'sendNotifMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  mo.innerHTML = `
    <div class="md" style="max-width:520px">
      <div class="md-hd">
        <h2><i class="fas fa-paper-plane" style="color:var(--primary2)"></i> إرسال إشعار للمستخدمين</h2>
        <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:20px;display:flex;flex-direction:column;gap:14px">

        <!-- المستهدفون -->
        <div>
          <label style="font-size:12.5px;font-weight:700;display:block;margin-bottom:6px">
            <i class="fas fa-users" style="color:var(--primary)"></i> المستهدفون
          </label>
          <select id="notifTarget" style="width:100%;padding:10px;border:1px solid var(--border);border-radius:9px;background:var(--bg);color:var(--txt);font-family:inherit;font-size:13px">
            <option value="all_proctors">جميع المراقبين</option>
            <option value="all_students">جميع الطلاب (عبر نظام الإشعارات)</option>
            <option value="admins">المسؤولون والمنسقون</option>
            <option value="dept_head">رؤساء الأقسام</option>
          </select>
        </div>

        <!-- نوع الإشعار -->
        <div>
          <label style="font-size:12.5px;font-weight:700;display:block;margin-bottom:6px">
            <i class="fas fa-tag" style="color:var(--primary)"></i> نوع الإشعار
          </label>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${['info','warning','success','exam'].map(t => {
              const labels = {info:'معلومة',warning:'تحذير',success:'نجاح',exam:'امتحان'};
              const icons  = {info:'fa-info-circle',warning:'fa-exclamation-triangle',success:'fa-check-circle',exam:'fa-file-alt'};
              const colors = {info:'var(--primary)',warning:'var(--gold)',success:'var(--green)',exam:'var(--purple2)'};
              return `<label style="display:flex;align-items:center;gap:6px;padding:7px 12px;border:1.5px solid var(--border);border-radius:8px;cursor:pointer;font-size:12.5px;font-weight:600">
                <input type="radio" name="notifType" value="${t}" ${t==='info'?'checked':''} style="accent-color:${colors[t]}">
                <i class="fas ${icons[t]}" style="color:${colors[t]}"></i> ${labels[t]}
              </label>`;
            }).join('')}
          </div>
        </div>

        <!-- العنوان -->
        <div>
          <label style="font-size:12.5px;font-weight:700;display:block;margin-bottom:6px">
            <i class="fas fa-heading" style="color:var(--primary)"></i> العنوان *
          </label>
          <input id="notifTitle" type="text" placeholder="عنوان الإشعار..."
            style="width:100%;padding:10px 14px;border:1px solid var(--border);border-radius:9px;background:var(--bg);color:var(--txt);font-family:inherit;font-size:13px;box-sizing:border-box">
        </div>

        <!-- النص -->
        <div>
          <label style="font-size:12.5px;font-weight:700;display:block;margin-bottom:6px">
            <i class="fas fa-align-left" style="color:var(--primary)"></i> نص الإشعار
          </label>
          <textarea id="notifBody" rows="3" placeholder="تفاصيل الإشعار (اختياري)..."
            style="width:100%;padding:10px 14px;border:1px solid var(--border);border-radius:9px;background:var(--bg);color:var(--txt);font-family:inherit;font-size:13px;resize:vertical;box-sizing:border-box"></textarea>
        </div>

      </div>
      <div class="md-ft" style="padding:14px 20px;display:flex;gap:10px;justify-content:flex-end">
        <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
        <button class="btn bp" id="sendNotifBtn" onclick="_doSendNotification()">
          <i class="fas fa-paper-plane"></i> إرسال
        </button>
      </div>
    </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _doSendNotification() {
  const target = document.getElementById('notifTarget')?.value;
  const type   = document.querySelector('input[name="notifType"]:checked')?.value || 'info';
  const title  = document.getElementById('notifTitle')?.value?.trim();
  const body   = document.getElementById('notifBody')?.value?.trim() || '';
  const btn    = document.getElementById('sendNotifBtn');

  if (!title) { toast('أدخل عنوان الإشعار', 'error'); return; }

  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإرسال...'; }

  try {
    const db = SB.getClient();

    // تحديد المستهدفين من profiles
    let targetRoles = [];
    if (target === 'all_proctors')     targetRoles = ['proctor'];
    else if (target === 'admins')      targetRoles = ['admin', 'coordinator'];
    else if (target === 'dept_head')   targetRoles = ['dept_head'];
    else if (target === 'all_students') {
      // إشعار للطلاب: نسجّله في toast_log فقط (بدون user_id في notifications)
      toast(`📢 تم إرسال إشعار بث للطلاب: "${title}"`, 'success');
      // نحفظ الإشعار العام في جدول notifications كـ broadcast
      await db.from('notifications').insert({
        user_id: STATE.currentUser.id, // المرسل
        title: `[بث للطلاب] ${title}`,
        body,
        type,
        is_read: false
      });
      closeMo('sendNotifMo');
      return;
    }

    // جلب users بالـ roles المحددة
    const { data: targets } = await db
      .from('profiles')
      .select('id')
      .in('role', targetRoles);

    if (!targets?.length) { toast('لا يوجد مستخدمون في هذه الفئة', 'warning'); return; }

    // إدراج الإشعارات
    const rows = targets.map(u => ({
      user_id: u.id,
      title,
      body,
      type,
      is_read: false
    }));

    const { error } = await db.from('notifications').insert(rows);
    if (error) throw new Error(error.message);

    toast(`✓ تم إرسال الإشعار لـ ${targets.length} مستخدم`, 'success');
    closeMo('sendNotifMo');

    // إضافة للحالة المحلية
    STATE.notifications.push(...rows.filter(r => r.user_id === STATE.currentUser?.id).map(r => ({
      ...r, id: Date.now(), created_at: new Date().toISOString()
    })));

  } catch(e) {
    toast('خطأ: ' + e.message, 'error');
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-paper-plane"></i> إرسال'; }
  }
}

// تصدير للاستخدام الخارجي
window.openSendNotification = openSendNotification;
