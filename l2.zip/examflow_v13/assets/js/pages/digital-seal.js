// ═══════════════════════════════════════════════════════════════
//  digital-seal.js — بروتوكول التسليم الرقمي v1
//  ختم رقمي للمراقب + سجل سلسلة حضور لا يمكن التلاعب به
// ═══════════════════════════════════════════════════════════════

function renderDigitalSeal() {
  const canDo = canEdit() || STATE.currentUser?.role === 'proctor';

  // زر إضافة ختم جديد
  if (canDo) {
    setHTML('sealActs', `
      <button class="btn bp btn-sm" onclick="openSealModal()">
        <i class="fas fa-stamp"></i> ختم امتحان جديد
      </button>`);
  }

  // جلب سجلات الختم من الذاكرة المحلية + Supabase
  _renderSealContent();
}

function _renderSealContent() {
  const seals = _getSeals();
  const myRole = STATE.currentUser?.role;

  let filtered = seals;
  if (myRole === 'proctor') {
    filtered = seals.filter(s => s.proctor_id === STATE.currentUser?.id);
  }

  // إحصائيات
  const total     = filtered.length;
  const today     = filtered.filter(s => s.timestamp?.startsWith(new Date().toISOString().slice(0,10))).length;
  const verified  = filtered.filter(s => s.chain_verified).length;

  setHTML('sealContent', `
    <!-- إحصائيات -->
    <div class="stats-grid" style="margin-bottom:20px">
      <div class="stat-card">
        <div class="stat-ic ic-purple"><i class="fas fa-stamp"></i></div>
        <div><div class="stat-val">${total}</div><div class="stat-lbl">إجمالي الأختام</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-blue"><i class="fas fa-calendar-day"></i></div>
        <div><div class="stat-val">${today}</div><div class="stat-lbl">أختام اليوم</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-green"><i class="fas fa-shield-check"></i></div>
        <div><div class="stat-val">${verified}</div><div class="stat-lbl">سجلات موثّقة</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-gold"><i class="fas fa-link"></i></div>
        <div><div class="stat-val">${total > 0 ? Math.round(verified/total*100) : 0}%</div><div class="stat-lbl">نسبة التحقق</div></div>
      </div>
    </div>

    <!-- شرح البروتوكول -->
    <div class="card" style="margin-bottom:16px;border-right:4px solid var(--purple)">
      <div class="card-b" style="display:flex;gap:14px;align-items:flex-start">
        <div style="width:42px;height:42px;border-radius:12px;background:var(--purple-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas fa-info-circle" style="color:var(--purple);font-size:18px"></i>
        </div>
        <div>
          <div style="font-weight:800;font-size:14px;margin-bottom:4px">كيف يعمل بروتوكول التسليم الرقمي؟</div>
          <div style="font-size:12.5px;color:var(--txt2);line-height:1.8">
            بعد انتهاء كل امتحان، يقوم المراقب بتسجيل <strong>ختم رقمي</strong> يتضمن توقيعه الإلكتروني وطابع زمني دقيق.
            كل ختم مرتبط بالختم السابق عبر <strong>سلسلة تشفير (Hash Chain)</strong> مما يجعل أي تعديل أو تلاعب مكشوفاً فوراً.
          </div>
        </div>
      </div>
    </div>

    <!-- قائمة الأختام -->
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-link" style="color:var(--purple2)"></i> سجل سلسلة الأختام الرقمية</h3>
        <div style="display:flex;gap:8px">
          <button class="btn bo btn-sm" onclick="_verifySealChain()">
            <i class="fas fa-shield-alt"></i> التحقق من السلسلة
          </button>
          <button class="btn bo btn-sm" onclick="_exportSealCSV()">
            <i class="fas fa-file-csv"></i> تصدير
          </button>
        </div>
      </div>
      <div id="sealList">
        ${filtered.length === 0
          ? `<div class="empty-state"><i class="fas fa-stamp"></i><p>لا توجد أختام مسجّلة بعد</p><span>قم بإضافة ختم بعد انتهاء الامتحان</span></div>`
          : filtered.map((s,i) => _buildSealRow(s, i, filtered)).join('')
        }
      </div>
    </div>

    <!-- مودال الختم -->
    <div class="mo" id="moSeal">
      <div class="md" style="max-width:560px">
        <div class="md-hd">
          <h2><i class="fas fa-stamp" style="color:var(--purple2)"></i> ختم رقمي جديد</h2>
          <button class="md-close" onclick="closeMo('moSeal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="md-bd" id="sealModalBody"></div>
        <div class="md-ft">
          <button class="btn bo" onclick="closeMo('moSeal')">إلغاء</button>
          <button class="btn bpurple" onclick="_submitSeal()">
            <i class="fas fa-stamp"></i> تسجيل الختم
          </button>
        </div>
      </div>
    </div>`);
}

function _buildSealRow(s, index, all) {
  const proctor = getProfile(s.proctor_id);
  const exam    = STATE.exams?.find(e => e.id === s.exam_id);
  const subject = exam ? getSubject(exam.subject_id) : null;
  const prev    = index > 0 ? all[index - 1] : null;
  const isValid = _verifySealHash(s, prev);

  return `
    <div style="display:flex;gap:14px;padding:14px 20px;border-bottom:1px solid var(--border);align-items:flex-start">
      <!-- Chain indicator -->
      <div style="display:flex;flex-direction:column;align-items:center;gap:0;flex-shrink:0">
        <div style="width:36px;height:36px;border-radius:10px;background:${isValid?'var(--green-bg)':'var(--red-bg)'};display:flex;align-items:center;justify-content:center">
          <i class="fas ${isValid?'fa-check':'fa-exclamation-triangle'}" style="color:${isValid?'var(--green)':'var(--red)'};font-size:14px"></i>
        </div>
        ${index < all.length-1 ? `<div style="width:2px;height:24px;background:${isValid?'var(--green)':'var(--border)'};margin:3px auto;border-radius:2px;opacity:.4"></div>` : ''}
      </div>
      <!-- Content -->
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:5px">
          <span style="font-weight:800;font-size:13.5px">${subject?.name || exam?.id || 'امتحان غير معروف'}</span>
          <span class="badge ${isValid?'b-green':'b-red'}">${isValid?'✓ موثّق':'⚠ خطأ في السلسلة'}</span>
          <span class="badge b-purple">${s.exam_type || 'نهائي'}</span>
        </div>
        <div style="font-size:12px;color:var(--txt2);margin-bottom:6px;display:flex;gap:16px;flex-wrap:wrap">
          <span><i class="fas fa-user-tie" style="margin-left:4px;color:var(--txt3)"></i>${proctor?.name || s.proctor_name || '—'}</span>
          <span><i class="fas fa-clock" style="margin-left:4px;color:var(--txt3)"></i>${new Date(s.timestamp).toLocaleString('ar-OM')}</span>
          <span><i class="fas fa-users" style="margin-left:4px;color:var(--txt3)"></i>${s.student_count || 0} طالب</span>
        </div>
        <!-- Hash -->
        <div style="font-family:monospace;font-size:10px;color:var(--txt3);background:var(--bg);padding:5px 8px;border-radius:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr">
          🔗 ${s.hash?.substring(0,48) || '—'}...
        </div>
        ${s.notes ? `<div style="font-size:11.5px;color:var(--txt2);margin-top:5px;padding:5px 8px;background:var(--gold-bg);border-radius:6px;border-right:2px solid var(--gold)">📝 ${s.notes}</div>` : ''}
      </div>
      <!-- Signature preview -->
      <div style="flex-shrink:0;text-align:center">
        ${s.signature_data
          ? `<img src="${s.signature_data}" style="width:60px;height:36px;object-fit:contain;border:1px solid var(--border);border-radius:6px;background:white">`
          : `<div style="width:60px;height:36px;border:1px dashed var(--border);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--txt3)">بدون توقيع</div>`
        }
      </div>
    </div>`;
}

function openSealModal() {
  // بناء قائمة الامتحانات المنتهية التي لم تُختم بعد
  const sealedExamIds = _getSeals().map(s => s.exam_id);
  const completedExams = STATE.exams?.filter(e =>
    examStatus(e) === 'completed' &&
    !sealedExamIds.includes(e.id) &&
    (canEdit() || (e.proctor_ids||[]).includes(STATE.currentUser?.id))
  ) || [];

  setHTML('sealModalBody', `
    <div class="field">
      <label class="field-lbl"><i class="fas fa-file-alt"></i> اختر الامتحان <span class="req">*</span></label>
      <select id="sealExamSel" onchange="_onSealExamChange()">
        <option value="">— اختر الامتحان —</option>
        ${completedExams.map(e => {
          const s = getSubject(e.subject_id);
          return `<option value="${e.id}">${s?.name||'—'} — ${e.date} ${e.time}</option>`;
        }).join('')}
        ${completedExams.length === 0 ? `<option disabled>لا توجد امتحانات منتهية بدون ختم</option>` : ''}
      </select>
    </div>
    <div id="sealExamInfo" style="display:none" class="card" style="margin-bottom:14px">
      <div class="card-b" id="sealExamInfoBody"></div>
    </div>
    <div class="g2">
      <div class="field">
        <label class="field-lbl"><i class="fas fa-users"></i> عدد الطلاب الحاضرين</label>
        <input type="number" id="sealStudCount" min="0" placeholder="0">
      </div>
      <div class="field">
        <label class="field-lbl"><i class="fas fa-tag"></i> نوع الامتحان</label>
        <select id="sealExamType">
          <option value="final">نهائي</option>
          <option value="midterm">منتصف الفصل</option>
          <option value="quiz">اختبار قصير</option>
          <option value="makeup">تعويضي</option>
        </select>
      </div>
    </div>
    <div class="field">
      <label class="field-lbl"><i class="fas fa-pen"></i> التوقيع الرقمي <span class="req">*</span></label>
      <div style="border:2px solid var(--border);border-radius:10px;overflow:hidden;background:white">
        <canvas id="sealSigCanvas" width="480" height="120"
          style="display:block;width:100%;cursor:crosshair;touch-action:none"></canvas>
      </div>
      <div style="display:flex;gap:8px;margin-top:6px">
        <button class="btn bo btn-xs" onclick="_clearSealSig()"><i class="fas fa-eraser"></i> مسح</button>
        <span style="font-size:11px;color:var(--txt3);align-self:center">ارسم توقيعك بالماوس أو باللمس</span>
      </div>
    </div>
    <div class="field">
      <label class="field-lbl"><i class="fas fa-sticky-note"></i> ملاحظات (اختياري)</label>
      <textarea id="sealNotes" placeholder="أي ملاحظات خاصة بالامتحان..." style="height:70px"></textarea>
    </div>`);

  openMo('moSeal');
  setTimeout(_initSealSignaturePad, 100);
}

function _onSealExamChange() {
  const examId = document.getElementById('sealExamSel')?.value;
  const infoDiv = document.getElementById('sealExamInfo');
  const infoBody = document.getElementById('sealExamInfoBody');
  if (!examId || !infoDiv) return;

  const exam    = STATE.exams?.find(e => e.id === examId);
  const subject = exam ? getSubject(exam.subject_id) : null;
  const rooms   = (exam?.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);

  infoDiv.style.display = 'block';
  infoBody.innerHTML = `
    <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:12.5px">
      <span><strong>المادة:</strong> ${subject?.name||'—'}</span>
      <span><strong>التاريخ:</strong> ${exam?.date||'—'} ${exam?.time||''}</span>
      <span><strong>المدة:</strong> ${exam?.duration||'—'} دقيقة</span>
      <span><strong>القاعات:</strong> ${rooms.join('، ')||'—'}</span>
    </div>`;

  // تعبئة عدد الطلاب تلقائياً
  const att = STATE.attendance?.filter(a => a.exam_id === examId && a.status === 'present') || [];
  const countEl = document.getElementById('sealStudCount');
  if (countEl) countEl.value = att.length || (exam?.section_ids?.length ? 30 : 0);
}

let _sealSigDrawing = false;
let _sealSigCtx = null;
function _initSealSignaturePad() {
  const canvas = document.getElementById('sealSigCanvas');
  if (!canvas) return;
  _sealSigCtx = canvas.getContext('2d');
  _sealSigCtx.strokeStyle = '#1e293b';
  _sealSigCtx.lineWidth = 2;
  _sealSigCtx.lineCap = 'round';

  const getPos = e => {
    const r = canvas.getBoundingClientRect();
    const src = e.touches ? e.touches[0] : e;
    return { x: (src.clientX - r.left) * (canvas.width / r.width),
             y: (src.clientY - r.top)  * (canvas.height / r.height) };
  };

  canvas.addEventListener('mousedown',  e => { _sealSigDrawing=true; const p=getPos(e); _sealSigCtx.beginPath(); _sealSigCtx.moveTo(p.x,p.y); });
  canvas.addEventListener('mousemove',  e => { if(!_sealSigDrawing)return; const p=getPos(e); _sealSigCtx.lineTo(p.x,p.y); _sealSigCtx.stroke(); });
  canvas.addEventListener('mouseup',    () => _sealSigDrawing=false);
  canvas.addEventListener('mouseleave', () => _sealSigDrawing=false);
  canvas.addEventListener('touchstart', e => { e.preventDefault(); _sealSigDrawing=true; const p=getPos(e); _sealSigCtx.beginPath(); _sealSigCtx.moveTo(p.x,p.y); }, {passive:false});
  canvas.addEventListener('touchmove',  e => { e.preventDefault(); if(!_sealSigDrawing)return; const p=getPos(e); _sealSigCtx.lineTo(p.x,p.y); _sealSigCtx.stroke(); }, {passive:false});
  canvas.addEventListener('touchend',   () => _sealSigDrawing=false);
}

function _clearSealSig() {
  const canvas = document.getElementById('sealSigCanvas');
  if (canvas && _sealSigCtx) _sealSigCtx.clearRect(0,0,canvas.width,canvas.height);
}

async function _submitSeal() {
  const examId     = document.getElementById('sealExamSel')?.value;
  const studCount  = parseInt(document.getElementById('sealStudCount')?.value || '0');
  const examType   = document.getElementById('sealExamType')?.value || 'final';
  const notes      = document.getElementById('sealNotes')?.value || '';
  const canvas     = document.getElementById('sealSigCanvas');

  if (!examId) { toast('يرجى اختيار الامتحان', 'error'); return; }

  // التحقق من وجود توقيع
  const sigData = canvas ? canvas.toDataURL() : null;
  const isBlankCanvas = _isCanvasBlank(canvas);
  if (isBlankCanvas) { toast('يرجى رسم توقيعك', 'error'); return; }

  const now       = new Date().toISOString();
  const prevSeals = _getSeals();
  const prevHash  = prevSeals.length > 0 ? prevSeals[prevSeals.length-1].hash : 'GENESIS';

  // بناء الختم
  const sealRecord = {
    id:           'seal_' + Date.now(),
    exam_id:      examId,
    proctor_id:   STATE.currentUser?.id,
    proctor_name: STATE.currentUser?.name,
    timestamp:    now,
    student_count:studCount,
    exam_type:    examType,
    notes:        notes,
    signature_data: sigData,
    prev_hash:    prevHash,
    chain_verified: true,
  };

  // توليد الـ Hash
  sealRecord.hash = await _generateSealHash(sealRecord);

  // حفظ محلياً
  _saveSeals([...prevSeals, sealRecord]);

  // محاولة رفع لـ Supabase
  try {
    await SB.getClient().from('exam_seals').insert({
      exam_id:       examId,
      proctor_id:    STATE.currentUser?.id,
      proctor_name:  STATE.currentUser?.name,
      timestamp:     now,
      student_count: studCount,
      exam_type:     examType,
      notes:         notes,
      hash:          sealRecord.hash,
      prev_hash:     prevHash,
    });
  } catch(e) {
    // يُحفظ محلياً ويُرفع لاحقاً عند الاتصال
  }

  closeMo('moSeal');
  toast('✅ تم تسجيل الختم الرقمي بنجاح', 'success');

  // سجل في audit log
  try { await SB.logAction('seal_exam', examId, 'ختم رقمي'); } catch{}

  _renderSealContent();
}

function _isCanvasBlank(canvas) {
  if (!canvas) return true;
  const blank = document.createElement('canvas');
  blank.width  = canvas.width;
  blank.height = canvas.height;
  return canvas.toDataURL() === blank.toDataURL();
}

async function _generateSealHash(seal) {
  const raw = `${seal.exam_id}|${seal.proctor_id}|${seal.timestamp}|${seal.student_count}|${seal.prev_hash}`;
  if (window.crypto?.subtle) {
    const enc  = new TextEncoder().encode(raw);
    const buf  = await crypto.subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
  }
  // Fallback hash
  let hash = 0;
  for (let i=0; i<raw.length; i++) { hash = ((hash<<5)-hash)+raw.charCodeAt(i); hash|=0; }
  return Math.abs(hash).toString(16).padStart(16,'0') + Date.now().toString(16);
}

function _verifySealHash(seal, prev) {
  if (!seal.hash) return false;
  const expectedPrev = prev ? prev.hash : 'GENESIS';
  return seal.prev_hash === expectedPrev;
}

async function _verifySealChain() {
  const seals = _getSeals();
  if (seals.length === 0) { toast('لا توجد أختام للتحقق', 'warning'); return; }
  let ok = 0, broken = 0;
  for (let i=0; i<seals.length; i++) {
    const prev = i > 0 ? seals[i-1] : null;
    if (_verifySealHash(seals[i], prev)) ok++;
    else broken++;
  }
  if (broken === 0) {
    toast(`✅ سلسلة موثّقة بالكامل — ${ok} ختم صحيح`, 'success');
  } else {
    toast(`⚠️ تحذير: ${broken} ختم بها مشكلة في السلسلة!`, 'error');
  }
}

function _exportSealCSV() {
  const seals = _getSeals();
  if (!seals.length) { toast('لا توجد بيانات للتصدير','warning'); return; }
  const rows = [
    ['المعرف','الامتحان','المراقب','الوقت','عدد الطلاب','النوع','الملاحظات','Hash','موثّق'],
    ...seals.map(s => [
      s.id, s.exam_id, s.proctor_name || s.proctor_id,
      s.timestamp, s.student_count, s.exam_type, s.notes || '',
      s.hash, s.chain_verified ? 'نعم' : 'لا'
    ])
  ];
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `digital_seals_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  toast('تم تصدير السجل بنجاح','success');
}

function _getSeals() {
  try { return JSON.parse(localStorage.getItem('examflow_seals') || '[]'); } catch { return []; }
}
function _saveSeals(seals) {
  try { localStorage.setItem('examflow_seals', JSON.stringify(seals)); } catch {}
}
