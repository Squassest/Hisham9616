// ═══════════════════════════════════════════════════════════════
//  qr-attendance.js v2 — حضور QR + بصمة الطالب من هاتفه
//   - المراقب يولّد QR ديناميكي (يدور كل 30s)
//   - الطالب يمسحه → صفحة تسجيل جميلة (بلا prompt)
//   - خيار 1: بصمة الطالب من هاتفه (Passkey)
//   - خيار 2: رقم الطالب الجامعي
// ═══════════════════════════════════════════════════════════════

const QR_LIB      = 'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js';
const QR_SCAN_LIB = 'https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js';

function _loadScript(src) {
  return new Promise((res, rej) => {
    if (document.querySelector(`script[src="${src}"]`)) return res();
    const s = document.createElement('script');
    s.src = src; s.onload = res; s.onerror = rej;
    document.head.appendChild(s);
  });
}

// ── client آمن (يعمل قبل وبعد تسجيل الدخول) ──────────────────
function _attDB() {
  if (typeof SB !== 'undefined' && SB.getClient?.()) return SB.getClient();
  if (window._efSB) return window._efSB;
  if (window.supabase && window.APP_CONFIG)
    return window.supabase.createClient(APP_CONFIG.SUPABASE_URL, APP_CONFIG.SUPABASE_ANON_KEY);
  throw new Error('لم يكتمل تحميل الصفحة بعد');
}

// ════════════════════════════════════════════════════════════════
//  شاشة المراقب: توليد QR
// ════════════════════════════════════════════════════════════════
async function openQRGenerator(examId) {
  await _loadScript(QR_LIB);
  STATE._qrExamId = examId;
  const e   = getExam(examId);
  const sub = getSubject(e?.subject_id);

  const moId = 'qrGenMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  mo.innerHTML = `
    <div class="md" style="max-width:500px">
      <div class="md-hd">
        <h2><i class="fas fa-qrcode" style="color:var(--primary)"></i> رمز الحضور</h2>
        <button class="md-close" onclick="_closeQR()"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:24px;text-align:center">
        <div style="font-weight:800;font-size:15px;margin-bottom:3px">${esc(sub?.name||'—')}</div>
        <div style="font-size:12px;color:var(--txt2);margin-bottom:20px">${fmtDate(e?.date)} · ${fmtTime(e?.time)}</div>

        <div id="qrBox" style="width:290px;height:290px;background:white;border-radius:20px;padding:14px;margin:0 auto;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 24px rgba(0,0,0,.12)"></div>

        <div style="margin-top:16px;display:flex;align-items:center;justify-content:center;gap:8px">
          <div style="width:8px;height:8px;background:var(--green);border-radius:50%" id="qrDot"></div>
          <span style="font-size:12.5px;color:var(--txt2)">يتجدد خلال <b id="qrSec">30</b> ثانية</span>
        </div>
        <div style="font-size:11.5px;color:var(--txt3);margin-top:8px;padding:10px;background:var(--primary-bg);border-radius:10px">
          <i class="fas fa-mobile-alt"></i>
          الطلاب يصوّرون هذا الرمز بهواتفهم ويسجّلون بصماتهم أو أرقامهم الجامعية
        </div>
      </div>
    </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
  _rotateQR();
}

let _qrTimer = null, _qrCountTimer = null;
function _closeQR() {
  closeMo('qrGenMo');
  clearInterval(_qrTimer);
  clearInterval(_qrCountTimer);
}

async function _rotateQR() {
  const examId = STATE._qrExamId;
  const token  = _genToken();
  const ttl    = 30;
  const expiresAt = new Date(Date.now() + ttl * 1000).toISOString();

  await SB.update('exams', examId, { qr_token: token, qr_expires_at: expiresAt });

  const url = `${location.origin}${location.pathname}#att?e=${examId}&t=${token}`;
  const box = document.getElementById('qrBox');
  if (box) {
    box.innerHTML = '';
    const cv = document.createElement('canvas');
    box.appendChild(cv);
    QRCode.toCanvas(cv, url, { width: 262, margin: 1 });
  }

  let s = ttl;
  const sEl = document.getElementById('qrSec');
  const dot = document.getElementById('qrDot');
  clearInterval(_qrCountTimer);
  _qrCountTimer = setInterval(() => {
    s--;
    if (sEl) sEl.textContent = s;
    if (dot) dot.style.opacity = (s % 2 === 0) ? '1' : '0.3';
    if (s <= 0) clearInterval(_qrCountTimer);
  }, 1000);

  clearTimeout(_qrTimer);
  _qrTimer = setTimeout(_rotateQR, ttl * 1000);
}

function _genToken() {
  return Array.from(crypto.getRandomValues(new Uint8Array(12)))
    .map(b => b.toString(16).padStart(2, '0')).join('');
}

// ════════════════════════════════════════════════════════════════
//  شاشة الطالب: مسح QR (من داخل التطبيق — للطلاب المسجلين)
// ════════════════════════════════════════════════════════════════
async function openStudentScanner() {
  await _loadScript(QR_SCAN_LIB);
  const moId = 'qrScanMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  mo.innerHTML = `
    <div class="md" style="max-width:460px">
      <div class="md-hd">
        <h2><i class="fas fa-camera" style="color:var(--primary)"></i> مسح رمز الحضور</h2>
        <button class="md-close" onclick="_closeScanner()"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:18px">
        <div id="qrReader" style="width:100%;border-radius:14px;overflow:hidden"></div>
        <div id="qrScanMsg" style="margin-top:14px;font-size:13px;color:var(--txt2);text-align:center">
          <i class="fas fa-camera"></i> وجّه الكاميرا نحو رمز QR الموجود لدى المراقب
        </div>
      </div>
    </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));

  const html5 = new Html5Qrcode('qrReader');
  STATE._qrScanner = html5;
  html5.start({ facingMode: 'environment' },
    { fps: 10, qrbox: 240 },
    async (decoded) => {
      try { await html5.stop(); } catch {}
      _closeScanner();
      // استخرج examId + token وافتح صفحة التسجيل
      const m = decoded.match(/[?&#]e=(\d+).*?t=([a-f0-9]+)/);
      if (m) _showAttendancePage(parseInt(m[1]), m[2]);
      else toast('رمز QR غير صالح', 'error');
    },
    () => {}
  );
}

function _closeScanner() {
  try { STATE._qrScanner?.stop(); } catch {}
  closeMo('qrScanMo');
}

// ════════════════════════════════════════════════════════════════
//  صفحة تسجيل الحضور — تفتح على هاتف الطالب
//  (من مسح QR أو من رابط مباشر #att)
// ════════════════════════════════════════════════════════════════
async function _showAttendancePage(examId, token) {
  // إزالة أي صفحة حضور قديمة
  document.getElementById('attPage')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'attPage';
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:9999;
    background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%);
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    padding:24px;color:white;font-family:inherit;direction:rtl;
  `;

  overlay.innerHTML = `
    <div style="width:100%;max-width:400px">

      <!-- Header -->
      <div style="text-align:center;margin-bottom:28px">
        <div style="font-size:38px;margin-bottom:10px">🎓</div>
        <h2 style="margin:0;font-size:20px;font-weight:800">تسجيل الحضور</h2>
        <div id="attExamInfo" style="font-size:12.5px;opacity:.7;margin-top:6px">جارٍ التحقق من الرمز...</div>
      </div>

      <!-- حالة التحقق -->
      <div id="attStatus" style="
        background:rgba(255,255,255,.08);border-radius:18px;padding:22px;
        text-align:center;margin-bottom:22px;min-height:80px;
        display:flex;align-items:center;justify-content:center;
      ">
        <div><i class="fas fa-spinner fa-spin" style="font-size:28px;opacity:.6"></i></div>
      </div>

      <!-- تسجيل الدخول: رقم جامعي + كلمة مرور -->
      <div id="attIdSection" style="display:none">
        <div style="font-size:12px;opacity:.7;text-align:center;margin-bottom:12px">
          <i class="fas fa-lock" style="margin-left:4px"></i>
          سجّل دخولك بمعلومات حسابك الجامعي
        </div>
        <input id="attStudId" type="text" placeholder="الرقم الجامعي" inputmode="text" autocomplete="username"
          style="
            width:100%;padding:14px 18px;border-radius:12px;border:1.5px solid rgba(255,255,255,.15);
            background:rgba(255,255,255,.10);color:white;font-size:14px;
            font-family:inherit;box-sizing:border-box;outline:none;margin-bottom:10px;
          "
          onfocus="this.style.borderColor='rgba(255,255,255,.5)'"
          onblur="this.style.borderColor='rgba(255,255,255,.15)'"
          onkeydown="if(event.key==='Enter') document.getElementById('attStudPass').focus()">
        <div style="position:relative">
          <input id="attStudPass" type="password" placeholder="كلمة المرور" autocomplete="current-password"
            style="
              width:100%;padding:14px 48px 14px 18px;border-radius:12px;border:1.5px solid rgba(255,255,255,.15);
              background:rgba(255,255,255,.10);color:white;font-size:14px;
              font-family:inherit;box-sizing:border-box;outline:none;
            "
            onfocus="this.style.borderColor='rgba(255,255,255,.5)'"
            onblur="this.style.borderColor='rgba(255,255,255,.15)'"
            onkeydown="if(event.key==='Enter') _attCheckInLogin()">
          <button onclick="(function(e){const i=document.getElementById('attStudPass');i.type=i.type==='password'?'text':'password';e.innerHTML=i.type==='password'?'<i class=\\'fas fa-eye\\'></i>':'<i class=\\'fas fa-eye-slash\\'></i>';})(this)"
            style="position:absolute;left:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:rgba(255,255,255,.5);cursor:pointer;padding:4px">
            <i class="fas fa-eye"></i>
          </button>
        </div>
        <button id="attLoginBtn" onclick="_attCheckInLogin()" style="
          width:100%;margin-top:12px;padding:15px;border-radius:14px;border:none;cursor:pointer;
          background:linear-gradient(135deg,#2563eb,#0ea5e9);color:white;font-size:14px;font-weight:700;
          font-family:inherit;transition:.2s;display:flex;align-items:center;justify-content:center;gap:8px;
        ">
          <i class="fas fa-check-circle"></i> تسجيل الحضور
        </button>
        <div id="attLoginErr" style="display:none;margin-top:10px;padding:10px 14px;background:rgba(239,68,68,.2);border:1px solid rgba(239,68,68,.4);border-radius:10px;font-size:12.5px;color:#fca5a5;text-align:center"></div>
      </div>

      <!-- زر الإغلاق -->
      <button onclick="document.getElementById('attPage').remove(); history.replaceState(null,'',location.pathname);"
        style="
          width:100%;margin-top:20px;padding:12px;border-radius:12px;border:none;cursor:pointer;
          background:rgba(255,255,255,.07);color:rgba(255,255,255,.5);
          font-size:12.5px;font-family:inherit;
        ">
        إغلاق
      </button>
    </div>
  `;

  document.body.appendChild(overlay);

  // حفظ بيانات الجلسة للاستخدام في دوال _att
  window._attSession = { examId, token };

  // تحقق من صحة الرمز وجهّز الصفحة
  await _attVerifyAndSetup(examId, token);
}

async function _attVerifyAndSetup(examId, token) {
  const statusEl   = document.getElementById('attStatus');
  const infoEl     = document.getElementById('attExamInfo');
  const bioSection = document.getElementById('attBioSection');
  const idSection  = document.getElementById('attIdSection');
  const divider    = document.getElementById('attDivider');

  try {
    const db = _attDB();

    // جلب بيانات الامتحان وتحقق من الرمز
    const { data: exam, error } = await db
      .from('exams')
      .select('id,subject_id,date,time,room_id,qr_token,qr_expires_at,allow_qr')
      .eq('id', examId).single();

    if (error || !exam)        throw new Error('الامتحان غير موجود');
    if (exam.qr_token !== token) throw new Error('رمز QR غير صالح أو منتهي الصلاحية');
    if (new Date(exam.qr_expires_at) < new Date()) throw new Error('انتهت صلاحية الرمز — اطلب من المراقب تحديثه');

    // جلب اسم المادة
    const { data: subj } = await db.from('subjects').select('name').eq('id', exam.subject_id).maybeSingle();

    if (infoEl) {
      infoEl.textContent = `${subj?.name||'امتحان'} · ${exam.date||''} ${exam.time||''}`;
    }

    statusEl.innerHTML = `
      <div style="color:#4ade80;font-size:36px;margin-bottom:8px">✓</div>
      <div style="font-size:14px;font-weight:700">رمز صالح — سجّل حضورك</div>
    `;

    // إظهار الخيارات
    idSection.style.display = 'block';

  } catch(e) {
    statusEl.innerHTML = `
      <div>
        <div style="color:#f87171;font-size:28px;margin-bottom:8px">✗</div>
        <div style="font-size:13px;font-weight:600">${e.message}</div>
      </div>
    `;
  }
}

// تسجيل الحضور بالبصمة (من هاتف الطالب)
window._attCheckInBio = async function() {
  const btn      = document.getElementById('attBioBtn');
  const statusEl = document.getElementById('attStatus');
  const { examId } = window._attSession || {};
  if (!examId) return;

  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin" style="font-size:22px"></i> ضع إصبعك على المستشعر...'; }
  statusEl.innerHTML = `<div style="font-size:38px">👆</div>`;

  try {
    // على هاتف الطالب: Passkey مخزن على هاتفه → يعرّفه تلقائياً
    const result = await BIO.authenticateStudentAuto();
    await _attDoCheckIn(examId, result.studentId, 'biometric', statusEl);
  } catch(e) {
    statusEl.innerHTML = `
      <div>
        <div style="color:#f87171;font-size:22px;margin-bottom:6px">✗</div>
        <div style="font-size:13px">${e.message}</div>
        <div style="font-size:11px;opacity:.6;margin-top:6px">استخدم رقمك الجامعي بدلاً من ذلك</div>
      </div>`;
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-fingerprint" style="font-size:24px"></i> سجّل حضوري بالبصمة'; }
  }
};

// تسجيل الحضور بالرقم الجامعي + كلمة المرور (الإصدار الجديد)
window._attCheckInLogin = async function() {
  const sid      = document.getElementById('attStudId')?.value?.trim();
  const pass     = document.getElementById('attStudPass')?.value;
  const statusEl = document.getElementById('attStatus');
  const errEl    = document.getElementById('attLoginErr');
  const btn      = document.getElementById('attLoginBtn');
  const { examId } = window._attSession || {};
  if (!examId) return;

  const _setErr = msg => {
    if (!errEl) return;
    errEl.textContent = msg;
    errEl.style.display = msg ? 'block' : 'none';
  };

  if (!sid || !pass) {
    _setErr('يرجى إدخال الرقم الجامعي وكلمة المرور');
    if (!sid && document.getElementById('attStudId'))
      document.getElementById('attStudId').style.borderColor = 'rgba(239,68,68,.7)';
    if (!pass && document.getElementById('attStudPass'))
      document.getElementById('attStudPass').style.borderColor = 'rgba(239,68,68,.7)';
    return;
  }

  _setErr('');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جارٍ التحقق...'; }

  try {
    const db = _attDB();

    // 1. التحقق من الهوية: رقم جامعي + كلمة المرور
    const { data: student, error: sErr } = await db
      .from('students')
      .select('id,name,stud_id')
      .eq('stud_id', sid)
      .eq('password', pass)
      .maybeSingle();

    if (sErr || !student) throw new Error('الرقم الجامعي أو كلمة المرور غير صحيحة');
    if (student.banned) throw new Error('حسابك موقوف، تواصل مع الإدارة');

    // 2. التحقق أن الطالب مسجّل في إحدى شُعَب الامتحان
    const { data: exam, error: eErr } = await db
      .from('exams')
      .select('id,section_ids,subject_id,qr_token,qr_expires_at')
      .eq('id', examId)
      .maybeSingle();

    if (eErr || !exam) throw new Error('الامتحان غير موجود');

    // التحقق من صلاحية الرمز مرة أخرى
    const { token } = window._attSession || {};
    if (exam.qr_token !== token)           throw new Error('رمز QR انتهت صلاحيته — اطلب من المراقب تحديثه');
    if (new Date(exam.qr_expires_at) < new Date()) throw new Error('انتهت صلاحية الرمز — اطلب من المراقب تحديثه');

    // التحقق من الانتساب للشعبة
    let sectionIds = exam.section_ids;
    if (typeof sectionIds === 'string') { try { sectionIds = JSON.parse(sectionIds); } catch { sectionIds = []; } }
    sectionIds = (sectionIds || []).map(Number).filter(Boolean);

    if (!sectionIds.length) throw new Error('هذا الامتحان لا يحتوي على شُعَب مسجّلة');

    const { data: secs, error: secErr } = await db
      .from('sections')
      .select('id,student_ids')
      .in('id', sectionIds);

    if (secErr) throw new Error('خطأ في التحقق من الشعبة');

    const inSection = (secs || []).some(sec => {
      let ids = sec.student_ids;
      if (typeof ids === 'string') { try { ids = JSON.parse(ids); } catch { ids = []; } }
      return (ids || []).map(Number).includes(Number(student.id));
    });

    if (!inSection) throw new Error('أنت غير مسجّل في شُعبة هذا الامتحان');

    // 3. تسجيل الحضور
    await _attDoCheckIn(examId, student.id, 'qr', statusEl, student);

  } catch(e) {
    _setErr(e.message);
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check-circle"></i> تسجيل الحضور'; }
  }
};

// للتوافق مع المنادى القديم _attCheckInId
window._attCheckInId = window._attCheckInLogin;

// تنفيذ فعلي لتسجيل الحضور
async function _attDoCheckIn(examId, studentId, method, statusEl, studentData) {
  const db = _attDB();

  let lat = null, lng = null, device = null;
  try {
    if (typeof GEO !== 'undefined') {
      const p = await GEO.getCurrent();
      lat = p.lat; lng = p.lng;
      device = await GEO.deviceHash?.() || null;
    }
  } catch {}

  // جلب اسم الطالب إذا لم نعرفه
  if (!studentData) {
    const { data } = await db.from('students').select('id,name,stud_id').eq('id', studentId).maybeSingle();
    studentData = data;
  }

  // محاولة RPC أولاً، ثم upsert مباشر كـ fallback
  let checkInError = null;
  try {
    const { error: rpcErr } = await db.rpc('check_in_student', {
      p_exam_id:    examId,
      p_student_id: studentId,
      p_method:     method,
      p_lat:        lat,
      p_lng:        lng,
      p_device:     device
    });
    checkInError = rpcErr;
  } catch { checkInError = null; }

  // Fallback: upsert مباشر في جدول attendance
  if (checkInError) {
    const { error: uErr } = await db.from('attendance').upsert({
      exam_id:     examId,
      student_id:  studentId,
      status:      'present',
      method:      method,
      recorded_at: new Date().toISOString()
    }, { onConflict: 'exam_id,student_id' });
    if (uErr) throw new Error(uErr.message);
  }

  const error = null; // تجاوز الفحص القديم
  const warn = '';

  statusEl.innerHTML = `
    <div style="text-align:center">
      <div style="font-size:44px;margin-bottom:8px">✅</div>
      <div style="font-size:17px;font-weight:800;color:#4ade80">تم تسجيل حضورك</div>
      <div style="font-size:13px;opacity:.8;margin-top:4px">${esc(studentData?.name||'')}</div>
      ${warn}
    </div>`;

  // تحديث STATE المحلي إذا كان المستخدم مسجلاً دخوله
  if (window.STATE) {
    if (STATE.attendance) {
      if (!STATE.attendance[examId]) STATE.attendance[examId] = {};
      STATE.attendance[examId][Number(studentId)] = 'present';
    }
    // تحديث سجل الطالب إذا كان مسجلاً بالبوابة
    if (STATE._studentAttendance !== undefined) {
      STATE._studentAttendance[Number(examId)] = 'present';
    }
  }

  // إغلاق بعد 3.5 ثانية
  setTimeout(() => {
    document.getElementById('attPage')?.remove();
    history.replaceState(null, '', location.pathname);
  }, 3500);
}

// ════════════════════════════════════════════════════════════════
//  معالج رابط مباشر  #att?e=...&t=...
//  يُستدعى عند فتح الطالب للرابط من متصفحه مباشرة
// ════════════════════════════════════════════════════════════════
window.addEventListener('hashchange', _handleAttHash);
window.addEventListener('load',       _handleAttHash);

async function _handleAttHash() {
  const h = location.hash || '';
  if (!h.startsWith('#att')) return;
  const m = h.match(/e=(\d+).*?t=([a-f0-9]+)/);
  if (!m) return;

  const examId = parseInt(m[1]);
  const token  = m[2];

  // انتظر تحميل Supabase (قد يُستدعى مبكراً جداً)
  let tries = 0;
  const waitAndOpen = () => {
    try {
      _attDB(); // اختبر الاتصال
      _showAttendancePage(examId, token);
    } catch {
      if (tries++ < 20) setTimeout(waitAndOpen, 300);
    }
  };
  waitAndOpen();
}
