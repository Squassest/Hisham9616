// ═══════════════════════════════════════════════════════════════════════════════
//  test-student-login.js
//  أداة اختبار: للتحقق من إصلاحات دخول الطالب
//
//  الاستخدام:
//  انسخ هذا الملف في console (F12) بعد فتح الصفحة
// ═══════════════════════════════════════════════════════════════════════════════

(function() {
  const Tests = {
    results: [],
    
    // ────────────────────────────────────────────────────────────────
    // Helper: Log with styling
    // ────────────────────────────────────────────────────────────────
    log: function(title, message, type = 'info') {
      const styles = {
        info:  'background: #3b82f6; color: white; padding: 4px 8px; border-radius: 3px;',
        success: 'background: #10b981; color: white; padding: 4px 8px; border-radius: 3px;',
        warning: 'background: #f59e0b; color: white; padding: 4px 8px; border-radius: 3px;',
        error: 'background: #ef4444; color: white; padding: 4px 8px; border-radius: 3px;',
      };
      console.log(`%c${title}`, styles[type], message || '');
      this.results.push({ title, message, type });
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 1: Check if functions are defined
    // ────────────────────────────────────────────────────────────────
    test1_FunctionsDefined: function() {
      this.log('TEST 1', '🔍 فحص: هل الدوال معرّفة؟', 'info');
      
      const checks = [
        { name: 'studentLogin', fn: window.studentLogin },
        { name: 'restoreStudentSession', fn: window.restoreStudentSession },
        { name: 'studentLogout', fn: window.studentLogout },
        { name: 'APP.boot', fn: window.APP?.boot },
        { name: 'APP.studentLogout', fn: window.APP?.studentLogout },
      ];
      
      let allDefined = true;
      checks.forEach(check => {
        const isDefined = typeof check.fn === 'function';
        const status = isDefined ? '✓' : '✗';
        this.log(`  ${status} ${check.name}`, isDefined ? 'معرّفة' : 'غير معرّفة', isDefined ? 'success' : 'error');
        if (!isDefined) allDefined = false;
      });
      
      return allDefined;
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 2: Check localStorage
    // ────────────────────────────────────────────────────────────────
    test2_LocalStorage: function() {
      this.log('TEST 2', '🔍 فحص: localStorage', 'info');
      
      try {
        const test = 'test_' + Date.now();
        localStorage.setItem(test, 'value');
        const retrieved = localStorage.getItem(test);
        localStorage.removeItem(test);
        
        if (retrieved === 'value') {
          this.log('  ✓ localStorage', 'يعمل بشكل صحيح', 'success');
          return true;
        } else {
          this.log('  ✗ localStorage', 'فشل الاختبار', 'error');
          return false;
        }
      } catch (e) {
        this.log('  ✗ localStorage', e.message, 'error');
        return false;
      }
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 3: Check STATE object
    // ────────────────────────────────────────────────────────────────
    test3_StateObject: function() {
      this.log('TEST 3', '🔍 فحص: STATE object', 'info');
      
      const checks = [
        { name: 'STATE._studentUser', prop: () => STATE?._studentUser !== undefined },
        { name: 'STATE._studentAttendance', prop: () => STATE?._studentAttendance !== undefined },
        { name: 'STATE.exams', prop: () => STATE?.exams !== undefined },
        { name: 'STATE.sections', prop: () => STATE?.sections !== undefined },
      ];
      
      let allFound = true;
      checks.forEach(check => {
        const exists = check.prop();
        const status = exists ? '✓' : '✗';
        this.log(`  ${status} ${check.name}`, exists ? 'موجود' : 'غير موجود', exists ? 'success' : 'warning');
        if (!exists) allFound = false;
      });
      
      return allFound;
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 4: Simulate student login
    // ────────────────────────────────────────────────────────────────
    test4_SaveSession: function() {
      this.log('TEST 4', '🔍 فحص: حفظ جلسة الطالب', 'info');
      
      try {
        const mockStudent = {
          id: 999,
          stud_id: 'TEST123',
          name: 'طالب اختبار',
          email: 'test@example.com'
        };
        
        localStorage.setItem('_studentSession', JSON.stringify({
          student: mockStudent,
          timestamp: Date.now()
        }));
        
        const saved = localStorage.getItem('_studentSession');
        if (saved) {
          const parsed = JSON.parse(saved);
          this.log('  ✓ حفظ الجلسة', `تم حفظ جلسة الطالب: ${parsed.student.stud_id}`, 'success');
          localStorage.removeItem('_studentSession');  // امسح بعد الاختبار
          return true;
        } else {
          this.log('  ✗ حفظ الجلسة', 'فشل الحفظ', 'error');
          return false;
        }
      } catch (e) {
        this.log('  ✗ حفظ الجلسة', e.message, 'error');
        return false;
      }
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 5: Test restoreStudentSession function
    // ────────────────────────────────────────────────────────────────
    test5_RestoreSession: function() {
      this.log('TEST 5', '🔍 فحص: استعادة الجلسة من localStorage', 'info');
      
      try {
        if (typeof window.restoreStudentSession !== 'function') {
          this.log('  ✗ restoreStudentSession', 'الدالة غير معرّفة', 'error');
          return false;
        }
        
        // حفظ جلسة تجريبية
        const mockStudent = {
          id: 888,
          stud_id: 'TEST456',
          name: 'طالب آخر',
          email: 'another@example.com'
        };
        
        localStorage.setItem('_studentSession', JSON.stringify({
          student: mockStudent,
          timestamp: Date.now()
        }));
        
        // جرّب الاستعادة
        const restored = window.restoreStudentSession();
        
        if (restored && restored.stud_id === 'TEST456') {
          this.log('  ✓ استعادة الجلسة', `تم استعادة جلسة: ${restored.stud_id}`, 'success');
          localStorage.removeItem('_studentSession');
          return true;
        } else {
          this.log('  ✗ استعادة الجلسة', 'فشل الاستعادة', 'error');
          localStorage.removeItem('_studentSession');
          return false;
        }
      } catch (e) {
        this.log('  ✗ استعادة الجلسة', e.message, 'error');
        return false;
      }
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 6: Check STATE initialization
    // ────────────────────────────────────────────────────────────────
    test6_StateInitialization: function() {
      this.log('TEST 6', '🔍 فحص: تهيئة STATE', 'info');
      
      if (!window.STATE) {
        this.log('  ✗ STATE', 'object غير موجود', 'error');
        return false;
      }
      
      // تحقق من القيم الأولية
      const checks = [
        { name: '_studentUser', value: STATE._studentUser, expected: null },
        { name: '_studentAttendance', value: STATE._studentAttendance, isArray: true },
      ];
      
      let allCorrect = true;
      checks.forEach(check => {
        if (check.expected !== undefined && check.value !== check.expected) {
          this.log(`  ⚠ STATE.${check.name}`, `القيمة: ${check.value} (متوقع: ${check.expected})`, 'warning');
          allCorrect = false;
        } else if (check.isArray && !Array.isArray(check.value) && typeof check.value !== 'object') {
          this.log(`  ⚠ STATE.${check.name}`, 'يجب أن يكون array أو object', 'warning');
        } else {
          this.log(`  ✓ STATE.${check.name}`, `صحيح`, 'success');
        }
      });
      
      return allCorrect;
    },
    
    // ────────────────────────────────────────────────────────────────
    // Test 7: Check UI elements
    // ────────────────────────────────────────────────────────────────
    test7_UIElements: function() {
      this.log('TEST 7', '🔍 فحص: عناصر الواجهة', 'info');
      
      const elements = [
        { id: 'studEmailInput', name: 'حقل البريد الإلكتروني' },
        { id: 'studPassInput', name: 'حقل كلمة المرور' },
        { id: 'studLoginBtn', name: 'زر دخول الطالب' },
        { id: 'studLoginErr', name: 'رسالة الخطأ' },
        { id: 'app', name: 'حاوية التطبيق' },
        { id: 'loginScreen', name: 'شاشة الدخول' },
      ];
      
      let allFound = true;
      elements.forEach(el => {
        const exists = document.getElementById(el.id) !== null;
        const status = exists ? '✓' : '✗';
        this.log(`  ${status} ${el.name} (#${el.id})`, exists ? 'موجود' : 'غير موجود', exists ? 'success' : 'warning');
        if (!exists) allFound = false;
      });
      
      return allFound;
    },
    
    // ────────────────────────────────────────────────────────────────
    // Run all tests
    // ────────────────────────────────────────────────────────────────
    runAll: function() {
      console.clear();
      console.log('%c═══════════════════════════════════════════════════════════════', 'color: #3b82f6; font-weight: bold;');
      console.log('%c   🧪 اختبار إصلاحات دخول الطالب - ExamFlow v13', 'color: #3b82f6; font-weight: bold; font-size: 14px;');
      console.log('%c═══════════════════════════════════════════════════════════════', 'color: #3b82f6; font-weight: bold;');
      console.log('');
      
      const results = [
        this.test1_FunctionsDefined(),
        this.test2_LocalStorage(),
        this.test3_StateObject(),
        this.test4_SaveSession(),
        this.test5_RestoreSession(),
        this.test6_StateInitialization(),
        this.test7_UIElements(),
      ];
      
      console.log('');
      console.log('%c═══════════════════════════════════════════════════════════════', 'color: #3b82f6; font-weight: bold;');
      
      const passed = results.filter(r => r).length;
      const total = results.length;
      const percentage = Math.round((passed / total) * 100);
      
      if (percentage === 100) {
        console.log(`%c✅ جميع الاختبارات نجحت! (${passed}/${total})`, 'color: #10b981; font-weight: bold; font-size: 13px;');
      } else if (percentage >= 70) {
        console.log(`%c⚠️  معظم الاختبارات نجحت (${passed}/${total} - ${percentage}%)`, 'color: #f59e0b; font-weight: bold; font-size: 13px;');
      } else {
        console.log(`%c❌ هناك مشاكل (${passed}/${total} - ${percentage}%)`, 'color: #ef4444; font-weight: bold; font-size: 13px;');
      }
      
      console.log('%c═══════════════════════════════════════════════════════════════', 'color: #3b82f6; font-weight: bold;');
      console.log('');
      console.log('%c💡 نصيحة: انظر إلى أي اختبارات فشلت أعلاه وتابع معالجة المشاكل', 'color: #6b7280;');
      console.log('');
      
      return {
        passed,
        total,
        percentage,
        results: this.results
      };
    }
  };
  
  // جعل Tests عامة
  window.TestStudentLogin = Tests;
  
  // اطبع تعليمات الاستخدام
  console.log('%c🚀 اختبار دخول الطالب جاهز!', 'color: #10b981; font-weight: bold; font-size: 12px;');
  console.log('%c الاستخدام: TestStudentLogin.runAll()', 'color: #6b7280; font-size: 11px;');
  
})();

// ────────────────────────────────────────────────────────────────────────────
// Manual test helpers
// ────────────────────────────────────────────────────────────────────────────

window.testHelpers = {
  // Simulate successful student login
  mockStudentLogin: function() {
    const mockStudent = {
      id: 1,
      stud_id: '12345678',
      name: 'محمد أحمد محمود',
      email: 'm.ahmed@university.edu',
      phone: '96895551234',
      active: true,
      banned: false,
      created_at: new Date().toISOString()
    };
    
    STATE._studentUser = mockStudent;
    localStorage.setItem('_studentSession', JSON.stringify({
      student: mockStudent,
      timestamp: Date.now()
    }));
    
    console.log('%c✓ تم محاكاة دخول الطالب', 'color: #10b981;', mockStudent);
    return mockStudent;
  },
  
  // Clear student session
  clearStudentSession: function() {
    STATE._studentUser = null;
    localStorage.removeItem('_studentSession');
    console.log('%c✓ تم مسح جلسة الطالب', 'color: #10b981;');
  },
  
  // Check current session
  checkSession: function() {
    const session = localStorage.getItem('_studentSession');
    if (session) {
      console.log('%c📋 جلسة حالية:', 'color: #3b82f6; font-weight: bold;', JSON.parse(session));
    } else {
      console.log('%c❌ لا توجد جلسة حالية', 'color: #ef4444;');
    }
    return session ? JSON.parse(session) : null;
  },
  
  // Get all console logs for current test
  getTestResults: function() {
    if (window.TestStudentLogin?.results) {
      return window.TestStudentLogin.results;
    }
    return null;
  }
};

console.log('%c💡 أدوات مساعدة متاحة:', 'color: #6b7280; font-size: 11px;');
console.log('%c testHelpers.mockStudentLogin()  - محاكاة دخول طالب', 'color: #6b7280; font-size: 10px;');
console.log('%c testHelpers.clearStudentSession() - مسح الجلسة', 'color: #6b7280; font-size: 10px;');
console.log('%c testHelpers.checkSession() - فحص الجلسة الحالية', 'color: #6b7280; font-size: 10px;');
