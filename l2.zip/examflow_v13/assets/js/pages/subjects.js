// ═══════════════════════════════════════════════════════════════
//  subjects.js — المواد الدراسية والشعب v2 (تصميم احترافي)
// ═══════════════════════════════════════════════════════════════

let _selectedSubjId = null; // المادة المحددة حالياً

// ── نقطة الدخول الرئيسية ──────────────────────────────────────
function renderSubjects() {
  const isAllowed = canEdit() || isProctor() || isDeptHead() || isDean() || isAssistantDean() || isCoord();
  if (!isAllowed) {
    setHTML('subjectsContent', emptyState('fa-lock', 'غير مصرح'));
    return;
  }

  // المراقب: عرض مخصص لموادهم المرتبطة فقط
  if (isProctor() && !canEdit()) {
    _renderProctorSubjectsPage();
    return;
  }

  _renderFullSubjectsPage();
}

// ══════════════════════════════════════════════════════════════
//  الصفحة الكاملة (admin / coord / dept_head / dean)
// ══════════════════════════════════════════════════════════════
function _renderFullSubjectsPage() {
  const editable = canEdit();

  // تحضير البيانات
  let subjects = STATE.subjects;
  if (isDeptHead() && !isCoord()) {
    subjects = subjects.filter(s => s.dept_id === STATE.currentUser?.dept_id);
  }
  const total     = subjects.length;
  const totalSecs = STATE.sections.filter(s => s.semester === STATE.currentSem).length;
  const totalStuds= [...new Set(
    STATE.sections.filter(s=>s.semester===STATE.currentSem).flatMap(s=>s.student_ids||[])
  )].length;

  if (editable) {
    setHTML('subjActs', `
      <button class="btn bp btn-sm" onclick="openAddSubj()"><i class="fas fa-plus"></i> مادة جديدة</button>
      <button class="btn bo btn-sm" onclick="openAddSection()"><i class="fas fa-layer-group"></i> شعبة جديدة</button>
      <button class="btn" style="background:linear-gradient(135deg,#059669,#0d9488);color:white;border-color:transparent;padding:6px 14px;border-radius:8px;font-size:12.5px;font-weight:700;display:flex;align-items:center;gap:6px;cursor:pointer" onclick="openImportSections()">
        <i class="fas fa-file-excel"></i> استيراد Excel
      </button>`);
  }

  setHTML('subjectsContent', `
    <!-- إحصاءات سريعة -->
    <div class="stats-grid" style="margin-bottom:18px">
      <div class="stat-card">
        <div class="stat-ic ic-gold"><i class="fas fa-book"></i></div>
        <div><div class="stat-val">${total}</div><div class="stat-lbl">مادة دراسية</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-purple"><i class="fas fa-layer-group"></i></div>
        <div><div class="stat-val">${totalSecs}</div><div class="stat-lbl">شعبة (الفصل الحالي)</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-teal"><i class="fas fa-user-graduate"></i></div>
        <div><div class="stat-val">${totalStuds}</div><div class="stat-lbl">طالب مسجَّل</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-blue"><i class="fas fa-sitemap"></i></div>
        <div><div class="stat-val">${STATE.departments.length}</div><div class="stat-lbl">قسم أكاديمي</div></div>
      </div>
    </div>

    <!-- التصميم الرئيسي: المواد + تفاصيل المادة -->
    <div style="display:grid;grid-template-columns:1fr 1.1fr;gap:16px;align-items:start">

      <!-- عمود المواد -->
      <div class="card" id="subjMainCard">
        <div style="padding:14px 16px;border-bottom:1px solid var(--border)">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
            <i class="fas fa-book" style="color:var(--gold)"></i>
            <span style="font-weight:800;font-size:14px">المواد الدراسية</span>
            <span class="badge b-gold">${total}</span>
          </div>
          <!-- شريط البحث والفلتر -->
          <div style="display:flex;gap:8px">
            <div class="sbar" style="flex:1">
              <i class="fas fa-search"></i>
              <input type="text" id="subjSrch" placeholder="بحث بالاسم أو الرمز..." oninput="_filterSubjList()">
            </div>
            ${!isDeptHead() ? `<select id="subjDeptF" onchange="_filterSubjList()" 
              style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12px;background:var(--surface);min-width:110px">
              <option value="">كل الأقسام</option>
              ${STATE.departments.map(d=>`<option value="${d.id}">${esc(d.name)}</option>`).join('')}
            </select>` : ''}
          </div>
        </div>
        <div id="subjList" style="max-height:580px;overflow-y:auto"></div>
      </div>

      <!-- عمود التفاصيل -->
      <div id="subjDetailPanel">
        <div style="padding:60px 20px;text-align:center;color:var(--txt3)">
          <div style="width:64px;height:64px;border-radius:16px;background:var(--gold)15;display:flex;align-items:center;justify-content:center;margin:0 auto 14px">
            <i class="fas fa-hand-pointer" style="font-size:24px;color:var(--gold)40"></i>
          </div>
          <div style="font-weight:700;font-size:14px;margin-bottom:6px">اختر مادة لعرض تفاصيلها</div>
          <div style="font-size:12.5px">اضغط على أي مادة من القائمة لعرض شعبها وإحصاءاتها</div>
        </div>
      </div>
    </div>`);

  _filterSubjList();
}

// ── فلترة وعرض قائمة المواد ───────────────────────────────────
function _filterSubjList() {
  const q    = (document.getElementById('subjSrch')?.value||'').toLowerCase();
  const dept = document.getElementById('subjDeptF')?.value||'';
  let subjects = STATE.subjects;
  if (isDeptHead() && !isCoord()) subjects = subjects.filter(s => s.dept_id === STATE.currentUser?.dept_id);
  if (isProctor() && !canEdit()) subjects = getProctorScopeSubjects();
  if (q)    subjects = subjects.filter(s => s.name?.toLowerCase().includes(q) || s.code?.toLowerCase().includes(q));
  if (dept) subjects = subjects.filter(s => String(s.dept_id) === dept);
  _renderSubjCards(subjects);
}

function _renderSubjList() { _filterSubjList(); }

function _renderSubjCards(subjects) {
  const el = document.getElementById('subjList'); if (!el) return;
  if (!subjects.length) {
    el.innerHTML = `<div style="padding:40px;text-align:center;color:var(--txt3)">
      <i class="fas fa-search" style="font-size:32px;opacity:.2;margin-bottom:10px"></i>
      <div style="font-weight:700">لا توجد مواد مطابقة</div>
    </div>`;
    return;
  }
  const editable = canEdit();
  el.innerHTML = subjects.map(s => {
    const dept      = STATE.departments.find(d => d.id === s.dept_id);
    const deptColor = dept?.color || 'var(--primary2)';
    const secCount  = STATE.sections.filter(sec => sec.subject_id === s.id && sec.semester === STATE.currentSem).length;
    const examCount = STATE.exams.filter(e => e.subject_id === s.id && e.semester === STATE.currentSem).length;
    const staffCount= (s.staff_ids||[]).length;
    const studCount = STATE.sections.filter(sec => sec.subject_id===s.id && sec.semester===STATE.currentSem)
                       .reduce((sum,sec)=>sum+(sec.student_ids||[]).length, 0);
    const isSelected = s.id === _selectedSubjId;

    return `<div id="subjItem_${s.id}"
      onclick="_selectSubject(${s.id})"
      style="display:flex;align-items:center;gap:12px;padding:13px 16px;border-bottom:1px solid var(--border);cursor:pointer;transition:all .15s;
             background:${isSelected?'var(--primary)08':'transparent'};
             border-right:${isSelected?'3px solid var(--primary)':'3px solid transparent'};"
      onmouseover="if(${!isSelected})this.style.background='var(--bg)'"
      onmouseout="if(${!isSelected})this.style.background='transparent'">

      <!-- أيقونة القسم -->
      <div style="width:42px;height:42px;border-radius:12px;background:${deptColor}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-book" style="color:${deptColor};font-size:16px"></i>
      </div>

      <!-- بيانات المادة -->
      <div style="flex:1;min-width:0">
        <div style="font-weight:800;font-size:13.5px;color:var(--txt);margin-bottom:3px">${esc(s.name)}</div>
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:10.5px;font-weight:700;color:${deptColor};background:${deptColor}15;padding:2px 7px;border-radius:5px">${s.code||'—'}</span>
          ${dept?`<span style="font-size:10.5px;color:var(--txt3)">${esc(dept.name)}</span>`:''}
        </div>
        <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:5px">
          ${secCount?`<span style="font-size:10px;background:var(--purple)18;color:var(--purple2);padding:2px 7px;border-radius:4px;font-weight:700">${secCount} شعبة</span>`:''}
          ${studCount?`<span style="font-size:10px;background:var(--teal)18;color:var(--teal);padding:2px 7px;border-radius:4px;font-weight:700">${studCount} طالب</span>`:''}
          ${examCount?`<span style="font-size:10px;background:var(--green)18;color:var(--green);padding:2px 7px;border-radius:4px;font-weight:700">${examCount} امتحان</span>`:''}
          ${staffCount?`<span style="font-size:10px;background:var(--primary)18;color:var(--primary2);padding:2px 7px;border-radius:4px;font-weight:700">${staffCount} مرتبط</span>`:''}
        </div>
      </div>

      <!-- أزرار الإجراءات -->
      <div style="display:flex;gap:4px;flex-shrink:0;opacity:0;transition:opacity .15s" class="subj-actions">
        ${editable?`
        <button class="btn bo btn-xs" title="ربط المدرسين" onclick="event.stopPropagation();openManageSubjectStaff(${s.id})">
          <i class="fas fa-user-tie"></i>
        </button>
        <button class="btn bo btn-xs" onclick="event.stopPropagation();openEditSubj(${s.id})">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn bd btn-xs" onclick="event.stopPropagation();deleteSubj(${s.id})">
          <i class="fas fa-trash"></i>
        </button>`:''}
      </div>
    </div>`;
  }).join('');

  // إظهار أزرار عند hover
  el.querySelectorAll('[id^="subjItem_"]').forEach(item => {
    const actions = item.querySelector('.subj-actions');
    if (!actions) return;
    item.addEventListener('mouseenter', () => actions.style.opacity = '1');
    item.addEventListener('mouseleave', () => actions.style.opacity = '0');
  });
}

// ── تحديد مادة وعرض تفاصيلها ──────────────────────────────────
function _selectSubject(id) {
  _selectedSubjId = id;
  // تحديث التحديد المرئي
  document.querySelectorAll('[id^="subjItem_"]').forEach(el => {
    const isMe = el.id === `subjItem_${id}`;
    el.style.background = isMe ? 'var(--primary)08' : 'transparent';
    el.style.borderRight = isMe ? '3px solid var(--primary)' : '3px solid transparent';
  });
  _renderSubjectDetail(id);
}

function _renderSubjectDetail(subjId) {
  const subj = getSubject(subjId);
  if (!subj) return;
  const el = document.getElementById('subjDetailPanel');
  if (!el) return;

  const dept      = STATE.departments.find(d => d.id === subj.dept_id);
  const deptColor = dept?.color || 'var(--primary2)';
  const editable  = canEdit();

  // الشعب مجمَّعة حسب الفصل
  const allSecs   = STATE.sections.filter(s => s.subject_id === subjId);
  const semGroups = {};
  allSecs.forEach(s => {
    if (!semGroups[s.semester]) semGroups[s.semester] = [];
    semGroups[s.semester].push(s);
  });
  const sortedSems = Object.keys(semGroups).sort((a,b) => b.localeCompare(a));

  // إحصاءات المادة
  const curSecs  = allSecs.filter(s => s.semester === STATE.currentSem);
  const curStuds = [...new Set(curSecs.flatMap(s => s.student_ids||[]))].length;
  const curExams = STATE.exams.filter(e => e.subject_id === subjId && e.semester === STATE.currentSem).length;
  const staff    = (subj.staff_ids||[]).map(id => getProfile(id)).filter(Boolean);

  el.innerHTML = `
    <!-- رأس المادة -->
    <div class="card" style="margin-bottom:12px;overflow:hidden">
      <div style="padding:16px 18px;background:linear-gradient(135deg,${deptColor}20,${deptColor}08);border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:start;gap:12px">
          <div style="width:50px;height:50px;border-radius:14px;background:${deptColor}25;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-book" style="color:${deptColor};font-size:20px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:900;font-size:16px;color:var(--txt)">${esc(subj.name)}</div>
            <div style="font-size:12px;color:var(--txt2);margin-top:3px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <span style="background:${deptColor}20;color:${deptColor};padding:2px 8px;border-radius:5px;font-weight:700;font-size:11px">${esc(subj.code||'—')}</span>
              ${dept?`<span style="color:var(--txt3)">${esc(dept.name)}</span>`:''}
              ${subj.hours?`<span style="color:var(--txt3)">${subj.hours} ساعات</span>`:''}
            </div>
          </div>
          ${editable?`<div style="display:flex;gap:5px">
            <button class="btn bp btn-xs" onclick="openAddSectionForSubj(${subjId})" title="إضافة شعبة">
              <i class="fas fa-plus"></i> شعبة
            </button>
            <button class="btn bo btn-xs" onclick="openManageSubjectStaff(${subjId})" title="إدارة المرتبطين">
              <i class="fas fa-user-tie"></i>
            </button>
          </div>`:''}
        </div>
        <!-- إحصاءات سريعة -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px">
          ${_statMini(curSecs.length, 'شعبة', 'fa-layer-group', deptColor)}
          ${_statMini(curStuds, 'طالب', 'fa-user-graduate', 'var(--teal)')}
          ${_statMini(curExams, 'امتحان', 'fa-file-alt', 'var(--green)')}
        </div>
      </div>

      <!-- المرتبطون بالمادة -->
      ${staff.length ? `
      <div style="padding:10px 16px;border-bottom:1px solid var(--border);background:var(--bg)">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);margin-bottom:7px;display:flex;align-items:center;gap:5px">
          <i class="fas fa-user-tie" style="color:var(--primary2)"></i> المرتبطون بالمادة
          ${editable?`<button class="btn bo btn-xs" style="margin-right:auto;font-size:9px" onclick="openManageSubjectStaff(${subjId})">تعديل</button>`:''}
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px">
          ${staff.map(p => {
            const rc = APP_CONFIG.ROLE_COLORS[p.role]||'var(--primary)';
            return `<div style="display:flex;align-items:center;gap:5px;padding:3px 8px;border:1.5px solid ${rc}30;border-radius:7px;background:${rc}08">
              <div style="width:22px;height:22px;border-radius:6px;background:${rc}25;display:flex;align-items:center;justify-content:center">
                <i class="fas ${APP_CONFIG.ROLE_ICONS[p.role]||'fa-user'}" style="color:${rc};font-size:10px"></i>
              </div>
              <span style="font-size:11.5px;font-weight:700;color:var(--txt)">${esc(p.name?.split(' ').slice(0,2).join(' '))}</span>
            </div>`;
          }).join('')}
        </div>
      </div>` : editable ? `
      <div style="padding:8px 16px;background:var(--gold-bg);border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;justify-content:space-between">
          <span style="font-size:11.5px;color:var(--gold);font-weight:700">
            <i class="fas fa-exclamation-circle" style="margin-left:5px"></i>لا يوجد مستخدمون مرتبطون بهذه المادة
          </span>
          <button class="btn bo btn-xs" onclick="openManageSubjectStaff(${subjId})">
            <i class="fas fa-user-plus"></i> ربط
          </button>
        </div>
      </div>` : ''}
    </div>

    <!-- الشعب -->
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-layer-group" style="color:var(--purple2)"></i> الشعب الدراسية</h3>
        <span class="badge b-purple">${allSecs.length} شعبة</span>
      </div>
      ${allSecs.length ? `
      <!-- تاب الفصول -->
      <div style="padding:6px 12px;border-bottom:1px solid var(--border);overflow-x:auto">
        <div style="display:flex;gap:4px">
          ${sortedSems.map((sem, i) => {
            const label = STATE.semesters.find(s=>s.code===sem)?.label || sem;
            const isCur = sem === STATE.currentSem;
            const isFirst = i === 0;
            return `<button onclick="_showSubjSemSections('${subjId}','${sem}',this)"
              style="padding:5px 12px;border-radius:8px;border:1.5px solid ${isFirst||isCur?'var(--primary)':'var(--border)'};
                     background:${isFirst||isCur?'var(--primary)':'transparent'};
                     color:${isFirst||isCur?'white':'var(--txt2)'};
                     font-size:11.5px;font-weight:700;cursor:pointer;white-space:nowrap;transition:all .2s;font-family:inherit"
              class="sem-tab ${isFirst?'active':''}">
              ${esc(label)} ${isCur?'✓':''}
              <span style="font-size:10px;opacity:.8">(${semGroups[sem].length})</span>
            </button>`;
          }).join('')}
        </div>
      </div>
      <div id="subjSecList" style="max-height:420px;overflow-y:auto">
        ${_buildSectionItems(semGroups[sortedSems[0]]||[], editable)}
      </div>` :
      `<div style="padding:40px;text-align:center;color:var(--txt3)">
        <i class="fas fa-layer-group" style="font-size:36px;opacity:.2;margin-bottom:12px"></i>
        <div style="font-weight:700;margin-bottom:8px">لا توجد شعب لهذه المادة</div>
        ${editable?`<button class="btn bp btn-sm" onclick="openAddSectionForSubj(${subjId})">
          <i class="fas fa-plus"></i> إضافة شعبة
        </button>`:''}
      </div>`}
    </div>`;
}

function _statMini(val, lbl, icon, color) {
  return `<div style="padding:8px;background:var(--bg);border-radius:9px;text-align:center;border:1px solid var(--border)">
    <div style="font-size:18px;font-weight:900;color:${color}">${val}</div>
    <div style="font-size:10px;color:var(--txt3);display:flex;align-items:center;justify-content:center;gap:3px;margin-top:2px">
      <i class="fas ${icon}" style="font-size:9px"></i>${lbl}
    </div>
  </div>`;
}

function _showSubjSemSections(subjId, sem, btn) {
  // تحديث تاب نشط
  btn.closest('.card').querySelectorAll('.sem-tab').forEach(t => {
    t.style.background = 'transparent';
    t.style.borderColor = 'var(--border)';
    t.style.color = 'var(--txt2)';
  });
  btn.style.background = 'var(--primary)';
  btn.style.borderColor = 'var(--primary)';
  btn.style.color = 'white';

  const secs = STATE.sections.filter(s => s.subject_id == subjId && s.semester === sem);
  const el = document.getElementById('subjSecList');
  if (el) el.innerHTML = _buildSectionItems(secs, canEdit());
}

function _buildSectionItems(sections, editable) {
  if (!sections.length) return `<div style="padding:24px;text-align:center;color:var(--txt3);font-size:13px">لا توجد شعب في هذا الفصل</div>`;
  return sections.map(sec => {
    const studCount  = (sec.student_ids||[]).length;
    const examCount  = STATE.exams.filter(e => (e.section_ids||[]).includes(sec.id)).length;
    const staffLinked = (sec.staff_ids||[]).map(id => getProfile(id)).filter(Boolean);
    return `<div style="display:flex;align-items:center;gap:11px;padding:12px 16px;border-bottom:1px solid var(--border);transition:background .15s"
                 onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
      <div style="width:38px;height:38px;border-radius:10px;background:var(--purple)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-layer-group" style="color:var(--purple2);font-size:14px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13.5px">${esc(sec.name)}</div>
        <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:4px">
          <span style="font-size:10px;background:var(--teal)15;color:var(--teal);padding:2px 7px;border-radius:4px;font-weight:700">
            <i class="fas fa-users" style="font-size:8px;margin-left:2px"></i>${studCount} طالب
          </span>
          ${examCount?`<span style="font-size:10px;background:var(--green)15;color:var(--green);padding:2px 7px;border-radius:4px;font-weight:700">
            <i class="fas fa-file-alt" style="font-size:8px;margin-left:2px"></i>${examCount} امتحان
          </span>`:''}
          ${staffLinked.length?`<span style="font-size:10px;background:var(--primary)15;color:var(--primary2);padding:2px 7px;border-radius:4px;font-weight:700">
            <i class="fas fa-user-tie" style="font-size:8px;margin-left:2px"></i>${staffLinked.map(p=>p.name?.split(' ')[0]).join('، ')}
          </span>`:''}
        </div>
      </div>
      <div style="display:flex;gap:5px">
        <button class="btn bo btn-xs" onclick="openSectionStudents(${sec.id})" title="إدارة الطلاب">
          <i class="fas fa-users"></i>
        </button>
        ${editable?`
        <button class="btn bo btn-xs" onclick="openManageSectionStaff(${sec.id})" title="ربط مستخدمين بالشعبة" style="color:var(--primary2);border-color:var(--primary)30">
          <i class="fas fa-user-tie"></i>
        </button>
        <button class="btn bo btn-xs" onclick="openEditSection(${sec.id})"><i class="fas fa-edit"></i></button>
        <button class="btn bd btn-xs" onclick="deleteSectionAndRefresh(${sec.id},${sec.subject_id})"><i class="fas fa-trash"></i></button>
        `:''}
      </div>
    </div>`;
  }).join('');
}

// ── ربط مستخدمين بشعبة معينة ─────────────────────────────────
function openManageSectionStaff(secId) {
  const sec  = getSection(secId);
  if (!sec) return;
  const subj = getSubject(sec.subject_id);
  const currentStaff = sec.staff_ids || [];
  const allowedRoles = ['proctor','dept_head','coordinator','admin'];

  // مراقبو نفس القسم أولاً
  const subjDeptId = subj?.dept_id;
  const deptStaff  = STATE.profiles.filter(p => p.active && allowedRoles.includes(p.role) && subjDeptId && p.dept_id === subjDeptId);
  const otherStaff = STATE.profiles.filter(p => p.active && allowedRoles.includes(p.role) && (!subjDeptId || p.dept_id !== subjDeptId));

  const moId = 'manageSecStaffMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  const _buildUserRow = (p) => {
    const isChk = currentStaff.includes(p.id);
    const rc = APP_CONFIG.ROLE_COLORS[p.role]||'var(--primary)';
    return `<label style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid ${isChk?'var(--primary)':'var(--border)'};
            border-radius:9px;cursor:pointer;transition:all .15s;background:${isChk?'var(--primary)08':''}">
      <input type="checkbox" data-uid="${p.id}" ${isChk?'checked':''}
        style="accent-color:var(--primary);width:14px;height:14px;flex-shrink:0"
        onchange="_onSecStaffCheckChange(this)">
      ${userAvatar(p, 32)}
      <div style="flex:1;min-width:0">
        <div style="font-size:12.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(p.name?.split(' ').slice(0,3).join(' '))}</div>
        <div style="font-size:10.5px;color:var(--txt3)">${APP_CONFIG.ROLES[p.role]||p.role} ${p.emp_id?'· '+p.emp_id:''}</div>
      </div>
      <span class="badge" style="background:${rc}15;color:${rc};font-size:9px">${isChk?'مرتبط':''}</span>
    </label>`;
  };

  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-user-tie" style="color:var(--primary2)"></i> ربط مستخدمين بالشعبة: ${esc(sec.name)}</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:0">
      <div style="padding:10px 16px;background:var(--bg);border-bottom:1px solid var(--border)">
        <div style="font-size:12px;color:var(--txt2)">
          <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
          المرتبطون بالشعبة سيرون طلابها في سجلاتهم. المادة: <strong>${esc(subj?.name||'—')}</strong>
        </div>
      </div>
      <div style="max-height:60vh;overflow-y:auto;padding:12px 16px">
        ${deptStaff.length ? `
          <div style="font-size:11px;font-weight:800;color:var(--primary2);margin-bottom:8px;padding:4px 8px;background:var(--primary)08;border-radius:6px">
            <i class="fas fa-star" style="font-size:10px"></i> نفس القسم (${deptStaff.length})
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:12px">
            ${deptStaff.map(_buildUserRow).join('')}
          </div>` : ''}
        ${otherStaff.length ? `
          <div style="font-size:11px;font-weight:800;color:var(--txt3);margin-bottom:8px;padding:4px 8px;background:var(--bg);border-radius:6px">
            <i class="fas fa-users" style="font-size:10px"></i> أقسام أخرى (${otherStaff.length})
          </div>
          <div style="display:flex;flex-direction:column;gap:6px">
            ${otherStaff.map(_buildUserRow).join('')}
          </div>` : ''}
        ${!deptStaff.length && !otherStaff.length ? '<div style="padding:20px;text-align:center;color:var(--txt3)">لا يوجد مستخدمون للربط</div>' : ''}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" onclick="_saveSectionStaff(${secId},'${moId}')">
        <i class="fas fa-save"></i> حفظ الارتباط
      </button>
    </div>
  </div>`;
  showMo(moId);
}

function _onSecStaffCheckChange(cb) {
  const lbl = cb.closest('label');
  if (!lbl) return;
  lbl.style.borderColor = cb.checked ? 'var(--primary)' : 'var(--border)';
  lbl.style.background  = cb.checked ? 'var(--primary)08' : '';
  const badge = lbl.querySelector('.badge');
  if (badge) badge.textContent = cb.checked ? 'مرتبط' : '';
}

async function _saveSectionStaff(secId, moId) {
  const mo = document.getElementById(moId);
  if (!mo) return;
  const staffIds = Array.from(mo.querySelectorAll('input[type=checkbox][data-uid]:checked'))
    .map(cb => cb.dataset.uid).filter(Boolean);

  const sec = getSection(secId);
  if (!sec) return;

  try {
    await SB.update('sections', secId, { staff_ids: staffIds });
    sec.staff_ids = staffIds;
    closeMo(moId);

    // تحديث عرض الشعب
    if (_selectedSubjId) _renderSubjectDetail(_selectedSubjId);
    toast(`✓ تم ربط ${staffIds.length} مستخدم بالشعبة ${sec.name}`, 'success');
    await SB.logAction('ربط مستخدمين بشعبة', 'sections', sec.name);
  } catch(e) { toast('خطأ: ' + e.message, 'error'); }
}

function openAddSectionForSubj(subjId) {
  openAddSection();
  setTimeout(() => {
    const el = document.getElementById('scSubj');
    if (el) { el.value = subjId; }
  }, 200);
}

async function deleteSectionAndRefresh(secId, subjId) {
  const s = getSection(secId);
  confirmDelete(`حذف شعبة "${s?.name}"؟`, async () => {
    try {
      await dbDelete('sections', secId);
      STATE.sections = STATE.sections.filter(x => x.id !== secId);
      toast('تم الحذف', 'info');
      _renderSubjectDetail(subjId);
      _filterSubjList();
    } catch { toast('فشل الحذف','error'); }
  });
}

// ══════════════════════════════════════════════════════════════
//  صفحة المراقب — موادي المرتبطة فقط (staff_ids)
// ══════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════
//  صفحة المراقب الاحترافية — موادي حسب الفصل الحالي
//  المواد تظهر فقط إذا كان لها شعب في الفصل الحالي
// ══════════════════════════════════════════════════════════════

let _proctorSelSubj = null; // المادة المحددة
let _proctorSelSec  = null; // الشعبة المحددة

function _renderProctorSubjectsPage() {
  const uid  = STATE.currentUser?.id;
  const sem  = STATE.currentSem;
  const semLabel = STATE.semesters.find(s=>s.code===sem)?.label || sem;

  setHTML('subjActs', '');

  // ── المنطق الموحَّد: كل شعب نطاق المراقب في الفصل الحالي ──
  // (يشمل: الشعب المرتبطة على مستوى الشعبة + شعب المواد المرتبطة على مستوى المادة)
  const mySections = getProctorScopeSections().filter(s => s.semester === sem);

  // ✅ المواد المرئية = المستنبَطة من الشعب + المواد المرتبطة مباشرةً (حتى لو بلا شعب في الفصل)
  const mySubjIdsSet = new Set(mySections.map(s => s.subject_id));
  STATE.subjects
    .filter(s => (s.staff_ids||[]).includes(uid))
    .forEach(s => mySubjIdsSet.add(s.id));
  const mySubjects = STATE.subjects.filter(s => mySubjIdsSet.has(s.id));

  // طلابي = طلاب شعبي فقط
  const myStudIds = new Set(mySections.flatMap(s=>s.student_ids||[]));
  const myStuds   = STATE.students.filter(s => myStudIds.has(s.id));

  // ── امتحانات الفصل الحالي في موادي ──────────────────────────
  const myExams = STATE.exams.filter(e =>
    mySubjIdsSet.has(e.subject_id) && e.semester === sem &&
    (e.proctor_ids||[]).includes(uid)
  );

  if (!mySubjects.length) {
    // لا توجد مواد مرتبطة على الإطلاق
    setHTML('subjectsContent', _proctorEmptyState(false, sem, semLabel));
    return;
  }

  setHTML('subjectsContent', `
    <!-- رأس احترافي -->
    <div style="border-radius:16px;background:linear-gradient(135deg,var(--primary)15,var(--teal)08);border:1px solid var(--primary)20;padding:18px 20px;margin-bottom:16px;display:flex;align-items:center;gap:14px">
      <div style="width:52px;height:52px;border-radius:14px;background:var(--primary);display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 4px 12px var(--primary)40">
        <i class="fas fa-graduation-cap" style="color:white;font-size:20px"></i>
      </div>
      <div style="flex:1">
        <div style="font-weight:900;font-size:17px;color:var(--txt)">موادي الدراسية</div>
        <div style="font-size:12.5px;color:var(--txt2);margin-top:3px">
          <i class="fas fa-calendar-check" style="color:var(--primary2);margin-left:5px"></i>${esc(semLabel)}
        </div>
      </div>
    </div>

    <!-- إحصاءات -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
      ${_pStatCard(mySubjects.length,'موادي','fa-book','#f59e0b','#fef3c7')}
      ${_pStatCard(mySections.length,'شعبي','fa-layer-group','#8b5cf6','#f5f3ff')}
      ${_pStatCard(myStudIds.size,'طلابي','fa-user-graduate','#0891b2','#e0f2fe')}
      ${_pStatCard(myExams.length,'امتحاناتي','fa-file-alt','#059669','#d1fae5')}
    </div>

    <!-- التخطيط الثنائي -->
    <div style="display:grid;grid-template-columns:340px 1fr;gap:14px;align-items:start">

      <!-- ── عمود المواد ── -->
      <div>
        <!-- المواد -->
        <div class="card" style="margin-bottom:12px">
          <div style="padding:11px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:7px">
            <i class="fas fa-book" style="color:var(--gold);font-size:13px"></i>
            <span style="font-weight:800;font-size:13px">المقررات</span>
            <span class="badge b-gold" style="margin-right:auto">${mySubjects.length}</span>
          </div>
          <div id="pSubjListWrap" style="max-height:calc(100vh - 380px);overflow-y:auto">
            ${mySubjects.map((s,i) => _buildProctorSubjRow(s, i===0, sem, uid)).join('')}
          </div>
        </div>
      </div>

      <!-- ── لوحة التفاصيل ── -->
      <div id="proctorDetailPanel">
        <div style="padding:60px 24px;text-align:center;color:var(--txt3);background:var(--card);border-radius:16px;border:2px dashed var(--border)">
          <div style="width:64px;height:64px;border-radius:16px;background:var(--bg);display:flex;align-items:center;justify-content:center;margin:0 auto 14px">
            <i class="fas fa-hand-pointer" style="font-size:26px;color:var(--txt3)40"></i>
          </div>
          <div style="font-weight:700;font-size:14px;margin-bottom:6px">اختر مقرراً لعرض التفاصيل</div>
          <div style="font-size:12.5px">اضغط على أي مقرر من القائمة لعرض شعبه وطلابه</div>
        </div>
      </div>

    </div>`);

  // حدد المادة الأولى تلقائياً
  if (mySubjects.length) {
    _proctorSelSubj = mySubjects[0].id;
    setTimeout(() => _selectProctorSubject(mySubjects[0].id), 0);
  }
}

function _proctorEmptyState(hasLinkedButNoSem, sem, semLabel) {
  if (hasLinkedButNoSem) {
    return `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:80px 20px;text-align:center;color:var(--txt3)">
      <div style="width:80px;height:80px;border-radius:20px;background:var(--gold)12;display:flex;align-items:center;justify-content:center;margin-bottom:18px">
        <i class="fas fa-calendar-times" style="font-size:32px;color:var(--gold)60"></i>
      </div>
      <div style="font-weight:800;font-size:16px;margin-bottom:8px;color:var(--txt2)">لا توجد شعب في الفصل الحالي</div>
      <div style="font-size:13px;max-width:380px;line-height:1.8;color:var(--txt3)">
        أنت مرتبط بمواد دراسية، لكن لا توجد شعب مسجَّلة في فصل <strong>${esc(semLabel)}</strong> بعد.<br>
        تواصل مع منسق الكلية لإضافة شعب الفصل الحالي.
      </div>
    </div>`;
  }
  return `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:80px 20px;text-align:center;color:var(--txt3)">
    <div style="width:80px;height:80px;border-radius:20px;background:var(--primary)10;display:flex;align-items:center;justify-content:center;margin-bottom:18px">
      <i class="fas fa-book-open" style="font-size:32px;color:var(--primary)60"></i>
    </div>
    <div style="font-weight:800;font-size:16px;margin-bottom:8px;color:var(--txt2)">لا توجد مواد مرتبطة بحسابك</div>
    <div style="font-size:13px;max-width:380px;line-height:1.8">
      يجب أن يقوم منسق الكلية أو رئيس القسم بربطك بالمواد الدراسية أولاً.
    </div>
  </div>`;
}

function _pStatCard(val, lbl, icon, color, bg) {
  return `<div style="padding:14px 10px;border-radius:12px;background:${bg};border:1px solid ${color}25;text-align:center">
    <div style="width:36px;height:36px;border-radius:10px;background:${color}25;display:flex;align-items:center;justify-content:center;margin:0 auto 8px">
      <i class="fas ${icon}" style="color:${color};font-size:14px"></i>
    </div>
    <div style="font-size:20px;font-weight:900;color:${color}">${val}</div>
    <div style="font-size:10.5px;color:${color}90;font-weight:700;margin-top:2px">${lbl}</div>
  </div>`;
}

function _buildProctorSubjRow(s, isFirst, sem, uid) {
  const dept    = STATE.departments.find(d=>d.id===s.dept_id);
  const dc      = dept?.color||'var(--primary2)';
  // ✅ الشعب المرئية للمراقب (ربط مباشر أو ربط على مستوى المادة)
  const mySecs  = getProctorScopeSections().filter(sec =>
    sec.subject_id === s.id && sec.semester === sem
  );
  const studCnt = [...new Set(mySecs.flatMap(sec=>sec.student_ids||[]))].length;
  const isActive = isFirst;
  return `<div id="pSubjItem_${s.id}" onclick="_selectProctorSubject(${s.id})"
    style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid var(--border);cursor:pointer;transition:all .15s;
           border-right:3px solid ${isActive?dc:'transparent'};background:${isActive?dc+'10':'transparent'}">
    <div style="width:38px;height:38px;border-radius:10px;background:${dc}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <i class="fas fa-book" style="color:${dc};font-size:14px"></i>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-weight:800;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(s.name)}</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:4px">
        <span style="font-size:10px;background:${dc}18;color:${dc};padding:1px 6px;border-radius:4px;font-weight:700">${esc(s.code||'—')}</span>
        ${mySecs.length?`<span style="font-size:10px;background:var(--purple)15;color:var(--purple2);padding:1px 6px;border-radius:4px;font-weight:700">${mySecs.length} شعبة</span>`:''}
        ${studCnt?`<span style="font-size:10px;background:var(--teal)15;color:var(--teal);padding:1px 6px;border-radius:4px;font-weight:700">${studCnt} طالب</span>`:''}
      </div>
    </div>
    <i class="fas fa-chevron-left" style="color:${isActive?dc:'var(--txt3)40'};font-size:11px;flex-shrink:0;transition:color .15s"></i>
  </div>`;
}

function _selectProctorSubject(subjId) {
  _proctorSelSubj = subjId;
  const sem = STATE.currentSem;
  const subj = getSubject(subjId);
  const dc = STATE.departments.find(d=>d.id===subj?.dept_id)?.color || 'var(--primary2)';

  document.querySelectorAll('[id^="pSubjItem_"]').forEach(el => {
    el.style.background = 'transparent';
    el.style.borderRight = '3px solid transparent';
    el.querySelector('i.fa-chevron-left').style.color = 'var(--txt3)40';
  });
  const sel = document.getElementById(`pSubjItem_${subjId}`);
  if (sel) {
    sel.style.background = dc + '10';
    sel.style.borderRight = `3px solid ${dc}`;
    sel.querySelector('i.fa-chevron-left').style.color = dc;
  }
  _renderProctorSubjDetail(subjId);
}

function _renderProctorSubjDetail(subjId) {
  const subj = getSubject(subjId);
  const panel = document.getElementById('proctorDetailPanel');
  if (!subj || !panel) return;

  const uid    = STATE.currentUser?.id;
  const sem    = STATE.currentSem;
  const semLabel = STATE.semesters.find(s=>s.code===sem)?.label || sem;
  const dept   = STATE.departments.find(d=>d.id===subj.dept_id);
  const dc     = dept?.color||'var(--primary2)';

  // ✅ الشعب المرئية للمراقب في هذه المادة (في الفصل الحالي)
  // [ربط مباشر للشعبة ، أو ربط على مستوى المادة]
  const curSecs = getProctorScopeSections().filter(s =>
    s.subject_id === subjId && s.semester === sem
  );
  const studIds = new Set(curSecs.flatMap(s=>s.student_ids||[]));
  const studs   = STATE.students.filter(s => studIds.has(s.id));
  const myExams = STATE.exams.filter(e =>
    e.subject_id === subjId && e.semester === sem &&
    (e.proctor_ids||[]).includes(uid)
  );

  // إحصاءات الحضور
  let totalAtt = 0, totalPresent = 0;
  myExams.forEach(e => {
    const att = STATE.attendance[e.id] || {};
    studs.forEach(s => {
      totalAtt++;
      if (att[s.id] === 'present') totalPresent++;
    });
  });
  const attRate = totalAtt ? Math.round(totalPresent/totalAtt*100) : null;

  panel.innerHTML = `
    <!-- ── رأس المادة ── -->
    <div class="card" style="margin-bottom:12px;overflow:hidden">
      <div style="padding:18px 20px;background:linear-gradient(135deg,${dc}18,${dc}08);border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:start;gap:13px;margin-bottom:14px">
          <div style="width:50px;height:50px;border-radius:14px;background:${dc}25;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-book" style="color:${dc};font-size:19px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:900;font-size:16px;color:var(--txt)">${esc(subj.name)}</div>
            <div style="font-size:12px;color:var(--txt2);margin-top:4px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
              <span style="background:${dc}20;color:${dc};padding:2px 9px;border-radius:6px;font-weight:700;font-size:11px">${esc(subj.code||'—')}</span>
              ${dept?`<span style="color:var(--txt3)">${esc(dept.name)}</span>`:''}
              ${subj.hours?`<span style="color:var(--txt3)">· ${subj.hours} ساعة</span>`:''}
              <span style="font-size:11px;background:var(--primary)15;color:var(--primary2);padding:2px 8px;border-radius:5px;font-weight:700">${esc(semLabel)}</span>
            </div>
          </div>
        </div>
        <!-- mini stats -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">
          ${_pMini(curSecs.length,'شعبة','fa-layer-group',dc)}
          ${_pMini(studs.length,'طالب','fa-user-graduate','#0891b2')}
          ${_pMini(myExams.length,'امتحان','fa-file-alt','#059669')}
          ${attRate!==null ? _pMini(attRate+'%','الحضور','fa-user-check','#d97706') : _pMini('—','الحضور','fa-user-check','#94a3b8')}
        </div>
      </div>

      <!-- ── الشعب بالتاب ── -->
      <div>
        <div style="padding:10px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;background:var(--bg)">
          <i class="fas fa-layer-group" style="color:var(--purple2);font-size:12px"></i>
          <span style="font-size:12px;font-weight:800;color:var(--txt2)">الشعب في ${esc(semLabel)}</span>
          <span class="badge b-purple" style="margin-right:auto">${curSecs.length}</span>
        </div>
        <div id="proctorSectionItems">
          ${curSecs.length ? curSecs.map(sec => _buildProctorSecRow(sec, studs)).join('')
            : '<div style="padding:20px;text-align:center;color:var(--txt3);font-size:12.5px">لا توجد شعب في هذا الفصل</div>'}
        </div>
      </div>
    </div>

    <!-- ── الامتحانات ── -->
    ${myExams.length ? `
    <div class="card" style="margin-bottom:12px">
      <div class="card-h">
        <h3><i class="fas fa-file-alt" style="color:var(--green)"></i> امتحاناتي في هذه المادة</h3>
        <span class="badge b-green">${myExams.length}</span>
      </div>
      <div style="max-height:200px;overflow-y:auto">
        ${myExams.sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`)).map(e => {
          const st = examStatus(e);
          const ps = (e.proctor_statuses||{})[uid] || 'pending';
          const psColors = {accepted:'b-green', rejected:'b-red', pending:'b-gold'};
          const psLabels = {accepted:'مؤكَّد', rejected:'مرفوض', pending:'بانتظار قبولك'};
          return `<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border)">
            <div style="width:36px;height:36px;border-radius:9px;background:var(--green)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fas fa-file-alt" style="color:var(--green);font-size:13px"></i>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-weight:700;font-size:12.5px">${fmtDate(e.date)} · ${fmtTime(e.time)} · ${e.duration} دق</div>
              <div style="font-size:11px;color:var(--txt3);margin-top:2px">
                ${e.type==='final'?'نهائي':e.type==='midterm'?'منتصف فصل':e.type==='quiz'?'اختبار':e.type}
                ${(e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join(' · ') ? '· '+(e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join(' · ') : ''}
              </div>
            </div>
            <div style="display:flex;flex-direction:column;gap:3px;align-items:flex-end">
              ${getStatusBadge(st)}
              <span class="badge ${psColors[ps]}" style="font-size:9.5px">${psLabels[ps]}</span>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>` : ''}

    <!-- ── قائمة الطلاب مع السجل ── -->
    <div class="card">
      <div style="padding:11px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;background:var(--bg)">
        <i class="fas fa-user-graduate" style="color:var(--teal);font-size:12px"></i>
        <span style="font-size:12px;font-weight:800;color:var(--txt2)">الطلاب (${studs.length})</span>
        <div class="sbar" style="flex:1;max-width:180px;margin-right:auto">
          <i class="fas fa-search" style="font-size:10px"></i>
          <input type="text" id="pStudSrch" placeholder="بحث..." oninput="_filterProctorStudents()" style="font-size:12px">
        </div>
      </div>
      <div id="pStudList" style="max-height:380px;overflow-y:auto">
        ${_buildProctorStudentList(studs, curSecs, myExams)}
      </div>
    </div>`;

  // حفظ بيانات للبحث
  window._pCurStuds   = studs;
  window._pCurSecs    = curSecs;
  window._pCurExams   = myExams;
}

function _pMini(val, lbl, icon, color) {
  return `<div style="padding:7px 6px;border-radius:8px;background:${color}10;text-align:center;border:1px solid ${color}20">
    <div style="font-size:16px;font-weight:900;color:${color}">${val}</div>
    <div style="font-size:9.5px;color:${color}90;font-weight:700;margin-top:1px;display:flex;align-items:center;justify-content:center;gap:2px">
      <i class="fas ${icon}" style="font-size:8px"></i>${lbl}
    </div>
  </div>`;
}

function _buildProctorSecRow(sec, allStuds) {
  const cnt   = (sec.student_ids||[]).length;
  const studs = allStuds.filter(s=>(sec.student_ids||[]).includes(s.id));
  return `<div style="border-bottom:1px solid var(--border)">
    <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;transition:background .15s"
         onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"
         onclick="_toggleProctorSecStudents(${sec.id},this)">
      <div style="width:36px;height:36px;border-radius:9px;background:var(--purple)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-layer-group" style="color:var(--purple2);font-size:13px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px">${esc(sec.name)}</div>
      </div>
      <span style="font-size:11px;background:var(--teal)15;color:var(--teal);padding:3px 9px;border-radius:6px;font-weight:700">${cnt} طالب</span>
      <i class="fas fa-chevron-down" style="color:var(--txt3);font-size:11px;transition:transform .2s" id="secChev_${sec.id}"></i>
    </div>
    <div id="secStudInline_${sec.id}" style="display:none;padding:0 14px 8px 14px;background:var(--bg)">
      ${studs.length ? studs.map(s=>`
        <div style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:8px;margin-bottom:4px;cursor:pointer;transition:background .15s"
             onmouseover="this.style.background='var(--card)'" onmouseout="this.style.background='transparent'"
             onclick="_openStudentActivity('${s.id}')">
          <div style="width:32px;height:32px;border-radius:8px;background:var(--teal)18;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:var(--teal);flex-shrink:0">
            ${getInitials(s.name||'?')}
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:12.5px">${esc(s.name)}</div>
            <div style="font-size:10.5px;color:var(--txt3)">${esc(s.stud_id||'')}</div>
          </div>
          <span class="badge ${s.banned?'b-red':s.active?'b-green':'b-gray'}" style="font-size:10px">${s.banned?'موقوف':s.active?'نشط':'—'}</span>
          <i class="fas fa-chart-line" style="color:var(--primary2);font-size:11px" title="عرض النشاط"></i>
        </div>`).join('')
        : '<div style="padding:10px;text-align:center;color:var(--txt3);font-size:12px">لا يوجد طلاب</div>'}
    </div>
  </div>`;
}

function _toggleProctorSecStudents(secId, headerEl) {
  const box  = document.getElementById(`secStudInline_${secId}`);
  const chev = document.getElementById(`secChev_${secId}`);
  if (!box) return;
  const isOpen = box.style.display !== 'none';
  box.style.display = isOpen ? 'none' : 'block';
  if (chev) chev.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
}

function _buildProctorStudentList(studs, curSecs, myExams) {
  if (!studs.length) return '<div style="padding:24px;text-align:center;color:var(--txt3);font-size:13px">لا يوجد طلاب في هذه المادة</div>';
  return studs.map(s => {
    const secName = curSecs.find(sec=>(sec.student_ids||[]).includes(s.id))?.name||'';
    // إحصاء الحضور السريع
    let pres=0, total=0;
    myExams.forEach(e => {
      const att = STATE.attendance[e.id]||{};
      if ((e.section_ids||[]).some(sid => curSecs.find(sec=>sec.id===sid&&(sec.student_ids||[]).includes(s.id)))) {
        total++;
        if (att[s.id]==='present') pres++;
      }
    });
    const rate = total ? Math.round(pres/total*100) : null;
    return `<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s"
                 onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"
                 onclick="_openStudentActivity('${s.id}')">
      <div style="width:38px;height:38px;border-radius:10px;background:var(--teal)18;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:var(--teal);flex-shrink:0">
        ${getInitials(s.name||'?')}
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px">${esc(s.name)}</div>
        <div style="font-size:11px;color:var(--txt3);margin-top:2px">
          ${s.stud_id?`<span>${esc(s.stud_id)}</span> · `:''} ${esc(secName)}
          ${s.batch?` · دفعة ${s.batch}`:''}
        </div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
        ${rate !== null ? `<div style="font-size:11px;font-weight:700;color:${rate>=75?'var(--green)':rate>=50?'var(--gold)':'var(--red2)'}">
          ${rate}% حضور
        </div>` : ''}
        <span class="badge ${s.banned?'b-red':s.active?'b-green':'b-gray'}" style="font-size:10px">${s.banned?'موقوف':s.active?'نشط':'—'}</span>
      </div>
      <i class="fas fa-chevron-left" style="color:var(--txt3)50;font-size:11px"></i>
    </div>`;
  }).join('');
}

function _filterProctorStudents() {
  const q = (document.getElementById('pStudSrch')?.value||'').toLowerCase();
  const studs  = window._pCurStuds || [];
  const secs   = window._pCurSecs  || [];
  const exams  = window._pCurExams || [];
  const filtered = q ? studs.filter(s => s.name?.toLowerCase().includes(q) || s.stud_id?.toLowerCase().includes(q)) : studs;
  const el = document.getElementById('pStudList');
  if (el) el.innerHTML = _buildProctorStudentList(filtered, secs, exams);
}

// ══════════════════════════════════════════════════════════════
//  نافذة نشاط الطالب وتاريخه
// ══════════════════════════════════════════════════════════════

function _openStudentActivity(studId) {
  const s = STATE.students.find(x => x.id == studId);
  if (!s) return;

  const uid      = STATE.currentUser?.id;
  const sem      = STATE.currentSem;
  const semLabel = STATE.semesters.find(x=>x.code===sem)?.label || sem;

  // كل الشعب التي ينتمي لها الطالب في مواد المراقب (الفصل الحالي)
  const mySubjIds = new Set(STATE.subjects.filter(x=>(x.staff_ids||[]).includes(uid)).map(x=>x.id));
  const mySecs = STATE.sections.filter(sec =>
    mySubjIds.has(sec.subject_id) && sec.semester === sem &&
    (sec.student_ids||[]).includes(s.id)
  );

  // كل امتحانات الفصل في مواد المراقب
  const examsList = STATE.exams
    .filter(e => mySubjIds.has(e.subject_id) && e.semester === sem)
    .sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`));

  // تجميع: امتحانات مرتبطة بالطالب (في شعبه)
  const studExams = examsList.filter(e =>
    (e.section_ids||[]).some(sid => mySecs.find(sec=>sec.id===sid))
  );

  // إحصاءات الحضور
  let present=0, absent=0, late=0, excused=0, unmarked=0;
  studExams.forEach(e => {
    const att = (STATE.attendance[e.id]||{})[s.id];
    if (!att)           { unmarked++; }
    else if (att==='present') present++;
    else if (att==='absent')  absent++;
    else if (att==='late')    late++;
    else if (att==='excused') excused++;
  });
  const total   = studExams.length;
  const attRate = total ? Math.round((present+late)/total*100) : null;

  const moId = 'studActivityMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo=document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
  mo.innerHTML = `
    <div class="md" style="max-width:560px">
      <div class="md-hd">
        <h2><i class="fas fa-user-graduate" style="color:var(--teal)"></i> نشاط الطالب وسجله</h2>
        <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:0">

        <!-- بطاقة الطالب -->
        <div style="padding:18px 20px;background:linear-gradient(135deg,var(--teal)12,var(--teal)04);border-bottom:1px solid var(--border)">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
            <div style="width:52px;height:52px;border-radius:14px;background:var(--teal)25;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:var(--teal)">
              ${getInitials(s.name||'?')}
            </div>
            <div style="flex:1">
              <div style="font-weight:900;font-size:16px">${esc(s.name)}</div>
              <div style="font-size:12px;color:var(--txt2);margin-top:4px;display:flex;gap:10px;flex-wrap:wrap">
                ${s.stud_id?`<span><i class="fas fa-id-card" style="color:var(--teal);margin-left:4px"></i>${esc(s.stud_id)}</span>`:''}
                ${s.batch?`<span><i class="fas fa-graduation-cap" style="color:var(--primary2);margin-left:4px"></i>دفعة ${s.batch}</span>`:''}
                ${s.email?`<span><i class="fas fa-envelope" style="color:var(--gold);margin-left:4px"></i>${esc(s.email)}</span>`:''}
              </div>
            </div>
            <span class="badge ${s.banned?'b-red':s.active?'b-green':'b-gray'}" style="font-size:12px">${s.banned?'موقوف':s.active?'نشط':'غير نشط'}</span>
          </div>

          <!-- إحصاءات الحضور -->
          <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px">
            ${[
              {v:total,     l:'امتحان',  c:'#64748b', bg:'#f1f5f9'},
              {v:present,   l:'حاضر',    c:'#059669', bg:'#d1fae5'},
              {v:absent,    l:'غائب',    c:'#dc2626', bg:'#fee2e2'},
              {v:late,      l:'متأخر',   c:'#d97706', bg:'#fef3c7'},
              {v:attRate!==null?attRate+'%':'—', l:'الحضور', c:'#0891b2', bg:'#e0f2fe'}
            ].map(x=>`<div style="padding:8px 4px;border-radius:8px;background:${x.bg};text-align:center">
              <div style="font-size:17px;font-weight:900;color:${x.c}">${x.v}</div>
              <div style="font-size:9.5px;color:${x.c}90;font-weight:700">${x.l}</div>
            </div>`).join('')}
          </div>
        </div>

        <!-- الشعب المسجَّل فيها -->
        <div style="padding:10px 20px;background:var(--bg);border-bottom:1px solid var(--border)">
          <div style="font-size:11px;font-weight:800;color:var(--txt3);margin-bottom:7px;text-transform:uppercase;letter-spacing:.5px">الشعب في ${esc(semLabel)}</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${mySecs.length ? mySecs.map(sec => {
              const subj = getSubject(sec.subject_id);
              return `<div style="padding:5px 10px;border-radius:7px;background:var(--purple)15;border:1px solid var(--purple)20;font-size:11.5px;font-weight:700;color:var(--purple2)">
                <i class="fas fa-layer-group" style="font-size:10px;margin-left:4px"></i>
                ${esc(subj?.code||'')}: ${esc(sec.name)}
              </div>`;
            }).join('')
            : '<span style="font-size:12px;color:var(--txt3)">لا توجد شعب مشتركة</span>'}
          </div>
        </div>

        <!-- سجل الامتحانات التفصيلي -->
        <div style="padding:10px 20px 6px;border-bottom:1px solid var(--border)">
          <div style="font-size:11px;font-weight:800;color:var(--txt3);margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px">سجل الامتحانات</div>
        </div>
        <div style="max-height:320px;overflow-y:auto">
          ${studExams.length ? studExams.map(e => {
            const sub = getSubject(e.subject_id);
            const att = (STATE.attendance[e.id]||{})[s.id];
            const st  = examStatus(e);
            const attInfo = att === 'present' ? {lbl:'حاضر',    cl:'b-green',  ic:'fa-check-circle'}
                          : att === 'absent'  ? {lbl:'غائب',    cl:'b-red',    ic:'fa-times-circle'}
                          : att === 'late'    ? {lbl:'متأخر',   cl:'b-gold',   ic:'fa-clock'}
                          : att === 'excused' ? {lbl:'بعذر',    cl:'b-purple', ic:'fa-file-alt'}
                          :                    {lbl:'لم يُسجَّل', cl:'b-gray',  ic:'fa-minus-circle'};
            return `<div style="display:flex;align-items:center;gap:11px;padding:11px 20px;border-bottom:1px solid var(--border);transition:background .15s"
                         onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
              <div style="width:36px;height:36px;border-radius:9px;background:var(--green)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <i class="fas ${attInfo.ic}" style="color:var(--${att==='present'?'green':att==='absent'?'red':att==='late'?'gold':'txt3'});font-size:14px"></i>
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-weight:700;font-size:13px">${esc(sub?.name||'—')}</div>
                <div style="font-size:11px;color:var(--txt3);margin-top:2px;display:flex;gap:8px;flex-wrap:wrap">
                  <span><i class="fas fa-calendar" style="color:var(--primary2);font-size:9px;margin-left:3px"></i>${fmtDate(e.date)}</span>
                  <span><i class="fas fa-clock" style="color:var(--gold);font-size:9px;margin-left:3px"></i>${fmtTime(e.time)}</span>
                  <span>${e.type==='final'?'نهائي':e.type==='midterm'?'منتصف فصل':'اختبار'}</span>
                </div>
              </div>
              <div style="display:flex;flex-direction:column;gap:3px;align-items:flex-end">
                <span class="badge ${attInfo.cl}" style="font-size:11px">${attInfo.lbl}</span>
                ${getStatusBadge(st)}
              </div>
            </div>`;
          }).join('')
          : '<div style="padding:32px;text-align:center;color:var(--txt3);font-size:13px">لا توجد امتحانات مشتركة في هذا الفصل</div>'}
        </div>

      </div>
      <div class="md-ft">
        <button class="btn bo" onclick="closeMo('${moId}')">إغلاق</button>
      </div>
    </div>`;
  showMo(moId);
}

function openManageSubjectStaff(subjId) {
  const subj = getSubject(subjId);
  if (!subj) return;
  const dept = STATE.departments.find(d => d.id === subj.dept_id);
  const currentStaff = subj.staff_ids || [];
  const allowedRoles = ['proctor','dept_head','assistant_dean','admin','coordinator'];

  // فصل: نفس قسم المادة أولاً، ثم البقية
  const deptStaff  = STATE.profiles.filter(p => p.active && allowedRoles.includes(p.role) && subj.dept_id && p.dept_id === subj.dept_id);
  const otherStaff = STATE.profiles.filter(p => p.active && allowedRoles.includes(p.role) && (!subj.dept_id || p.dept_id !== subj.dept_id));

  const moId = 'manageStaffMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
  mo.innerHTML = `
    <div class="md" style="max-width:500px">
      <div class="md-hd">
        <h2><i class="fas fa-user-tie" style="color:var(--primary2)"></i> ربط مستخدمين بـ: ${esc(subj.name)}</h2>
        <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:0">
        <!-- معلومات -->
        <div style="padding:10px 16px;background:var(--bg);border-bottom:1px solid var(--border)">
          <div style="font-size:12px;color:var(--txt2);margin-bottom:8px">
            <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
            المرتبطون بالمادة يستطيعون رؤية شعبها وطلابها.
            ${dept?`<span style="color:${dept.color||'var(--primary2)'}">· يُعرض أعضاء <strong>${esc(dept.name)}</strong> أولاً.</span>`:''}
          </div>
          <!-- بحث + أزرار -->
          <div style="display:flex;gap:8px">
            <div class="sbar" style="flex:1">
              <i class="fas fa-search"></i>
              <input type="text" id="staffSrch" placeholder="بحث بالاسم..." oninput="_filterStaffList()" autocomplete="off">
            </div>
            <button class="btn bo btn-xs" onclick="_toggleAllStaff(true)"><i class="fas fa-check-double"></i></button>
            <button class="btn bo btn-xs" onclick="_toggleAllStaff(false)"><i class="fas fa-times"></i></button>
          </div>
          <!-- عداد المحددين -->
          <div id="staffCounter" style="font-size:11.5px;color:var(--primary2);font-weight:700;margin-top:6px">
            ${currentStaff.length} مرتبط حالياً
          </div>
        </div>

        <!-- قائمة المستخدمين -->
        <div id="staffListContainer" style="max-height:420px;overflow-y:auto;padding:10px 14px">
          ${_buildStaffGroupHTML(deptStaff, dept ? `أعضاء قسم: ${dept.name}` : '', currentStaff)}
          ${_buildStaffGroupHTML(otherStaff, 'أقسام أخرى', currentStaff)}
          ${(!deptStaff.length && !otherStaff.length) ? '<div style="padding:20px;text-align:center;color:var(--txt3)">لا يوجد مستخدمون</div>' : ''}
        </div>
      </div>
      <div class="md-ft">
        <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
        <button class="btn bp" onclick="saveSubjectStaff(${subjId})"><i class="fas fa-save"></i> حفظ الارتباطات</button>
      </div>
    </div>`;
  showMo(moId);
  _updateStaffCounter();
}

function _buildStaffGroupHTML(list, label, currentStaff) {
  if (!list.length) return '';
  return `
    <div style="font-size:10.5px;font-weight:800;color:var(--txt3);padding:8px 4px 6px;text-transform:uppercase;letter-spacing:.5px;display:flex;align-items:center;gap:6px">
      ${label}
      <span style="font-size:9.5px;font-weight:400;opacity:.7">(${list.length})</span>
    </div>
    ${list.map(p => {
      const isLinked = currentStaff.includes(p.id);
      const rc = APP_CONFIG.ROLE_COLORS[p.role]||'var(--primary)';
      const rl = APP_CONFIG.ROLES[p.role]||p.role;
      return `<label data-name="${esc((p.name||'').toLowerCase())}" style="display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:10px;cursor:pointer;border:1.5px solid ${isLinked?'var(--primary)':'var(--border)'};background:${isLinked?'var(--primary)08':'transparent'};margin-bottom:6px;transition:all .15s"
               onclick="setTimeout(_updateStaffCounter,50)">
        <input type="checkbox" id="staff_${p.id}" ${isLinked?'checked':''} style="accent-color:var(--primary);width:15px;height:15px;flex-shrink:0">
        <div style="width:36px;height:36px;border-radius:10px;background:${rc}20;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas ${APP_CONFIG.ROLE_ICONS[p.role]||'fa-user'}" style="color:${rc};font-size:14px"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:13px">${esc(p.name?.split(' ').slice(0,3).join(' '))}</div>
          <div style="font-size:10.5px;color:${rc}">● ${esc(rl)}${p.emp_id?' · '+esc(p.emp_id):''}</div>
        </div>
        ${isLinked?`<span style="font-size:10px;background:var(--primary)18;color:var(--primary2);padding:2px 7px;border-radius:5px;font-weight:700">مرتبط</span>`:''}
      </label>`;
    }).join('')}`;
}

function _filterStaffList() {
  const q = (document.getElementById('staffSrch')?.value||'').toLowerCase();
  document.querySelectorAll('#staffListContainer label[data-name]').forEach(lbl => {
    const name = lbl.dataset.name || '';
    lbl.style.display = !q || name.includes(q) ? '' : 'none';
  });
  // إخفاء رؤوس المجموعات الفارغة
  document.querySelectorAll('#staffListContainer > div[style*="uppercase"]').forEach(hdr => {
    const next = hdr.nextElementSibling;
    let hasVisible = false;
    let el = hdr.nextElementSibling;
    while (el && !el.style.textTransform) {
      if (el.style.display !== 'none') { hasVisible = true; break; }
      el = el.nextElementSibling;
    }
    hdr.style.display = hasVisible ? '' : 'none';
  });
}

function _updateStaffCounter() {
  const count = document.querySelectorAll('#manageStaffMo input[type="checkbox"]:checked').length;
  const el = document.getElementById('staffCounter');
  if (el) el.textContent = `${count} مرتبط`;
}

function _toggleAllStaff(select) {
  document.querySelectorAll('#staffListContainer label[data-name]').forEach(lbl => {
    if (lbl.style.display !== 'none') {
      const cb = lbl.querySelector('input[type="checkbox"]');
      if (cb) cb.checked = select;
    }
  });
  _updateStaffCounter();
}

async function saveSubjectStaff(subjId) {
  const checked = [...document.querySelectorAll('#manageStaffMo input[type="checkbox"]:checked')]
    .map(cb => cb.id.replace('staff_',''));
  const subj = getSubject(subjId);
  if (!subj) return;
  try {
    await dbUpdate('subjects', subjId, { staff_ids: checked });
    subj.staff_ids = checked;
    closeMo('manageStaffMo');
    if (_selectedSubjId === subjId) _renderSubjectDetail(subjId);
    _filterSubjList();
    toast(`✓ تم ربط ${checked.length} مستخدم بالمادة`, 'success');
    await addLog('تحديث ربط المدرسين بالمادة', 'subjects', subj.name);
  } catch(e) { toast('خطأ: '+e.message, 'error'); }
}


// ── المواد CRUD ──────────────────────────────────────────────
function openAddSubj() { _buildSubjModal(null); }
function openEditSubj(id) { _buildSubjModal(id); }

function _buildSubjModal(editId) {
  const s = editId ? getSubject(editId) : null;
  const mo = _getMo('subjMo');
  mo.innerHTML = `<div class="md" style="max-width:440px">
    <div class="md-hd">
      <h2><i class="fas fa-book" style="color:var(--gold)"></i> ${s?'تعديل':'إضافة'} مادة</h2>
      <button class="md-close" onclick="closeMo('subjMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">اسم المادة <span class="req">*</span></label>
        <input type="text" id="sjName" value="${esc(s?.name||'')}"></div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الرمز <span class="req">*</span></label>
          <input type="text" id="sjCode" value="${esc(s?.code||'')}" placeholder="NURS101"></div>
        <div class="field"><label class="field-lbl">القسم</label>
          <select id="sjDept" style="width:100%">
            <option value="">— بدون قسم —</option>
            ${STATE.departments.map(d=>`<option value="${d.id}" ${s?.dept_id==d.id?'selected':''}>${esc(d.name)}</option>`).join('')}
          </select></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الساعات المعتمدة</label>
          <input type="number" id="sjHours" value="${s?.hours||3}" min="1" max="10"></div>
        <div class="field"><label class="field-lbl">المستوى</label>
          <input type="text" id="sjLevel" value="${esc(s?.level||'')}" placeholder="Level 1"></div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('subjMo')">إلغاء</button>
      <button class="btn bp" onclick="saveSubj(${editId||null})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('subjMo');
}

async function saveSubj(editId) {
  const name  = document.getElementById('sjName')?.value?.trim();
  const code  = document.getElementById('sjCode')?.value?.trim();
  const dept  = document.getElementById('sjDept')?.value;
  const hours = parseInt(document.getElementById('sjHours')?.value||3);
  const level = document.getElementById('sjLevel')?.value?.trim()||'';
  if (!name || !code) { toast('الاسم والرمز مطلوبان','error'); return; }
  try {
    const deptId = dept ? parseInt(dept) : null;
    if (editId) {
      await dbUpdate('subjects', editId, { name, code, dept_id: deptId, hours, level });
      const s = getSubject(editId);
      if (s) Object.assign(s, { name, code, dept_id: deptId, hours, level });
    } else {
      const row = await dbInsert('subjects', { name, code, dept_id: deptId, hours, level, staff_ids: [] });
      if (row) STATE.subjects.push(Hydrate.subject ? Hydrate.subject(row) : row);
    }
    closeMo('subjMo');
    renderSubjects();
    toast('✓ تم الحفظ','success');
  } catch (e) { toast('خطأ: '+e.message,'error'); }
}

async function deleteSubj(id) {
  const s = getSubject(id);
  confirmDelete(`حذف مادة "${s?.name}"؟`, async () => {
    try {
      await dbDelete('subjects', id);
      STATE.subjects = STATE.subjects.filter(x => x.id !== id);
      if (_selectedSubjId === id) {
        _selectedSubjId = null;
        const detPanel = document.getElementById('subjDetailPanel');
        if (detPanel) detPanel.innerHTML = '<div style="padding:60px 20px;text-align:center;color:var(--txt3)"><i class="fas fa-book" style="font-size:32px;opacity:.2;margin-bottom:12px"></i><div style="font-weight:700">تم حذف المادة</div></div>';
      }
      _filterSubjList();
      toast('تم الحذف','info');
    } catch { toast('فشل الحذف','error'); }
  });
}

// ── الشعب CRUD ──────────────────────────────────────────────
function openAddSection() { _buildSectionModal(null); }
function openEditSection(id) { _buildSectionModal(id); }

function _buildSectionModal(editId) {
  const s = editId ? getSection(editId) : null;
  const mo = _getMo('secMo');
  mo.innerHTML = `<div class="md" style="max-width:440px">
    <div class="md-hd">
      <h2><i class="fas fa-layer-group" style="color:var(--purple2)"></i> ${s?'تعديل':'إضافة'} شعبة</h2>
      <button class="md-close" onclick="closeMo('secMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">اسم الشعبة <span class="req">*</span></label>
        <input type="text" id="scName" value="${esc(s?.name||'')}" placeholder="الشعبة أ"></div>
      <div class="field"><label class="field-lbl">المادة <span class="req">*</span></label>
        <select id="scSubj">
          <option value="">— اختر المادة —</option>
          ${STATE.subjects.map(sub=>`<option value="${sub.id}" ${s?.subject_id===sub.id?'selected':''}>${sub.name}</option>`).join('')}
        </select></div>
      <div class="field"><label class="field-lbl">الفصل الدراسي</label>
        <div style="padding:10px 14px;background:var(--bg);border-radius:9px;border:1.5px solid var(--border);font-size:13px;color:var(--txt2);display:flex;align-items:center;gap:8px">
          <i class="fas fa-lock" style="font-size:11px;color:var(--txt3)"></i>
          <span>${STATE.semesters.find(s=>s.code===STATE.currentSem)?.label || STATE.currentSem || '—'}</span>
          <span style="font-size:10.5px;color:var(--txt3);margin-inline-start:auto">يُضاف تلقائياً للفصل الحالي</span>
        </div>
        <input type="hidden" id="scSem" value="${STATE.currentSem}"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('secMo')">إلغاء</button>
      <button class="btn bp" onclick="saveSection(${editId||null})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('secMo');
}

async function saveSection(editId) {
  const name   = document.getElementById('scName')?.value?.trim();
  const subjId = parseInt(document.getElementById('scSubj')?.value);
  const sem    = document.getElementById('scSem')?.value?.trim() || STATE.currentSem;
  if (!name || !subjId) { toast('الاسم والمادة مطلوبان','error'); return; }
  try {
    if (editId) await dbUpdate('sections', editId, { name, subject_id:subjId, semester:sem });
    else await dbInsert('sections', { name, subject_id:subjId, semester:sem, student_ids:[] });
    closeMo('secMo'); renderSubjects();
    toast('✓ تم الحفظ','success');
  } catch (e) { toast('خطأ: '+e.message,'error'); }
}

async function deleteSection(id) {
  const s = getSection(id);
  confirmDelete(`حذف شعبة "${s?.name}"؟`, async () => {
    try { await dbDelete('sections', id); renderSubjects(); toast('تم الحذف','info'); }
    catch { toast('فشل الحذف','error'); }
  });
}

async function deleteAllSemSections(sem) {
  const secs = STATE.sections.filter(s=>s.semester===sem);
  const semLabel = STATE.semesters.find(s=>s.code===sem)?.label || sem;
  confirmDelete(`حذف جميع شعب الفصل "${semLabel}" (${secs.length} شعبة)؟ هذا الإجراء لا يمكن التراجع عنه.`, async () => {
    try {
      for (const sec of secs) {
        await dbDelete('sections', sec.id);
      }
      toast(`✓ تم حذف ${secs.length} شعبة من فصل ${semLabel}`, 'success');
      renderSubjects();
      await addLog('حذف فصل دراسي', 'section', semLabel);
    } catch(e) { toast('خطأ: '+e.message, 'error'); }
  });
}

// ── إدارة طلاب الشعبة (v2 — مع كشف التعارضات ومنع التسجيل المزدوج) ──────────
function openSectionStudents(secId) {
  const sec = getSection(secId); if (!sec) return;
  const subj  = getSubject(sec.subject_id);
  const inSec = new Set(sec.student_ids||[]);
  const semLabel = STATE.semesters.find(s=>s.code===sec.semester)?.label || sec.semester || '—';

  // بناء خريطة التعارضات: طلاب مسجَّلون في شعب أخرى من نفس المقرر/الفصل
  const conflictMap = _buildConflictMap(secId, sec, inSec);
  const conflictCount = Object.keys(conflictMap).length;
  window._secStudConflictMap = conflictMap;

  const mo = _getMo('secStudMo');
  mo.innerHTML = `<div class="md" style="max-width:580px">
    <div class="md-hd">
      <h2><i class="fas fa-users" style="color:var(--purple2)"></i> طلاب الشعبة: ${esc(sec.name)}</h2>
      <button class="md-close" onclick="closeMo('secStudMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:16px 20px">

      <!-- بطاقة معلومات الشعبة -->
      <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:var(--bg);border-radius:10px;border:1.5px solid var(--border);margin-bottom:14px">
        <div style="width:40px;height:40px;border-radius:10px;background:#f5f3ff;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas fa-layer-group" style="color:var(--purple2);font-size:16px"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:13.5px">${esc(subj?.name||'—')}</div>
          <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">${esc(sec.name)} · ${esc(semLabel)}</div>
        </div>
        <div style="text-align:center;flex-shrink:0;padding:6px 12px;background:white;border-radius:8px;border:1px solid var(--border)">
          <div style="font-size:20px;font-weight:800;color:var(--primary2)">${inSec.size}</div>
          <div style="font-size:10px;color:var(--txt3)">طالب حالياً</div>
        </div>
      </div>

      <!-- تحذير التعارض -->
      ${conflictCount ? `<div style="display:flex;align-items:center;gap:10px;padding:10px 13px;background:#fff7ed;border-radius:9px;border:1.5px solid #fed7aa;margin-bottom:12px">
        <i class="fas fa-exclamation-triangle" style="color:#d97706;font-size:14px;flex-shrink:0"></i>
        <div style="font-size:12.5px;color:#92400e">
          <b>${conflictCount} طالب</b> مسجَّل في شعبة أخرى من نفس المقرر — يظهر بتحذير خاص عند إضافته
        </div>
      </div>` : ''}

      <!-- البحث -->
      <div class="sbar" style="margin-bottom:10px">
        <i class="fas fa-search"></i>
        <input type="text" id="secStudSrch" placeholder="بحث بالاسم أو رقم الطالب..." oninput="filterSecStudList(${secId})">
      </div>

      <!-- أزرار التحكم والعداد -->
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <div style="display:flex;gap:6px">
          <button class="btn bo btn-xs" onclick="selectAllSecStudents(${secId},true)"><i class="fas fa-check-double"></i> تحديد الكل</button>
          <button class="btn bo btn-xs" onclick="selectAllSecStudents(${secId},false)"><i class="fas fa-times"></i> إلغاء الكل</button>
        </div>
        <div id="secStudCounter" style="font-size:12px;color:var(--txt2)"></div>
      </div>

      <!-- قائمة الطلاب مقسَّمة بمجموعات -->
      <div id="secStudList" style="max-height:360px;overflow-y:auto;border:1.5px solid var(--border);border-radius:10px;overflow:hidden"></div>
    </div>
    <div class="md-ft">
      <span style="font-size:11px;color:var(--txt3);flex:1">يمكن نقل الطلاب المتعارضين تلقائياً عند الحفظ</span>
      <button class="btn bo" onclick="closeMo('secStudMo')">إلغاء</button>
      <button class="btn bp" onclick="saveSectionStudents(${secId})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('secStudMo');
  _renderSecStudList(secId, inSec, STATE.students, conflictMap);
}

// بناء خريطة التعارضات: { studentId → { secId, secName } }
function _buildConflictMap(secId, sec, inSec) {
  const siblings = STATE.sections.filter(s =>
    s.subject_id === sec.subject_id &&
    s.semester   === sec.semester   &&
    s.id         !== secId
  );
  const map = {};
  siblings.forEach(sib => {
    (sib.student_ids||[]).forEach(sid => {
      if (!inSec.has(sid)) map[sid] = { secId: sib.id, secName: sib.name };
    });
  });
  return map;
}

// رندر قائمة الطلاب مجمَّعةً في ثلاث فئات
function _renderSecStudList(secId, inSec, students, conflictMap) {
  conflictMap = conflictMap || window._secStudConflictMap || {};
  const el = document.getElementById('secStudList'); if (!el) return;
  if (!students.length) { el.innerHTML = emptyState('fa-users','لا يوجد طلاب'); return; }

  const inThisSec    = students.filter(s => inSec.has(s.id));
  const available    = students.filter(s => !inSec.has(s.id) && !conflictMap[s.id]);
  const withConflict = students.filter(s => !inSec.has(s.id) && conflictMap[s.id]);

  let html = '';
  if (inThisSec.length) {
    html += _ssg(`<i class="fas fa-users"></i> الطلاب المسجَّلون حالياً`, inThisSec.length, '#1e40af', '#eff6ff');
    html += inThisSec.map(s => _ssRow(s, true, null)).join('');
  }
  if (available.length) {
    html += _ssg(`<i class="fas fa-user-plus"></i> متاحون للإضافة`, available.length, '#065f46', '#ecfdf5');
    html += available.map(s => _ssRow(s, false, null)).join('');
  }
  if (withConflict.length) {
    html += _ssg(`<i class="fas fa-exclamation-triangle"></i> مسجَّلون في شعبة أخرى`, withConflict.length, '#92400e', '#fff7ed');
    html += withConflict.map(s => _ssRow(s, false, conflictMap[s.id])).join('');
  }
  el.innerHTML = html || emptyState('fa-search','لا توجد نتائج');
  _updateSecStudCounter();
}

// رأس مجموعة
function _ssg(label, count, color, bg) {
  return `<div style="display:flex;align-items:center;gap:8px;padding:7px 14px;background:${bg};font-size:11px;font-weight:700;color:${color};border-bottom:1px solid var(--border);position:sticky;top:0;z-index:1">
    ${label}
    <span style="margin-inline-start:auto;font-weight:500;opacity:.8">${count} طالب</span>
  </div>`;
}

// صف طالب واحد
function _ssRow(s, checked, conflict) {
  const conflictBadge = conflict
    ? `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;color:#92400e;background:#fff7ed;border:1px solid #fed7aa;border-radius:5px;padding:2px 7px;white-space:nowrap;flex-shrink:0">
        <i class="fas fa-exchange-alt" style="font-size:9px"></i>${esc(conflict.secName)}
       </span>`
    : '';
  const rowStyle = conflict ? 'background:#fffbeb;' : '';
  return `<label style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s;${rowStyle}" onmouseover="this.style.opacity='.88'" onmouseout="this.style.opacity='1'">
    <input type="checkbox" id="scs_${s.id}" ${checked?'checked':''} ${conflict?`data-conflict="${conflict.secId}"`:''}
      style="accent-color:var(--primary);width:16px;height:16px;flex-shrink:0" onchange="_updateSecStudCounter()">
    <div style="flex:1;min-width:0">
      <div style="font-weight:600;font-size:13px;display:flex;align-items:center;gap:7px;flex-wrap:wrap">
        ${esc(s.name)}${conflictBadge}
      </div>
      <div style="font-size:11px;color:var(--txt3);margin-top:2px">${esc(s.stud_id||'—')} · دفعة ${s.batch||'—'}</div>
    </div>
  </label>`;
}

// عداد التحديد
function _updateSecStudCounter() {
  const total    = document.querySelectorAll('#secStudList input[type="checkbox"]:checked').length;
  const conflict = document.querySelectorAll('#secStudList input[type="checkbox"][data-conflict]:checked').length;
  const el = document.getElementById('secStudCounter'); if (!el) return;
  el.innerHTML = `<span style="color:var(--primary);font-weight:600">${total} محدَّد</span>`
    + (conflict ? ` · <span style="color:#d97706">${conflict} بتعارض</span>` : '');
}

function filterSecStudList(secId) {
  const q   = (document.getElementById('secStudSrch')?.value||'').toLowerCase();
  const sec = getSection(secId); if (!sec) return;
  const inSec = new Set(sec.student_ids||[]);
  const filtered = q
    ? STATE.students.filter(s => s.name?.toLowerCase().includes(q) || (s.stud_id||'').includes(q))
    : STATE.students;
  _renderSecStudList(secId, inSec, filtered, window._secStudConflictMap || {});
}

function selectAllSecStudents(secId, select) {
  document.querySelectorAll('#secStudList input[type="checkbox"]').forEach(cb => cb.checked = select);
  _updateSecStudCounter();
}

async function saveSectionStudents(secId) {
  const sec = getSection(secId); if (!sec) return;
  const subj = getSubject(sec.subject_id);
  const selected = STATE.students.filter(s => document.getElementById(`scs_${s.id}`)?.checked).map(s => s.id);

  // اكتشاف التعارضات: طلاب مختارون لكنهم موجودون في شعبة أخرى من نفس المقرر/الفصل
  const siblings = STATE.sections.filter(s =>
    s.subject_id === sec.subject_id &&
    s.semester   === sec.semester   &&
    s.id         !== secId
  );
  const conflicts = [];
  selected.forEach(sid => {
    const st  = STATE.students.find(s => s.id === sid);
    const sib = siblings.find(s => (s.student_ids||[]).includes(sid));
    if (sib && st) conflicts.push({ student: st, fromSection: sib });
  });

  if (conflicts.length) {
    window._secStudPendingSelected = selected;
    _showConflictDialog(secId, conflicts, sec, subj);
    return;
  }
  await _doSaveSectionStudents(secId, selected);
}

// نافذة حل التعارض
function _showConflictDialog(secId, conflicts, sec, subj) {
  const mo = _getMo('secConflictMo');
  mo.innerHTML = `<div class="md" style="max-width:520px">
    <div class="md-hd" style="border-bottom:2px solid #fed7aa">
      <h2 style="color:#d97706"><i class="fas fa-exclamation-triangle"></i> تعارض في التسجيل</h2>
      <button class="md-close" onclick="closeMo('secConflictMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:20px">
      <p style="font-size:13.5px;margin-bottom:16px;color:var(--txt)">
        <b>${conflicts.length} ${conflicts.length===1?'طالب':'طلاب'}</b>
        مسجَّل بالفعل في شعبة أخرى من مادة <b>${esc(subj?.name||'')}</b>،
        لا يمكن تسجيل الطالب في شعبتين من نفس المقرر:
      </p>

      <!-- جدول التعارضات -->
      <div style="border:1.5px solid #fed7aa;border-radius:10px;overflow:hidden;margin-bottom:20px">
        <div style="display:flex;padding:8px 14px;background:#fff7ed;font-size:11px;font-weight:700;color:#92400e;gap:10px">
          <span style="flex:1">الطالب</span><span style="width:110px">من شعبة</span><span style="width:24px"></span><span style="width:110px">إلى شعبة</span>
        </div>
        ${conflicts.map((c,i) => `
        <div style="display:flex;align-items:center;gap:10px;padding:11px 14px;border-top:1px solid #fed7aa;background:${i%2?'#fffbeb':'white'}">
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:13px">${esc(c.student.name)}</div>
            <div style="font-size:11px;color:var(--txt3)">${esc(c.student.stud_id||'—')}</div>
          </div>
          <div style="width:110px;text-align:center">
            <span style="display:inline-block;background:#fff7ed;border:1px solid #fed7aa;border-radius:6px;padding:3px 8px;font-size:11.5px;font-weight:600;color:#92400e">${esc(c.fromSection.name)}</span>
          </div>
          <div style="width:24px;text-align:center;color:#d97706;font-size:13px">→</div>
          <div style="width:110px;text-align:center">
            <span style="display:inline-block;background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:3px 8px;font-size:11.5px;font-weight:600;color:#1e40af">${esc(sec.name)}</span>
          </div>
        </div>`).join('')}
      </div>

      <!-- شرح الخيارات -->
      <div style="padding:14px;background:var(--bg);border-radius:10px;border:1.5px solid var(--border);font-size:12.5px;color:var(--txt2)">
        <div style="font-weight:700;color:var(--txt);margin-bottom:8px;font-size:13px"><i class="fas fa-info-circle" style="color:var(--primary2)"></i> اختر إجراءً:</div>
        <div style="display:flex;gap:6px;align-items:flex-start;margin-bottom:6px">
          <i class="fas fa-exchange-alt" style="color:var(--primary2);margin-top:2px;flex-shrink:0"></i>
          <span><b>نقل تلقائي:</b> يُزال الطلاب من شعبهم الحالية وينتقلون إلى "${esc(sec.name)}" مع حفظ بقية التغييرات</span>
        </div>
        <div style="display:flex;gap:6px;align-items:flex-start;margin-bottom:6px">
          <i class="fas fa-save" style="color:#d97706;margin-top:2px;flex-shrink:0"></i>
          <span><b>تجاهل التعارض:</b> يُحفظ باقي الطلاب فقط، ويبقى الطلاب المتعارضون في شعبهم الحالية</span>
        </div>
        <div style="display:flex;gap:6px;align-items:flex-start">
          <i class="fas fa-times" style="color:var(--danger);margin-top:2px;flex-shrink:0"></i>
          <span><b>إلغاء:</b> العودة لتعديل القائمة</span>
        </div>
      </div>
    </div>
    <div class="md-ft" style="gap:8px;flex-wrap:wrap">
      <button class="btn bo" style="flex:0 0 auto" onclick="closeMo('secConflictMo')"><i class="fas fa-times"></i> إلغاء</button>
      <button class="btn" style="background:#f59e0b;color:white;flex:0 0 auto" onclick="_resolveConflictSave(${secId},false)">
        <i class="fas fa-save"></i> تجاهل وحفظ الباقي
      </button>
      <button class="btn bp" style="flex:0 0 auto" onclick="_resolveConflictSave(${secId},true)">
        <i class="fas fa-exchange-alt"></i> نقل تلقائي وحفظ
      </button>
    </div>
  </div>`;
  showMo('secConflictMo');
}

// تنفيذ الحفظ بعد قرار المستخدم بشأن التعارض
async function _resolveConflictSave(secId, autoMove) {
  const sec = getSection(secId); if (!sec) return;
  let selected = window._secStudPendingSelected ? [...window._secStudPendingSelected] : [];
  closeMo('secConflictMo');

  const siblings = STATE.sections.filter(s =>
    s.subject_id === sec.subject_id &&
    s.semester   === sec.semester   &&
    s.id         !== secId
  );

  if (autoMove) {
    // أزِل الطلاب المنتقلين من شعبهم القديمة
    for (const sib of siblings) {
      const oldIds = sib.student_ids||[];
      const newIds = oldIds.filter(sid => !selected.includes(sid));
      if (newIds.length !== oldIds.length) {
        await dbUpdate('sections', sib.id, { student_ids: newIds });
        sib.student_ids = newIds;
      }
    }
  } else {
    // تجاهل: أزِل الطلاب المتعارضين من قائمة التحديد
    const conflictIds = new Set();
    siblings.forEach(sib => (sib.student_ids||[]).forEach(sid => {
      if (selected.includes(sid)) conflictIds.add(sid);
    }));
    selected = selected.filter(sid => !conflictIds.has(sid));
  }

  await _doSaveSectionStudents(secId, selected);
}

// الحفظ الفعلي
async function _doSaveSectionStudents(secId, selectedIds) {
  try {
    await dbUpdate('sections', secId, { student_ids: selectedIds });
    const sec = getSection(secId);
    if (sec) sec.student_ids = selectedIds;
    closeMo('secStudMo');
    renderSubjects();
    toast(`✓ تم تحديث طلاب الشعبة (${selectedIds.length} طالب)`, 'success');
    await addLog('تحديث طلاب الشعبة', 'section', sec?.name||'');
  } catch (e) { toast('خطأ: ' + e.message, 'error'); }
}

function _getMo(id) {
  let mo = document.getElementById(id);
  if (!mo) { mo=document.createElement('div'); mo.className='mo'; mo.id=id; document.body.appendChild(mo); }
  return mo;
}

// ════════════════════════════════════════════════════════════════
//  استيراد الشعب والطلاب من Excel — نظام احترافي متكامل
// ════════════════════════════════════════════════════════════════

let _importParsedData = [];
let _importMode = 'auto'; // 'auto' | 'existing'

function openImportSections() {
  if (typeof XLSX === 'undefined') {
    toast('مكتبة Excel غير محملة بعد، يرجى الانتظار...', 'warning');
    return;
  }
  const mo = _getMo('importSecMo');
  mo.innerHTML = `<div class="md" style="max-width:680px">
    <div class="md-hd">
      <h2><i class="fas fa-file-excel" style="color:#059669"></i> استيراد الشعب والطلاب من Excel</h2>
      <button class="md-close" onclick="closeMo('importSecMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:20px">

      <!-- تعليمات -->
      <div style="background:var(--bg);border:1.5px solid var(--border);border-radius:12px;padding:16px;margin-bottom:16px">
        <div style="font-weight:800;font-size:13px;margin-bottom:10px;color:var(--txt)">
          <i class="fas fa-info-circle" style="color:var(--primary2)"></i> تنسيق الملف المطلوب
        </div>
        <div style="font-size:12px;color:var(--txt2);line-height:1.9">
          يجب أن يحتوي الملف على الأعمدة التالية (الصف الأول رأس الجدول):
        </div>
        <div style="margin-top:8px;display:grid;grid-template-columns:repeat(3,1fr);gap:6px">
          ${[
            ['section_name / اسم الشعبة','مطلوب'],
            ['subject_code / رمز المادة','مطلوب'],
            ['student_id / رقم الطالب','مطلوب'],
            ['student_name / اسم الطالب','مطلوب'],
            ['email / البريد','اختياري'],
            ['phone / الهاتف','اختياري'],
            ['batch / الدفعة','اختياري']
          ].map(([col,req]) => `
            <div style="padding:6px 10px;border-radius:7px;border:1px solid var(--border);font-size:11px;background:var(--card)">
              <div style="font-weight:700;color:var(--txt)">${col}</div>
              <div style="color:${req==='مطلوب'?'var(--red2)':'var(--txt3)'}">${req}</div>
            </div>`).join('')}
        </div>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn bo btn-sm" onclick="downloadImportTemplate()">
            <i class="fas fa-download" style="color:var(--primary2)"></i> تحميل نموذج Excel
          </button>
        </div>
      </div>

      <!-- اختيار الفصل -->
      <div class="field" style="margin-bottom:14px">
        <label class="field-lbl">الفصل الدراسي <span class="req">*</span></label>
        <select id="importSem" style="width:100%;padding:10px;border:1.5px solid var(--border);border-radius:9px;font-size:13px;background:var(--bg2)">
          ${STATE.semesters.map(s=>`<option value="${s.code}" ${s.code===STATE.currentSem?'selected':''}>${s.label}</option>`).join('')}
        </select>
      </div>

      <!-- وضع التعامل مع الشعب -->
      <div style="margin-bottom:14px">
        <div style="font-size:12.5px;font-weight:700;margin-bottom:8px;color:var(--txt)">
          طريقة التعامل مع الشعب الموجودة:
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <label style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:2px solid var(--primary);border-radius:10px;cursor:pointer;background:var(--primary)06">
            <input type="radio" name="importMode" value="auto" checked onchange="_importMode=this.value" style="accent-color:var(--primary);margin-top:2px;flex-shrink:0">
            <div>
              <div style="font-weight:700;font-size:12.5px">إنشاء تلقائي</div>
              <div style="font-size:11px;color:var(--txt2);margin-top:3px">أنشئ الشعبة إذا لم تكن موجودة، أضف الطلاب للشعبة الموجودة إذا وجدت</div>
            </div>
          </label>
          <label style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:1.5px solid var(--border);border-radius:10px;cursor:pointer">
            <input type="radio" name="importMode" value="existing" onchange="_importMode=this.value" style="accent-color:var(--primary);margin-top:2px;flex-shrink:0">
            <div>
              <div style="font-weight:700;font-size:12.5px">دمج مع الموجود</div>
              <div style="font-size:11px;color:var(--txt2);margin-top:3px">استخدم الشعب الموجودة فقط وأضف الطلاب لها، تجاهل الشعب غير الموجودة</div>
            </div>
          </label>
        </div>
      </div>

      <!-- رفع الملف -->
      <div id="importDropZone"
           style="border:2.5px dashed var(--border);border-radius:14px;padding:30px 20px;text-align:center;cursor:pointer;transition:all .2s;background:var(--bg)"
           onclick="document.getElementById('importFileInput').click()"
           ondragover="event.preventDefault();this.style.borderColor='var(--primary)';this.style.background='var(--primary)08'"
           ondragleave="this.style.borderColor='var(--border)';this.style.background='var(--bg)'"
           ondrop="event.preventDefault();this.style.borderColor='var(--border)';this.style.background='var(--bg)';_handleImportDrop(event)">
        <i class="fas fa-cloud-upload-alt" style="font-size:38px;color:var(--txt3);margin-bottom:10px"></i>
        <div style="font-size:14px;font-weight:700;color:var(--txt)">اسحب ملف Excel هنا أو انقر للاختيار</div>
        <div style="font-size:12px;color:var(--txt3);margin-top:5px">.xlsx, .xls, .csv</div>
        <input type="file" id="importFileInput" accept=".xlsx,.xls,.csv" style="display:none" onchange="_parseImportFile(this.files[0])">
      </div>

      <!-- معاينة البيانات -->
      <div id="importPreview" style="margin-top:16px"></div>
    </div>
    <div class="md-ft" id="importFooter">
      <button class="btn bo" onclick="closeMo('importSecMo')">إلغاء</button>
    </div>
  </div>`;
  showMo('importSecMo');
  _importParsedData = [];
  _importMode = 'auto';
}

function _handleImportDrop(e) {
  const file = e.dataTransfer.files[0];
  if (file) _parseImportFile(file);
}

function _parseImportFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const wb = XLSX.read(data, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
      if (rows.length < 2) { toast('الملف فارغ أو لا يحتوي على بيانات كافية','error'); return; }

      // معالجة الرؤوس بمرونة
      const headers = rows[0].map(h => String(h).trim().toLowerCase()
        .replace(/\s+/g,'_')
        .replace('section_name','section_name').replace('اسم_الشعبة','section_name')
        .replace('subject_code','subject_code').replace('رمز_المادة','subject_code')
        .replace('student_id','student_id').replace('رقم_الطالب','student_id')
        .replace('student_name','student_name').replace('اسم_الطالب','student_name')
        .replace('email','email').replace('البريد','email')
        .replace('phone','phone').replace('الهاتف','phone')
        .replace('batch','batch').replace('الدفعة','batch')
      );

      const colIdx = {};
      headers.forEach((h,i) => { colIdx[h] = i; });

      if (colIdx.section_name === undefined && colIdx['section'] === undefined) {
        toast('العمود "section_name" أو "اسم الشعبة" غير موجود', 'error'); return;
      }
      if (colIdx.subject_code === undefined && colIdx['subject'] === undefined) {
        toast('العمود "subject_code" أو "رمز المادة" غير موجود', 'error'); return;
      }
      if (colIdx.student_id === undefined) {
        toast('العمود "student_id" أو "رقم الطالب" غير موجود', 'error'); return;
      }
      if (colIdx.student_name === undefined) {
        toast('العمود "student_name" أو "اسم الطالب" غير موجود', 'error'); return;
      }

      _importParsedData = rows.slice(1).filter(r => r.some(c => String(c).trim())).map(r => ({
        section_name:  String(r[colIdx.section_name || colIdx['section']] || '').trim(),
        subject_code:  String(r[colIdx.subject_code || colIdx['subject']] || '').trim(),
        student_id:    String(r[colIdx.student_id] || '').trim(),
        student_name:  String(r[colIdx.student_name] || '').trim(),
        email:         String(r[colIdx.email] || '').trim().toLowerCase(),
        phone:         String(r[colIdx.phone] || '').trim(),
        batch:         parseInt(r[colIdx.batch]) || new Date().getFullYear()
      })).filter(r => r.section_name && r.student_id && r.student_name);

      _renderImportPreview();
    } catch(err) {
      toast('خطأ في قراءة الملف: ' + err.message, 'error');
    }
  };
  reader.readAsArrayBuffer(file);
}

function _renderImportPreview() {
  const el = document.getElementById('importPreview');
  const footer = document.getElementById('importFooter');
  if (!el || !_importParsedData.length) return;

  // تجميع حسب الشعب
  const bySection = {};
  _importParsedData.forEach(r => {
    const key = r.section_name + '::' + r.subject_code;
    if (!bySection[key]) bySection[key] = { section_name: r.section_name, subject_code: r.subject_code, students: [] };
    bySection[key].students.push(r);
  });

  const sections = Object.values(bySection);
  let warnings = 0;
  let html = `
    <div style="background:var(--bg);border-radius:12px;border:1.5px solid var(--border);overflow:hidden">
      <div style="padding:12px 16px;background:var(--primary)08;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px">
        <i class="fas fa-eye" style="color:var(--primary2)"></i>
        <div style="font-weight:800;font-size:13px">معاينة البيانات</div>
        <span class="badge b-blue" style="margin-inline-start:auto">${sections.length} شعبة</span>
        <span class="badge b-green">${_importParsedData.length} طالب</span>
      </div>
      <div style="max-height:280px;overflow-y:auto">`;

  sections.forEach(sec => {
    const subj = STATE.subjects.find(s => s.code?.toLowerCase() === sec.subject_code?.toLowerCase() || s.name?.toLowerCase() === sec.subject_code?.toLowerCase());
    const existingSec = STATE.sections.find(s => s.name?.toLowerCase() === sec.section_name?.toLowerCase() && s.semester === (document.getElementById('importSem')?.value || STATE.currentSem));
    const isNew = !existingSec;
    if (isNew && !subj) warnings++;

    html += `
      <div style="border-bottom:1px solid var(--border);padding:10px 15px">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
          <i class="fas fa-layer-group" style="color:var(--purple2)"></i>
          <span style="font-weight:700;font-size:13px">${esc(sec.section_name)}</span>
          ${isNew ? '<span class="badge" style="background:#059669;color:white;font-size:9.5px">جديدة</span>' : '<span class="badge b-blue" style="font-size:9.5px">موجودة</span>'}
          <span style="font-size:11.5px;color:var(--txt2)">· ${esc(sec.subject_code)}</span>
          ${!subj && isNew ? '<span class="badge b-red" style="font-size:9.5px">⚠ مادة غير موجودة</span>' : ''}
          <span class="badge b-gray" style="margin-inline-start:auto">${sec.students.length} طالب</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:4px">
          ${sec.students.slice(0,8).map(s => `<span style="font-size:10.5px;padding:2px 8px;background:var(--bg2);border-radius:5px;border:1px solid var(--border)">${esc(s.student_name)} (${esc(s.student_id)})</span>`).join('')}
          ${sec.students.length > 8 ? `<span style="font-size:10.5px;color:var(--txt3)">+${sec.students.length-8} آخرين</span>` : ''}
        </div>
      </div>`;
  });

  html += `</div></div>`;

  if (warnings) {
    html += `<div style="margin-top:10px;padding:10px 14px;background:#fff7ed;border-radius:10px;border:1.5px solid #fed7aa;font-size:12px;color:#92400e">
      <i class="fas fa-exclamation-triangle"></i> <b>${warnings} شعبة</b> تشير لمواد غير موجودة في النظام. يجب إضافة المادة أولاً أو ستُتجاهل تلك الشعب.
    </div>`;
  }

  el.innerHTML = html;
  if (footer) footer.innerHTML = `
    <button class="btn bo" onclick="closeMo('importSecMo')">إلغاء</button>
    <button class="btn" style="background:linear-gradient(135deg,#059669,#0d9488);color:white;border-color:transparent;gap:8px" onclick="executeImport()">
      <i class="fas fa-file-import"></i> تنفيذ الاستيراد
    </button>`;
}

async function executeImport() {
  if (!_importParsedData.length) { toast('لا توجد بيانات للاستيراد','error'); return; }

  const sem = document.getElementById('importSem')?.value || STATE.currentSem;
  const mode = _importMode || 'auto';
  const btn = document.querySelector('#importSecMo .btn[onclick="executeImport()"]');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> جارٍ الاستيراد...'; }

  const progress = document.getElementById('importPreview');
  if (progress) progress.innerHTML = `<div style="text-align:center;padding:24px;color:var(--txt2)"><i class="fas fa-spinner fa-spin" style="font-size:24px;margin-bottom:10px"></i><br>جارٍ معالجة البيانات...</div>`;

  let createdSections = 0, updatedSections = 0, createdStudents = 0, addedToSections = 0, skipped = 0;
  const errors = [];

  // تجميع حسب الشعبة
  const bySection = {};
  _importParsedData.forEach(r => {
    const key = r.section_name + '::' + r.subject_code;
    if (!bySection[key]) bySection[key] = { section_name: r.section_name, subject_code: r.subject_code, students: [] };
    bySection[key].students.push(r);
  });

  for (const [, sec] of Object.entries(bySection)) {
    try {
      // إيجاد المادة
      const subj = STATE.subjects.find(s =>
        s.code?.toLowerCase() === sec.subject_code?.toLowerCase() ||
        s.name?.toLowerCase() === sec.subject_code?.toLowerCase()
      );

      if (!subj) { errors.push(`مادة "${sec.subject_code}" غير موجودة`); skipped += sec.students.length; continue; }

      // إيجاد أو إنشاء الشعبة
      let section = STATE.sections.find(s =>
        s.name?.toLowerCase() === sec.section_name?.toLowerCase() &&
        s.subject_id === subj.id &&
        s.semester === sem
      );

      if (!section) {
        if (mode === 'existing') { skipped += sec.students.length; continue; }
        // إنشاء شعبة جديدة
        const { data, error } = await SB.getClient().from('sections').insert({
          name: sec.section_name, subject_id: subj.id, semester: sem, student_ids: []
        }).select().single();
        if (error) throw error;
        section = Hydrate.section(data);
        STATE.sections.push(section);
        createdSections++;
      } else {
        updatedSections++;
      }

      // معالجة الطلاب
      const currentIds = new Set(section.student_ids || []);
      for (const st of sec.students) {
        // إيجاد أو إنشاء الطالب
        let student = STATE.students.find(s => s.stud_id === st.student_id);
        if (!student) {
          // إنشاء طالب جديد
          const defPass = await AUTH.hashPassword(st.student_id);
          const { data, error } = await SB.getClient().from('students').insert({
            stud_id: st.student_id,
            name: st.student_name,
            email: st.email || '',
            phone: st.phone || '',
            batch: st.batch || new Date().getFullYear(),
            active: true,
            banned: false,
            password: defPass,
            subject_ids: [subj.id],
            section_ids: [section.id]
          }).select().single();
          if (error) { errors.push(`خطأ في إنشاء طالب ${st.student_id}: ${error.message}`); continue; }
          student = Hydrate.student(data);
          STATE.students.push(student);
          createdStudents++;
        }

        if (!currentIds.has(student.id)) {
          currentIds.add(student.id);
          addedToSections++;
          // تحديث section_ids للطالب أيضاً
          const newSecIds = [...new Set([...(student.section_ids||[]), section.id])];
          const newSubjIds = [...new Set([...(student.subject_ids||[]), subj.id])];
          await SB.getClient().from('students').update({ section_ids: newSecIds, subject_ids: newSubjIds }).eq('id', student.id);
          student.section_ids = newSecIds;
          student.subject_ids = newSubjIds;
        }
      }

      // تحديث student_ids في الشعبة
      const newIds = [...currentIds];
      await SB.getClient().from('sections').update({ student_ids: newIds }).eq('id', section.id);
      section.student_ids = newIds;

    } catch(e) {
      errors.push(`خطأ في شعبة "${sec.section_name}": ${e.message}`);
    }
  }

  // نتيجة الاستيراد
  if (progress) {
    progress.innerHTML = `
      <div style="padding:16px;background:var(--green-bg);border-radius:12px;border:1.5px solid var(--green);text-align:center">
        <i class="fas fa-check-circle" style="font-size:28px;color:var(--green);margin-bottom:8px"></i>
        <div style="font-weight:800;font-size:14px;color:var(--green2)">تم الاستيراد بنجاح ✓</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px">
          <div style="padding:10px;background:white;border-radius:9px;border:1px solid var(--border)">
            <div style="font-size:20px;font-weight:900;color:var(--primary)">${createdSections}</div>
            <div style="font-size:11px;color:var(--txt3)">شعب جديدة</div>
          </div>
          <div style="padding:10px;background:white;border-radius:9px;border:1px solid var(--border)">
            <div style="font-size:20px;font-weight:900;color:var(--green)">${createdStudents}</div>
            <div style="font-size:11px;color:var(--txt3)">طلاب جدد</div>
          </div>
          <div style="padding:10px;background:white;border-radius:9px;border:1px solid var(--border)">
            <div style="font-size:20px;font-weight:900;color:var(--teal)">${addedToSections}</div>
            <div style="font-size:11px;color:var(--txt3)">إضافات للشعب</div>
          </div>
        </div>
        ${errors.length ? `<div style="margin-top:12px;text-align:right;font-size:11.5px;color:var(--red2)"><b>تحذيرات:</b><br>${errors.slice(0,3).map(e=>`• ${esc(e)}`).join('<br>')}${errors.length>3?`<br>• و${errors.length-3} أخرى...`:''}</div>` : ''}
      </div>`;
  }
  const footer = document.getElementById('importFooter');
  if (footer) footer.innerHTML = `<button class="btn bp" onclick="closeMo('importSecMo');renderSubjects()"><i class="fas fa-check"></i> تم، إغلاق</button>`;

  toast(`✓ تم الاستيراد: ${createdSections} شعبة جديدة، ${createdStudents} طالب`, 'success', 5000);
  await addLog('استيراد شعب وطلاب من Excel', 'section', `${createdSections} شعبة، ${createdStudents} طالب`);
}

function downloadImportTemplate() {
  if (typeof XLSX === 'undefined') { toast('جارٍ تحميل مكتبة Excel...', 'warning'); return; }
  const ws_data = [
    ['section_name', 'subject_code', 'student_id', 'student_name', 'email', 'phone', 'batch'],
    ['الشعبة أ', 'NURS101', 'S2021001', 'محمد أحمد العبري', 'student@squ.edu.om', '+96891000001', '2021'],
    ['الشعبة أ', 'NURS101', 'S2021002', 'فاطمة سالم البلوشي', 'student2@squ.edu.om', '+96891000002', '2021'],
    ['الشعبة ب', 'NURS101', 'S2021003', 'علي خالد الحارثي', 'student3@squ.edu.om', '', '2021'],
    ['الشعبة أ', 'NURS102', 'S2021001', 'محمد أحمد العبري', 'student@squ.edu.om', '', '2021'],
  ];
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(ws_data);
  // عرض الأعمدة
  ws['!cols'] = [{wch:15},{wch:14},{wch:12},{wch:20},{wch:22},{wch:14},{wch:8}];
  XLSX.utils.book_append_sheet(wb, ws, 'الشعب والطلاب');
  XLSX.writeFile(wb, 'نموذج_استيراد_الشعب.xlsx');
}

