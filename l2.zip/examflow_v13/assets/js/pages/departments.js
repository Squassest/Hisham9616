// departments.js v7 — إدارة الأقسام الأكاديمية

function renderDepartments() {
  const u = STATE.currentUser;
  const myDept = isDeptHead() ? STATE.departments.find(d => d.id === u?.dept_id) : null;

  if (isAdmin() || isCoord()) {
    setHTML('deptsActs', `
      <div style="display:flex;gap:8px;align-items:center">
        <button class="btn bp btn-sm" onclick="openAddDept()">
          <i class="fas fa-plus"></i> قسم جديد
        </button>
        <button class="btn bo btn-sm" onclick="exportDepartmentsCSV()" title="تصدير بيانات الأقسام">
          <i class="fas fa-file-csv"></i> تصدير CSV
        </button>
        <button class="btn bo btn-sm" onclick="exportDepartmentsPDF()" title="تصدير PDF">
          <i class="fas fa-file-pdf"></i> تصدير PDF
        </button>
      </div>`);
  }

  setHTML('deptsContent', `
    <div class="stats-grid" style="margin-bottom:18px" id="deptStats"></div>

    <!-- فلاتر الأقسام -->
    <div class="card" style="margin-bottom:14px;padding:12px 16px">
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <div class="sbar" style="flex:1;max-width:260px">
          <i class="fas fa-search"></i>
          <input type="text" id="deptSrch" placeholder="بحث باسم القسم..." oninput="_filterDepts()">
        </div>
        <select id="deptHasHead" onchange="_filterDepts()" style="height:34px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;background:var(--surface)">
          <option value="">جميع الأقسام</option>
          <option value="has_head">لديه رئيس قسم</option>
          <option value="no_head">بدون رئيس قسم</option>
        </select>
        <select id="deptSortBy" onchange="_filterDepts()" style="height:34px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;background:var(--surface)">
          <option value="name">ترتيب بالاسم</option>
          <option value="members">ترتيب بالأعضاء</option>
          <option value="exams">ترتيب بالامتحانات</option>
        </select>
        <button class="btn bo btn-xs" onclick="document.getElementById('deptSrch').value='';document.getElementById('deptHasHead').value='';_filterDepts()">
          <i class="fas fa-undo"></i>
        </button>
      </div>
    </div>

    <div class="gl" style="align-items:start">
      <div id="deptMainList"></div>
      <div id="deptSidebar"></div>
    </div>`);

  _renderDeptStats();
  _filterDepts();
}

function _filterDepts() {
  const q       = (document.getElementById('deptSrch')?.value||'').toLowerCase();
  const hasHead = document.getElementById('deptHasHead')?.value||'';
  const sortBy  = document.getElementById('deptSortBy')?.value||'name';

  let depts = [...STATE.departments];
  if (q) depts = depts.filter(d => d.name?.toLowerCase().includes(q) || d.name_en?.toLowerCase().includes(q) || d.code?.toLowerCase().includes(q));
  if (hasHead === 'has_head') depts = depts.filter(d => !!d.head_id);
  if (hasHead === 'no_head')  depts = depts.filter(d => !d.head_id);

  if (sortBy === 'members') depts.sort((a,b)=>STATE.profiles.filter(p=>p.dept_id===b.id).length-STATE.profiles.filter(p=>p.dept_id===a.id).length);
  else if (sortBy === 'exams') depts.sort((a,b)=>{
    const getCount = d => STATE.exams.filter(e=>STATE.subjects.find(s=>s.id===e.subject_id&&s.dept_id===d.id)).length;
    return getCount(b)-getCount(a);
  });
  else depts.sort((a,b)=>a.name?.localeCompare(b.name,'ar'));

  _renderDeptList(depts);
}

function _renderDeptStats() {
  const el = document.getElementById('deptStats'); if (!el) return;
  const depts = STATE.departments;
  const totalSubj  = STATE.subjects.filter(s => s.dept_id).length;
  const totalProct = STATE.profiles.filter(p => p.dept_id && p.role==='proctor').length;
  const deptHeads  = STATE.profiles.filter(p => p.role==='dept_head').length;

  el.innerHTML = [
    { icon:'fa-sitemap',         val: depts.length,  lbl:'الأقسام',      color:'blue' },
    { icon:'fa-book',            val: totalSubj,      lbl:'المواد',       color:'gold' },
    { icon:'fa-users',           val: totalProct,     lbl:'أعضاء القسم',  color:'purple' },
    { icon:'fa-chalkboard-teacher', val: deptHeads,  lbl:'رؤساء الأقسام', color:'teal' }
  ].map(s => `
    <div class="stat-card">
      <div class="stat-ic ic-${s.color}"><i class="fas ${s.icon}"></i></div>
      <div><div class="stat-val">${s.val}</div><div class="stat-lbl">${s.lbl}</div></div>
    </div>`).join('');
}

function _renderDeptList(depts) {
  const el = document.getElementById('deptMainList'); if (!el) return;
  if (!depts) depts = STATE.departments;

  if (!depts.length) {
    el.innerHTML = `<div class="card">${emptyState('fa-sitemap','لا توجد أقسام','أضف قسماً أكاديمياً أولاً')}</div>`;
    return;
  }

  el.innerHTML = depts.map(dept => {
    const head        = getProfile(dept.head_id);
    const coordinator = getProfile(dept.coordinator_id);
    const subjects    = STATE.subjects.filter(s => s.dept_id === dept.id);
    const proctors    = STATE.profiles.filter(p => p.dept_id === dept.id && p.role === 'proctor');
    const deptHead    = STATE.profiles.find(p => p.dept_id === dept.id && p.role === 'dept_head');
    const deptCoord   = STATE.profiles.find(p => p.dept_id === dept.id && p.role === 'coordinator') || coordinator;
    const color       = dept.color || '#2563eb';
    const semExams    = STATE.exams.filter(e => e.semester === STATE.currentSem);
    const deptSubjIds = subjects.map(s=>s.id);
    const deptExams   = semExams.filter(e => deptSubjIds.includes(e.subject_id));
    const activeExams = deptExams.filter(e => examStatus(e) === 'active');

    const _personBadge = (person, role, color, icon, bgColor) => person ? `
      <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:${bgColor||'var(--bg)'};border-radius:10px;border:1px solid ${color}30;cursor:pointer;transition:all .15s"
        onclick="openUserProfile('${person.id}')"
        onmouseover="this.style.transform='scale(1.01)';this.style.boxShadow='0 4px 12px rgba(0,0,0,.1)'"
        onmouseout="this.style.transform='';this.style.boxShadow=''">
        ${userAvatar(person, 36)}
        <div style="flex:1;min-width:0">
          <div style="font-size:12.5px;font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${person.name}</div>
          <div style="font-size:10.5px;color:var(--txt3)">${role}</div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
          <i class="fas ${icon}" style="color:${color};font-size:13px"></i>
          <span style="font-size:10px;color:var(--txt3)"><i class="fas fa-external-link-alt"></i></span>
        </div>
      </div>` : `<div style="padding:8px 10px;background:var(--bg);border-radius:8px;font-size:11.5px;color:var(--txt3);border:1px dashed var(--border)">
        <i class="fas ${icon}" style="margin-inline-end:5px;color:${color};opacity:.4"></i>
        ${role === 'رئيس القسم' || role === 'Dept Head' ? (I18N.isAr()?'لم يُعيَّن رئيس قسم':'No head assigned') : (I18N.isAr()?'لم يُعيَّن منسق':'No coordinator')}
      </div>`;

    const isAr = I18N.isAr();

    return `<div class="card" style="margin-bottom:14px;overflow:hidden">
      <div style="background:linear-gradient(90deg,${color},${color}88);height:4px"></div>
      <div class="card-h">
        <div style="display:flex;align-items:center;gap:12px;flex:1;min-width:0">
          <div style="width:44px;height:44px;border-radius:12px;background:${color}20;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-sitemap" style="color:${color};font-size:18px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:800;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${dept.name}</div>
            <div style="font-size:11.5px;color:var(--txt3)">${dept.name_en || ''} · ${isAr?'كود':'Code'}: ${dept.code}</div>
          </div>
          ${activeExams.length ? `<span class="badge b-green" style="font-size:10px;animation:pulse 2s infinite"><i class="fas fa-circle" style="font-size:7px"></i> ${activeExams.length} ${isAr?'جارٍ':'active'}</span>` : ''}
        </div>
        <div style="display:flex;gap:5px;flex-shrink:0">
          ${isAdminOrCoord() ? `
          <button class="btn bo btn-xs" onclick="exportOneDeptPDF(${dept.id})" title="${isAr?'تصدير':'Export'}"><i class="fas fa-file-export"></i></button>
          <button class="btn bo btn-xs" onclick="openEditDept(${dept.id})"><i class="fas fa-edit"></i></button>
          <button class="btn bd btn-xs" onclick="deleteDept(${dept.id})"><i class="fas fa-trash"></i></button>` : ''}
        </div>
      </div>

      <!-- رئيس القسم والمنسق في الأعلى مباشرة — قابلان للنقر -->
      <div style="padding:12px 18px;border-bottom:1px solid var(--border);display:grid;grid-template-columns:1fr 1fr;gap:8px">
        ${_personBadge(deptHead, isAr?'رئيس القسم':'Dept Head', 'var(--purple)', 'fa-chalkboard-teacher', 'var(--purple-bg)')}
        ${_personBadge(deptCoord, isAr?'المنسق':'Coordinator', 'var(--teal)', 'fa-user-tie', '#f0fdfa')}
      </div>

      <!-- إحصاءات -->
      <div style="padding:12px 18px;display:grid;grid-template-columns:repeat(4,1fr);gap:8px;border-bottom:1px solid var(--border)">
        <div style="text-align:center;background:var(--bg);border-radius:9px;padding:10px 4px">
          <div style="font-size:20px;font-weight:900;color:${color}">${subjects.length}</div>
          <div style="font-size:10px;color:var(--txt3);font-weight:600">${isAr?'مادة':'Subjects'}</div>
        </div>
        <div style="text-align:center;background:var(--bg);border-radius:9px;padding:10px 4px">
          <div style="font-size:20px;font-weight:900;color:var(--purple)">${proctors.length}</div>
          <div style="font-size:10px;color:var(--txt3);font-weight:600">${isAr?'عضو قسم':'Members'}</div>
        </div>
        <div style="text-align:center;background:var(--bg);border-radius:9px;padding:10px 4px">
          <div style="font-size:20px;font-weight:900;color:var(--green)">${deptExams.length}</div>
          <div style="font-size:10px;color:var(--txt3);font-weight:600">${isAr?'امتحان':'Exams'}</div>
        </div>
        <div style="text-align:center;background:var(--bg);border-radius:9px;padding:10px 4px">
          <div style="font-size:20px;font-weight:900;color:var(--gold)">${STATE.profiles.filter(p=>p.dept_id===dept.id&&p.active).length}</div>
          <div style="font-size:10px;color:var(--txt3);font-weight:600">${isAr?'عضو':'Members'}</div>
        </div>
      </div>

      <!-- شريط نشاط الفصل الدراسي الحالي -->
      ${deptExams.length ? `<div style="padding:8px 18px;border-bottom:1px solid var(--border);background:var(--green)06">
        <div style="display:flex;align-items:center;gap:8px;font-size:11.5px">
          <span style="width:7px;height:7px;border-radius:50%;background:${activeExams.length?'var(--green)':'var(--gold)'};animation:${activeExams.length?'pulse 1s infinite':'none'}"></span>
          <span style="color:var(--txt2);font-weight:700">الفصل الحالي:</span>
          <span class="badge b-green" style="font-size:10px">${deptExams.length} امتحان</span>
          ${activeExams.length ? `<span class="badge" style="background:var(--green)20;color:var(--green);font-size:10px">${activeExams.length} جارٍ الآن</span>` : ''}
          <span style="color:var(--txt3);font-size:10.5px;margin-inline-start:auto">${deptExams.filter(e=>examStatus(e)==='upcoming').length} قادم</span>
        </div>
      </div>` : ''}

      <!-- المواد -->
      ${subjects.length ? `<div style="padding:10px 18px;border-bottom:1px solid var(--border)">
        <div style="display:flex;flex-wrap:wrap;gap:5px">
          ${subjects.slice(0,6).map(s=>`<span class="badge b-gold" style="font-size:10px">${s.code}</span>`).join('')}
          ${subjects.length>6?`<span class="badge b-gray" style="font-size:10px">+${subjects.length-6}</span>`:''}
        </div>
      </div>` : ''}

      <!-- أزرار الإدارة -->
      ${isAdminOrCoord()||isDeptHead() ? `
      <div style="padding:10px 18px;display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn bo btn-xs" onclick="openDeptSubjects(${dept.id})">
          <i class="fas fa-book"></i> ${isAr?'المواد':'Subjects'}
        </button>
        <button class="btn bo btn-xs" onclick="openDeptProctors(${dept.id})">
          <i class="fas fa-user-tie"></i> ${isAr?'المراقبون':'Proctors'}
        </button>
        ${isAdminOrCoord() ? `
        <button class="btn bo btn-xs" onclick="openSetDeptHead(${dept.id})">
          <i class="fas fa-chalkboard-teacher" style="color:var(--purple)"></i> ${isAr?'رئيس القسم':'Set Head'}
        </button>
        <button class="btn bo btn-xs" onclick="openSetDeptCoord(${dept.id})">
          <i class="fas fa-user-tie" style="color:var(--teal)"></i> ${isAr?'المنسق':'Set Coord'}
        </button>` : ''}
      </div>` : ''}
    </div>`;
  }).join('');
}

// ── Add / Edit Department ─────────────────────────────────────
function openAddDept() {
  STATE._editDeptId = null;
  _showDeptModal({ name:'', name_en:'', code:'', color:'#2563eb', description:'' });
}

function openEditDept(id) {
  STATE._editDeptId = id;
  const d = STATE.departments.find(x => x.id === id);
  if (!d) return;
  _showDeptModal(d);
}

function _showDeptModal(d) {
  const isEdit = !!STATE._editDeptId;
  const mo = _getMo('deptMo');
  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-sitemap" style="color:var(--primary)"></i> ${isEdit?'تعديل القسم':'قسم جديد'}</h2>
      <button class="md-close" onclick="closeMo('deptMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="g2">
        <div class="field"><label class="field-lbl">اسم القسم بالعربية <span class="req">*</span></label>
          <input id="dName" value="${d.name||''}" placeholder="قسم التمريض السريري"></div>
        <div class="field"><label class="field-lbl">الاسم بالإنجليزية</label>
          <input id="dNameEn" value="${d.name_en||''}" placeholder="Clinical Nursing"></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الكود <span class="req">*</span></label>
          <input id="dCode" value="${d.code||''}" placeholder="CN101" style="text-transform:uppercase"></div>
        <div class="field"><label class="field-lbl">اللون</label>
          <input type="color" id="dColor" value="${d.color||'#2563eb'}" style="height:40px;padding:2px;width:100%;cursor:pointer;border:1.5px solid var(--border);border-radius:9px"></div>
      </div>
      <div class="field"><label class="field-lbl">الوصف</label>
        <textarea id="dDesc" rows="2">${d.description||''}</textarea></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('deptMo')">إلغاء</button>
      <button class="btn bp" onclick="saveDept()"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('deptMo');
}

async function saveDept() {
  const name = document.getElementById('dName')?.value?.trim();
  const code = document.getElementById('dCode')?.value?.trim()?.toUpperCase();
  if (!name || !code) return toast('أدخل اسم القسم والكود','warning');

  const data = {
    name,
    name_en:     document.getElementById('dNameEn')?.value?.trim() || '',
    code,
    color:       document.getElementById('dColor')?.value || '#2563eb',
    description: document.getElementById('dDesc')?.value?.trim() || ''
  };

  setBtnLoading('saveDept', true);
  try {
    if (STATE._editDeptId) {
      const res = await SB.update('departments', STATE._editDeptId, data);
      const idx = STATE.departments.findIndex(d => d.id === STATE._editDeptId);
      if (idx >= 0) STATE.departments[idx] = { ...STATE.departments[idx], ...res };
      toast('تم تحديث القسم ✓','success');
    } else {
      const res = await SB.insert('departments', data);
      STATE.departments.push(res);
      toast('تم إضافة القسم ✓','success');
    }
    await SB.logAction(STATE._editDeptId?'تعديل قسم':'إضافة قسم','departments',name);
    closeMo('deptMo');
    renderDepartments();
  } catch(e) { toast(e.message,'error'); }
}

// ── Delete Department ─────────────────────────────────────────
async function deleteDept(id) {
  const d = STATE.departments.find(x => x.id === id);
  if (!d) return;
  if (!confirm(`حذف قسم "${d.name}" ؟\nسيتم إلغاء ربط المواد والمراقبين بهذا القسم.`)) return;
  try {
    await SB.del('departments', id);
    STATE.departments = STATE.departments.filter(x => x.id !== id);
    STATE.subjects.forEach(s => { if (s.dept_id === id) s.dept_id = null; });
    STATE.profiles.forEach(p => { if (p.dept_id === id) p.dept_id = null; });
    toast('تم حذف القسم ✓','success');
    await SB.logAction('حذف قسم','departments',d.name,'warning');
    renderDepartments();
  } catch(e) { toast(e.message,'error'); }
}

// ── Dept Subjects Modal ───────────────────────────────────────
function openDeptSubjects(deptId) {
  const d = STATE.departments.find(x => x.id === deptId);
  if (!d) return;
  const allSubjects   = STATE.subjects;
  const deptSubjects  = allSubjects.filter(s => s.dept_id === deptId);
  const otherSubjects = allSubjects.filter(s => s.dept_id !== deptId);

  const mo = _getMo('deptSubjMo');
  mo.innerHTML = `<div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2><i class="fas fa-book" style="color:var(--gold)"></i> مواد قسم "${d.name}"</h2>
      <button class="md-close" onclick="closeMo('deptSubjMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="max-height:60vh;overflow-y:auto">
      <div style="font-size:12px;font-weight:700;color:var(--txt3);margin-bottom:8px">المواد المرتبطة بالقسم (${deptSubjects.length})</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;min-height:40px;padding:8px;background:var(--bg);border-radius:10px">
        ${deptSubjects.map(s=>`
          <span style="display:flex;align-items:center;gap:6px;background:var(--gold-bg);color:var(--gold);border-radius:8px;padding:4px 10px;font-size:12px;font-weight:700">
            ${s.code} · ${s.name}
            ${canEdit()?`<i class="fas fa-times" style="cursor:pointer;opacity:.6" onclick="toggleSubjectDept(${s.id},null,${deptId})"></i>`:''}
          </span>`).join('')}
        ${!deptSubjects.length?'<span style="font-size:12px;color:var(--txt3)">لا توجد مواد مرتبطة</span>':''}
      </div>
      <div style="font-size:12px;font-weight:700;color:var(--txt3);margin-bottom:8px">المواد الأخرى (اضغط لإضافة)</div>
      <div style="display:flex;flex-direction:column;gap:4px">
        ${otherSubjects.map(s=>`
          <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:8px;border:1px solid var(--border);cursor:pointer;transition:all .15s" 
               onmouseover="this.style.background='var(--primary-bg)'" onmouseout="this.style.background=''"
               onclick="toggleSubjectDept(${s.id},${deptId})">
            <i class="fas fa-book" style="color:var(--gold);font-size:13px;width:16px"></i>
            <div style="flex:1">
              <div style="font-size:12.5px;font-weight:700">${s.name}</div>
              <div style="font-size:11px;color:var(--txt3)">${s.code}${s.dept_id?` · ${STATE.departments.find(dd=>dd.id===s.dept_id)?.name||''}`:' · بدون قسم'}</div>
            </div>
            <i class="fas fa-plus-circle" style="color:var(--primary);font-size:14px"></i>
          </div>`).join('')}
        ${!otherSubjects.length?'<div style="text-align:center;color:var(--txt3);padding:16px;font-size:13px">كل المواد مرتبطة بهذا القسم</div>':''}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('deptSubjMo')">إغلاق</button>
    </div>
  </div>`;
  showMo('deptSubjMo');
}

async function toggleSubjectDept(subjId, newDeptId, refreshDeptId) {
  try {
    await SB.update('subjects', subjId, { dept_id: newDeptId || null });
    const idx = STATE.subjects.findIndex(s => s.id === subjId);
    if (idx >= 0) STATE.subjects[idx].dept_id = newDeptId || null;
    toast(newDeptId ? 'تم ربط المادة بالقسم ✓' : 'تم إلغاء ربط المادة','success');
    openDeptSubjects(newDeptId || refreshDeptId);
  } catch(e) { toast(e.message,'error'); }
}

// ── Dept Proctors Modal (إعادة تصميم احترافي) ────────────────
function openDeptProctors(deptId) {
  const d = STATE.departments.find(x => x.id === deptId);
  if (!d) return;
  const inDept    = STATE.profiles.filter(p => p.dept_id === deptId && p.role === 'proctor');
  const notInDept = STATE.profiles.filter(p => p.role === 'proctor' && (p.dept_id !== deptId));
  // تجميع غير المنتسبين: بدون قسم أو في قسم آخر
  const available  = notInDept.filter(p => !p.dept_id);
  const otherDept  = notInDept.filter(p => !!p.dept_id);

  const semCount = id => STATE.exams.filter(e => e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(id)).length;

  const mo = _getMo('deptProcMo');
  mo.innerHTML = `<div class="md" style="max-width:620px">
    <div class="md-hd" style="border-bottom:2px solid ${d.color||'var(--primary)'}30">
      <h2 style="display:flex;align-items:center;gap:10px">
        <div style="width:36px;height:36px;border-radius:10px;background:${d.color||'var(--primary)'}20;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-user-tie" style="color:${d.color||'var(--purple)'}"></i>
        </div>
        <div>
          <div style="font-size:15px">مراقبو ${d.name}</div>
          <div style="font-size:11px;color:var(--txt3);font-weight:400">${inDept.length} مراقب منتسب</div>
        </div>
      </h2>
      <button class="md-close" onclick="closeMo('deptProcMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:0">
      <!-- تبويبات -->
      <div style="display:flex;border-bottom:1px solid var(--border);background:var(--bg)">
        <button id="dpTab1" onclick="_dpSwitchTab(1)"
          style="flex:1;padding:12px;font-size:12.5px;font-weight:700;border:none;border-bottom:2px solid ${d.color||'var(--primary)'};background:transparent;cursor:pointer;color:${d.color||'var(--primary)'}">
          <i class="fas fa-users" style="margin-left:5px"></i>المنتسبون (${inDept.length})
        </button>
        <button id="dpTab2" onclick="_dpSwitchTab(2)"
          style="flex:1;padding:12px;font-size:12.5px;font-weight:700;border:none;border-bottom:2px solid transparent;background:transparent;cursor:pointer;color:var(--txt2)">
          <i class="fas fa-user-plus" style="margin-left:5px"></i>إضافة مراقب (${available.length})
        </button>
        <button id="dpTab3" onclick="_dpSwitchTab(3)"
          style="flex:1;padding:12px;font-size:12.5px;font-weight:700;border:none;border-bottom:2px solid transparent;background:transparent;cursor:pointer;color:var(--txt2)">
          <i class="fas fa-exchange-alt" style="margin-left:5px"></i>نقل من قسم (${otherDept.length})
        </button>
      </div>

      <!-- محتوى التبويب 1: المنتسبون -->
      <div id="dpPanel1" style="max-height:55vh;overflow-y:auto;padding:12px 16px">
        ${inDept.length ? inDept.map(p => {
          const sc = semCount(p.id);
          return `<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;border:1px solid var(--border);margin-bottom:8px;background:var(--card)">
            ${userAvatar(p,40)}
            <div style="flex:1;min-width:0">
              <div style="font-size:13px;font-weight:700;margin-bottom:2px">${p.name}</div>
              <div style="font-size:11px;color:var(--txt3)">${p.emp_id||p.email||'—'}</div>
              <div style="margin-top:5px">
                <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9.5px">${sc}/3 مراقبات هذا الفصل</span>
              </div>
            </div>
            ${canEdit() ? `<button class="btn bd btn-xs" style="gap:4px" onclick="toggleProctorDept('${p.id}',null,${deptId})">
              <i class="fas fa-user-minus"></i> إزالة
            </button>` : ''}
          </div>`;
        }).join('') : `<div style="text-align:center;padding:40px;color:var(--txt3)">
          <i class="fas fa-user-slash" style="font-size:36px;margin-bottom:12px;opacity:.3"></i>
          <div style="font-size:13px">لا يوجد مراقبون منتسبون لهذا القسم</div>
          <div style="font-size:11px;margin-top:6px;opacity:.6">انتقل لتبويب "إضافة مراقب" لإضافة مراقبين</div>
        </div>`}
      </div>

      <!-- محتوى التبويب 2: إضافة (بدون قسم) -->
      <div id="dpPanel2" style="display:none;max-height:55vh;overflow-y:auto;padding:12px 16px">
        ${available.length ? `
        <div style="padding:8px 12px;background:var(--primary-bg);border-radius:8px;margin-bottom:12px;font-size:11.5px;color:var(--primary2)">
          <i class="fas fa-info-circle" style="margin-left:5px"></i>هؤلاء المراقبون ليسوا منتسبين لأي قسم — انقر لإضافتهم
        </div>
        ${available.map(p => {
          const sc = semCount(p.id);
          return `<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;border:1.5px dashed var(--border);margin-bottom:8px;cursor:pointer;transition:all .2s;background:var(--card)"
            onmouseover="this.style.borderColor='${d.color||'var(--primary)'}';this.style.background='${d.color||'var(--primary)'}10'"
            onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--card)'"
            onclick="toggleProctorDept('${p.id}',${deptId})">
            ${userAvatar(p,40)}
            <div style="flex:1;min-width:0">
              <div style="font-size:13px;font-weight:700">${p.name}</div>
              <div style="font-size:11px;color:var(--txt3)">${p.emp_id||p.email||'—'}</div>
              <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9.5px;margin-top:4px;display:inline-block">${sc}/3 مراقبات</span>
            </div>
            <div style="width:32px;height:32px;border-radius:8px;background:${d.color||'var(--primary)'}20;display:flex;align-items:center;justify-content:center">
              <i class="fas fa-plus" style="color:${d.color||'var(--primary)'}"></i>
            </div>
          </div>`;
        }).join('')}` : `<div style="text-align:center;padding:40px;color:var(--txt3)">
          <i class="fas fa-check-circle" style="font-size:36px;margin-bottom:12px;opacity:.3;color:var(--green)"></i>
          <div>كل المراقبين منتسبون لأقسام</div>
        </div>`}
      </div>

      <!-- محتوى التبويب 3: نقل من قسم آخر -->
      <div id="dpPanel3" style="display:none;max-height:55vh;overflow-y:auto;padding:12px 16px">
        ${otherDept.length ? `
        <div style="padding:8px 12px;background:#fef3c7;border-radius:8px;margin-bottom:12px;font-size:11.5px;color:#92400e">
          <i class="fas fa-exclamation-triangle" style="margin-left:5px"></i>نقل المراقب سيزيله من قسمه الحالي
        </div>
        ${otherDept.map(p => {
          const curDept = STATE.departments.find(dd => dd.id === p.dept_id);
          const sc = semCount(p.id);
          return `<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;border:1px solid var(--border);margin-bottom:8px;cursor:pointer;transition:all .2s;background:var(--card)"
            onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background='var(--card)'"
            onclick="if(confirm('نقل ${p.name} من ${curDept?.name||'قسمه'} إلى ${d.name}?'))toggleProctorDept('${p.id}',${deptId})">
            ${userAvatar(p,40)}
            <div style="flex:1;min-width:0">
              <div style="font-size:13px;font-weight:700">${p.name}</div>
              <div style="font-size:11px;color:var(--txt3)">${p.emp_id||p.email||'—'}</div>
              <div style="margin-top:4px;display:flex;align-items:center;gap:6px">
                <span style="font-size:10px;padding:2px 8px;background:${curDept?.color||'var(--txt3)'}20;color:${curDept?.color||'var(--txt3)'};border-radius:20px">${curDept?.name||'—'}</span>
                <i class="fas fa-arrow-left" style="font-size:10px;color:var(--txt3)"></i>
                <span style="font-size:10px;padding:2px 8px;background:${d.color||'var(--primary)'}20;color:${d.color||'var(--primary)'};border-radius:20px">${d.name}</span>
              </div>
            </div>
            <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9.5px">${sc}/3</span>
          </div>`;
        }).join('')}` : `<div style="text-align:center;padding:40px;color:var(--txt3)">
          <div>لا يوجد مراقبون في أقسام أخرى</div>
        </div>`}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('deptProcMo')"><i class="fas fa-times"></i> إغلاق</button>
    </div>
  </div>`;
  showMo('deptProcMo');
}

function _dpSwitchTab(n) {
  const tabColors = ['var(--purple)','var(--primary2)','var(--gold)'];
  [1,2,3].forEach(i => {
    const btn = document.getElementById('dpTab'+i);
    const panel = document.getElementById('dpPanel'+i);
    if (!btn || !panel) return;
    const active = i === n;
    panel.style.display = active ? 'block' : 'none';
    btn.style.borderBottomColor = active ? tabColors[i-1] : 'transparent';
    btn.style.color = active ? tabColors[i-1] : 'var(--txt2)';
    btn.style.fontWeight = active ? '800' : '600';
  });
}

async function toggleProctorDept(profileId, newDeptId, refreshDeptId) {
  try {
    await SB.update('profiles', profileId, { dept_id: newDeptId || null }, 'id');
    const idx = STATE.profiles.findIndex(p => p.id === profileId);
    if (idx >= 0) STATE.profiles[idx].dept_id = newDeptId || null;
    toast(newDeptId ? 'تم إضافة المراقب للقسم ✓' : 'تم إزالة المراقب من القسم','success');
    openDeptProctors(newDeptId || refreshDeptId);
  } catch(e) { toast(e.message,'error'); }
}

// ── Set Dept Head ─────────────────────────────────────────────
function openSetDeptHead(deptId) {
  const d = STATE.departments.find(x => x.id === deptId);
  if (!d) return;
  // السماح للمسؤول وأي دور بأن يكون رئيس القسم
  const deptHeads = STATE.profiles.filter(p => p.role === 'dept_head' || p.role === 'admin' || p.role === 'coordinator');
  const mo = _getMo('deptHeadMo');
  mo.innerHTML = `<div class="md" style="max-width:440px">
    <div class="md-hd">
      <h2><i class="fas fa-chalkboard-teacher" style="color:var(--purple)"></i> رئيس قسم "${d.name}"</h2>
      <button class="md-close" onclick="closeMo('deptHeadMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">اختر رئيس القسم</label>
        <select id="deptHeadSel">
          <option value="">— بدون رئيس قسم —</option>
          ${deptHeads.map(p=>`<option value="${p.id}" ${p.id===d.head_id?'selected':''}>${p.name} · ${p.emp_id||p.email}</option>`).join('')}
        </select>
      </div>
      ${!deptHeads.length?`<div style="font-size:12px;color:var(--gold);background:var(--gold-bg);border-radius:8px;padding:10px 12px">
        <i class="fas fa-info-circle"></i> لا يوجد مستخدمون. أضف مستخدمين أولاً.
      </div>`:''}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('deptHeadMo')">إلغاء</button>
      <button class="btn bp" onclick="saveDeptHead(${deptId})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('deptHeadMo');
}

async function saveDeptHead(deptId) {
  const headId = document.getElementById('deptHeadSel')?.value || null;
  try {
    await SB.update('departments', deptId, { head_id: headId || null });
    const idx = STATE.departments.findIndex(d => d.id === deptId);
    if (idx >= 0) STATE.departments[idx].head_id = headId || null;
    // Update the dept_head's dept_id as well
    if (headId) {
      await SB.update('profiles', headId, { dept_id: deptId }, 'id');
      const pidx = STATE.profiles.findIndex(p => p.id === headId);
      if (pidx >= 0) STATE.profiles[pidx].dept_id = deptId;
    }
    toast('تم تعيين رئيس القسم ✓','success');
    closeMo('deptHeadMo');
    renderDepartments();
  } catch(e) { toast(e.message,'error'); }
}

// ── Set Dept Coordinator ────────────────────────────────────────
function openSetDeptCoord(deptId) {
  const d = STATE.departments.find(x => x.id === deptId);
  if (!d) return;
  const coordinators = STATE.profiles.filter(p => p.role === 'coordinator' || p.role === 'admin');
  const mo = _getMo('deptCoordMo');
  mo.innerHTML = `<div class="md" style="max-width:440px">
    <div class="md-hd">
      <h2><i class="fas fa-user-tie" style="color:var(--teal)"></i> منسق قسم "${d.name}"</h2>
      <button class="md-close" onclick="closeMo('deptCoordMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">اختر منسق القسم</label>
        <select id="deptCoordSel">
          <option value="">— بدون منسق —</option>
          ${coordinators.map(p=>`<option value="${p.id}" ${p.id===d.coordinator_id?'selected':''}>${p.name} · ${p.emp_id||p.email}</option>`).join('')}
        </select>
      </div>
      ${!coordinators.length?`<div style="font-size:12px;color:var(--gold);background:var(--gold-bg);border-radius:8px;padding:10px 12px">
        <i class="fas fa-info-circle"></i> لا يوجد منسقون. أضف مستخدمين بدور "منسق الكلية" أولاً.
      </div>`:''}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('deptCoordMo')">إلغاء</button>
      <button class="btn bp" onclick="saveDeptCoord(${deptId})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('deptCoordMo');
}

async function saveDeptCoord(deptId) {
  const coordId = document.getElementById('deptCoordSel')?.value || null;
  try {
    await SB.update('departments', deptId, { coordinator_id: coordId || null });
    const idx = STATE.departments.findIndex(d => d.id === deptId);
    if (idx >= 0) STATE.departments[idx].coordinator_id = coordId || null;
    toast('تم تعيين منسق القسم ✓', 'success');
    closeMo('deptCoordMo');
    renderDepartments();
  } catch(e) { toast(e.message, 'error'); }
}

// ── Export Departments CSV ─────────────────────────────────────
function exportDepartmentsCSV() {
  const rows = [['الكود','اسم القسم','الاسم بالإنجليزية','رئيس القسم','منسق القسم','عدد المواد','عدد المراقبين','الوصف']];
  STATE.departments.forEach(d => {
    const head  = getProfile(d.head_id);
    const coord = getProfile(d.coordinator_id);
    const subjs = STATE.subjects.filter(s => s.dept_id === d.id).length;
    const procs = STATE.profiles.filter(p => p.dept_id === d.id && p.role === 'proctor').length;
    rows.push([d.code, d.name, d.name_en||'', head?.name||'—', coord?.name||'—', subjs, procs, d.description||'']);
  });
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8'});
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), {href:url, download:'departments.csv'});
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  toast('✓ تم تصدير بيانات الأقسام', 'success');
}

// ── Export Single Dept PDF (print view) ───────────────────────
function exportOneDeptPDF(deptId) {
  const d = STATE.departments.find(x => x.id === deptId);
  if (!d) return;
  const head  = getProfile(d.head_id);
  const coord = getProfile(d.coordinator_id);
  const subjs = STATE.subjects.filter(s => s.dept_id === d.id);
  const procs = STATE.profiles.filter(p => p.dept_id === d.id && p.role === 'proctor');

  const w = window.open('', '_blank', 'width=800,height=600');
  w.document.write(`<!DOCTYPE html><html dir="rtl"><head>
    <meta charset="utf-8"><title>بيانات قسم ${d.name}</title>
    <style>body{font-family:Arial,sans-serif;padding:32px;color:#111}
    h1{color:${d.color||'#2563eb'}}table{border-collapse:collapse;width:100%}
    td,th{padding:8px 12px;border:1px solid #ddd;font-size:13px}
    th{background:#f8f9fa;font-weight:700}.badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:${d.color||'#2563eb'}20;color:${d.color||'#2563eb'}}
    </style></head><body>
    <h1><i>🏛</i> ${d.name}</h1>
    <p style="color:#666">${d.name_en||''} · كود: <b>${d.code}</b></p>
    ${d.description?`<p>${d.description}</p>`:''}
    <table style="margin-bottom:20px">
      <tr><th>رئيس القسم</th><td>${head?.name||'—'}</td></tr>
      <tr><th>منسق القسم</th><td>${coord?.name||'—'}</td></tr>
      <tr><th>عدد المواد</th><td>${subjs.length}</td></tr>
      <tr><th>عدد المراقبين</th><td>${procs.length}</td></tr>
    </table>
    <h3>المواد الدراسية (${subjs.length})</h3>
    <table><tr><th>الكود</th><th>الاسم</th><th>الساعات</th></tr>
    ${subjs.map(s=>`<tr><td>${s.code}</td><td>${s.name}</td><td>${s.hours||3}</td></tr>`).join('')}
    </table>
    <h3 style="margin-top:20px">المراقبون (${procs.length})</h3>
    <table><tr><th>الاسم</th><th>البريد</th><th>الرقم الوظيفي</th></tr>
    ${procs.map(p=>`<tr><td>${p.name}</td><td>${p.email||'—'}</td><td>${p.emp_id||'—'}</td></tr>`).join('')}
    </table>
    <script>window.onload=()=>{window.print()}<\/script>
  </body></html>`);
  w.document.close();
}

function exportDepartmentsPDF() {
  const w = window.open('', '_blank', 'width=900,height=700');
  const uniName = STATE.settings?.university_name || 'ExamFlow';
  w.document.write(`<!DOCTYPE html><html dir="rtl"><head>
    <meta charset="utf-8"><title>تقرير الأقسام الأكاديمية</title>
    <style>body{font-family:Arial,sans-serif;padding:32px;color:#111}
    h1{color:#2563eb;text-align:center}table{border-collapse:collapse;width:100%}
    td,th{padding:8px 12px;border:1px solid #ddd;font-size:12px}
    th{background:#f1f5f9;font-weight:700}tr:nth-child(even){background:#f8f9fa}
    .hdr{text-align:center;margin-bottom:24px}
    </style></head><body>
    <div class="hdr"><h1>🏛 الأقسام الأكاديمية</h1><p>${uniName}</p></div>
    <table>
      <tr><th>#</th><th>الكود</th><th>اسم القسم</th><th>رئيس القسم</th><th>منسق القسم</th><th>المواد</th><th>المراقبون</th></tr>
      ${STATE.departments.map((d,i)=>{
        const head  = getProfile(d.head_id);
        const coord = getProfile(d.coordinator_id);
        const subjs = STATE.subjects.filter(s=>s.dept_id===d.id).length;
        const procs = STATE.profiles.filter(p=>p.dept_id===d.id&&p.role==='proctor').length;
        return `<tr><td>${i+1}</td><td><b>${d.code}</b></td><td>${d.name}</td><td>${head?.name||'—'}</td><td>${coord?.name||'—'}</td><td>${subjs}</td><td>${procs}</td></tr>`;
      }).join('')}
    </table>
    <script>window.onload=()=>{window.print()}<\/script>
  </body></html>`);
  w.document.close();
}
