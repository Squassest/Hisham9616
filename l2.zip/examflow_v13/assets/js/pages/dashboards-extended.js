// dashboards-extended.js — لوحة تحكم العميد ورئيس القسم

function renderDeanDashboard() {
  // العميد يرى نفس لوحة المسؤول (للقراءة فقط)
  renderDashboard && renderDashboard();
}

function renderDeptHeadDashboard() {
  // رئيس القسم يرى لوحة مبسطة مع بيانات قسمه
  const u    = STATE.currentUser;
  const myDeptSubjectIds = STATE.subjects.filter(s=>s.dept_id===u?.dept_id).map(s=>s.id);
  const semExams = STATE.exams.filter(e=>e.semester===STATE.currentSem&&myDeptSubjectIds.includes(e.subject_id));

  const titleEl = document.getElementById('dashTitleH');
  if (titleEl) titleEl.textContent = `لوحة قسم ${STATE.departments.find(d=>d.id===u?.dept_id)?.name||''}`;

  setHTML('dashWelcome', `مرحباً، ${u?.name?.split(' ').slice(0,2).join(' ')} 👋`);
  setHTML('dashStats', `
    <div class="stat-card">
      <div class="stat-ic ic-blue"><i class="fas fa-file-alt"></i></div>
      <div><div class="stat-val">${semExams.length}</div><div class="stat-lbl">امتحانات الفصل</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-green"><i class="fas fa-circle" style="font-size:10px"></i></div>
      <div><div class="stat-val">${semExams.filter(e=>examStatus(e)==='active').length}</div><div class="stat-lbl">جارية الآن</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-gold"><i class="fas fa-book"></i></div>
      <div><div class="stat-val">${myDeptSubjectIds.length}</div><div class="stat-lbl">مواد القسم</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-purple"><i class="fas fa-user-graduate"></i></div>
      <div><div class="stat-val">${STATE.students.length}</div><div class="stat-lbl">الطلاب</div></div>
    </div>`);
  setHTML('dashGrid', '');
  setHTML('dashWidgetGrid', '');
}
