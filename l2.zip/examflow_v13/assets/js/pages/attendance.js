// attendance.js — تسجيل حضور وغياب الطلاب

function openAttendance(examId) {
  const e = getExam(examId);
  if (!e) return;
  const sub  = getSubject(e.subject_id);
  const moId = 'attendanceMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  const uid = STATE.currentUser?.id;
  const rp  = e.room_proctors || {};
  const rs  = e.room_sections || {};

  let sectionsToShow = e.section_ids || [];
  let roomName = '';
  if (isProctor && isProctor() && uid) {
    const myRid = (e.room_ids||[]).find(rid => { const arr = rp[String(rid)]; return arr && arr.includes(uid); });
    if (myRid) { sectionsToShow = rs[String(myRid)] || sectionsToShow; roomName = getRoom(myRid)?.name || ''; }
  }

  const atts     = STATE.attendance[examId] || {};
  const labels   = { present:'حاضر', late:'متأخر', absent:'غائب', excused:'معذور' };
  const colors   = { present:'var(--green2)', late:'var(--gold)', absent:'var(--red2)', excused:'var(--primary2)' };

  function rows() {
    let html = '';
    sectionsToShow.forEach(secId => {
      const sec = getSection(secId); if (!sec) return;
      html += `<div style="font-weight:800;font-size:11.5px;color:var(--txt2);padding:10px 4px 4px">${esc(sec.name)}</div>`;
      (sec.student_ids||[]).forEach(sid => {
        const st = getStudent(sid); if (!st) return;
        const att = atts[sid] || 'absent';
        html += `<div style="display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px solid var(--border)">
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:13px">${esc(st.name||'—')}</div>
            <div style="font-size:11px;color:var(--txt3)">${esc(st.stud_id||'')}</div>
          </div>
          <select data-sid="${sid}" onchange="_setAttStatus(${examId},${sid},this.value)"
            style="border:1.5px solid ${colors[att]}40;border-radius:8px;padding:5px 10px;font-size:12px;font-weight:700;color:${colors[att]};background:${colors[att]}12;cursor:pointer">
            ${['present','late','absent','excused'].map(s=>`<option value="${s}"${att===s?' selected':''}>${labels[s]}</option>`).join('')}
          </select>
        </div>`;
      });
    });
    return html || `<div style="padding:30px;text-align:center;color:var(--txt3)">لا يوجد طلاب</div>`;
  }

  const totalCnt   = sectionsToShow.reduce((a,sid)=>a+(getSection(sid)?.student_ids||[]).length,0);
  const presentCnt = Object.values(atts).filter(v=>v==='present'||v==='late').length;

  mo.innerHTML = `<div class="md" style="max-width:500px;max-height:82vh;display:flex;flex-direction:column">
    <div class="md-hd" style="flex-shrink:0">
      <h2><i class="fas fa-clipboard-check" style="color:var(--primary)"></i> حضور: ${esc(sub?.name||'—')}</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div style="padding:8px 20px;background:var(--bg2);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <span style="font-size:12px;color:var(--txt2)">${fmtDate(e.date)} ${fmtTime(e.time)}${roomName?` · ${esc(roomName)}`:''}</span>
      <span class="badge b-green" style="font-size:11px">${presentCnt}/${totalCnt} حاضر</span>
      <div style="margin-right:auto;display:flex;gap:5px">
        <button class="btn bp btn-xs" onclick="_markAllAtt(${examId},'present',${JSON.stringify(sectionsToShow)})"><i class="fas fa-check-double"></i> حضور كل</button>
        <button class="btn bo btn-xs" onclick="_markAllAtt(${examId},'absent',${JSON.stringify(sectionsToShow)})"><i class="fas fa-times"></i> غياب كل</button>
      </div>
    </div>
    <div style="flex:1;overflow-y:auto;padding:6px 20px" id="attRowsWrap">${rows()}</div>
    <div class="md-ft" style="flex-shrink:0">
      <button class="btn bo" onclick="closeMo('${moId}')">إغلاق</button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _setAttStatus(examId, studentId, status) {
  if (!STATE.attendance[examId]) STATE.attendance[examId] = {};
  STATE.attendance[examId][studentId] = status;
  try {
    const db = SB.getClient();
    const { data: ex } = await db.from('attendance').select('id').eq('exam_id',examId).eq('student_id',studentId).maybeSingle();
    if (ex?.id) await db.from('attendance').update({status}).eq('id',ex.id);
    else        await db.from('attendance').insert({exam_id:examId,student_id:studentId,status});
  } catch(err) { console.warn('[att]',err); }
}

async function _markAllAtt(examId, status, sectionIds) {
  const allSids = [];
  (sectionIds||[]).forEach(sid => { const sec=getSection(sid); (sec?.student_ids||[]).forEach(id=>allSids.push(id)); });
  if (!allSids.length) return;
  if (!STATE.attendance[examId]) STATE.attendance[examId] = {};
  allSids.forEach(sid => { STATE.attendance[examId][sid] = status; });
  document.querySelectorAll('#attRowsWrap select[data-sid]').forEach(sel => { sel.value = status; });
  try {
    const rows = allSids.map(sid=>({exam_id:examId,student_id:sid,status}));
    await SB.getClient().from('attendance').upsert(rows,{onConflict:'exam_id,student_id'});
  } catch(err) { console.warn('[markAll]',err); }
  toast(`✓ تم تسجيل ${status==='present'?'حضور':'غياب'} ${allSids.length} طالب`,'success');
}
