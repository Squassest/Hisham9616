// dashboard.js — لوحات تحكم متعددة (Admin/Coord/Proctor/Student)

// ══ لوحة المسؤول/المنسق ══════════════════════════════════════
let _dashExamFilter = 'upcoming';
function setDE(f, el) {
  _dashExamFilter = f;
  document.querySelectorAll('#dashExamTabs .tab').forEach(t => t.classList.remove('active'));
  el?.classList.add('active');
  _renderDashExams();
}

function renderDashboard() {
  const u = STATE.currentUser;
  if (!u) { renderMyDashboard && renderMyDashboard(); return; }
  if (u.role === 'proctor') { renderMyDashboard && renderMyDashboard(); return; }
  if (u.role === 'dept_head') { renderDeptHeadDashboard && renderDeptHeadDashboard(); return; }

  const sem  = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const now  = sem.filter(e => examStatus(e) === 'active').length;
  const soon = sem.filter(e => examStatus(e) === 'upcoming').length;
  const done = sem.filter(e => examStatus(e) === 'completed').length;
  const pend = STATE.swapRequests.filter(r => r.status === 'pending').length;
  const activeSem = STATE.semesters.find(s => s.code === STATE.currentSem);

  const icon = isAdmin() ? '⚙️' : '📋';
  document.getElementById('dashTitleH').innerHTML =
    `${icon} لوحة ${isAdmin()?'المسؤول':'المنسق'}`;
  setHTML('dashWelcome', `مرحباً، ${u?.name?.split(' ').slice(0,2).join(' ')} 👋`);

  setHTML('dashActs', canEdit() ? `
    <button class="btn bp btn-sm" onclick="openAddExam()">
      <i class="fas fa-plus"></i> امتحان جديد
    </button>
    <button class="btn bo btn-sm" onclick="SB.manualSync()">
      <i class="fas fa-sync"></i>
    </button>` : '');

  // إحصاءات
  const attRate = _calcAttRate();
  setHTML('dashStats', `
    <div class="stat-card" onclick="UI.showPage('live')" style="cursor:pointer">
      <div class="stat-ic ic-green"><i class="fas fa-circle" style="font-size:11px"></i></div>
      <div><div class="stat-val">${now}</div><div class="stat-lbl">جارية الآن</div>
        ${now>0?`<div class="stat-trend up">● مباشر</div>`:''}</div>
    </div>
    <div class="stat-card" onclick="setDE('upcoming',document.querySelector('#dashExamTabs .tab:nth-child(2)'))" style="cursor:pointer">
      <div class="stat-ic ic-blue"><i class="fas fa-clock"></i></div>
      <div><div class="stat-val">${soon}</div><div class="stat-lbl">قادمة</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-gold"><i class="fas fa-file-alt"></i></div>
      <div><div class="stat-val">${sem.length}</div><div class="stat-lbl">امتحانات الفصل</div></div>
    </div>
    <div class="stat-card" onclick="UI.showPage('swaps')" style="cursor:pointer">
      <div class="stat-ic ic-${pend>0?'red':'teal'}"><i class="fas fa-exchange-alt"></i></div>
      <div><div class="stat-val">${pend}</div><div class="stat-lbl">طلبات معلقة</div>
        ${pend>0?`<div class="stat-trend down">⚠ تحتاج موافقة</div>`:''}</div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-purple"><i class="fas fa-user-tie"></i></div>
      <div><div class="stat-val">${STATE.profiles.filter(p=>p.role==='proctor'&&p.active).length}</div><div class="stat-lbl">مراقبون نشطون</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-teal"><i class="fas fa-user-check"></i></div>
      <div><div class="stat-val">${attRate}%</div><div class="stat-lbl">نسبة الحضور</div></div>
    </div>`);

  // تحميل ترتيب الويدجت المحفوظ
  const savedLayout = _dashLoadLayout();
  
  setHTML('dashGrid', `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
      <div style="font-size:11.5px;color:var(--txt3)"><i class="fas fa-grip-vertical" style="margin-left:5px"></i>اسحب الويدجت لإعادة الترتيب</div>
      <div style="flex:1"></div>
      <button class="btn bo btn-xs" onclick="_dashResetLayout()" title="إعادة الترتيب الافتراضي"><i class="fas fa-undo"></i> افتراضي</button>
    </div>
    <div id="dashWidgetGrid" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start"></div>
  `);

  _renderDashWidgets(savedLayout);
  _renderDashExams();
}

function _renderDashExams() {
  let exams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  if (_dashExamFilter !== 'all') exams = exams.filter(e => examStatus(e) === _dashExamFilter);
  exams.sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  const el = document.getElementById('dashExamList');
  if (!el) return;
  if (!exams.length) { el.innerHTML = emptyState('fa-calendar', 'لا توجد امتحانات'); return; }

  el.innerHTML = exams.slice(0, 12).map(e => {
    const sub    = getSubject(e.subject_id);
    const status = examStatus(e);
    const colors = { active: 'var(--green)', upcoming: 'var(--primary2)', completed: 'var(--txt3)' };
    return `<div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);cursor:pointer"
        onclick="UI.showPage('exams')">
      <div style="width:4px;height:36px;border-radius:2px;background:${colors[status]};flex-shrink:0"></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${sub?.name||'—'}</div>
        <div style="font-size:11px;color:var(--txt3)">${fmtDate(e.date)} ${fmtTime(e.time)}</div>
      </div>
      ${getStatusBadge(status)}
    </div>`;
  }).join('');
}

function _dashPressureWidget() {
  const exams = STATE.exams?.filter(e => e.semester === STATE.currentSem) || [];
  const weeks = {};
  exams.forEach(e => {
    const d = new Date(e.date);
    const wk = `W${Math.ceil(((d - new Date(d.getFullYear(),0,1))/86400000+1)/7)}`;
    weeks[wk] = (weeks[wk]||0)+1;
  });
  const maxW = Math.max(...Object.values(weeks), 0);
  if (maxW < 3) return ''; // لا تُظهر إذا كان الجدول مريحاً
  const isDanger  = maxW >= 8;
  const isWarning = maxW >= 5;
  const col   = isDanger?'var(--red)':isWarning?'var(--gold)':'var(--green)';
  const bg    = isDanger?'var(--red-bg)':isWarning?'var(--gold-bg)':'var(--green-bg)';
  const icon  = isDanger?'fa-exclamation-circle':'fa-exclamation-triangle';
  const msg   = isDanger
    ? `تحذير: أسبوع بـ ${maxW} امتحانات — ضغط شديد!`
    : `تنبيه: أسبوع بـ ${maxW} امتحانات متراكمة`;
  return `
    <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:${bg};border-radius:12px;border:1.5px solid ${col}30;margin-bottom:14px;cursor:pointer" onclick="UI.showPage('class-compare')">
      <i class="fas ${icon}" style="color:${col};font-size:20px;flex-shrink:0"></i>
      <div style="flex:1">
        <div style="font-weight:800;font-size:13px;color:${col}">${msg}</div>
        <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">انقر لعرض مؤشر ضغط الجدول</div>
      </div>
      <i class="fas fa-arrow-left" style="color:${col};opacity:.5"></i>
    </div>`;
}

function _v10ShortcutsCard() {
  return `
    <div class="card" style="margin-bottom:14px">
      <div class="card-h"><h3><i class="fas fa-star" style="color:var(--gold)"></i> ميزات v10</h3></div>
      <div class="card-b" style="display:flex;flex-direction:column;gap:8px;padding:12px 16px">
        <button class="btn bo btn-sm" style="justify-content:flex-start;gap:10px;width:100%" onclick="UI.showPage('digital-seal')">
          <i class="fas fa-stamp" style="color:var(--purple2);width:16px"></i>
          <span>بروتوكول التسليم الرقمي</span>
        </button>
        <button class="btn bo btn-sm" style="justify-content:flex-start;gap:10px;width:100%" onclick="UI.showPage('class-compare')">
          <i class="fas fa-balance-scale" style="color:var(--teal);width:16px"></i>
          <span>مقارنة الفصول + ضغط الجدول</span>
        </button>
        <button class="btn bo btn-sm" style="justify-content:flex-start;gap:10px;width:100%" onclick="UI.showPage('ai-engine')">
          <i class="fas fa-robot" style="color:var(--primary);width:16px"></i>
          <span>مساعد الذكاء الاصطناعي</span>
        </button>
        <button class="btn bo btn-sm" style="justify-content:flex-start;gap:10px;width:100%" onclick="exportSemesterReportPDF()">
          <i class="fas fa-file-pdf" style="color:var(--red2);width:16px"></i>
          <span>تقرير الفصل PDF</span>
        </button>
        <button class="btn bo btn-sm" style="justify-content:flex-start;gap:10px;width:100%" onclick="openAIScheduleGen()">
          <i class="fas fa-magic" style="color:var(--purple2);width:16px"></i>
          <span>توليد الجدول بالذكاء الاصطناعي</span>
        </button>
      </div>
    </div>`;
}

function _quickActionsCard() {
  if (!canEdit()) return '';
  return `<div class="card">
    <div class="card-h"><h3><i class="fas fa-bolt" style="color:var(--gold)"></i> إجراءات سريعة</h3></div>
    <div class="card-b" style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <button class="btn bo" style="height:56px;flex-direction:column;gap:4px" onclick="openAddExam()">
        <i class="fas fa-file-plus" style="font-size:18px;color:var(--primary2)"></i>
        <span style="font-size:11px">امتحان جديد</span>
      </button>
      <button class="btn bo" style="height:56px;flex-direction:column;gap:4px" onclick="UI.showPage('students');openAddStudent()">
        <i class="fas fa-user-graduate" style="font-size:18px;color:var(--teal)"></i>
        <span style="font-size:11px">إضافة طالب</span>
      </button>
      ${isAdmin()?`
      <button class="btn bo" style="height:56px;flex-direction:column;gap:4px" onclick="UI.showPage('users');openAddUser()">
        <i class="fas fa-user-plus" style="font-size:18px;color:var(--purple2)"></i>
        <span style="font-size:11px">مستخدم جديد</span>
      </button>
      <button class="btn bo" style="height:56px;flex-direction:column;gap:4px" onclick="UI.showPage('analytics')">
        <i class="fas fa-chart-bar" style="font-size:18px;color:var(--gold)"></i>
        <span style="font-size:11px">التحليلات</span>
      </button>`:''}
    </div>
  </div>`;
}

function _semInfoCard(sem) {
  return `<div class="card" style="margin-bottom:14px">
    <div class="card-h"><h3><i class="fas fa-calendar-check" style="color:var(--green)"></i> الفصل الحالي</h3></div>
    <div class="card-b">
      <div style="font-size:15px;font-weight:800;margin-bottom:8px">${sem?.label||STATE.currentSem}</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        ${sem?.is_active?`<span class="badge b-green">نشط</span>`:`<span class="badge b-gray">غير نشط</span>`}
        ${sem?.is_closed?`<span class="badge b-red">مقفل</span>`:''}
      </div>
      ${isAdmin()?`<div style="margin-top:12px;display:flex;gap:6px">
        <button class="btn bo btn-sm" onclick="UI.showPage('settings')"><i class="fas fa-cog"></i> إدارة الفصول</button>
      </div>`:''}
    </div>
  </div>`;
}

function _topProctorsCard() {
  const top = [...STATE.profiles]
    .filter(p => p.role === 'proctor' && p.active)
    .sort((a, b) => (b.points||0) - (a.points||0))
    .slice(0, 5);

  return `<div class="card" style="margin-bottom:14px">
    <div class="card-h">
      <h3><i class="fas fa-trophy" style="color:var(--gold2)"></i> أعلى المراقبين</h3>
      <button class="btn bo btn-xs" onclick="UI.showPage('proctors')">الكل</button>
    </div>
    <div class="card-b" style="padding:12px 16px">
      ${top.map((p,i) => `<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border)">
        <span style="font-size:14px;${i<3?'color:var(--gold2);':''}">${['🥇','🥈','🥉'][i]||`${i+1}.`}</span>
        ${userAvatar(p, 30)}
        <span style="flex:1;font-size:12.5px;font-weight:600">${p.name?.split(' ').slice(0,2).join(' ')}</span>
        <span class="badge b-gold">${p.points||0} نقطة</span>
      </div>`).join('') || emptyState('fa-trophy','لا بيانات')}
    </div>
  </div>`;
}

function _recentLogCard() {
  const logs = (STATE.auditLog || []).slice(0, 6);
  return `<div class="card">
    <div class="card-h">
      <h3><i class="fas fa-history" style="color:var(--txt3)"></i> آخر النشاطات</h3>
      <button class="btn bo btn-xs" onclick="UI.showPage('log')">الكل</button>
    </div>
    <div class="card-b" style="padding:8px 16px">
      ${logs.map(l => `<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--border)">
        <i class="fas fa-dot-circle" style="color:var(--primary2);font-size:8px;flex-shrink:0"></i>
        <div style="flex:1;min-width:0">
          <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${l.action}</div>
          <div style="font-size:10px;color:var(--txt3)">${l.user_name||'—'} · ${fmtDateTime(l.created_at)}</div>
        </div>
      </div>`).join('') || '<div style="padding:12px 0;text-align:center;color:var(--txt3);font-size:12px">لا توجد نشاطات</div>'}
    </div>
  </div>`;
}

function _calcAttRate() {
  let total = 0, present = 0;
  Object.values(STATE.attendance).forEach(examAtt => {
    Object.values(examAtt).forEach(s => { total++; if (s === 'present') present++; });
  });
  return total > 0 ? Math.round((present / total) * 100) : 0;
}

// ══ لوحة المراقب ═══════════════════════════════════════════
function renderMyDashboard() {
  const u   = STATE.currentUser;
  const uid = u?.id;
  const sem = STATE.exams.filter(e => e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(uid));
  const coming  = sem.filter(e => examStatus(e) === 'upcoming').length;
  const active  = sem.filter(e => examStatus(e) === 'active').length;
  const done    = sem.filter(e => examStatus(e) === 'completed').length;
  // طلبات المراقبة المعلقة (حيث أنا هدف التعيين وتنتظر قبولي)
  const pendingAssign = STATE.exams.filter(e =>
    (e.proctor_ids||[]).includes(uid) &&
    (e.proctor_statuses||{})[uid] === 'pending' &&
    e.semester === STATE.currentSem
  );
  const pendingSwaps = STATE.swapRequests.filter(r =>
    r.target_id === uid && r.status === 'pending'
  );
  const totalPending = pendingAssign.length + pendingSwaps.length;

  // المواد المرتبطة بحساب المراقب مباشرةً (staff_ids) — ليس من الامتحانات
  const mySubjs = STATE.subjects.filter(s => (s.staff_ids||[]).includes(uid));
  // ✅ فقط الشعب التي يكون المراقب في staff_ids الخاص بها — لا نعرض شُعَب لا تخصه
  // (يضمن أن أي طالب يُحسب هنا ينتمي حقاً للمراقب)
  const mySections = STATE.sections.filter(s =>
    s.semester === STATE.currentSem && (s.staff_ids||[]).includes(uid)
  );

  setHTML('myWelcome', `مرحباً، ${u?.name?.split(' ').slice(0,2).join(' ')} 👋`);

  setHTML('myStats', `
    <div class="stat-card" onclick="UI.showPage('exams')" style="cursor:pointer">
      <div class="stat-ic ic-blue"><i class="fas fa-clock"></i></div>
      <div><div class="stat-val">${coming}</div><div class="stat-lbl">امتحانات قادمة</div></div>
    </div>
    <div class="stat-card" style="cursor:${active?'pointer':'default'}" ${active?'onclick="UI.showPage(\'live\')"':''}>
      <div class="stat-ic ic-green"><i class="fas fa-tv" style="font-size:14px"></i></div>
      <div><div class="stat-val">${active}</div><div class="stat-lbl">شاشة المراقبة</div>
        ${active>0?`<div class="stat-trend up">● مباشر</div>`:''}</div>
    </div>
    <div class="stat-card" onclick="UI.showPage('swaps')" style="cursor:pointer;position:relative">
      <div class="stat-ic ${totalPending?'ic-red':'ic-purple'}">
        <i class="fas fa-clipboard-list"></i>
        ${totalPending?`<span style="position:absolute;top:6px;right:6px;width:18px;height:18px;background:var(--red2);color:white;border-radius:50%;font-size:10px;font-weight:800;display:flex;align-items:center;justify-content:center">${totalPending}</span>`:''}
      </div>
      <div><div class="stat-val">${totalPending}</div><div class="stat-lbl">طلبات المراقبة</div>
        ${totalPending?`<div class="stat-trend" style="color:var(--red2)">● تحتاج رداً</div>`:''}
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-gold"><i class="fas fa-star"></i></div>
      <div><div class="stat-val">${u?.points||0}</div><div class="stat-lbl">نقاطي</div></div>
    </div>`);

  const upcoming = sem.filter(e => examStatus(e) !== 'completed').slice(0, 8);

  // طلبات تعيين المراقبة المعلقة
  const pendingAssignHTML = pendingAssign.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--red2)">
      <div class="card-h">
        <h3><i class="fas fa-bell" style="color:var(--red2)"></i> طلبات المراقبة المعلقة
          <span class="badge b-red" style="font-size:10px">${pendingAssign.length}</span>
        </h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${pendingAssign.map(e => {
          const sub = getSubject(e.subject_id);
          const rooms = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
          // القاعة المخصصة للمراقب
          const myRoom = (e.room_ids||[]).find(rid => {
            const rp = (e.room_proctors||{})[String(rid)];
            return rp && rp.includes(uid);
          });
          const myRoomName = myRoom ? getRoom(myRoom)?.name : rooms.join('، ');
          return `<div style="padding:14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--red2)30;margin-bottom:10px">
            <div style="font-weight:800;font-size:14px;margin-bottom:6px">${sub?.name||'—'}</div>
            <div style="font-size:12px;color:var(--txt2);margin-bottom:8px;display:flex;gap:12px;flex-wrap:wrap">
              <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)}</span>
              <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}د)</span>
              ${myRoomName?`<span><i class="fas fa-door-open" style="color:var(--teal)"></i> ${myRoomName}</span>`:''}
            </div>
            <div style="display:flex;gap:8px">
              <button class="btn btn-sm" style="flex:1;background:var(--green2);color:white;border:none" onclick="_respondToProctorAssign(${e.id},'accepted')">
                <i class="fas fa-check"></i> قبول
              </button>
              <button class="btn btn-sm" style="flex:1;background:var(--red2)15;color:var(--red2);border:1px solid var(--red2)50" onclick="_respondToProctorAssign(${e.id},'rejected')">
                <i class="fas fa-times"></i> رفض أو طلب بديل
              </button>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>` : '';

  setHTML('myGrid', `
    <div style="display:grid;grid-template-columns:1fr 340px;gap:16px;align-items:start" class="my-dash-gl">
      <div>
        ${pendingAssignHTML}
        <div class="card" style="margin-bottom:14px">
          <div class="card-h">
            <h3><i class="fas fa-calendar" style="color:var(--purple2)"></i> امتحاناتي القادمة</h3>
            <button class="btn bo btn-xs" onclick="UI.showPage('exams')">الكل →</button>
          </div>
          <div class="card-b" style="padding:0">
            ${upcoming.length ? upcoming.map(e => {
              const sub = getSubject(e.subject_id);
              const st  = examStatus(e);
              const rp  = e.room_proctors || {};
              // القاعة المخصصة لي
              const myRid = (e.room_ids||[]).find(rid => {
                const assigned = rp[String(rid)];
                return assigned && assigned.includes(uid);
              }) || (e.room_ids||[])[0];
              const myRoomName = myRid ? getRoom(myRid)?.name : '';
              // الشعب في قاعتي
              const mySecIds = myRid ? ((e.room_sections||{})[String(myRid)] || e.section_ids || []) : (e.section_ids||[]);
              const myStudCount = mySecIds.reduce((acc,sid) => {
                const sec = getSection(sid);
                return acc + (sec?.student_ids||[]).length;
              }, 0);
              const typeColors = {final:'#2563eb',midterm:'#d97706',quiz:'#0891b2',makeup:'#7c3aed'};
              return `<div style="display:flex;align-items:start;gap:12px;padding:14px 16px;border-bottom:1px solid var(--border);transition:all .15s" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
                <div style="width:44px;height:44px;border-radius:12px;background:${typeColors[e.type]||'var(--primary2)'}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                  <i class="fas fa-file-alt" style="color:${typeColors[e.type]||'var(--primary2)'};font-size:18px"></i>
                </div>
                <div style="flex:1;min-width:0">
                  <div style="font-weight:800;font-size:14px;margin-bottom:4px">${sub?.name||'—'}</div>
                  <div style="font-size:12px;color:var(--txt2);display:flex;gap:10px;flex-wrap:wrap">
                    <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)}</span>
                    <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}د)</span>
                    ${myRoomName?`<span style="color:var(--teal)"><i class="fas fa-door-open"></i> ${myRoomName}</span>`:''}
                    ${myStudCount>0?`<span style="color:var(--primary2)"><i class="fas fa-users"></i> ${myStudCount} طالب</span>`:''}
                  </div>
                </div>
                <div style="display:flex;flex-direction:column;gap:5px;align-items:flex-end;flex-shrink:0">
                  ${getStatusBadge(st)}
                  ${st==='active'?`<button class="btn btn-xs" style="background:var(--teal);color:white" onclick="openAttendance(${e.id})"><i class="fas fa-clipboard-check"></i> حضور</button>`:''}
                </div>
              </div>`;
            }).join('') : `<div style="padding:30px;text-align:center;color:var(--txt3)"><i class="fas fa-calendar" style="font-size:28px;opacity:.3;display:block;margin-bottom:8px"></i>لا توجد امتحانات مجدولة</div>`}
          </div>
        </div>

        <!-- مقرراتي الحالية — فقط المواد المرتبطة بالحساب مع شعب في الفصل الحالي -->
        <div class="card">
          <div class="card-h">
            <h3><i class="fas fa-book" style="color:var(--gold)"></i>
              موادي
              <span style="font-size:11px;font-weight:600;color:var(--primary2);background:var(--primary)10;padding:2px 8px;border-radius:20px;margin-right:6px">
                ${STATE.semesters.find(s=>s.code===STATE.currentSem)?.label||STATE.currentSem}
              </span>
            </h3>
            <button class="btn bo btn-xs" onclick="UI.showPage('subjects')">التفاصيل →</button>
          </div>
          <div class="card-b" style="padding:0">
            ${(()=>{
              // فقط المواد التي لها شعب في الفصل الحالي
              const subjsWithSem = mySubjs.filter(subj =>
                mySections.some(s => s.subject_id === subj.id)
              );
              if (!subjsWithSem.length) {
                return `<div style="padding:24px;text-align:center;color:var(--txt3)">
                  <i class="fas fa-book" style="font-size:26px;opacity:.25;display:block;margin-bottom:10px"></i>
                  <div style="font-size:13px;font-weight:700">لا توجد مواد مرتبطة بك</div>
                  <div style="font-size:11.5px;margin-top:4px">في ${STATE.semesters.find(s=>s.code===STATE.currentSem)?.label||STATE.currentSem}</div>
                </div>`;
              }
              return subjsWithSem.map(subj => {
                const mySecs   = mySections.filter(s => s.subject_id === subj.id);
                const dept     = STATE.departments.find(d => d.id === subj.dept_id);
                const studCount= mySecs.reduce((acc,s) => acc+(s.student_ids||[]).length, 0);
                const clr      = dept?.color || 'var(--gold)';
                return `<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);transition:all .15s"
                  onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
                  <div style="width:40px;height:40px;border-radius:11px;background:${clr}15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                    <i class="fas fa-book" style="color:${clr};font-size:16px"></i>
                  </div>
                  <div style="flex:1;min-width:0">
                    <div style="font-weight:800;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(subj.name)}</div>
                    <div style="font-size:11px;color:var(--txt3)">${subj.code||''} ${dept?`· ${esc(dept.name)}`:''}</div>
                  </div>
                  <div style="display:flex;gap:8px;flex-shrink:0">
                    <div style="text-align:center;padding:5px 8px;background:var(--primary2)12;border-radius:8px">
                      <div style="font-size:15px;font-weight:900;color:var(--primary2)">${mySecs.length}</div>
                      <div style="font-size:9.5px;color:var(--txt3)">شعبة</div>
                    </div>
                    <div style="text-align:center;padding:5px 8px;background:var(--teal)12;border-radius:8px">
                      <div style="font-size:15px;font-weight:900;color:var(--teal)">${studCount}</div>
                      <div style="font-size:9.5px;color:var(--txt3)">طالب</div>
                    </div>
                  </div>
                </div>`;
              }).join('');
            })()}
          </div>
        </div>
      </div>

      <!-- العمود الجانبي -->
      <div style="display:flex;flex-direction:column;gap:14px">
        <!-- ملفي الشخصي -->
        <div class="card" style="padding:18px">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
            ${userAvatar(u, 52)}
            <div>
              <div style="font-weight:800;font-size:15px">${esc(u?.name||'—')}</div>
              <div style="font-size:12px;color:var(--txt3)">${esc(u?.email||'')}</div>
              <div style="margin-top:6px"><span class="badge b-purple">${done} امتحان هذا الفصل</span></div>
            </div>
          </div>
          <button class="btn bo" style="width:100%" onclick="openProfile()">
            <i class="fas fa-user-edit"></i> تعديل الملف الشخصي
          </button>
        </div>

        <!-- الإجراءات السريعة -->
        <div class="card" style="padding:14px">
          <div style="font-weight:800;font-size:13px;margin-bottom:10px;display:flex;align-items:center;gap:7px">
            <i class="fas fa-bolt" style="color:var(--gold)"></i> إجراءات سريعة
          </div>
          <div style="display:flex;flex-direction:column;gap:7px">
            ${active ? `<button class="btn btn-sm" style="background:var(--green2);color:white;border-color:var(--green2)" onclick="UI.showPage('live')">
              <span style="width:8px;height:8px;border-radius:50%;background:white;animation:pulse 1s infinite;display:inline-block;margin-left:4px"></span>
              شاشة المراقبة الحية
            </button>` : ''}
            <button class="btn bo btn-sm" onclick="UI.showPage('swaps')">
              <i class="fas fa-clipboard-check" style="color:var(--purple2)"></i> طلبات المراقبة
              ${totalPending?`<span class="badge b-red" style="font-size:10px">${totalPending}</span>`:''}
            </button>
            <button class="btn bo btn-sm" onclick="UI.showPage('calendar')">
              <i class="fas fa-calendar-alt" style="color:var(--primary2)"></i> التقويم العام
            </button>
            <button class="btn bo btn-sm" onclick="UI.showPage('analytics')">
              <i class="fas fa-chart-bar" style="color:var(--teal)"></i> إحصائياتي
            </button>
          </div>
        </div>

        <!-- إحصائياتي -->
        <div class="card" style="padding:14px">
          <div style="font-weight:800;font-size:13px;margin-bottom:12px;display:flex;align-items:center;gap:7px">
            <i class="fas fa-chart-pie" style="color:var(--primary2)"></i> إحصائياتي هذا الفصل
          </div>
          ${_proctorStats(uid)}
        </div>
      </div>
    </div>`);
}

// استجابة المراقب لطلب التعيين
// يستخدم دوال swaps.js المُعاد كتابتها مباشرةً
async function _respondToProctorAssign(examId, response) {
  if (response === 'accepted') {
    await proctorAcceptAssignment(examId);
    renderMyDashboard();
  } else {
    proctorRejectAssignment(examId);
  }
}

// _confirmProctorReject moved to swaps.js as _confirmRejectAssignment

function _proctorStats(uid) {
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(uid));
  const byType = {};
  semExams.forEach(e => { byType[e.type] = (byType[e.type]||0)+1; });
  const max = Math.max(...Object.values(byType), 1);
  return Object.entries(byType).map(([type, count]) => `
    <div class="chart-row">
      <span class="chart-lbl">${getTypeLabel(type)}</span>
      <div class="chart-track"><div class="chart-fill" style="width:${Math.round(count/max*100)}%">${count}</div></div>
    </div>`).join('') || '<div style="text-align:center;color:var(--txt3);font-size:12px;padding:16px">لا بيانات</div>';
}

// ══ بوابة الطالب ════════════════════════════════════════════
function renderStudentPortal() {
  const u = STATE.currentUser;
  setHTML('studWelcome', `مرحباً، ${u?.name?.split(' ').slice(0,2).join(' ')} 🎓`);

  // امتحانات الطالب عبر الشعب — متعدد الأقسام
  const mySubjectIds = u?.subject_ids || [];
  const mySections  = STATE.sections.filter(s =>
    s.semester === STATE.currentSem && (s.student_ids||[]).includes(u?.id)
  );
  const mySubjectIdsFromSec = mySections.map(s => s.subject_id);
  // كل المواد التي يدرسها الطالب (من الـ profile + الشعب)
  const allMySubjIds = [...new Set([...mySubjectIds, ...mySubjectIdsFromSec])];
  // الأقسام التي يدرس الطالب فيها (متعددة)
  const myDeptIds = [...new Set(allMySubjIds
    .map(id => STATE.subjects.find(s=>s.id===id)?.dept_id)
    .filter(Boolean))];
  const myExams = STATE.exams.filter(e =>
    e.semester === STATE.currentSem && allMySubjIds.includes(e.subject_id)
  ).sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  // إظهار شريط الأقسام
  const deptsBar = myDeptIds.length ? `
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
      <span style="font-size:11.5px;color:var(--txt3);align-self:center"><i class="fas fa-sitemap" style="margin-left:4px"></i>أقسامي:</span>
      ${myDeptIds.map(id=>{
        const d = STATE.departments.find(x=>x.id===id);
        return d?`<span class="badge" style="background:${d.color||'#2563eb'}20;color:${d.color||'#2563eb'};border:1px solid ${d.color||'#2563eb'}40">${esc(d.name)}</span>`:'';
      }).join('')}
    </div>` : '';
  const portalCt = document.getElementById('student-portalContent');
  if (portalCt && deptsBar) {
    // سنحقن شريط الأقسام بعد الـ stats
    setTimeout(() => {
      const stats = document.getElementById('studStats');
      if (stats && !document.getElementById('studDeptsBar')) {
        const wrap = document.createElement('div');
        wrap.id = 'studDeptsBar';
        wrap.innerHTML = deptsBar;
        stats.insertAdjacentElement('afterend', wrap);
      }
    }, 0);
  }

  const coming = myExams.filter(e => examStatus(e) === 'upcoming').length;
  const active = myExams.filter(e => examStatus(e) === 'active').length;

  setHTML('studStats', `
    <div class="stat-card">
      <div class="stat-ic ic-blue"><i class="fas fa-file-alt"></i></div>
      <div><div class="stat-val">${myExams.length}</div><div class="stat-lbl">امتحاناتي</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-green"><i class="fas fa-clock"></i></div>
      <div><div class="stat-val">${coming}</div><div class="stat-lbl">قادمة</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ${active>0?'ic-green':'ic-gray'}"><i class="fas fa-circle" style="font-size:10px"></i></div>
      <div><div class="stat-val">${active}</div><div class="stat-lbl">جارية الآن</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-ic ic-purple"><i class="fas fa-book"></i></div>
      <div><div class="stat-val">${mySections.length}</div><div class="stat-lbl">شُعبي</div></div>
    </div>`);

  setHTML('studGrid', `
    <div class="gl" style="align-items:start">
      <div class="card">
        <div class="card-h"><h3><i class="fas fa-calendar" style="color:var(--green2)"></i> جدول امتحاناتي</h3></div>
        <div class="card-b" style="padding:12px 16px">
          ${myExams.map(e => {
            const sub = getSubject(e.subject_id);
            const st  = examStatus(e);
            const rooms = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
            return `<div style="display:flex;align-items:start;gap:12px;padding:13px 0;border-bottom:1px solid var(--border)">
              <div style="width:44px;height:44px;border-radius:12px;background:var(--green-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <i class="fas fa-file-alt" style="color:var(--green);font-size:18px"></i>
              </div>
              <div style="flex:1">
                <div style="font-weight:800;font-size:14px">${sub?.name||'—'}</div>
                <div style="font-size:11.5px;color:var(--txt2);margin-top:3px;display:flex;gap:12px;flex-wrap:wrap">
                  <span><i class="fas fa-calendar" style="color:var(--primary2);margin-left:4px"></i>${fmtDate(e.date)}</span>
                  <span><i class="fas fa-clock" style="color:var(--gold);margin-left:4px"></i>${fmtTime(e.time)}</span>
                  <span><i class="fas fa-hourglass" style="color:var(--teal);margin-left:4px"></i>${e.duration} دقيقة</span>
                  ${rooms.length?`<span><i class="fas fa-door-open" style="color:var(--purple2);margin-left:4px"></i>${rooms.join('، ')}</span>`:''}
                </div>
              </div>
              <div>${getStatusBadge(st)}</div>
            </div>`;
          }).join('') || emptyState('fa-calendar','لا توجد امتحانات مجدولة لهذا الفصل')}
        </div>
      </div>
      <div>
        <div class="card" style="margin-bottom:14px">
          <div class="card-h"><h3><i class="fas fa-book" style="color:var(--teal)"></i> شُعبي</h3></div>
          <div class="card-b" style="padding:12px 16px">
            ${mySections.map(s => {
              const subj = getSubject(s.subject_id);
              return `<div style="padding:10px;border-radius:10px;background:var(--bg);margin-bottom:8px">
                <div style="font-weight:700;font-size:13px">${s.name}</div>
                <div style="font-size:11.5px;color:var(--txt2);margin-top:3px">${subj?.name||'—'}</div>
              </div>`;
            }).join('') || '<div style="text-align:center;color:var(--txt3);font-size:12px;padding:12px">لم تُضف لأي شعبة</div>'}
          </div>
        </div>
        <div class="card">
          <div class="card-h"><h3><i class="fas fa-user" style="color:var(--green)"></i> معلوماتي</h3></div>
          <div class="card-b" style="padding:12px 16px">
            ${_studentInfoCard(u)}
          </div>
        </div>
      </div>
    </div>`);
}

function _studentInfoCard(u) {
  const p = STATE.students.find(s => s.email === u?.email) || {};
  return `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
      ${userAvatar(u, 52)}
      <div>
        <div style="font-weight:800;font-size:15px">${u?.name||'—'}</div>
        <div style="font-size:12px;color:var(--txt2)">${u?.stud_id||p?.stud_id||'—'}</div>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:6px">
      <div style="display:flex;justify-content:space-between;font-size:12.5px">
        <span style="color:var(--txt3)">البريد الإلكتروني</span>
        <span style="font-weight:600">${u?.email||'—'}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:12.5px">
        <span style="color:var(--txt3)">الدفعة</span>
        <span style="font-weight:600">${p?.batch||u?.batch||'—'}</span>
      </div>
    </div>
    <button class="btn bo btn-sm" style="margin-top:12px;width:100%" onclick="openProfile()">
      <i class="fas fa-user-edit"></i> تعديل الملف الشخصي
    </button>`;
}

// ═══════════════════════════════════════════════════════════════
//  FEATURE 1: Drag & Drop Dashboard
// ═══════════════════════════════════════════════════════════════

const DASH_WIDGETS_DEFAULT = ['exams','pressure','quick','shortcuts','sem','proctors','log'];

function _dashLoadLayout() {
  try {
    const s = localStorage.getItem('dash_layout_' + (STATE.currentUser?.id||'default'));
    return s ? JSON.parse(s) : [...DASH_WIDGETS_DEFAULT];
  } catch { return [...DASH_WIDGETS_DEFAULT]; }
}

function _dashSaveLayout(layout) {
  try { localStorage.setItem('dash_layout_' + (STATE.currentUser?.id||'default'), JSON.stringify(layout)); } catch {}
}

function _dashResetLayout() {
  try { localStorage.removeItem('dash_layout_' + (STATE.currentUser?.id||'default')); } catch {}
  renderDashboard();
  toast('✓ تم إعادة الترتيب الافتراضي','success');
}

function _renderDashWidgets(layout) {
  const grid = document.getElementById('dashWidgetGrid');
  if (!grid) return;
  const activeSem = STATE.semesters.find(s => s.code === STATE.currentSem);

  const WIDGET_BUILDERS = {
    exams:    () => `<div class="dash-widget card" data-widget="exams" style="margin-bottom:0">
      <div class="card-h" style="cursor:grab">
        <h3><i class="fas fa-calendar-alt" style="color:var(--primary2)"></i> الامتحانات</h3>
        <div class="dash-drag-handle" title="اسحب"><i class="fas fa-grip-vertical" style="color:var(--txt3)"></i></div>
        <div class="tabs" id="dashExamTabs" style="margin:0">
          <div class="tab" onclick="setDE('upcoming',this)">قادمة</div>
          <div class="tab active" onclick="setDE('active',this)">جارية</div>
          <div class="tab" onclick="setDE('all',this)">الكل</div>
        </div>
      </div>
      <div class="card-b" id="dashExamList" style="max-height:340px;overflow-y:auto;padding:12px 16px"></div>
    </div>`,
    pressure: () => {
      const w = _dashPressureWidget();
      if (!w) return null;
      return `<div class="dash-widget" data-widget="pressure">${w}</div>`;
    },
    quick:    () => `<div class="dash-widget" data-widget="quick">${_quickActionsCard()}</div>`,
    shortcuts:() => `<div class="dash-widget" data-widget="shortcuts">${_v10ShortcutsCard()}</div>`,
    sem:      () => `<div class="dash-widget" data-widget="sem">${_semInfoCard(activeSem)}</div>`,
    proctors: () => `<div class="dash-widget" data-widget="proctors">${_topProctorsCard()}</div>`,
    log:      () => `<div class="dash-widget" data-widget="log">${_recentLogCard()}</div>`,
    qr:       () => null
  };

  let html = '';
  layout.forEach(wid => {
    const builder = WIDGET_BUILDERS[wid];
    if (!builder) return;
    const content = builder();
    if (content) html += content;
  });

  grid.innerHTML = html;
  _initDashDragDrop();
}

function _initDashDragDrop() {
  const grid = document.getElementById('dashWidgetGrid');
  if (!grid) return;

  let dragEl = null, placeholder = null;

  grid.querySelectorAll('.dash-widget').forEach(widget => {
    widget.setAttribute('draggable','true');

    widget.addEventListener('dragstart', e => {
      dragEl = widget;
      widget.style.opacity = '0.4';
      widget.style.transform = 'scale(0.98)';
      e.dataTransfer.effectAllowed = 'move';
    });

    widget.addEventListener('dragend', () => {
      widget.style.opacity = '';
      widget.style.transform = '';
      dragEl = null;
      placeholder?.remove();
      placeholder = null;
      // Save new layout
      const newLayout = [...grid.querySelectorAll('.dash-widget')].map(w => w.dataset.widget);
      _dashSaveLayout(newLayout);
    });

    widget.addEventListener('dragover', e => {
      e.preventDefault();
      if (!dragEl || dragEl === widget) return;
      const rect = widget.getBoundingClientRect();
      const mid  = rect.top + rect.height / 2;
      if (e.clientY < mid) {
        grid.insertBefore(dragEl, widget);
      } else {
        grid.insertBefore(dragEl, widget.nextSibling);
      }
    });
  });
}

