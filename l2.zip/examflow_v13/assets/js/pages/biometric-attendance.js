// biometric-attendance.js — حضور بالبصمة (stub)
// يعتمد على BIO module من core/biometric.js
