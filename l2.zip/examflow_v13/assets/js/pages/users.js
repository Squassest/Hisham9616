// users.js v14 — إدارة المستخدمين (بدون Supabase Auth)

function renderUsers() {
  // رئيس القسم يرى فقط مستخدمي قسمه
  if (isDeptHead()) {
    const myDeptId = STATE.currentUser?.dept_id;
    const deptUsers = STATE.profiles.filter(u => u.dept_id === myDeptId);
    const dept = STATE.departments.find(d => d.id === myDeptId);
    setHTML('usersActs', '');
    setHTML('usersContent', `
      <div class="card">
        <div class="card-h">
          <h3><i class="fas fa-users" style="color:var(--primary2)"></i> مستخدمو قسم ${dept?.name||'قسمي'} (${deptUsers.length})</h3>
          <div class="sbar" style="width:200px">
            <i class="fas fa-search"></i>
            <input type="text" id="userSrch" placeholder="بحث..." oninput="filterUsersList()">
          </div>
        </div>
        <div id="usersList"></div>
      </div>`);
    _renderUsersList(deptUsers);
    return;
  }
  if (!isAdmin() && !isCoord()) {
    setHTML('usersContent', emptyState('fa-lock','غير مصرح','هذه الصفحة للمسؤول فقط'));
    return;
  }
  setHTML('usersActs', `
    ${isAdmin() ? `<button class="btn bo btn-sm" onclick="downloadUsersTemplate()">
      <i class="fas fa-download"></i> نموذج Excel
    </button>
    <button class="btn bo btn-sm" onclick="openImportUsers()">
      <i class="fas fa-file-import"></i> استيراد
    </button>
    <button class="btn bp btn-sm" onclick="openAddUser()">
      <i class="fas fa-user-plus"></i> مستخدم جديد
    </button>` : ''}`);

  const users = STATE.profiles;
  const stats = {};
  Object.keys(APP_CONFIG.ROLES).forEach(r => stats[r] = 0);
  users.forEach(u => { if (stats[u.role]!==undefined) stats[u.role]++; });

  setHTML('usersContent', `
    <div class="stats-grid" style="margin-bottom:18px">
      ${Object.entries(stats).map(([role, count]) => `
        <div class="stat-card" style="cursor:pointer" onclick="filterByRole('${role}')">
          <div class="stat-ic" style="background:${APP_CONFIG.ROLE_COLORS[role]}20;color:${APP_CONFIG.ROLE_COLORS[role]}">
            <i class="fas ${APP_CONFIG.ROLE_ICONS[role]}"></i>
          </div>
          <div><div class="stat-val">${count}</div><div class="stat-lbl">${APP_CONFIG.ROLES[role]}</div></div>
        </div>`).join('')}
    </div>
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-users" style="color:var(--primary2)"></i> المستخدمون (${users.length})</h3>
        <div style="display:flex;gap:8px">
          <select id="roleFilter" onchange="filterUsersList()" class="field" style="height:32px;margin:0;width:150px">
            <option value="">كل الأدوار</option>
            ${Object.entries(APP_CONFIG.ROLES).map(([v,l]) => `<option value="${v}">${l}</option>`).join('')}
          </select>
          <select id="deptFilter" onchange="filterUsersList()" class="field" style="height:32px;margin:0;width:150px">
            <option value="">كل الأقسام</option>
            ${STATE.departments.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}
          </select>
          <select id="sigFilter" onchange="filterUsersList()" class="field" style="height:32px;margin:0;width:140px">
              <option value="">كل التوقيعات</option>
              <option value="no_sig">بدون توقيع</option>
              <option value="has_sig">لديه توقيع</option>
            </select>
          <div class="sbar" style="width:200px">
            <i class="fas fa-search"></i>
            <input type="text" id="userSrch" placeholder="بحث..." oninput="filterUsersList()">
          </div>
        </div>
      </div>
      <div id="usersList"></div>
    </div>`);
  _renderUsersList(users);
}

function filterByRole(role) {
  const sel = document.getElementById('roleFilter');
  if (sel) sel.value = role;
  filterUsersList();
}

function filterUsersList() {
  const q    = (document.getElementById('userSrch')?.value||'').toLowerCase();
  const role = document.getElementById('roleFilter')?.value||'';
  const dept = document.getElementById('deptFilter')?.value||'';
  let f = STATE.profiles;
  const sig = document.getElementById('sigFilter')?.value||'';
  if (role) f = f.filter(u => u.role === role);
  if (dept) f = f.filter(u => String(u.dept_id) === dept);
  if (sig === 'no_sig')  f = f.filter(u => !u.signature);
  if (sig === 'has_sig') f = f.filter(u => !!u.signature);
  if (q)    f = f.filter(u => u.name?.toLowerCase().includes(q) || u.email?.toLowerCase().includes(q) || u.emp_id?.toLowerCase().includes(q));
  _renderUsersList(f);
}

function _renderUsersList(users) {
  const el = document.getElementById('usersList');
  if (!el) return;
  if (!users.length) { el.innerHTML = emptyState('fa-users','لا يوجد مستخدمون'); return; }

  el.innerHTML = users.map(u => {
    const isSelf  = u.id === STATE.currentUser?.id;
    const col     = APP_CONFIG.ROLE_COLORS[u.role] || '#2563eb';
    const dept    = STATE.departments.find(d => d.id === u.dept_id);
    const isAr    = I18N.isAr();
    const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
    const examCount = semExams.filter(e => (e.proctor_ids||[]).includes(u.id)).length;

    return `<div style="display:flex;align-items:center;gap:12px;padding:13px 20px;border-bottom:1px solid var(--border);transition:background .15s;cursor:pointer"
      onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"
      onclick="openUserProfile('${u.id}')">
      ${userAvatar(u, 40)}
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13.5px;display:flex;align-items:center;gap:6px">
          ${u.name}
          ${isSelf?`<span class="badge b-blue" style="font-size:9px">${isAr?'أنت':'You'}</span>`:''}
        </div>
        <div style="font-size:11.5px;color:var(--txt2)">${u.email||'—'} · ${u.emp_id||'—'}${dept?` · <span style="color:${dept.color||'#2563eb'}">${dept.name}</span>`:''}</div>
      </div>
      <!-- النقاط وعدد الامتحانات -->
      ${u.role === 'proctor' ? `<div style="text-align:center;min-width:50px;flex-shrink:0">
        <div style="font-size:16px;font-weight:900;color:var(--gold)">${u.points||0}</div>
        <div style="font-size:9px;color:var(--txt3)">${isAr?'نقطة':'pts'}</div>
        <div style="font-size:9px;color:var(--txt3)">${examCount} ${isAr?'امتحان':'exams'}</div>
      </div>` : ''}
      <div style="display:flex;align-items:center;gap:5px;flex-shrink:0" onclick="event.stopPropagation()">
        ${getRoleBadge(u.role)}
        ${u.signature && isAdmin() ? `<span title="${isAr?'لديه توقيع':'Has signature'}" style="width:22px;height:22px;border-radius:5px;background:var(--green-bg);display:flex;align-items:center;justify-content:center"><i class="fas fa-signature" style="color:var(--green);font-size:9px"></i></span>` : ''}
        <span class="badge ${u.active?'b-green':'b-red'}" style="font-size:10px">${u.active?(isAr?'نشط':'Active'):(isAr?'موقوف':'Inactive')}</span>
        <button class="btn bo btn-xs" onclick="openUserProfile('${u.id}')" title="${isAr?'البروفايل':'Profile'}"><i class="fas fa-id-card"></i></button>
        <button class="btn bo btn-xs" onclick="openEditUser('${u.id}')" title="${isAr?'تعديل':'Edit'}"><i class="fas fa-edit"></i></button>
        <button class="btn bo btn-xs" onclick="openChangePassword('${u.id}')" title="${isAr?'كلمة المرور':'Password'}"><i class="fas fa-key"></i></button>
        ${isAdmin() ? `<button class="btn bo btn-xs" onclick="openUserSignature('${u.id}')" title="${isAr?'التوقيع':'Signature'}"><i class="fas fa-signature"></i></button>` : ''}
        ${isAdmin() || STATE.currentUser?.id===u.id ? `<button class="btn bo btn-xs" onclick="openStaffBiometric('${u.id}')" title="${isAr?'البصمة':'Biometric'}" style="color:var(--purple2);border-color:var(--purple)40"><i class="fas fa-fingerprint"></i></button>` : ''}
        ${isAdmin() && u.role !== 'admin' ? `<button class="btn bo btn-xs" onclick="openUserPermissions('${u.id}')" title="${isAr?'الصلاحيات':'Permissions'}" style="color:var(--primary2);border-color:var(--primary)40"><i class="fas fa-shield-alt"></i></button>` : ''}
        ${!isSelf ? `
        <button class="btn ${u.active?'bd':'bs'} btn-xs" onclick="toggleUserActive('${u.id}')">
          <i class="fas fa-${u.active?'ban':'check'}"></i>
        </button>
        ${isAdmin() ? `<button class="btn bd btn-xs" onclick="deleteUser('${u.id}')" title="${isAr?'حذف':'Delete'}"><i class="fas fa-trash"></i></button>` : ''}
        ` : ''}
      </div>
    </div>`;
  }).join('');
}

// ── Add User ──────────────────────────────────────────────────
function openAddUser() {
  const mo = _getMo('addUserMo');
  mo.innerHTML = `<div class="md" style="max-width:520px">
    <div class="md-hd">
      <h2><i class="fas fa-user-plus" style="color:var(--primary)"></i> مستخدم جديد</h2>
      <button class="md-close" onclick="closeMo('addUserMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="g2">
        <div class="field"><label class="field-lbl">الاسم الكامل <span class="req">*</span></label>
          <input id="unName" placeholder="أحمد محمد العبري"></div>
        <div class="field"><label class="field-lbl">البريد الإلكتروني <span class="req">*</span></label>
          <input id="unEmail" type="email" placeholder="ahmed@squ.edu.om"></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الدور <span class="req">*</span></label>
          <select id="unRole" onchange="updateDeptVisibility()">
            ${Object.entries(APP_CONFIG.ROLES).filter(([v])=>v!=='student').map(([v,l])=>`<option value="${v}">${l}</option>`).join('')}
          </select></div>
        <div class="field"><label class="field-lbl">القسم</label>
          <select id="unDept">
            <option value="">— بدون قسم —</option>
            ${STATE.departments.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}
          </select></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الرقم الوظيفي</label>
          <input id="unEmpId" placeholder="EMP001"></div>
        <div class="field"><label class="field-lbl">رقم الهاتف</label>
          <input id="unPhone" placeholder="+96891234567"></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">كلمة المرور <span class="req">*</span></label>
          <div class="pass-wrap">
            <input id="unPass" type="password" placeholder="••••••••" oninput="checkPassStrength(this,'unPassBar','unPassLbl')">
            <span class="pass-eye" onclick="togglePassVis('unPass',this)"><i class="fas fa-eye"></i></span>
          </div>
          <div class="pass-strength"><div class="pass-bar"><div class="pass-bar-fill" id="unPassBar"></div></div>
          <div class="pass-lbl" id="unPassLbl"></div></div>
        </div>
        <div class="field"><label class="field-lbl">تأكيد كلمة المرور</label>
          <input id="unPass2" type="password" placeholder="••••••••" oninput="checkPassMatch('unPass','unPass2','unMatchLbl')">
          <div class="pass-match" id="unMatchLbl"></div>
        </div>
      </div>
      <div class="field"><label class="field-lbl">اللون</label>
        <input type="color" id="unColor" value="#2563eb" style="height:36px;width:100%;border:1.5px solid var(--border);border-radius:8px;cursor:pointer"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('addUserMo')">إلغاء</button>
      <button id="addUserBtn" class="btn bp" onclick="createUser()"><i class="fas fa-user-plus"></i> إنشاء</button>
    </div>
  </div>`;
  showMo('addUserMo');
}

async function createUser() {
  const name  = document.getElementById('unName')?.value?.trim();
  const email = document.getElementById('unEmail')?.value?.trim()?.toLowerCase();
  const role  = document.getElementById('unRole')?.value;
  const pass  = document.getElementById('unPass')?.value;
  const pass2 = document.getElementById('unPass2')?.value;
  if (!name||!email||!role||!pass) return toast('أكمل الحقول المطلوبة','warning');
  if (pass !== pass2) return toast('كلمة المرور غير متطابقة','warning');
  if (pass.length < 8) return toast('كلمة المرور يجب أن تكون 8 أحرف على الأقل','warning');
  if (STATE.profiles.find(p => p.email === email)) return toast('البريد مستخدم مسبقاً','warning');

  setBtnLoading('addUserBtn', true);
  try {
    // تشفير كلمة المرور ثم إنشاء مستخدم في profiles مباشرةً
    const hash = await AUTH.hashPassword(pass);
    const newId = crypto.randomUUID();
    const profileData = {
      id:      newId,
      email,   name,   role,
      password: hash,
      emp_id:  document.getElementById('unEmpId')?.value?.trim()  || '',
      phone:   document.getElementById('unPhone')?.value?.trim()   || '',
      color:   document.getElementById('unColor')?.value           || '#2563eb',
      dept_id: parseInt(document.getElementById('unDept')?.value)  || null,
      active:  true
    };
    await SB.upsert('profiles', profileData);
    const hydratedProfile = Hydrate.profile(profileData);
    STATE.profiles.push(hydratedProfile);
    toast(`تم إنشاء حساب ${name} ✓`, 'success');
    await SB.logAction('إنشاء مستخدم', 'profiles', name);
    closeMo('addUserMo');
    renderUsers();
  } catch (e) {
    setBtnLoading('addUserBtn', false);
    toast(e.message, 'error');
  }
}

// ── Edit User ─────────────────────────────────────────────────
function openEditUser(id) {
  const u = getProfile(id);
  if (!u) return;
  const mo = _getMo('editUserMo');
  mo.innerHTML = `<div class="md" style="max-width:520px">
    <div class="md-hd">
      <h2><i class="fas fa-user-edit" style="color:var(--primary)"></i> تعديل: ${u.name}</h2>
      <button class="md-close" onclick="closeMo('editUserMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="g2">
        <div class="field"><label class="field-lbl">الاسم الكامل <span class="req">*</span></label>
          <input id="euName" value="${u.name||''}"></div>
        <div class="field"><label class="field-lbl">البريد الإلكتروني</label>
          <input id="euEmail" type="email" value="${u.email||''}" readonly style="opacity:.7"></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الدور</label>
          <select id="euRole" ${u.id===STATE.currentUser?.id?'disabled':''}>
            ${Object.entries(APP_CONFIG.ROLES).map(([v,l])=>`<option value="${v}" ${u.role===v?'selected':''}>${l}</option>`).join('')}
          </select></div>
        <div class="field"><label class="field-lbl">القسم</label>
          <select id="euDept">
            <option value="">— بدون قسم —</option>
            ${STATE.departments.map(d=>`<option value="${d.id}" ${u.dept_id===d.id?'selected':''}>${d.name}</option>`).join('')}
          </select></div>
      </div>
      <div class="g2">
        <div class="field"><label class="field-lbl">الرقم الوظيفي</label>
          <input id="euEmpId" value="${u.emp_id||''}"></div>
        <div class="field"><label class="field-lbl">رقم الهاتف</label>
          <input id="euPhone" value="${u.phone||''}"></div>
      </div>
      <div class="field"><label class="field-lbl">اللون</label>
        <input type="color" id="euColor" value="${u.color||'#2563eb'}" style="height:36px;width:100%;border:1.5px solid var(--border);border-radius:8px;cursor:pointer"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('editUserMo')">إلغاء</button>
      <button id="saveUserBtn_${id}" class="btn bp" onclick="saveUser('${id}')"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('editUserMo');
}

async function saveUser(id) {
  const name  = document.getElementById('euName')?.value?.trim();
  if (!name) return toast('أدخل الاسم','warning');
  const roleEl = document.getElementById('euRole');
  const role  = roleEl?.disabled ? getProfile(id)?.role : roleEl?.value;
  const data  = {
    name,
    role,
    emp_id:  document.getElementById('euEmpId')?.value?.trim()||'',
    phone:   document.getElementById('euPhone')?.value?.trim()||'',
    color:   document.getElementById('euColor')?.value||'#2563eb',
    dept_id: parseInt(document.getElementById('euDept')?.value)||null
  };
  try {
    await SB.update('profiles', id, data, 'id');
    const idx = STATE.profiles.findIndex(p => p.id === id);
    if (idx>=0) STATE.profiles[idx] = { ...STATE.profiles[idx], ...data };
    toast('تم التحديث ✓','success');
    await SB.logAction('تعديل مستخدم','profiles',name);
    closeMo('editUserMo');
    renderUsers();
  } catch(e) { toast(e.message,'error'); }
}

// ── Signature Modal ───────────────────────────────────────────
function openUserSignature(id) {
  const u = getProfile(id);
  if (!u) return;
  const mo = _getMo('sigMo');
  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-signature" style="color:var(--primary)"></i> توقيع ${u.name}</h2>
      <button class="md-close" onclick="closeMo('sigMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="font-size:12.5px;color:var(--txt2);margin-bottom:12px">ارسم التوقيع باستخدام الفأرة أو اللمس:</div>
      <canvas id="sigCanvas" width="430" height="180" 
              style="border:1.5px solid var(--border);border-radius:10px;width:100%;cursor:crosshair;touch-action:none;background:#fff"></canvas>
      ${u.signature ? `<div style="margin-top:10px">
        <div style="font-size:11.5px;color:var(--txt3);margin-bottom:6px">التوقيع الحالي:</div>
        <img src="${u.signature}" style="max-width:100%;border:1px solid var(--border);border-radius:8px;background:#fff">
      </div>` : ''}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="clearSigCanvas()"><i class="fas fa-eraser"></i> مسح</button>
      <button class="btn bo" onclick="closeMo('sigMo')">إلغاء</button>
      <button class="btn bp" onclick="saveSig('${id}')"><i class="fas fa-save"></i> حفظ التوقيع</button>
    </div>
  </div>`;
  showMo('sigMo');
  setTimeout(() => _initSigCanvas(), 100);
}

function _initSigCanvas() {
  const canvas = document.getElementById('sigCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth   = 2.5;
  ctx.lineCap     = 'round';
  ctx.lineJoin    = 'round';
  let drawing = false;

  const getPos = e => {
    const r = canvas.getBoundingClientRect();
    const scaleX = canvas.width / r.width;
    const scaleY = canvas.height / r.height;
    const src = e.touches ? e.touches[0] : e;
    return { x: (src.clientX - r.left) * scaleX, y: (src.clientY - r.top) * scaleY };
  };

  canvas.onmousedown = canvas.ontouchstart = e => {
    e.preventDefault(); drawing=true;
    const p = getPos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y);
  };
  canvas.onmousemove = canvas.ontouchmove = e => {
    e.preventDefault(); if (!drawing) return;
    const p = getPos(e); ctx.lineTo(p.x,p.y); ctx.stroke();
  };
  canvas.onmouseup = canvas.ontouchend = () => drawing=false;
}

function clearSigCanvas() {
  const c = document.getElementById('sigCanvas');
  if (c) c.getContext('2d').clearRect(0,0,c.width,c.height);
}

async function saveSig(id) {
  const canvas = document.getElementById('sigCanvas');
  if (!canvas) return;
  const dataUrl = canvas.toDataURL('image/png');
  // Check if canvas is empty
  const blank = document.createElement('canvas');
  blank.width = canvas.width; blank.height = canvas.height;
  if (dataUrl === blank.toDataURL()) return toast('الرجاء رسم التوقيع أولاً','warning');

  try {
    await SB.update('profiles', id, { signature: dataUrl }, 'id');
    const idx = STATE.profiles.findIndex(p => p.id === id);
    if (idx>=0) STATE.profiles[idx].signature = dataUrl;
    toast('تم حفظ التوقيع ✓','success');
    closeMo('sigMo');
    renderUsers();
  } catch(e) { toast(e.message,'error'); }
}

// ── Delete User ───────────────────────────────────────────────
async function deleteUser(id) {
  const u = getProfile(id);
  if (!u) return;
  if (u.id === STATE.currentUser?.id) return toast('لا يمكن حذف حسابك الخاص','warning');
  if (!confirm(`حذف المستخدم "${u.name}" نهائياً؟\nهذا الإجراء لا يمكن التراجع عنه.`)) return;
  try {
    // حذف مباشر من profiles (لا auth.users)
    await SB.del('profiles', id, 'id');
    STATE.profiles = STATE.profiles.filter(p => p.id !== id);
    toast(`تم حذف ${u.name} ✓`,'success');
    await SB.logAction('حذف مستخدم','profiles',u.name,'warning');
    renderUsers();
  } catch(e) { toast(e.message,'error'); }
}

// ── Toggle Active ─────────────────────────────────────────────
async function toggleUserActive(id) {
  const u = getProfile(id);
  if (!u) return;
  const newVal = !u.active;
  try {
    await SB.update('profiles', id, { active: newVal }, 'id');
    const idx = STATE.profiles.findIndex(p => p.id === id);
    if (idx>=0) STATE.profiles[idx].active = newVal;
    toast(`${u.name} — ${newVal?'تم التفعيل':'تم الإيقاف'}`,'success');
    renderUsers();
  } catch(e) { toast(e.message,'error'); }
}

// ── Change Password ───────────────────────────────────────────
function openChangePassword(id) {
  const u = getProfile(id);
  const mo = _getMo('chPassMo');
  mo.innerHTML = `<div class="md" style="max-width:400px">
    <div class="md-hd">
      <h2><i class="fas fa-key" style="color:var(--gold)"></i> تغيير كلمة مرور ${u?.name||''}</h2>
      <button class="md-close" onclick="closeMo('chPassMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">كلمة المرور الجديدة <span class="req">*</span></label>
        <div class="pass-wrap">
          <input id="cpPass" type="password" placeholder="••••••••" oninput="checkPassStrength(this,'cpBar','cpLbl')">
          <span class="pass-eye" onclick="togglePassVis('cpPass',this)"><i class="fas fa-eye"></i></span>
        </div>
        <div class="pass-strength"><div class="pass-bar"><div class="pass-bar-fill" id="cpBar"></div></div>
        <div class="pass-lbl" id="cpLbl"></div></div>
      </div>
      <div class="field"><label class="field-lbl">تأكيد كلمة المرور</label>
        <input id="cpPass2" type="password" placeholder="••••••••" oninput="checkPassMatch('cpPass','cpPass2','cpMatch')">
        <div class="pass-match" id="cpMatch"></div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('chPassMo')">إلغاء</button>
      <button class="btn bp" onclick="saveNewPass('${id}')"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('chPassMo');
}

async function saveNewPass(id) {
  const pass  = document.getElementById('cpPass')?.value;
  const pass2 = document.getElementById('cpPass2')?.value;
  if (!pass)           return toast('أدخل كلمة المرور', 'warning');
  if (pass !== pass2)  return toast('كلمة المرور غير متطابقة', 'warning');
  if (pass.length < 8) return toast('يجب أن تكون 8 أحرف على الأقل', 'warning');
  const u = getProfile(id);
  const btn = document.querySelector('#chPassMo .btn.bp');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جارٍ الحفظ...'; }
  try {
    // جميع تغييرات كلمة المرور تتم مباشرة في قاعدة البيانات
    await AUTH.setPasswordForUser(id, pass);
    toast(`✓ تم تغيير كلمة مرور ${u?.name || 'المستخدم'}`, 'success');
    closeMo('chPassMo');
  } catch (e) {
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> حفظ'; }
    toast('خطأ: ' + e.message, 'error');
  }
}

function downloadUsersTemplate() {
  const csv = 'الاسم,البريد الإلكتروني,الدور,الرقم الوظيفي,رقم الهاتف,القسم\nأحمد محمد,ahmed@squ.edu.om,proctor,EMP001,+96891234567,\n';
  const blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8;'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download='users_template.csv'; a.click();
}

function openImportUsers() {
  const isAr = I18N.isAr();
  const mo = _getMo('importUsersMo');
  mo.innerHTML = `<div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2><i class="fas fa-file-import" style="color:var(--primary)"></i> ${isAr?'استيراد مستخدمين':'Import Users'}</h2>
      <button class="md-close" onclick="closeMo('importUsersMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="background:var(--bg);border-radius:12px;padding:14px;margin-bottom:14px;font-size:12.5px;color:var(--txt2)">
        <div style="font-weight:800;color:var(--txt1);margin-bottom:8px"><i class="fas fa-info-circle" style="color:var(--primary2)"></i> ${isAr?'تعليمات الاستيراد':'Import Instructions'}</div>
        <ol style="padding-right:16px;line-height:2">
          <li>${isAr?'حمّل نموذج Excel أولاً':'Download the Excel template first'}</li>
          <li>${isAr?'أدخل بيانات المستخدمين في الأعمدة المحددة':'Fill in the user data in the specified columns'}</li>
          <li>${isAr?'الأعمدة المطلوبة: الاسم، البريد، الدور، الرقم الوظيفي، كلمة المرور':'Required: Name, Email, Role, Emp ID, Password'}</li>
          <li>${isAr?'الدور: admin / coordinator / dept_head / proctor / dean / assistant_dean':'Role: admin / coordinator / dept_head / proctor / dean / assistant_dean'}</li>
        </ol>
      </div>
      <div style="border:2px dashed var(--border);border-radius:12px;padding:24px;text-align:center;cursor:pointer;transition:all .2s"
        onclick="document.getElementById('importCSVInput').click()"
        ondragover="event.preventDefault();this.style.borderColor='var(--primary2)'"
        ondragleave="this.style.borderColor='var(--border)'"
        ondrop="event.preventDefault();this.style.borderColor='var(--border)';_handleImportDrop(event)">
        <i class="fas fa-cloud-upload-alt" style="font-size:36px;color:var(--txt3);margin-bottom:10px"></i>
        <div style="font-weight:700;font-size:14px;margin-bottom:4px">${isAr?'اسحب وأفلت ملف CSV هنا':'Drag & drop CSV file here'}</div>
        <div style="font-size:12px;color:var(--txt3)">${isAr?'أو انقر للتصفح':'or click to browse'}</div>
        <input type="file" id="importCSVInput" accept=".csv" style="display:none" onchange="_handleImportFile(this)">
      </div>
      <div id="importPreview" style="margin-top:14px"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo btn-sm" onclick="downloadUsersTemplate()"><i class="fas fa-download"></i> ${isAr?'نموذج CSV':'CSV Template'}</button>
      <button class="btn bo" onclick="closeMo('importUsersMo')">${isAr?'إلغاء':'Cancel'}</button>
      <button id="doImportBtn" class="btn bp" onclick="_doImportUsers()" disabled><i class="fas fa-file-import"></i> ${isAr?'استيراد':'Import'}</button>
    </div>
  </div>`;
  showMo('importUsersMo');
}

window._importParsedUsers = [];

function _handleImportDrop(event) {
  const file = event.dataTransfer.files[0];
  if (file) _parseImportCSV(file);
}

function _handleImportFile(input) {
  const file = input.files[0];
  if (file) _parseImportCSV(file);
}

function _parseImportCSV(file) {
  const isAr = I18N.isAr();
  const reader = new FileReader();
  reader.onload = (e) => {
    const text = e.target.result;
    const lines = text.split('\n').filter(l => l.trim());
    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g,'').toLowerCase());
    const users = [];
    for (let i = 1; i < lines.length; i++) {
      const vals = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g,''));
      const u = {};
      headers.forEach((h, idx) => { u[h] = vals[idx] || ''; });
      if (u['الاسم'] || u['name']) users.push({
        name:  u['الاسم'] || u['name'] || '',
        email: u['البريد الإلكتروني'] || u['email'] || '',
        role:  u['الدور'] || u['role'] || 'proctor',
        emp_id: u['الرقم الوظيفي'] || u['emp_id'] || '',
        phone: u['رقم الهاتف'] || u['phone'] || '',
        password: u['كلمة المرور'] || u['password'] || 'Pass@1234',
        dept_name: u['القسم'] || u['department'] || '',
      });
    }
    window._importParsedUsers = users;
    const preview = document.getElementById('importPreview');
    if (!preview) return;
    if (!users.length) { preview.innerHTML = `<p style="color:var(--red)">${isAr?'لم يتم العثور على بيانات صحيحة':'No valid data found'}</p>`; return; }
    preview.innerHTML = `
      <div style="font-size:12px;font-weight:700;color:var(--green);margin-bottom:8px">✓ ${isAr?'تم قراءة':'Parsed'} ${users.length} ${isAr?'مستخدم':'users'}</div>
      <div style="max-height:220px;overflow-y:auto;border:1px solid var(--border);border-radius:8px;font-size:11.5px">
        ${users.slice(0,10).map((u,i) => `<div style="display:flex;gap:8px;padding:7px 10px;border-bottom:1px solid var(--border);align-items:center">
          <span style="color:var(--txt3);min-width:20px">${i+1}</span>
          <span style="flex:1;font-weight:600">${u.name}</span>
          <span style="color:var(--txt2)">${u.email}</span>
          <span class="badge b-blue" style="font-size:9px">${u.role}</span>
        </div>`).join('')}
        ${users.length>10?`<div style="padding:8px;text-align:center;color:var(--txt3);font-size:11px">+${users.length-10} ${isAr?'أكثر':'more'}</div>`:''}
      </div>`;
    const btn = document.getElementById('doImportBtn');
    if (btn) btn.disabled = false;
  };
  reader.readAsText(file, 'utf-8');
}

async function _doImportUsers() {
  const users = window._importParsedUsers || [];
  const isAr = I18N.isAr();
  if (!users.length) return toast(isAr?'لا توجد بيانات للاستيراد':'No data to import','warning');
  const btn = document.getElementById('doImportBtn');
  if (btn) { btn.disabled=true; btn.innerHTML=`<i class="fas fa-spinner fa-spin"></i>`; }
  let success=0, failed=0;
  for (const u of users) {
    try {
      if (!u.name || !u.email) { failed++; continue; }
      // match dept by name
      let deptId = null;
      if (u.dept_name) {
        const dept = STATE.departments.find(d => d.name.includes(u.dept_name) || u.dept_name.includes(d.name));
        if (dept) deptId = dept.id;
      }
      const hash  = await AUTH.hashPassword(u.password || 'Pass@1234');
      const newId = crypto.randomUUID();
      await SB.upsert('profiles', {
        id: newId, email: u.email, name: u.name, password: hash,
        role: u.role || 'proctor', emp_id: u.emp_id || '', phone: u.phone || '',
        dept_id: deptId, active: true, color: '#2563eb'
      });
      success++;
    } catch(e) { failed++; console.warn('Import user failed:', u.email, e.message); }
  }
  toast(`${isAr?'تم الاستيراد':'Import done'}: ${success} ${isAr?'نجح':'ok'}, ${failed} ${isAr?'فشل':'failed'}`, success>0?'success':'error');
  await SB.logAction(isAr?'استيراد مستخدمين':'Import Users','profiles',`${success} users`);
  closeMo('importUsersMo');
  renderUsers();
}

// ── Helpers ───────────────────────────────────────────────────
function checkPassStrength(inp, barId, lblId) {
  const v = inp.value; const bar = document.getElementById(barId); const lbl = document.getElementById(lblId);
  if (!bar||!lbl) return;
  let score=0;
  if (v.length>=8) score++;
  if (/[A-Z]/.test(v)) score++;
  if (/[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  const colors=['var(--red)','var(--red2)','var(--gold)','var(--green)'];
  const labels=['ضعيفة جداً','ضعيفة','متوسطة','قوية'];
  bar.style.width=(score/4*100)+'%'; bar.style.background=colors[score-1]||colors[0];
  lbl.textContent=v?labels[score-1]||'': ''; lbl.style.color=colors[score-1]||'';
}
function checkPassMatch(id1,id2,lblId) {
  const a=document.getElementById(id1)?.value; const b=document.getElementById(id2)?.value;
  const lbl=document.getElementById(lblId); if(!lbl) return;
  if (!b) { lbl.textContent=''; return; }
  lbl.textContent = a===b ? '✓ متطابقة' : '✗ غير متطابقة';
  lbl.style.color  = a===b ? 'var(--green)' : 'var(--red)';
}
function togglePassVis(id, btn) {
  const inp = document.getElementById(id); if (!inp) return;
  inp.type = inp.type==='password' ? 'text' : 'password';
  btn.querySelector('i').className = `fas fa-eye${inp.type==='password'?'':'-slash'}`;
}
function setBtnLoading(id, loading) {
  const btn = document.getElementById(id); if (!btn) return;
  btn.disabled = loading;
  if (loading) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
}

// ── User Profile Modal (missing function fix) ─────────────────
function openUserProfile(userId) {
  const u = STATE.profiles?.find(p => p.id === userId);
  if (!u) { toast('لم يتم العثور على المستخدم', 'error'); return; }

  const col   = APP_CONFIG.ROLE_COLORS?.[u.role] || '#2563eb';
  const dept  = STATE.departments?.find(d => d.id === u.dept_id);
  const semExams = STATE.exams?.filter(e => e.semester === STATE.currentSem) || [];
  const examCount = semExams.filter(e => (e.proctor_ids||[]).includes(u.id)).length;
  const totalPts  = semExams.filter(e => (e.proctor_ids||[]).includes(u.id)).reduce((s,e)=>s+calcPoints(e),0);
  const isSelf    = u.id === STATE.currentUser?.id;

  // Create or reuse modal
  let mo = document.getElementById('moUserProfile');
  if (!mo) {
    mo = document.createElement('div');
    mo.id = 'moUserProfile';
    mo.className = 'mo';
    document.body.appendChild(mo);
  }
  mo.innerHTML = `
    <div class="md" style="max-width:500px">
      <div class="md-hd">
        <h2><i class="fas fa-id-card" style="color:var(--primary2)"></i> بروفايل المستخدم</h2>
        <button class="md-close" onclick="closeMo('moUserProfile')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd">
        <!-- Header -->
        <div style="text-align:center;margin-bottom:20px">
          <div style="width:70px;height:70px;border-radius:18px;background:${col};display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-family:'Cairo',sans-serif;font-size:22px;font-weight:900;color:white;box-shadow:0 4px 14px ${col}60">
            ${u.name?.charAt(0)||'?'}
          </div>
          <div style="font-size:18px;font-weight:900">${u.name || '—'}</div>
          <div style="font-size:12px;color:var(--txt3);margin-top:3px">${u.email || '—'}</div>
          <div style="margin-top:8px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap">
            <span class="badge" style="background:${col}20;color:${col}">
              <i class="fas ${APP_CONFIG.ROLE_ICONS?.[u.role]||'fa-user'}"></i>
              ${APP_CONFIG.ROLES?.[u.role] || u.role}
            </span>
            ${u.active!==false ? `<span class="badge b-green">نشط</span>` : `<span class="badge b-red">غير نشط</span>`}
            ${u.signature ? `<span class="badge b-purple"><i class="fas fa-signature"></i> موقّع</span>` : ''}
          </div>
        </div>

        <div class="divider"></div>

        <!-- Stats -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px">
          <div style="text-align:center;padding:12px;background:var(--bg);border-radius:10px">
            <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--primary)">${examCount}</div>
            <div style="font-size:11px;color:var(--txt3)">امتحانات الفصل</div>
          </div>
          <div style="text-align:center;padding:12px;background:var(--bg);border-radius:10px">
            <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--gold)">${totalPts}</div>
            <div style="font-size:11px;color:var(--txt3)">النقاط</div>
          </div>
          <div style="text-align:center;padding:12px;background:var(--bg);border-radius:10px">
            <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--teal)">${dept?.name?.split(' ')[0]||'—'}</div>
            <div style="font-size:11px;color:var(--txt3)">القسم</div>
          </div>
        </div>

        <!-- Details -->
        <div style="display:flex;flex-direction:column;gap:10px;font-size:13px">
          ${u.emp_id ? `<div style="display:flex;justify-content:space-between"><span style="color:var(--txt2)"><i class="fas fa-id-badge" style="margin-left:6px"></i>الرقم الوظيفي</span><strong>${u.emp_id}</strong></div>` : ''}
          ${u.phone  ? `<div style="display:flex;justify-content:space-between"><span style="color:var(--txt2)"><i class="fas fa-phone" style="margin-left:6px"></i>الهاتف</span><strong>${u.phone}</strong></div>` : ''}
          ${dept     ? `<div style="display:flex;justify-content:space-between"><span style="color:var(--txt2)"><i class="fas fa-sitemap" style="margin-left:6px"></i>القسم</span><strong>${dept.name}</strong></div>` : ''}
        </div>

        ${u.signature ? `
          <div style="margin-top:16px">
            <div style="font-size:12px;font-weight:700;color:var(--txt2);margin-bottom:6px"><i class="fas fa-signature" style="margin-left:5px"></i>التوقيع</div>
            <div style="border:1px solid var(--border);border-radius:8px;padding:8px;background:white;text-align:center">
              <img src="${u.signature}" style="max-height:60px;object-fit:contain">
            </div>
          </div>` : ''}
      </div>
      <div class="md-ft">
        <button class="btn bo" onclick="closeMo('moUserProfile')">إغلاق</button>
        <button class="btn" style="background:var(--teal);color:white;border-color:var(--teal)"
                onclick="closeMo('moUserProfile');_pcTargetUserId='${u.id}';UI.showPage('my-calendar')">
          <i class="fas fa-user-clock"></i> الجدول الشخصي
        </button>
        ${canEdit() ? `<button class="btn bp" onclick="closeMo('moUserProfile');openEditUser('${u.id}')">
          <i class="fas fa-edit"></i> تعديل
        </button>` : ''}
        ${(isAdmin()||isCoord()) ? `<button class="btn" style="background:var(--gold);color:white;border-color:var(--gold)" onclick="closeMo('moUserProfile');openChangePassword('${u.id}')">
          <i class="fas fa-key"></i> تغيير كلمة المرور
        </button>` : ''}
        <button class="btn" style="background:var(--purple2);color:white;border-color:var(--purple2)" onclick="closeMo('moUserProfile');openStaffBiometric('${u.id}')">
          <i class="fas fa-fingerprint"></i> إدارة البصمة
        </button>
      </div>
    </div>`;
  showMo('moUserProfile');
}

// ═══════════════════════════════════════════════════════════════
//  نظام الصلاحيات الذكي — Smart Permissions System v1
//  يُخزَّن في حقل permissions (JSONB) داخل جدول profiles
//  { pages:[...], can_add:[...], can_delete:[...] }
// ═══════════════════════════════════════════════════════════════

// قائمة كل الصفحات مع أسمائها وأيقوناتها وتصنيفاتها
const PERM_PAGES = [
  { section: 'الرئيسية والتقارير' },
  { id:'dashboard',    label:'لوحة التحكم',           icon:'fa-tachometer-alt' },
  { id:'calendar',     label:'التقويم',                icon:'fa-calendar-alt' },
  { id:'analytics',    label:'التحليلات والإحصاءات',   icon:'fa-chart-bar' },
  { section: 'إدارة الامتحانات' },
  { id:'exams',        label:'الامتحانات',              icon:'fa-file-alt' },
  { id:'live',         label:'المراقبة الحية',          icon:'fa-tv' },
  { id:'swaps',        label:'طلبات الاستبدال',         icon:'fa-exchange-alt' },
  { section: 'القاعات' },
  { id:'rooms',        label:'القاعات',                icon:'fa-door-open' },
  { id:'bookings',     label:'حجز القاعات',             icon:'fa-key' },
  { section: 'البيانات الأكاديمية' },
  { id:'departments',  label:'الأقسام',                icon:'fa-sitemap' },
  { id:'subjects',     label:'المواد والشعب',           icon:'fa-book' },
  { id:'proctors',     label:'المراقبون',               icon:'fa-user-tie' },
  { id:'students',     label:'الطلاب',                  icon:'fa-user-graduate' },
  { section: 'النظام والأدوات' },
  { id:'users',        label:'المستخدمون',              icon:'fa-users-cog' },
  { id:'settings',     label:'الإعدادات',               icon:'fa-cog' },
  { id:'log',          label:'سجل النشاط',              icon:'fa-history' },
  { id:'digital-seal', label:'التسليم الرقمي',          icon:'fa-stamp' },
  { id:'class-compare',label:'مقارنة الفصول',           icon:'fa-balance-scale' },
  { id:'ai-engine',    label:'مساعد الذكاء',            icon:'fa-robot' },
];

// الصلاحيات القابلة للتخصيص (إضافة/حذف) لكل قسم وظيفي
const PERM_ACTIONS = [
  { id:'exams',       label:'الامتحانات',        icon:'fa-file-alt' },
  { id:'rooms',       label:'القاعات',           icon:'fa-door-open' },
  { id:'subjects',    label:'المواد والشعب',     icon:'fa-book' },
  { id:'departments', label:'الأقسام',           icon:'fa-sitemap' },
  { id:'students',    label:'الطلاب',            icon:'fa-user-graduate' },
  { id:'bookings',    label:'حجز القاعات',       icon:'fa-key' },
  { id:'proctors',    label:'المراقبون',         icon:'fa-user-tie' },
  { id:'users',       label:'المستخدمون',        icon:'fa-users-cog' },
  { id:'settings',    label:'الإعدادات',         icon:'fa-cog' },
];

// ── فتح نافذة الصلاحيات ─────────────────────────────────────
function openUserPermissions(userId) {
  if (!isAdmin()) { toast('المسؤول فقط يستطيع تعديل الصلاحيات','error'); return; }
  const u = STATE.profiles.find(p => p.id === userId);
  if (!u) return;

  if (u.role === 'admin') {
    toast('المسؤول لديه صلاحيات كاملة دائماً','info'); return;
  }

  const perms = u.permissions || {};
  const userPages    = perms.pages    || null; // null = استخدام الافتراضي
  const userCanAdd   = perms.can_add  || [];
  const userCanDel   = perms.can_delete || [];
  const hasCustom    = perms.pages !== undefined;

  // الصفحات الافتراضية للدور (من NAV في shell)
  const defaultPagesMap = {
    coordinator:    ['dashboard','calendar','exams','live','swaps','rooms','bookings','departments','subjects','proctors','students','analytics','digital-seal','class-compare','ai-engine'],
    dept_head:      ['dashboard','calendar','exams','live','swaps','rooms','bookings','departments','subjects','proctors','students','analytics','class-compare','ai-engine'],
    proctor:        ['my-dashboard','calendar','exams','swaps','bookings','analytics'],
    dean:           ['dashboard','calendar','exams','live','rooms','bookings','departments','subjects','proctors','students','analytics','class-compare'],
    assistant_dean: ['dashboard','calendar','exams','live','rooms','bookings','departments','subjects','proctors','students','analytics','class-compare'],
  };
  const roleDefault = defaultPagesMap[u.role] || [];
  const activePgs   = hasCustom ? (userPages || []) : roleDefault;

  const mo = _getMo('userPermsMo');
  mo.innerHTML = `<div class="md" style="max-width:680px">
    <div class="md-hd">
      <h2 style="display:flex;align-items:center;gap:10px">
        <div style="width:36px;height:36px;border-radius:10px;background:var(--primary)15;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-shield-alt" style="color:var(--primary2)"></i>
        </div>
        صلاحيات: ${u.name}
      </h2>
      <button class="md-close" onclick="closeMo('userPermsMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="max-height:72vh;overflow-y:auto">

      <!-- وضع الصلاحيات -->
      <div style="padding:12px 16px;background:var(--bg);border-radius:12px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
        <div>
          <div style="font-weight:700;font-size:13.5px">وضع الصلاحيات</div>
          <div style="font-size:12px;color:var(--txt2);margin-top:2px">
            ${hasCustom ? '🔧 مخصّص — يعمل بالصلاحيات المحددة أدناه' : '🔄 افتراضي — يعمل بصلاحيات الدور الوظيفي'}
          </div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn bo btn-sm" onclick="_resetToRoleDefaults('${userId}')" title="إعادة للافتراضي">
            <i class="fas fa-undo"></i> إعادة للافتراضي
          </button>
          <button class="btn bp btn-sm" onclick="_selectAllPerms()" title="تحديد الكل">
            <i class="fas fa-check-double"></i> تحديد الكل
          </button>
        </div>
      </div>

      <!-- قسم: الصفحات المسموح بها -->
      <div style="margin-bottom:20px">
        <div style="font-size:12px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;display:flex;align-items:center;gap:6px">
          <i class="fas fa-eye" style="color:var(--primary2)"></i> الصفحات المرئية
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          ${PERM_PAGES.map(pg => {
            if (pg.section) return `<div style="font-size:11px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.8px;margin:8px 0 4px;padding-right:4px">${pg.section}</div>`;
            const on = activePgs.includes(pg.id);
            return `<label style="display:flex;align-items:center;gap:10px;padding:9px 14px;border:1.5px solid ${on?'var(--primary)':'var(--border)'};background:${on?'var(--primary-bg)':''};border-radius:9px;cursor:pointer;transition:all .15s" id="pgLbl_${pg.id}">
              <input type="checkbox" id="perm_pg_${pg.id}" ${on?'checked':''}
                style="accent-color:var(--primary);width:15px;height:15px;flex-shrink:0"
                onchange="_onPermPageToggle('${pg.id}')">
              <i class="fas ${pg.icon}" style="color:${on?'var(--primary2)':'var(--txt3)'};font-size:13px;width:16px;text-align:center" id="pgIc_${pg.id}"></i>
              <span style="font-size:13px;font-weight:600;flex:1">${pg.label}</span>
            </label>`;
          }).join('')}
        </div>
      </div>

      <!-- قسم: صلاحيات الإضافة -->
      <div style="margin-bottom:20px">
        <div style="font-size:12px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;display:flex;align-items:center;gap:6px">
          <i class="fas fa-plus-circle" style="color:var(--green)"></i> صلاحيات الإضافة والتعديل
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:7px">
          ${PERM_ACTIONS.map(ac => {
            const on = userCanAdd.includes(ac.id);
            return `<label style="display:flex;align-items:center;gap:6px;padding:7px 14px;border:1.5px solid ${on?'var(--green)':'var(--border)'};background:${on?'#f0fdf420':''};border-radius:8px;cursor:pointer;font-size:12.5px;transition:all .15s">
              <input type="checkbox" id="perm_add_${ac.id}" ${on?'checked':''}
                style="accent-color:var(--green);width:14px;height:14px">
              <i class="fas ${ac.icon}" style="font-size:11px;color:${on?'var(--green)':'var(--txt3)'}"></i>
              ${ac.label}
            </label>`;
          }).join('')}
        </div>
      </div>

      <!-- قسم: صلاحيات الحذف -->
      <div style="margin-bottom:8px">
        <div style="font-size:12px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;display:flex;align-items:center;gap:6px">
          <i class="fas fa-trash-alt" style="color:var(--red)"></i> صلاحيات الحذف
          <span style="font-size:10px;color:var(--txt3);font-weight:400;text-transform:none;letter-spacing:0">(يُنصح بمنحها بحذر)</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:7px">
          ${PERM_ACTIONS.map(ac => {
            const on = userCanDel.includes(ac.id);
            return `<label style="display:flex;align-items:center;gap:6px;padding:7px 14px;border:1.5px solid ${on?'var(--red)':'var(--border)'};background:${on?'#fef2f220':''};border-radius:8px;cursor:pointer;font-size:12.5px;transition:all .15s">
              <input type="checkbox" id="perm_del_${ac.id}" ${on?'checked':''}
                style="accent-color:var(--red);width:14px;height:14px">
              <i class="fas ${ac.icon}" style="font-size:11px;color:${on?'var(--red)':'var(--txt3)'}"></i>
              ${ac.label}
            </label>`;
          }).join('')}
        </div>
      </div>

    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('userPermsMo')">إلغاء</button>
      <button class="btn bp" style="min-width:140px" onclick="saveUserPermissions('${userId}')">
        <i class="fas fa-shield-alt"></i> حفظ الصلاحيات
      </button>
    </div>
  </div>`;
  showMo('userPermsMo');
}

function _onPermPageToggle(pgId) {
  const cb  = document.getElementById(`perm_pg_${pgId}`);
  const lbl = document.getElementById(`pgLbl_${pgId}`);
  const ic  = document.getElementById(`pgIc_${pgId}`);
  if (!cb || !lbl) return;
  lbl.style.borderColor = cb.checked ? 'var(--primary)' : 'var(--border)';
  lbl.style.background  = cb.checked ? 'var(--primary-bg)' : '';
  if (ic) ic.style.color = cb.checked ? 'var(--primary2)' : 'var(--txt3)';
}

function _selectAllPerms() {
  PERM_PAGES.filter(p=>p.id).forEach(p => {
    const cb = document.getElementById(`perm_pg_${p.id}`); if (!cb) return;
    cb.checked = true; _onPermPageToggle(p.id);
  });
  PERM_ACTIONS.forEach(a => {
    const ca = document.getElementById(`perm_add_${a.id}`); if (ca) ca.checked = true;
    const cd = document.getElementById(`perm_del_${a.id}`); if (cd) cd.checked = true;
  });
}

function _resetToRoleDefaults(userId) {
  const u = STATE.profiles.find(p => p.id === userId); if (!u) return;
  confirmDelete('إعادة صلاحيات المستخدم للافتراضية؟ سيتم حذف كل الصلاحيات المخصصة.', async () => {
    try {
      await dbUpdate('profiles', userId, { permissions: null });
      const pu = STATE.profiles.find(p => p.id === userId);
      if (pu) pu.permissions = null;
      closeMo('userPermsMo');
      toast('✓ تمت إعادة الصلاحيات للافتراضية','success');
    } catch(e) { toast('خطأ: '+e.message,'error'); }
  });
}

async function saveUserPermissions(userId) {
  const pages = PERM_PAGES.filter(p=>p.id && document.getElementById(`perm_pg_${p.id}`)?.checked).map(p=>p.id);
  const can_add = PERM_ACTIONS.filter(a => document.getElementById(`perm_add_${a.id}`)?.checked).map(a=>a.id);
  const can_delete = PERM_ACTIONS.filter(a => document.getElementById(`perm_del_${a.id}`)?.checked).map(a=>a.id);

  const perms = { pages, can_add, can_delete };
  try {
    await dbUpdate('profiles', userId, { permissions: perms });
    const pu = STATE.profiles.find(p => p.id === userId);
    if (pu) pu.permissions = perms;
    closeMo('userPermsMo');
    toast('✓ تم حفظ الصلاحيات بنجاح','success');
    renderUsers();
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

// ════════════════════════════════════════════════════════════════
//  إدارة بصمة الموظف
// ════════════════════════════════════════════════════════════════

async function openStaffBiometric(userId) {
  const user = getProfile(userId);
  if (!user) return;
  const isSelf = userId === STATE.currentUser?.id;

  const mo = _getMo('staffBioMo');
  let creds = [];
  try { creds = await BIO.listForStaff(userId); } catch {}

  const supported = await BIO.isAvailable();
  const isAr = I18N.isAr();

  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-fingerprint" style="color:var(--purple2)"></i> إدارة البصمة · ${esc(user.name)}</h2>
      <button class="md-close" onclick="closeMo('staffBioMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:20px">

      ${!supported ? `
        <div style="padding:18px;border:1px solid var(--red);background:var(--red-bg);border-radius:12px;color:var(--red2);text-align:center;margin-bottom:18px">
          <i class="fas fa-exclamation-triangle" style="font-size:24px"></i>
          <div style="margin-top:8px;font-weight:700">جهازك الحالي لا يدعم البصمة</div>
          <div style="font-size:12px;margin-top:4px">استخدم هاتف به Touch ID / Face ID لتسجيل البصمة</div>
        </div>` : ''}

      <div style="padding:14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--border);margin-bottom:16px">
        <div style="display:flex;align-items:center;gap:10px">
          ${userAvatar(user, 40)}
          <div>
            <div style="font-weight:700;font-size:13px">${esc(user.name)}</div>
            <div style="font-size:11.5px;color:var(--txt2)">${esc(user.email||'—')} · ${APP_CONFIG.ROLES[user.role]||user.role}</div>
          </div>
        </div>
      </div>

      <div style="margin-bottom:16px">
        <div style="font-weight:800;font-size:13px;margin-bottom:10px">
          <i class="fas fa-list" style="color:var(--primary2)"></i> البصمات المسجلة (${creds.length})
        </div>
        ${creds.length ? creds.map(c => `
          <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border:1.5px solid var(--border);border-radius:10px;margin-bottom:8px;background:var(--card)">
            <i class="fas fa-fingerprint" style="color:var(--purple2);font-size:18px"></i>
            <div style="flex:1;min-width:0">
              <div style="font-weight:600;font-size:12.5px">${esc(c.device_label||'جهاز')}</div>
              <div style="font-size:11px;color:var(--txt3)">${c.created_at ? new Date(c.created_at).toLocaleDateString('ar') : '—'}${c.last_used_at?' · آخر استخدام: '+new Date(c.last_used_at).toLocaleDateString('ar'):''}</div>
            </div>
            <button class="btn bd btn-xs" onclick="_deleteStaffBiometric('${userId}')">
              <i class="fas fa-trash"></i>
            </button>
          </div>`).join('') : `
          <div style="text-align:center;padding:20px;color:var(--txt3);border:1.5px dashed var(--border);border-radius:10px">
            <i class="fas fa-fingerprint" style="font-size:28px;opacity:.3;margin-bottom:8px"></i>
            <div style="font-size:12.5px">لا توجد بصمة مسجلة</div>
          </div>`}
      </div>

      ${(isSelf || isAdmin()) && supported ? `
        <button class="btn bp" style="width:100%;padding:14px;font-size:14px" onclick="_registerStaffBiometric('${userId}')">
          <i class="fas fa-fingerprint" style="font-size:18px;margin-left:8px"></i>
          ${creds.length ? 'إضافة جهاز جديد' : 'تسجيل البصمة الآن'}
        </button>` : ''}

      <div style="margin-top:12px;font-size:11.5px;color:var(--txt3);text-align:center;line-height:1.7">
        <i class="fas fa-shield-alt" style="color:var(--green)"></i>
        البصمة مشفرة ومحلية على جهازك — لا يتم إرسال بيانات البصمة
      </div>
    </div>
  </div>`;
  showMo('staffBioMo');
}

async function _registerStaffBiometric(userId) {
  const user = getProfile(userId) || STATE.currentUser;
  if (!user) return;
  const btn = document.querySelector('#staffBioMo .btn.bp');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> ضع إصبعك على المستشعر...'; }
  try {
    await BIO.registerStaff(user);
    toast('✓ تم تسجيل البصمة بنجاح', 'success');
    openStaffBiometric(userId);
  } catch(e) {
    toast(e.message||'فشل التسجيل', 'error');
    if (btn) { btn.disabled=false; btn.innerHTML='<i class="fas fa-fingerprint" style="font-size:18px;margin-left:8px"></i> تسجيل البصمة الآن'; }
  }
}

async function _deleteStaffBiometric(userId) {
  if (!confirm('حذف بصمة هذا المستخدم؟')) return;
  try {
    await BIO.unregisterStaff(userId);
    toast('تم حذف البصمة', 'success');
    openStaffBiometric(userId);
  } catch(e) { toast(e.message, 'error'); }
}
