// ═══════════════════════════════════════════════════════════════
//  rooms.js — إدارة القاعات مع التفاصيل والجدول الزمني
// ═══════════════════════════════════════════════════════════════

const ROOM_TYPES = {
  lecture:    { label: 'قاعة محاضرات',  icon: 'fa-chalkboard-teacher', color: 'var(--primary2)' },
  lab_comp:   { label: 'مختبر حاسوب',   icon: 'fa-desktop',            color: 'var(--teal)'     },
  lab_sci:    { label: 'مختبر علمي',     icon: 'fa-flask',              color: 'var(--green2)'   },
  classroom:  { label: 'فصل دراسي',     icon: 'fa-door-open',          color: 'var(--gold)'     },
  hall:       { label: 'قاعة كبيرة',    icon: 'fa-building',           color: 'var(--purple2)'  },
  seminar:    { label: 'قاعة ندوات',     icon: 'fa-users',              color: 'var(--teal)'     },
  simulation: { label: 'قاعة محاكاة',   icon: 'fa-hospital',           color: 'var(--red2)'     },
  other:      { label: 'أخرى',          icon: 'fa-map-marker-alt',     color: 'var(--txt3)'     }
};

function getRoomTypeInfo(type){ return ROOM_TYPES[type]||ROOM_TYPES.other; }

function _addMinutes(timeStr,mins){
  const [h,m]=timeStr.split(':').map(Number);
  const total=h*60+m+mins;
  return `${String(Math.floor(total/60)%24).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}
function _isRoomBusy(roomId,now){
  return STATE.exams.some(e=>{
    if(!(e.room_ids||[]).includes(roomId))return false;
    const st=new Date(`${e.date}T${e.time}`);
    const en=new Date(st.getTime()+(e.duration+(e.extra_time||0))*60000);
    return now>=st&&now<en;
  });
}
function _getNextExam(roomId,now){
  return STATE.exams
    .filter(e=>(e.room_ids||[]).includes(roomId)&&new Date(`${e.date}T${e.time}`)>now)
    .sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`))[0]||null;
}
function _getRoomTodayExams(roomId,now){
  const today=now.toISOString().split('T')[0];
  return STATE.exams.filter(e=>(e.room_ids||[]).includes(roomId)&&e.date===today);
}

function renderRooms(){
  if(!canEdit()&&!isProctor()&&!isDeptHead()){setHTML('roomsGrid',emptyState('fa-lock','غير مصرح'));return;}
  if(canEdit()) setHTML('roomsActs',`<button class="btn bp btn-sm" onclick="openAddRoom()"><i class="fas fa-plus"></i> قاعة جديدة</button>`);
  const now=new Date();
  const rooms=STATE.rooms;
  if(!rooms.length){setHTML('roomsGrid',emptyState('fa-door-open','لا توجد قاعات','أضف قاعات لتظهر هنا'));return;}
  const activeNow=rooms.filter(r=>_isRoomBusy(r.id,now)).length;
  setHTML('roomsGrid',`
    <div class="stats-grid" style="margin-bottom:18px">
      <div class="stat-card">
        <div class="stat-ic" style="background:var(--primary)20;color:var(--primary2)"><i class="fas fa-door-open"></i></div>
        <div><div class="stat-val">${rooms.length}</div><div class="stat-lbl">إجمالي القاعات</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic" style="background:var(--green)20;color:var(--green2)"><i class="fas fa-circle"></i></div>
        <div><div class="stat-val">${activeNow}</div><div class="stat-lbl">مشغولة الآن</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic" style="background:var(--teal)20;color:var(--teal)"><i class="fas fa-chair"></i></div>
        <div><div class="stat-val">${rooms.reduce((s,r)=>s+(r.cap||0),0)}</div><div class="stat-lbl">إجمالي المقاعد</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic" style="background:var(--gold)20;color:var(--gold)"><i class="fas fa-layer-group"></i></div>
        <div><div class="stat-val">${[...new Set(rooms.map(r=>r.type||'other'))].length}</div><div class="stat-lbl">أنواع القاعات</div></div>
      </div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <div class="sbar" style="flex:1;max-width:280px">
        <i class="fas fa-search"></i>
        <input type="text" id="roomSrch" placeholder="بحث..." oninput="filterRooms()">
      </div>
      <select id="roomTypeFilter" onchange="filterRooms()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;background:var(--card)">
        <option value="">كل الأنواع</option>
        ${Object.entries(ROOM_TYPES).map(([v,t])=>`<option value="${v}">${t.label}</option>`).join('')}
      </select>
      <select id="roomStatusFilter" onchange="filterRooms()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;background:var(--card)">
        <option value="">كل الحالات</option>
        <option value="busy">مشغولة الآن</option>
        <option value="free">متاحة الآن</option>
      </select>
      <select id="roomBldgFilter" onchange="filterRooms()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;background:var(--card)">
        <option value="">كل المباني</option>
        ${[...new Set(rooms.map(r=>r.building).filter(Boolean))].map(b=>`<option value="${b}">${b}</option>`).join('')}
      </select>
    </div>
    <div id="roomsListContainer">${_buildRoomsGrid(rooms,now)}</div>`);
}

function filterRooms(){
  const q    = (document.getElementById('roomSrch')?.value||'').toLowerCase();
  const type = document.getElementById('roomTypeFilter')?.value||'';
  const status = document.getElementById('roomStatusFilter')?.value||'';
  const bldg = document.getElementById('roomBldgFilter')?.value||'';
  const now  = new Date();
  let f = STATE.rooms;
  if(q)      f = f.filter(r=>r.name?.toLowerCase().includes(q)||r.building?.toLowerCase().includes(q));
  if(type)   f = f.filter(r=>(r.type||'other')===type);
  if(bldg)   f = f.filter(r=>r.building===bldg);
  if(status==='busy') f = f.filter(r=>_isRoomBusy(r.id,now));
  if(status==='free') f = f.filter(r=>!_isRoomBusy(r.id,now));
  const c = document.getElementById('roomsListContainer');
  if(c) c.innerHTML=_buildRoomsGrid(f,now);
}

function _buildRoomsGrid(rooms,now){
  if(!rooms.length) return emptyState('fa-search','لا توجد نتائج');
  return `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px">${rooms.map(r=>_buildRoomCard(r,now)).join('')}</div>`;
}

function _buildRoomCard(r,now){
  const info=getRoomTypeInfo(r.type);
  const busy=_isRoomBusy(r.id,now);
  const next=_getNextExam(r.id,now);
  const todayCount=_getRoomTodayExams(r.id,now).length;
  return `<div class="card" style="cursor:pointer;transition:all .2s;border:1.5px solid ${busy?'var(--green)':'var(--border)'}"
    onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.1)'"
    onmouseout="this.style.transform='';this.style.boxShadow=''"
    onclick="openRoomDetail(${r.id})">
    <div style="padding:16px 18px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:42px;height:42px;border-radius:12px;background:${info.color}20;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas ${info.icon}" style="color:${info.color};font-size:18px"></i>
          </div>
          <div>
            <div style="font-weight:800;font-size:14px">${esc(r.name)}</div>
            <div style="font-size:11px;color:var(--txt3)">${info.label}</div>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
          <span class="badge ${busy?'b-green':'b-gray'}" style="font-size:10px">
            <i class="fas fa-circle" style="font-size:7px;margin-left:3px"></i>
            ${busy?'مشغولة':'متاحة'}
          </span>
          ${canEdit()?`<div style="display:flex;gap:4px" onclick="event.stopPropagation()">
            <button class="btn bo btn-xs" onclick="openEditRoom(${r.id})" title="تعديل"><i class="fas fa-edit"></i></button>
            <button class="btn bd btn-xs" onclick="deleteRoom(${r.id})" title="حذف"><i class="fas fa-trash"></i></button>
          </div>`:''}
        </div>
      </div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:11.5px;color:var(--txt2);margin-bottom:8px">
        ${r.building?`<span><i class="fas fa-building" style="margin-left:3px;color:var(--txt3)"></i>${esc(r.building)}</span>`:''}
        ${r.floor?`<span><i class="fas fa-layer-group" style="margin-left:3px;color:var(--txt3)"></i>الطابق ${esc(r.floor)}</span>`:''}
        <span><i class="fas fa-chair" style="margin-left:3px;color:var(--txt3)"></i>${r.cap||0} مقعد</span>
        ${todayCount?`<span style="color:var(--gold)"><i class="fas fa-calendar-day" style="margin-left:3px"></i>${todayCount} امتحان اليوم</span>`:''}
      </div>
      ${busy?_buildBusyBadge(r.id,now):next?`<div style="font-size:11px;color:var(--txt3);padding:5px 9px;background:var(--bg);border-radius:7px"><i class="fas fa-clock" style="margin-left:4px;color:var(--primary2)"></i>التالي: ${getSubject(next.subject_id)?.name||'—'} · ${fmtTime(next.time)}</div>`:''}
    </div>
  </div>`;
}

function _buildBusyBadge(roomId,now){
  const exam=STATE.exams.find(e=>{
    if(!(e.room_ids||[]).includes(roomId))return false;
    const st=new Date(`${e.date}T${e.time}`);
    const en=new Date(st.getTime()+(e.duration+(e.extra_time||0))*60000);
    return now>=st&&now<en;
  });
  if(!exam) return '';
  const sub=getSubject(exam.subject_id);
  const en=new Date(new Date(`${exam.date}T${exam.time}`).getTime()+(exam.duration+(exam.extra_time||0))*60000);
  const rem=Math.max(0,Math.round((en-now)/60000));
  return `<div style="padding:6px 10px;background:var(--green)15;border:1px solid var(--green)40;border-radius:8px;font-size:11.5px">
    <div style="font-weight:700;color:var(--green2)">${sub?.name||'امتحان جارٍ'}</div>
    <div style="color:var(--txt2);margin-top:1px">ينتهي بعد ${rem} دقيقة</div>
  </div>`;
}

function openRoomDetail(id){
  const r=getRoom(id); if(!r) return;
  const now=new Date();
  const today=now.toISOString().split('T')[0];
  const info=getRoomTypeInfo(r.type);
  const busy=_isRoomBusy(id,now);
  const roomExams=STATE.exams.filter(e=>(e.room_ids||[]).includes(id)).sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`));
  const activeExams=roomExams.filter(e=>examStatus(e)==='active');
  const upcomingExams=roomExams.filter(e=>examStatus(e)==='upcoming');
  const completedExams=roomExams.filter(e=>examStatus(e)==='completed').slice(-5).reverse();

  // الحجوزات (غير الامتحانات)
  const roomBookings=(STATE.bookings||[]).filter(b=>b.room_id==id&&b.purpose!=='exam'&&b.date>=today)
    .sort((a,b)=>new Date(`${a.date}T${a.start_time||'00:00'}`)-new Date(`${b.date}T${b.start_time||'00:00'}`));

  const mo=_getMo('roomDetailMo');
  mo.innerHTML=`<div class="md" style="max-width:620px">
    <div class="md-hd">
      <h2 style="display:flex;align-items:center;gap:10px">
        <div style="width:34px;height:34px;border-radius:9px;background:${info.color}20;display:flex;align-items:center;justify-content:center">
          <i class="fas ${info.icon}" style="color:${info.color}"></i>
        </div>
        ${esc(r.name)}
      </h2>
      <button class="md-close" onclick="closeMo('roomDetailMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:0">
      <!-- إحصاءات سريعة -->
      <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;gap:20px;align-items:center;flex-wrap:wrap">
        <div style="display:flex;gap:22px;flex:1">
          <div style="text-align:center"><div style="font-size:24px;font-weight:900;color:var(--primary2)">${r.cap||0}</div><div style="font-size:11px;color:var(--txt3)">مقعد</div></div>
          <div style="text-align:center"><div style="font-size:24px;font-weight:900;color:var(--gold)">${roomExams.length}</div><div style="font-size:11px;color:var(--txt3)">إجمالي</div></div>
          <div style="text-align:center"><div style="font-size:24px;font-weight:900;color:var(--green2)">${upcomingExams.length+activeExams.length}</div><div style="font-size:11px;color:var(--txt3)">قادم</div></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:5px">
          <span class="badge ${busy?'b-green':'b-gray'}" style="font-size:12px;padding:5px 14px"><i class="fas fa-circle" style="font-size:8px;margin-left:4px"></i>${busy?'مشغولة الآن':'متاحة حالياً'}</span>
          <span class="badge b-blue" style="font-size:11px;text-align:center">${info.label}</span>
        </div>
      </div>

      <!-- التقويم المبسط -->
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
        <div id="roomMiniCalHeader" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-weight:800;font-size:13px;color:var(--txt2)"><i class="fas fa-calendar-alt" style="color:var(--primary2);margin-left:6px"></i>التقويم</div>
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn bo btn-xs" onclick="_roomCalPrev(${id})" title="الأسبوع السابق"><i class="fas fa-chevron-right"></i></button>
            <span id="roomCalWeekLabel" style="font-size:12px;font-weight:700;color:var(--txt2)"></span>
            <button class="btn bo btn-xs" onclick="_roomCalNext(${id})" title="الأسبوع القادم"><i class="fas fa-chevron-left"></i></button>
          </div>
        </div>
        <div id="roomMiniCal_${id}"></div>
      </div>

      <!-- الامتحانات الجارية والقادمة -->
      <div style="padding:14px 20px;border-bottom:1px solid var(--border)">
        <div style="font-weight:800;font-size:13px;margin-bottom:10px"><i class="fas fa-graduation-cap" style="color:var(--gold);margin-left:6px"></i>الامتحانات القادمة والجارية <span class="badge b-blue" style="font-size:10px;margin-right:6px">${activeExams.length+upcomingExams.length}</span></div>
        ${(activeExams.concat(upcomingExams)).length
          ? activeExams.concat(upcomingExams).slice(0,10).map(e=>{
              const sub=getSubject(e.subject_id);
              const isNow=examStatus(e)==='active';
              return `<div style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:10px;margin-bottom:6px;background:${isNow?'var(--green)10':'var(--primary)05'};border:1px solid ${isNow?'var(--green)30':'var(--primary)15'}">
                <i class="fas fa-file-alt" style="color:${isNow?'var(--green2)':'var(--primary2)'};flex-shrink:0"></i>
                <div style="flex:1;min-width:0">
                  <div style="font-weight:700;font-size:13px">${sub?.name||'—'}</div>
                  <div style="font-size:11px;color:var(--txt2)">${fmtDate(e.date)} · ${fmtTime(e.time)} · ${e.duration} دق</div>
                </div>
                ${getStatusBadge(examStatus(e))} ${getTypeBadge(e.type)}
              </div>`;
            }).join('')
          : `<div style="padding:16px;text-align:center;color:var(--txt3);font-size:13px"><i class="fas fa-check-circle" style="font-size:24px;display:block;margin-bottom:8px;opacity:.4"></i>لا توجد امتحانات قادمة</div>`}
      </div>

      <!-- الحجوزات الأخرى -->
      ${roomBookings.length ? `<div style="padding:14px 20px;border-bottom:1px solid var(--border)">
        <div style="font-weight:800;font-size:13px;margin-bottom:10px"><i class="fas fa-calendar-check" style="color:var(--teal);margin-left:6px"></i>حجوزات أخرى قادمة <span class="badge b-teal" style="font-size:10px;margin-right:6px">${roomBookings.length}</span></div>
        ${roomBookings.slice(0,5).map(b=>`
          <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:9px;margin-bottom:5px;background:var(--teal)08;border:1px solid var(--teal)20">
            <i class="fas fa-bookmark" style="color:var(--teal);flex-shrink:0"></i>
            <div style="flex:1">
              <div style="font-weight:700;font-size:12.5px">${esc(b.title||'حجز')}</div>
              <div style="font-size:11px;color:var(--txt2)">${fmtDate(b.date)} · ${(b.start_time||'').slice(0,5)} — ${(b.end_time||'').slice(0,5)}</div>
            </div>
          </div>`).join('')}
      </div>` : ''}

      <!-- الامتحانات المنتهية -->
      ${completedExams.length?`<div style="padding:12px 20px">
        <div style="font-weight:700;font-size:13px;margin-bottom:8px;color:var(--txt2)"><i class="fas fa-history" style="margin-left:5px"></i>آخر الامتحانات</div>
        ${completedExams.map(e=>{const sub=getSubject(e.subject_id);return`<div style="display:flex;align-items:center;gap:9px;padding:7px 10px;border-radius:8px;background:var(--bg);margin-bottom:4px;opacity:.75">
          <i class="fas fa-check-circle" style="color:var(--txt3);flex-shrink:0"></i>
          <div style="flex:1;font-size:12.5px;font-weight:600">${sub?.name||'—'}</div>
          <span style="font-size:11px;color:var(--txt3)">${fmtDate(e.date)}</span>
          ${getTypeBadge(e.type)}
        </div>`;}).join('')}
      </div>`:''}
    </div>
    <div class="md-ft">
      ${canEdit()?`<button class="btn bo" onclick="closeMo('roomDetailMo');openEditRoom(${r.id})"><i class="fas fa-edit"></i> تعديل</button>`:''}
      <button class="btn bp" onclick="closeMo('roomDetailMo')">إغلاق</button>
    </div>
  </div>`;
  showMo('roomDetailMo');

  // رسم التقويم للأسبوع الحالي
  STATE._roomCalOffset = STATE._roomCalOffset || 0;
  STATE._roomCalOffset = 0;
  _renderRoomMiniCal(id);
}

// ── التقويم المبسط للقاعة ────────────────────────────────────
function _renderRoomMiniCal(roomId) {
  const container = document.getElementById(`roomMiniCal_${roomId}`);
  if (!container) return;
  const offset = STATE._roomCalOffset || 0;
  const now = new Date();
  // بداية الأسبوع (الأحد)
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay() + (offset * 7));
  startOfWeek.setHours(0,0,0,0);

  const days = [];
  for (let i=0; i<7; i++) {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    days.push(d);
  }

  // تسمية الأسبوع
  const labelEl = document.getElementById('roomCalWeekLabel');
  if (labelEl) {
    const s = days[0], e = days[6];
    labelEl.textContent = `${s.getDate()}/${s.getMonth()+1} — ${e.getDate()}/${e.getMonth()+1}`;
  }

  const dayNames = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
  const todayStr = now.toISOString().split('T')[0];

  container.innerHTML = `<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">
    ${days.map((d, i) => {
      const ds = d.toISOString().split('T')[0];
      const isToday = ds === todayStr;
      const isHol = d.getDay()===5||d.getDay()===6;

      // امتحانات هذه القاعة في هذا اليوم
      const dayExams = STATE.exams.filter(e=>(e.room_ids||[]).includes(roomId)&&e.date===ds);
      // حجوزات هذا اليوم
      const dayBks = (STATE.bookings||[]).filter(b=>b.room_id==roomId&&b.date===ds&&b.purpose!=='exam');

      const hasExam = dayExams.length > 0;
      const hasBk   = dayBks.length > 0;

      let bg = isToday ? 'var(--primary)' : isHol ? 'var(--red2)08' : 'var(--bg)';
      let color = isToday ? 'white' : isHol ? 'var(--red2)' : 'var(--txt1)';
      let border = isToday ? '2px solid var(--primary2)' : '1px solid var(--border)';

      return `<div style="text-align:center;padding:6px 2px;border-radius:9px;background:${bg};border:${border};cursor:default;min-height:60px;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:3px">
        <div style="font-size:10px;font-weight:700;color:${isToday?'rgba(255,255,255,.75)':isHol?'var(--red2)':'var(--txt3)'}">${dayNames[i]}</div>
        <div style="font-size:14px;font-weight:900;color:${color}">${d.getDate()}</div>
        ${hasExam ? dayExams.slice(0,2).map(e=>{
          const s=examStatus(e);
          const dotColor=s==='active'?'#22c55e':s==='upcoming'?'#3b82f6':'#94a3b8';
          return `<div style="width:100%;padding:1px 3px;border-radius:4px;background:${dotColor}22;border-top:2px solid ${dotColor};font-size:9px;font-weight:700;color:${dotColor};white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${getSubject(e.subject_id)?.name||'امتحان'}">${(getSubject(e.subject_id)?.name||'امتحان').slice(0,6)}</div>`;
        }).join('') : ''}
        ${hasBk ? `<div style="width:100%;padding:1px 3px;border-radius:4px;background:var(--teal)20;border-top:2px solid var(--teal);font-size:9px;font-weight:700;color:var(--teal)" title="حجز">📅</div>` : ''}
      </div>`;
    }).join('')}
  </div>`;
}

function _roomCalPrev(roomId) {
  if (!STATE._roomCalOffset) STATE._roomCalOffset = 0;
  STATE._roomCalOffset -= 1;
  _renderRoomMiniCal(roomId);
}
function _roomCalNext(roomId) {
  if (!STATE._roomCalOffset) STATE._roomCalOffset = 0;
  STATE._roomCalOffset += 1;
  _renderRoomMiniCal(roomId);
}

function openAddRoom(){ _buildRoomModal(null); }
function openEditRoom(id){ _buildRoomModal(id); }

function _buildRoomModal(editId){
  const r=editId?getRoom(editId):null;
  const mo=_getMo('roomMo');
  mo.innerHTML=`<div class="md" style="max-width:460px">
    <div class="md-hd">
      <h2><i class="fas fa-door-open" style="color:var(--teal)"></i> ${r?'تعديل':'إضافة'} قاعة</h2>
      <button class="md-close" onclick="closeMo('roomMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">اسم القاعة <span class="req">*</span></label>
        <input type="text" id="rmName" value="${esc(r?.name||'')}" placeholder="قاعة 101"></div>
      <div class="g2">
        <div class="field"><label class="field-lbl">نوع القاعة</label>
          <select id="rmType">
            ${Object.entries(ROOM_TYPES).map(([v,t])=>`<option value="${v}" ${(r?.type||'other')===v?'selected':''}>${t.label}</option>`).join('')}
          </select></div>
        <div class="field"><label class="field-lbl">السعة (مقاعد) <span class="req">*</span></label>
          <input type="number" id="rmCap" value="${r?.cap||30}" min="1"></div>
        <div class="field"><label class="field-lbl">المبنى</label>
          <input type="text" id="rmBldg" value="${esc(r?.building||'')}" placeholder="المبنى الرئيسي"></div>
        <div class="field"><label class="field-lbl">الطابق</label>
          <input type="text" id="rmFloor" value="${esc(r?.floor||'')}" placeholder="الأرضي / الأول..."></div>
      </div>
      <div class="field"><label class="field-lbl">ملاحظات</label>
        <input type="text" id="rmNotes" value="${esc(r?.notes||'')}" placeholder="أي ملاحظات..."></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('roomMo')">إلغاء</button>
      <button class="btn bp" onclick="saveRoom(${editId?editId:'null'})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('roomMo');
}

async function saveRoom(editId){
  const name=document.getElementById('rmName')?.value?.trim();
  const type=document.getElementById('rmType')?.value||'other';
  const bldg=document.getElementById('rmBldg')?.value?.trim();
  const floor=document.getElementById('rmFloor')?.value?.trim();
  const cap=parseInt(document.getElementById('rmCap')?.value||30);
  const notes=document.getElementById('rmNotes')?.value?.trim();
  if(!name){toast('اسم القاعة مطلوب','error');return;}
  const payload={name,type,building:bldg||'',floor:floor||'',cap,notes:notes||''};
  try{
    if(editId&&editId!=='null'){
      const res=await SB.update('rooms',editId,payload);
      const idx=STATE.rooms.findIndex(r=>r.id==editId);
      if(idx>=0) STATE.rooms[idx]={...STATE.rooms[idx],...payload,...(res||{})};
    } else {
      const res=await SB.insert('rooms',payload);
      STATE.rooms.push(res||payload);
    }
    closeMo('roomMo'); renderRooms();
    toast('✓ تم حفظ القاعة','success');
    await addLog(`${editId&&editId!=='null'?'تعديل':'إضافة'} قاعة`,'room',name);
  }catch(e){toast('خطأ: '+e.message,'error');}
}

async function deleteRoom(id){
  const r=getRoom(id);
  const inUse=STATE.exams.some(e=>(e.room_ids||[]).includes(id));
  const msg=inUse?`القاعة "${r?.name}" مستخدمة في ${STATE.exams.filter(e=>(e.room_ids||[]).includes(id)).length} امتحان. هل أنت متأكد؟`:`حذف القاعة "${r?.name}"؟`;
  confirmDelete(msg,async()=>{
    try{
      await dbDelete('rooms',id);
      STATE.rooms=STATE.rooms.filter(r=>r.id!=id);
      renderRooms();
      toast('تم حذف القاعة','info');
      await addLog('حذف قاعة','room',r?.name||'');
    }catch(e){toast('فشل الحذف: '+e.message,'error');}
  });
}

function _getMo(id){
  let mo=document.getElementById(id);
  if(!mo){mo=document.createElement('div');mo.className='mo';mo.id=id;document.body.appendChild(mo);}
  return mo;
}
