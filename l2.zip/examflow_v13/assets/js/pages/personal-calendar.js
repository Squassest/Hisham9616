// personal-calendar.js v2 — التقويم الشخصي (موظفون + طلاب)

let _pcYear  = new Date().getFullYear();
let _pcMonth = new Date().getMonth();
let _pcMode  = 'month'; // month | week | list
let _pcTargetUserId = null; // للمنسق / رئيس القسم: رؤية تقويم مستخدم آخر

// ═══════════════════════════════════════════════════════════
//  الدخول الرئيسي
// ═══════════════════════════════════════════════════════════
function renderMyCalendar() {
  // وضع الطالب
  if (STATE._studentUser) {
    _renderStudentCalendar(STATE._studentUser);
    return;
  }

  const me = STATE.currentUser;
  if (!me) return;

  // رئيس القسم: يرى قائمة أعضاء قسمه أيضاً
  const isDH = isDeptHead();
  const myDeptMembers = isDH
    ? STATE.profiles.filter(p => p.dept_id === me.dept_id && p.id !== me.id && p.active)
    : [];

  const targetId   = _pcTargetUserId || me.id;
  const targetUser = getProfile(targetId) || me;

  let headerHTML = `
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px">
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:44px;height:44px;border-radius:12px;background:${targetUser.color||'var(--primary2)'};display:flex;align-items:center;justify-content:center">
          <span style="color:white;font-size:18px;font-weight:800">${targetUser.name?.charAt(0)||'؟'}</span>
        </div>
        <div>
          <div style="font-weight:800;font-size:15px">${targetId === me.id ? 'تقويمي الشخصي' : `تقويم: ${targetUser.name}`}</div>
          <div style="font-size:11.5px;color:var(--txt2)">${APP_CONFIG.ROLES?.[targetUser.role]||targetUser.role}</div>
        </div>
      </div>`;

  if (isDH && myDeptMembers.length) {
    headerHTML += `
      <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
        <span style="font-size:11.5px;color:var(--txt3);font-weight:600">أعضاء القسم:</span>
        <button class="btn btn-xs ${!_pcTargetUserId?'bp':'bo'}" onclick="_pcTargetUserId=null;renderMyCalendar()" style="font-size:11px">
          <i class="fas fa-user"></i> أنا
        </button>
        ${myDeptMembers.map(m => `
          <button class="btn btn-xs ${_pcTargetUserId===m.id?'bp':'bo'}" onclick="_pcTargetUserId='${m.id}';renderMyCalendar()" style="font-size:11px">
            ${m.name?.split(' ').slice(0,2).join(' ')}
          </button>`).join('')}
      </div>`;
  }

  headerHTML += `
      <div class="tabs" style="margin:0;margin-right:auto">
        <div class="tab ${_pcMode==='month'?'active':''}" onclick="_pcMode='month';renderMyCalendar()"><i class="fas fa-calendar-alt"></i> شهري</div>
        <div class="tab ${_pcMode==='week'?'active':''}"  onclick="_pcMode='week';renderMyCalendar()"><i class="fas fa-calendar-week"></i> أسبوعي</div>
        <div class="tab ${_pcMode==='list'?'active':''}"  onclick="_pcMode='list';renderMyCalendar()"><i class="fas fa-list"></i> قائمة</div>
      </div>
    </div>`;

  setHTML('myCalendarContent', headerHTML + `<div id="pcMain"></div>`);

  if (_pcMode === 'month')     _renderPCMonth(targetId);
  else if (_pcMode === 'week') _renderPCWeek(targetId);
  else                         _renderPCList(targetId);
}

// ═══════════════════════════════════════════════════════════
//  تقويم الطالب
// ═══════════════════════════════════════════════════════════
function _renderStudentCalendar(student) {
  const enrolledSubjNames = (student.subject_ids || [])
    .map(id => getSubject(id)?.name).filter(Boolean);

  const headerHTML = `
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px">
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#0ea5e9,#2563eb);display:flex;align-items:center;justify-content:center">
          <i class="fas fa-user-graduate" style="color:white;font-size:18px"></i>
        </div>
        <div>
          <div style="font-weight:800;font-size:15px">تقويمي الدراسي</div>
          <div style="font-size:11.5px;color:var(--txt2)">${student.name} · ${student.stud_id}</div>
          ${enrolledSubjNames.length
            ? `<div style="font-size:10.5px;color:var(--txt3);margin-top:2px">${enrolledSubjNames.slice(0,3).join(' · ')}${enrolledSubjNames.length>3?' · ...':''}</div>`
            : ''}
        </div>
      </div>
      <div class="tabs" style="margin:0;margin-right:auto">
        <div class="tab ${_pcMode==='month'?'active':''}" onclick="_pcMode='month';renderMyCalendar()"><i class="fas fa-calendar-alt"></i> شهري</div>
        <div class="tab ${_pcMode==='week'?'active':''}"  onclick="_pcMode='week';renderMyCalendar()"><i class="fas fa-calendar-week"></i> أسبوعي</div>
        <div class="tab ${_pcMode==='list'?'active':''}"  onclick="_pcMode='list';renderMyCalendar()"><i class="fas fa-list"></i> قائمة</div>
      </div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px">
      <span style="font-size:11px;display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:50%;background:#2563eb;display:inline-block"></span> امتحان نهائي</span>
      <span style="font-size:11px;display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:50%;background:#d97706;display:inline-block"></span> منتصف الفصل</span>
      <span style="font-size:11px;display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:50%;background:#0891b2;display:inline-block"></span> اختبار</span>
      <span style="font-size:11px;display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:50%;background:#0d9488;display:inline-block"></span> محاضرة/مختبر</span>
    </div>`;

  setHTML('myCalendarContent', headerHTML + `<div id="pcMain"></div>`);

  if (_pcMode === 'month')     _renderPCMonth('__student__');
  else if (_pcMode === 'week') _renderPCWeek('__student__');
  else                         _renderPCList('__student__');
}

// ═══════════════════════════════════════════════════════════
//  جمع أحداث المستخدم (موظف أو طالب)
// ═══════════════════════════════════════════════════════════
function _getUserEvents(userId, rangeStart, rangeEnd) {
  if (userId === '__student__' && STATE._studentUser) {
    return _getStudentEvents(STATE._studentUser, rangeStart, rangeEnd);
  }
  return _getStaffEvents(userId, rangeStart, rangeEnd);
}

// ── أحداث الموظف ──────────────────────────────────────────
function _getStaffEvents(userId, rangeStart, rangeEnd) {
  const events = [];

  // 1. الحجوزات المضافة للجدول الشخصي
  const myBkIds = STATE.userBookings
    .filter(ub => ub.user_id === userId)
    .map(ub => ub.booking_id);
  STATE.bookings
    .filter(b => {
      if (!myBkIds.includes(b.id)) return false;
      if (rangeStart && b.date < rangeStart) return false;
      if (rangeEnd   && b.date > rangeEnd)   return false;
      return true;
    })
    .forEach(b => {
      const room = getRoom(b.room_id);
      const subj = b.subject_id ? getSubject(b.subject_id) : null;
      events.push({
        date:       b.date,
        start_time: b.start_time?.slice(0,5) || '00:00',
        end_time:   b.end_time?.slice(0,5)   || '',
        title:      b.title,
        subtitle:   subj?.name || room?.name || '',
        color:      APP_CONFIG.BOOKING_PURPOSES?.[b.purpose]?.color || 'var(--teal)',
        icon:       'fa-key',
        type:       'booking',
        id:         b.id,
        recurring:  !!b.recurrence
      });
    });

  // 2. امتحانات المراقبة — يُضاف للتقويم حال التعيين
  // ✅ القاعدة: يظهر سواء كان معلّقاً أو مقبولاً (لمنع تعارضات مستقبلية)
  //    يُحذف من التقويم تلقائياً في حالتين:
  //    1) الرفض من المراقب → الفلتر يستبعد 'rejected'
  //    2) التبادل → بعد القبول يُحذَف uid من proctor_ids فيستبعده الشرط الأول
  //    3) الامتحان نفسه معلّق/مرفوض من المراجعة (approval_status) → لا يظهر
  STATE.exams
    .filter(e => {
      if (!(e.proctor_ids||[]).includes(userId)) return false;
      // ✅ امتحان لم يُوافَق عليه بعد → لا يظهر للمراقب
      if (e.approval_status === 'pending' || e.approval_status === 'rejected') return false;
      const pstatus = (e.proctor_statuses||{})[userId];
      if (pstatus === 'rejected') return false;     // المرفوضة لا تظهر
      if (rangeStart && e.date < rangeStart) return false;
      if (rangeEnd   && e.date > rangeEnd)   return false;
      return true;
    })
    .forEach(e => {
      const sub = getSubject(e.subject_id);
      const typeColors = { final:'#2563eb', midterm:'#d97706', quiz:'#0891b2', makeup:'#7c3aed' };
      const status = getProctorStatus(e.id, userId);
      // علامة بصرية إذا كان معلّقاً
      const isPending = status === 'pending';
      events.push({
        date:       e.date,
        start_time: e.time?.slice(0,5) || '00:00',
        end_time:   '',
        title:      `${isPending?'⏳':'🎓'} ${sub?.name||'امتحان'}`,
        subtitle:   `${e.type==='final'?'نهائي':e.type==='midterm'?'منتصف':'اختبار'} · ${e.duration} دق${isPending?' · بانتظار قبولك':''}`,
        color:      typeColors[e.type]||'#7c3aed',
        icon:       'fa-file-alt',
        type:       'exam',
        id:         e.id,
        status,
        isPending
      });
    });

  return events.sort((a,b) => (a.date+a.start_time).localeCompare(b.date+b.start_time));
}

// ── أحداث الطالب ──────────────────────────────────────────
function _getStudentEvents(student, rangeStart, rangeEnd) {
  const events = [];
  const sectIds = new Set((student.section_ids || []).map(Number));
  const subjIds = new Set((student.subject_ids || []).map(Number));

  // بناء sectIds من شعب الطالب
  const allStudentSectIds = new Set();
  STATE.sections.forEach(sec => {
    if ((sec.student_ids||[]).includes(student.id)) allStudentSectIds.add(Number(sec.id));
  });
  sectIds.forEach(id => allStudentSectIds.add(id));

  // 1. الامتحانات التي سُجّل فيها الطالب (عبر الشُّعب أو المواد المباشرة)
  const seenExamIds = new Set();
  STATE.exams.forEach(e => {
    const examSections = (e.section_ids || []).map(Number);
    // تسجيل عبر شعبة
    const enrolledViaSection = examSections.some(sId => allStudentSectIds.has(sId));
    // تسجيل عبر مادة مباشرة (بدون شعبة محددة — الامتحان للكل)
    const enrolledViaSubject = subjIds.has(Number(e.subject_id)) && (!examSections.length);
    const isEnrolled = enrolledViaSection || enrolledViaSubject;
    if (!isEnrolled) return;
    if (seenExamIds.has(e.id)) return; seenExamIds.add(e.id);
    if (rangeStart && e.date < rangeStart) return;
    if (rangeEnd   && e.date > rangeEnd)   return;

    const sub        = getSubject(e.subject_id);
    const typeColors = { final:'#2563eb', midterm:'#d97706', quiz:'#0891b2', makeup:'#7c3aed' };
    const typeLabels = { final:'نهائي', midterm:'منتصف الفصل', quiz:'اختبار', makeup:'تعويضي' };
    const st         = examStatus(e);
    const stBadge    = st === 'active'    ? '🔴 جارٍ الآن'
                     : st === 'upcoming'  ? '🕐 قادم'
                     : '✅ منتهٍ';

    events.push({
      date:       e.date,
      start_time: e.time?.slice(0,5) || '00:00',
      end_time:   '',
      title:      `📋 ${sub?.name || 'امتحان'}`,
      subtitle:   `${typeLabels[e.type] || e.type} · ${e.duration} دقيقة · ${stBadge}`,
      color:      typeColors[e.type] || '#7c3aed',
      icon:       'fa-file-alt',
      type:       'exam',
      id:         e.id,
      examSt:     st
    });
  });

  // 2. الجدول الأسبوعي الدراسي (متكرر)
  if (rangeStart && rangeEnd) {
    const schedSource = (STATE.semesterSchedules?.length
      ? STATE.semesterSchedules
      : STATE.schedules
    ).filter(sc => sc.is_active !== false);

    schedSource.forEach(sc => {
      const scSectId = sc.section_id ? Number(sc.section_id) : null;
      const scSubjId = sc.subject_id ? Number(sc.subject_id) : null;
      if (!sectIds.has(scSectId) && !subjIds.has(scSubjId)) return;

      const sub     = scSubjId ? getSubject(scSubjId) : null;
      const section = scSectId ? getSection(scSectId) : null;
      const room    = sc.room_id ? getRoom(sc.room_id) : null;
      const typeMap = { lecture:'محاضرة', lab:'مختبر', tutorial:'تمارين', seminar:'ندوة' };

      // جمع كل أيام المدى تطابق اليوم الأسبوعي
      const start   = new Date(rangeStart);
      const end     = new Date(rangeEnd);
      const current = new Date(start);
      // تقديم إلى أول يوم مطابق
      const dayDiff = (sc.day_of_week - current.getDay() + 7) % 7;
      current.setDate(current.getDate() + dayDiff);

      while (current <= end) {
        const ds = current.toISOString().split('T')[0];
        events.push({
          date:       ds,
          start_time: sc.start_time?.slice(0,5) || '08:00',
          end_time:   sc.end_time?.slice(0,5)   || '',
          title:      `📚 ${sub?.name || 'محاضرة'}`,
          subtitle:   [typeMap[sc.type]||sc.type, section?.name, room?.name].filter(Boolean).join(' · '),
          color:      '#0d9488',
          icon:       'fa-chalkboard-teacher',
          type:       'schedule',
          id:         sc.id,
          recurring:  true
        });
        current.setDate(current.getDate() + 7);
      }
    });
  }

  return events.sort((a,b) => (a.date+a.start_time).localeCompare(b.date+b.start_time));
}

// ═══════════════════════════════════════════════════════════
//  حساب نطاق الشهر المعروض
// ═══════════════════════════════════════════════════════════
function _monthRange() {
  const ys = String(_pcYear), ms = String(_pcMonth+1).padStart(2,'0');
  const daysInMonth = new Date(_pcYear, _pcMonth+1, 0).getDate();
  return { start: `${ys}-${ms}-01`, end: `${ys}-${ms}-${String(daysInMonth).padStart(2,'0')}` };
}

// ═══════════════════════════════════════════════════════════
//  عرض شهري
// ═══════════════════════════════════════════════════════════
function _renderPCMonth(userId) {
  const el = document.getElementById('pcMain'); if (!el) return;
  const { start, end } = _monthRange();
  const events    = _getUserEvents(userId, start, end);
  const today     = new Date().toISOString().split('T')[0];
  const months    = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  const days      = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
  const firstDay  = new Date(_pcYear, _pcMonth, 1).getDay();
  const daysCount = new Date(_pcYear, _pcMonth+1, 0).getDate();
  const monthKey  = `${_pcYear}-${String(_pcMonth+1).padStart(2,'0')}`;
  const monthEvts = events.filter(e => e.date.startsWith(monthKey));

  const byDate = {};
  monthEvts.forEach(e => { if (!byDate[e.date]) byDate[e.date]=[]; byDate[e.date].push(e); });

  let cells = '';
  for (let i=0; i<firstDay; i++) cells += `<div style="min-height:90px;border-radius:8px;background:var(--bg);opacity:.4"></div>`;
  for (let d=1; d<=daysCount; d++) {
    const ds     = `${_pcYear}-${String(_pcMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday = ds === today;
    const dayEvts = byDate[ds] || [];
    cells += `
      <div style="min-height:90px;border-radius:8px;border:1.5px solid ${isToday?'var(--primary)':'var(--border)'};padding:6px;background:${isToday?'var(--primary)08':'var(--card)'};transition:all .2s;cursor:pointer"
           onmouseover="this.style.boxShadow='0 4px 14px rgba(0,0,0,.1)'" onmouseout="this.style.boxShadow=''"
           onclick="_showPCDayDetail('${ds}',${JSON.stringify(dayEvts).replace(/"/g,'&quot;')})">
        <div style="font-weight:700;font-size:13px;color:${isToday?'var(--primary)':'inherit'};margin-bottom:4px">${d}</div>
        ${dayEvts.slice(0,3).map(ev => `
          <div style="font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:2px 5px;border-radius:4px;background:${ev.color}20;color:${ev.color};border-right:3px solid ${ev.color};margin-bottom:2px">
            ${ev.recurring?'🔁 ':''}${ev.title}
          </div>`).join('')}
        ${dayEvts.length>3?`<div style="font-size:9.5px;color:var(--txt3)">+${dayEvts.length-3} أخرى</div>`:''}
      </div>`;
  }

  el.innerHTML = `
    <div class="card" style="padding:18px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <button class="btn bo" style="width:36px;height:36px;padding:0" onclick="_pcMonth--;if(_pcMonth<0){_pcMonth=11;_pcYear--}renderMyCalendar()">
          <i class="fas fa-chevron-right"></i>
        </button>
        <div style="text-align:center">
          <div style="font-size:20px;font-weight:900">${months[_pcMonth]} ${_pcYear}</div>
          <div style="font-size:12px;color:var(--txt3)">${monthEvts.length} حدث هذا الشهر</div>
        </div>
        <button class="btn bo" style="width:36px;height:36px;padding:0" onclick="_pcMonth++;if(_pcMonth>11){_pcMonth=0;_pcYear++}renderMyCalendar()">
          <i class="fas fa-chevron-left"></i>
        </button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;margin-bottom:6px">
        ${days.map((d,i)=>`<div style="text-align:center;font-size:10.5px;font-weight:700;color:${i===5||i===6?'var(--red2)':'var(--txt3)'};padding:4px 0">${d}</div>`).join('')}
      </div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">${cells}</div>
    </div>
    <div id="pcDayDetail" style="margin-top:12px"></div>`;
}

// ═══════════════════════════════════════════════════════════
//  تفاصيل يوم
// ═══════════════════════════════════════════════════════════
function _showPCDayDetail(date, evtsJson) {
  const el = document.getElementById('pcDayDetail'); if (!el) return;
  const evts = typeof evtsJson === 'string' ? JSON.parse(evtsJson) : evtsJson;
  if (!evts.length) { el.innerHTML=''; return; }
  const [y,m,d] = date.split('-');
  const isStudentMode = !!STATE._studentUser;

  el.innerHTML = `
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-calendar-day" style="color:var(--primary2)"></i> ${d}/${m}/${y} · ${evts.length} أحداث</h3>
      </div>
      ${evts.map(ev => `
        <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);transition:background .15s"
             onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
          <div style="width:42px;height:42px;border-radius:10px;background:${ev.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas ${ev.icon||'fa-calendar'}" style="color:${ev.color};font-size:16px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:13px">${ev.recurring?'🔁 ':''}${ev.title}</div>
            <div style="font-size:11.5px;color:var(--txt2)">${ev.start_time}${ev.end_time?' – '+ev.end_time:''} · ${ev.subtitle}</div>
          </div>
          ${ev.type==='exam' && !isStudentMode ? `
          <div>
            ${ev.status==='accepted'
              ? `<span class="badge b-green" style="font-size:10.5px"><i class="fas fa-check-circle"></i> قبلتُ المراقبة</span>`
              : ev.status==='rejected'
              ? `<span class="badge b-red" style="font-size:10.5px"><i class="fas fa-times-circle"></i> رفضتُ</span>`
              : `<div style="display:flex;gap:5px">
                  <button class="btn btn-xs" style="background:var(--green);color:white;border-color:var(--green);font-size:10.5px" onclick="_acceptProctoring(${ev.id},'${date}')">
                    <i class="fas fa-check"></i> قبول
                  </button>
                  <button class="btn btn-xs" style="background:var(--red);color:white;border-color:var(--red);font-size:10.5px" onclick="_rejectProctoring(${ev.id},'${date}')">
                    <i class="fas fa-times"></i> رفض
                  </button>
                </div>`}
          </div>` : ''}
          ${ev.type==='exam' && isStudentMode && ev.examSt ? `
          <div>
            ${ev.examSt==='active'
              ? `<span class="badge" style="background:#ef4444;color:white;font-size:10.5px">🔴 جارٍ الآن</span>`
              : ev.examSt==='upcoming'
              ? `<span class="badge" style="background:#3b82f6;color:white;font-size:10.5px">⏰ قادم</span>`
              : `<span class="badge b-green" style="font-size:10.5px">✅ منتهٍ</span>`}
          </div>` : ''}
        </div>`).join('')}
    </div>`;
}

// ═══════════════════════════════════════════════════════════
//  عرض أسبوعي
// ═══════════════════════════════════════════════════════════
function _renderPCWeek(userId) {
  const el = document.getElementById('pcMain'); if (!el) return;
  const today       = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);

  const rangeStart = startOfWeek.toISOString().split('T')[0];
  const rangeEnd   = endOfWeek.toISOString().split('T')[0];

  const weekDates = Array.from({length:7}, (_,i) => {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  const events = _getUserEvents(userId, rangeStart, rangeEnd);
  const hours   = Array.from({length:14}, (_,i) => i+6);
  const days    = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
  const byDate  = {};
  weekDates.forEach(d => { byDate[d] = events.filter(e => e.date === d); });
  const todayStr = today.toISOString().split('T')[0];

  el.innerHTML = `
    <div class="card" style="overflow:hidden">
      <div class="card-h"><h3><i class="fas fa-calendar-week" style="color:var(--primary2)"></i> الجدول الأسبوعي</h3></div>
      <div style="overflow-x:auto">
        <table style="width:100%;min-width:700px;border-collapse:collapse">
          <thead>
            <tr style="background:var(--bg)">
              <th style="width:60px;padding:8px;font-size:11px;color:var(--txt3);border-bottom:1px solid var(--border)">الوقت</th>
              ${weekDates.map((d,i) => {
                const [,m,day] = d.split('-');
                const isT = d === todayStr;
                return `<th style="min-width:90px;padding:8px;text-align:center;border-bottom:1px solid var(--border);border-right:1px solid var(--border);${isT?'background:var(--primary)08':''}">
                  <div style="font-size:11.5px;font-weight:700;color:${i>=5?'var(--red2)':isT?'var(--primary)':'inherit'}">${days[i]}</div>
                  <div style="font-size:10px;color:var(--txt3)">${day}/${m}</div>
                </th>`;
              }).join('')}
            </tr>
          </thead>
          <tbody>
            ${hours.map(h => `
              <tr>
                <td style="padding:6px;text-align:center;font-size:11px;color:var(--txt3);border-bottom:1px solid var(--border);white-space:nowrap">${h}:00</td>
                ${weekDates.map((d,di) => {
                  const hEvts = (byDate[d]||[]).filter(e => parseInt(e.start_time?.split(':')[0]||0) === h);
                  return `<td style="border-bottom:1px solid var(--border);border-right:1px solid var(--border);padding:3px;vertical-align:top;min-height:38px;${di>=5?'background:var(--bg)':''};${d===todayStr?'background:var(--primary)04':''}">
                    ${hEvts.map(ev => `
                      <div style="background:${ev.color};color:white;padding:4px 6px;border-radius:5px;font-size:10px;margin-bottom:2px;cursor:pointer;overflow:hidden;white-space:nowrap;text-overflow:ellipsis"
                           title="${ev.title}">
                        ${ev.recurring?'🔁 ':''}${ev.title}
                        <div style="font-size:9px;opacity:.85">${ev.start_time}${ev.end_time?'–'+ev.end_time:''}</div>
                      </div>`).join('')}
                  </td>`;
                }).join('')}
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════
//  عرض قائمة
// ═══════════════════════════════════════════════════════════
function _renderPCList(userId) {
  const el = document.getElementById('pcMain'); if (!el) return;
  const isStudentMode = (userId === '__student__');

  // للقائمة: نجلب أحداث الأشهر الستة القادمة + الشهرين السابقَين
  const today    = new Date();
  const d1       = new Date(today); d1.setMonth(d1.getMonth() - 2);
  const d2       = new Date(today); d2.setMonth(d2.getMonth() + 6);
  const rangeStart = d1.toISOString().split('T')[0];
  const rangeEnd   = d2.toISOString().split('T')[0];
  const todayStr   = today.toISOString().split('T')[0];

  const events   = _getUserEvents(userId, rangeStart, rangeEnd);
  const upcoming = events.filter(e => e.date >= todayStr);
  const past     = events.filter(e => e.date < todayStr);

  const buildSection = (title, evts, icon, color) => {
    if (!evts.length) return '';
    return `
      <div class="card" style="margin-bottom:12px">
        <div class="card-h"><h3><i class="fas ${icon}" style="color:${color}"></i> ${title} (${evts.length})</h3></div>
        ${evts.map(ev => `
          <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);transition:background .15s"
               onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
            <div style="width:6px;height:40px;border-radius:3px;background:${ev.color};flex-shrink:0"></div>
            <div style="flex:1;min-width:0">
              <div style="font-weight:700;font-size:13px">${ev.recurring?'<i class="fas fa-redo" style="color:var(--teal);font-size:10px;margin-left:3px"></i>':''}${ev.title}</div>
              <div style="font-size:11.5px;color:var(--txt2)">${ev.date} · ${ev.start_time}${ev.end_time?' – '+ev.end_time:''} · ${ev.subtitle}</div>
            </div>
            ${ev.type==='exam' && !isStudentMode ? `
              <div>
                ${ev.status==='accepted'
                  ? `<span class="badge b-green" style="font-size:10.5px"><i class="fas fa-check-circle"></i> قبلتُ</span>`
                  : ev.status==='rejected'
                  ? `<span class="badge b-red" style="font-size:10.5px">رفضتُ</span>`
                  : `<div style="display:flex;gap:4px">
                      <button class="btn btn-xs" style="background:var(--green);color:white;border-color:var(--green)" onclick="_acceptProctoring(${ev.id},'${ev.date}')">قبول</button>
                      <button class="btn btn-xs" style="background:var(--red);color:white;border-color:var(--red)" onclick="_rejectProctoring(${ev.id},'${ev.date}')">رفض</button>
                    </div>`}
              </div>` : ''}
            ${ev.type==='exam' && isStudentMode && ev.examSt ? `
              ${ev.examSt==='active'
                ? `<span class="badge" style="background:#ef4444;color:white;font-size:10.5px">🔴 جارٍ</span>`
                : ev.examSt==='upcoming'
                ? `<span class="badge" style="background:#3b82f6;color:white;font-size:10.5px">⏰ قادم</span>`
                : `<span class="badge b-green" style="font-size:10.5px">✅ انتهى</span>`}` : ''}
          </div>`).join('')}
      </div>`;
  };

  el.innerHTML = buildSection(
    isStudentMode ? 'الامتحانات والمحاضرات القادمة' : 'الأحداث القادمة',
    upcoming, 'fa-calendar-check', 'var(--primary2)'
  ) || `<div style="text-align:center;padding:40px;color:var(--txt3)">
          <i class="fas fa-calendar-check" style="font-size:48px;opacity:.2;margin-bottom:12px"></i>
          <div style="font-weight:700">لا توجد أحداث قادمة</div>
        </div>`;
  el.innerHTML += buildSection(
    isStudentMode ? 'الامتحانات والمحاضرات السابقة' : 'الأحداث السابقة',
    past, 'fa-history', 'var(--txt3)'
  );
}

// ═══════════════════════════════════════════════════════════
//  قبول / رفض طلب المراقبة (للموظفين فقط)
// ═══════════════════════════════════════════════════════════
async function _acceptProctoring(examId, date) {
  await _respondToProctoring(examId, 'accepted');
}

async function _rejectProctoring(examId, date) {
  const reason = prompt('سبب الرفض (اختياري):') || '';
  await _respondToProctoring(examId, 'rejected', reason);
}

async function _respondToProctoring(examId, status, notes='') {
  const uid = STATE.currentUser?.id;
  if (!uid) return;
  try {
    await SB.updateProctorStatus(examId, uid, status);

    const exam = getExam(examId);
    const sub  = getSubject(exam?.subject_id);
    const statusLbl = status === 'accepted' ? 'قبل المراقبة' : 'رفض المراقبة';
    const me   = STATE.currentUser;

    const coord = STATE.profiles.find(p =>
      (p.role === 'coordinator' || p.role === 'admin') && p.dept_id === me.dept_id
    );
    if (coord) {
      await SB.insert('notifications', {
        user_id:    coord.id,
        type:       'proctor_response',
        title:      `${me.name?.split(' ').slice(0,2).join(' ')} ${statusLbl}`,
        body:       `للامتحان: ${sub?.name||'—'} بتاريخ ${exam?.date||'—'}`,
        exam_id:    examId,
        is_read:    false,
        created_at: new Date().toISOString()
      });
    }

    const crossReq = STATE.crossDeptRequests.find(r =>
      r.exam_id === examId && r.assigned_proctor_id === uid
    );
    if (crossReq) {
      const targetDeptHead = STATE.profiles.find(p =>
        p.role === 'dept_head' && p.dept_id === crossReq.target_dept_id
      );
      if (targetDeptHead) {
        await SB.insert('notifications', {
          user_id:    targetDeptHead.id,
          type:       'proctor_response',
          title:      `مراقب ${me.name?.split(' ').slice(0,2).join(' ')} ${statusLbl}`,
          body:       `طلب مراقبة خارجي للامتحان: ${sub?.name||'—'}`,
          exam_id:    examId,
          is_read:    false,
          created_at: new Date().toISOString()
        });
      }
    }

    toast(status==='accepted'?'تم قبول المراقبة ✓':'تم رفض المراقبة','success');
    renderMyCalendar();
  } catch(e) { toast(e.message,'error'); }
}
