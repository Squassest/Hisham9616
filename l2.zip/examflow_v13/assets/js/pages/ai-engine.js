// ═══════════════════════════════════════════════════════════════
//  ai-engine.js — مساعد الذكاء الاصطناعي v1
//  تحليل التعارضات + توليد جدول مثالي + اقتراح المراقبين
// ═══════════════════════════════════════════════════════════════

function renderAIEngine() {
  setHTML('aiActs', `
    <button class="btn bp btn-sm" onclick="_runFullAIAnalysis()">
      <i class="fas fa-brain"></i> تشغيل التحليل الكامل
    </button>
    <button class="btn bo btn-sm" style="background:linear-gradient(135deg,var(--purple2),#7c3aed);color:white;border-color:var(--purple2)" onclick="openAIScheduleGen()">
      <i class="fas fa-magic"></i> توليد جدول الامتحانات تلقائياً
    </button>`);

  setHTML('aiContent', `
    <!-- مقدمة الذكاء الاصطناعي -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:20px">
      <!-- بطاقة تحليل التعارضات -->
      <div class="card ai-card" style="border-top:3px solid var(--red);cursor:pointer" onclick="_analyzeConflicts()">
        <div class="card-b" style="text-align:center;padding:28px 20px">
          <div style="width:60px;height:60px;border-radius:16px;background:var(--red-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:26px">⚡</div>
          <div style="font-weight:900;font-size:16px;margin-bottom:8px">تحليل التعارضات</div>
          <div style="font-size:12.5px;color:var(--txt2);margin-bottom:16px">اكتشف تعارضات الجدول والقاعات والمراقبين تلقائياً</div>
          <button class="btn bd btn-sm" onclick="event.stopPropagation();_analyzeConflicts()">
            <i class="fas fa-search"></i> تحليل الآن
          </button>
        </div>
      </div>

      <!-- بطاقة الجدول المثالي -->
      <div class="card ai-card" style="border-top:3px solid var(--primary);cursor:pointer" onclick="_generateOptimalSchedule()">
        <div class="card-b" style="text-align:center;padding:28px 20px">
          <div style="width:60px;height:60px;border-radius:16px;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:26px">📅</div>
          <div style="font-weight:900;font-size:16px;margin-bottom:8px">توليد الجدول المثالي</div>
          <div style="font-size:12.5px;color:var(--txt2);margin-bottom:16px">توزيع ذكي للامتحانات يتجنب التعارضات ويوزع الضغط</div>
          <button class="btn bp btn-sm" onclick="event.stopPropagation();_generateOptimalSchedule()">
            <i class="fas fa-magic"></i> توليد الجدول
          </button>
        </div>
      </div>

      <!-- بطاقة اقتراح المراقبين -->
      <div class="card ai-card" style="border-top:3px solid var(--green);cursor:pointer" onclick="_aiSuggestProctors()">
        <div class="card-b" style="text-align:center;padding:28px 20px">
          <div style="width:60px;height:60px;border-radius:16px;background:var(--green-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:26px">👤</div>
          <div style="font-weight:900;font-size:16px;margin-bottom:8px">اقتراح المراقبين</div>
          <div style="font-size:12.5px;color:var(--txt2);margin-bottom:16px">اختيار الأنسب بناءً على النقاط والعبء والتخصص</div>
          <button class="btn bs btn-sm" onclick="event.stopPropagation();_aiSuggestProctors()">
            <i class="fas fa-user-check"></i> اقتراح الآن
          </button>
        </div>
      </div>
    </div>

    <!-- منطقة النتائج -->
    <div id="aiResults"></div>
  `);
}

// ── تحليل التعارضات ────────────────────────────────────────────
function _analyzeConflicts() {
  const results = document.getElementById('aiResults');
  if (!results) return;

  results.innerHTML = `<div style="text-align:center;padding:30px"><i class="fas fa-spinner fa-spin" style="font-size:28px;color:var(--primary)"></i><div style="margin-top:10px;color:var(--txt2)">جارٍ تحليل التعارضات...</div></div>`;

  setTimeout(() => {
    const exams    = STATE.exams?.filter(e => e.semester === STATE.currentSem) || [];
    const conflicts = [];

    // 1. تعارض القاعات
    for (let i = 0; i < exams.length; i++) {
      for (let j = i + 1; j < exams.length; j++) {
        const a = exams[i], b = exams[j];
        if (!_examsOverlap(a, b)) continue;

        // قاعة مشتركة
        const sharedRooms = (a.room_ids||[]).filter(id => (b.room_ids||[]).includes(id));
        sharedRooms.forEach(roomId => {
          conflicts.push({
            type: 'room', severity: 'high',
            msg: `تعارض قاعة: "${getRoom(roomId)?.name || roomId}" محجوزة لامتحانين في نفس الوقت`,
            exam1: a, exam2: b
          });
        });

        // مراقب مشترك
        const sharedProctors = (a.proctor_ids||[]).filter(id => (b.proctor_ids||[]).includes(id));
        sharedProctors.forEach(pid => {
          conflicts.push({
            type: 'proctor', severity: 'high',
            msg: `تعارض مراقب: "${getProfile(pid)?.name || pid}" مكلّف بامتحانين في نفس الوقت`,
            exam1: a, exam2: b
          });
        });
      }
    }

    // 2. امتحانات متراكمة في يوم واحد
    const byDate = {};
    exams.forEach(e => { byDate[e.date] = (byDate[e.date]||0) + 1; });
    Object.entries(byDate).forEach(([date, count]) => {
      if (count >= 4) {
        conflicts.push({
          type: 'pressure', severity: count >= 6 ? 'high' : 'medium',
          msg: `تكدّس في الجدول: ${count} امتحانات في يوم ${date}`,
          exam1: null, exam2: null
        });
      }
    });

    // 3. مراقب بدون امتحانات كافية
    const proctors = STATE.profiles?.filter(p => p.role === 'proctor' || p.role === 'coordinator') || [];
    proctors.forEach(p => {
      const count = exams.filter(e => (e.proctor_ids||[]).includes(p.id)).length;
      if (count === 0) {
        conflicts.push({
          type: 'idle', severity: 'low',
          msg: `المراقب "${p.name}" لم يُكلَّف بأي امتحان هذا الفصل`,
          exam1: null, exam2: null
        });
      }
    });

    const high   = conflicts.filter(c => c.severity === 'high');
    const medium = conflicts.filter(c => c.severity === 'medium');
    const low    = conflicts.filter(c => c.severity === 'low');

    results.innerHTML = `
      <div class="card" style="border-right:4px solid var(--red)">
        <div class="card-h">
          <h3><i class="fas fa-exclamation-triangle" style="color:var(--red)"></i> نتائج تحليل التعارضات</h3>
          <div style="display:flex;gap:8px">
            <span class="badge b-red">${high.length} حرج</span>
            <span class="badge b-gold">${medium.length} متوسط</span>
            <span class="badge b-gray">${low.length} منخفض</span>
          </div>
        </div>
        <div class="card-b">
          ${conflicts.length === 0
            ? `<div class="empty-state"><i class="fas fa-check-circle" style="color:var(--green);opacity:1;font-size:40px"></i><p style="color:var(--green)">لا توجد تعارضات! الجدول سليم ✓</p></div>`
            : conflicts.map(c => `
              <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);align-items:flex-start">
                <div style="width:32px;height:32px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:${c.severity==='high'?'var(--red-bg)':c.severity==='medium'?'var(--gold-bg)':'var(--bg)'};color:${c.severity==='high'?'var(--red)':c.severity==='medium'?'var(--gold)':'var(--txt3)'}">
                  <i class="fas ${c.type==='room'?'fa-door-open':c.type==='proctor'?'fa-user-tie':c.type==='pressure'?'fa-calendar-times':'fa-user-clock'}"></i>
                </div>
                <div style="flex:1">
                  <div style="font-weight:700;font-size:13px;margin-bottom:2px">${c.msg}</div>
                  ${c.exam1 ? `<div style="font-size:11.5px;color:var(--txt2)">${_examLabel(c.exam1)} ↔ ${_examLabel(c.exam2)}</div>` : ''}
                </div>
                <span class="badge ${c.severity==='high'?'b-red':c.severity==='medium'?'b-gold':'b-gray'}">${c.severity==='high'?'حرج':c.severity==='medium'?'متوسط':'منخفض'}</span>
              </div>`).join('')
          }
        </div>
      </div>`;
  }, 600);
}

function _examsOverlap(a, b) {
  const startA = new Date(`${a.date}T${a.time}`);
  const endA   = new Date(startA.getTime() + (a.duration||60)*60000);
  const startB = new Date(`${b.date}T${b.time}`);
  const endB   = new Date(startB.getTime() + (b.duration||60)*60000);
  return startA < endB && endA > startB;
}

function _examLabel(e) {
  if (!e) return '';
  const s = getSubject(e.subject_id);
  return `${s?.name||'—'} (${e.date} ${e.time})`;
}

// ── توليد الجدول المثالي ────────────────────────────────────────
function _generateOptimalSchedule() {
  const results = document.getElementById('aiResults');
  if (!results) return;

  results.innerHTML = `<div style="text-align:center;padding:30px"><i class="fas fa-brain fa-spin" style="font-size:28px;color:var(--primary)"></i><div style="margin-top:10px;color:var(--txt2)">يجري الذكاء الاصطناعي تحليل الجدول وتوليد الترتيب الأمثل...</div></div>`;

  setTimeout(() => {
    const exams = STATE.exams?.filter(e => e.semester === STATE.currentSem) || [];

    // تجميع الامتحانات حسب النوع والتاريخ
    const finals   = exams.filter(e => e.type === 'final').sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));
    const midterms = exams.filter(e => e.type === 'midterm').sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));
    const others   = exams.filter(e => e.type !== 'final' && e.type !== 'midterm');

    // حساب الكثافة اليومية
    const byDate = {};
    exams.forEach(e => { byDate[e.date] = (byDate[e.date]||[]).concat(e); });

    const crowdedDays = Object.entries(byDate)
      .filter(([,arr]) => arr.length >= 3)
      .sort((a,b) => b[1].length - a[1].length);

    const suggestions = [];

    // اقتراح إعادة توزيع الأيام المتكدسة
    crowdedDays.forEach(([date, dayExams]) => {
      suggestions.push({
        priority: 'high',
        icon: '📅',
        title: `إعادة توزيع امتحانات ${date}`,
        detail: `يوجد ${dayExams.length} امتحانات في هذا اليوم. يُقترح نقل ${Math.floor(dayExams.length/2)} امتحانات لأيام مجاورة فارغة.`,
        exams: dayExams.map(e => _examLabel(e))
      });
    });

    // اقتراح فجوة بين الامتحانات النهائية
    for (let i = 0; i < finals.length - 1; i++) {
      const d1 = new Date(finals[i].date);
      const d2 = new Date(finals[i+1].date);
      const diffDays = (d2-d1) / 86400000;
      if (diffDays < 2) {
        suggestions.push({
          priority: 'medium',
          icon: '⏱',
          title: 'فجوة قصيرة بين امتحانين نهائيين',
          detail: `فارق ${diffDays} يوم فقط بين "${_examLabel(finals[i])}" و "${_examLabel(finals[i+1])}". يُقترح 3 أيام على الأقل.`,
          exams: []
        });
      }
    }

    if (suggestions.length === 0) {
      suggestions.push({
        priority: 'success',
        icon: '✅',
        title: 'الجدول محسّن بالفعل!',
        detail: 'لم يجد نظام الذكاء الاصطناعي أي مشكلات في توزيع الامتحانات الحالي.',
        exams: []
      });
    }

    results.innerHTML = `
      <div class="card" style="border-right:4px solid var(--primary)">
        <div class="card-h">
          <h3><i class="fas fa-magic" style="color:var(--primary)"></i> اقتراحات الجدول المثالي</h3>
          <span class="badge b-blue">${suggestions.length} اقتراح</span>
        </div>
        <div class="card-b">
          <!-- ملخص إحصائي -->
          <div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:20px;padding:14px;background:var(--primary-bg);border-radius:12px">
            <div style="text-align:center">
              <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--primary)">${exams.length}</div>
              <div style="font-size:11px;color:var(--txt2)">إجمالي الامتحانات</div>
            </div>
            <div style="text-align:center">
              <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--gold)">${crowdedDays.length}</div>
              <div style="font-size:11px;color:var(--txt2)">أيام متكدسة</div>
            </div>
            <div style="text-align:center">
              <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--green)">${Object.keys(byDate).length}</div>
              <div style="font-size:11px;color:var(--txt2)">أيام امتحانية</div>
            </div>
            <div style="text-align:center">
              <div style="font-size:22px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--purple)">${finals.length}</div>
              <div style="font-size:11px;color:var(--txt2)">امتحانات نهائية</div>
            </div>
          </div>

          ${suggestions.map(s => `
            <div style="display:flex;gap:12px;padding:14px;margin-bottom:10px;border-radius:12px;border:1.5px solid ${s.priority==='high'?'#fecaca':s.priority==='medium'?'#fde68a':s.priority==='success'?'#a7f3d0':'var(--border)'};background:${s.priority==='high'?'var(--red-bg)':s.priority==='medium'?'var(--gold-bg)':s.priority==='success'?'var(--green-bg)':'var(--bg)'}">
              <div style="font-size:22px;flex-shrink:0">${s.icon}</div>
              <div style="flex:1">
                <div style="font-weight:800;font-size:13.5px;margin-bottom:4px">${s.title}</div>
                <div style="font-size:12.5px;color:var(--txt2);margin-bottom:${s.exams?.length?'8px':'0'}">${s.detail}</div>
                ${s.exams?.length ? `<div style="font-size:11px;color:var(--txt3)">${s.exams.join(' | ')}</div>` : ''}
              </div>
            </div>`).join('')}
        </div>
      </div>`;
  }, 800);
}

// ── اقتراح المراقبين ────────────────────────────────────────────
function _aiSuggestProctors() {
  const results = document.getElementById('aiResults');
  if (!results) return;

  results.innerHTML = `<div style="text-align:center;padding:30px"><i class="fas fa-brain fa-spin" style="font-size:28px;color:var(--green)"></i><div style="margin-top:10px;color:var(--txt2)">يحلل النظام سجلات المراقبين...</div></div>`;

  setTimeout(() => {
    const proctors  = STATE.profiles?.filter(p =>
      ['proctor','coordinator','dept_head'].includes(p.role) && !p.is_inactive
    ) || [];
    const exams     = STATE.exams?.filter(e => e.semester === STATE.currentSem) || [];
    const upcoming  = exams.filter(e => examStatus(e) === 'upcoming');

    // حساب النقاط والعبء
    const scored = proctors.map(p => {
      const totalPoints = exams.filter(e => (e.proctor_ids||[]).includes(p.id))
        .reduce((sum,e) => sum + calcPoints(e), 0);
      const examCount   = exams.filter(e => (e.proctor_ids||[]).includes(p.id)).length;
      const upcomingCount = upcoming.filter(e => (e.proctor_ids||[]).includes(p.id)).length;
      const hasSig      = !!p.signature;
      const dept        = STATE.departments?.find(d => d.id === p.dept_id);

      return {
        ...p,
        totalPoints,
        examCount,
        upcomingCount,
        hasSig,
        deptName: dept?.name || '—',
        // درجة الأولوية: نقاط أقل + حمل أقل = أولوية أعلى
        priority: 100 - totalPoints * 3 - upcomingCount * 10 + (hasSig ? 5 : 0)
      };
    }).sort((a,b) => b.priority - a.priority);

    const top = scored.slice(0, 8);
    const low = scored.filter(p => p.examCount === 0);

    results.innerHTML = `
      <div class="card" style="border-right:4px solid var(--green)">
        <div class="card-h">
          <h3><i class="fas fa-user-check" style="color:var(--green)"></i> ترتيب المراقبين الموصى بهم</h3>
          <span class="badge b-green">بناءً على النقاط والعبء الحالي</span>
        </div>
        <div class="card-b">
          <!-- شرح -->
          <div style="padding:12px 14px;background:var(--green-bg);border-radius:10px;font-size:12.5px;color:var(--green);margin-bottom:16px;font-weight:600">
            <i class="fas fa-info-circle" style="margin-left:6px"></i>
            الترتيب يعتمد على: نقاط المراقبة التراكمية (أقل = أولوية أعلى) + عدد الامتحانات القادمة + وجود التوقيع الرقمي
          </div>

          <!-- قائمة المراقبين -->
          ${top.map((p, i) => {
            const rankColor = i===0?'var(--gold)':i<=2?'var(--primary)':'var(--txt3)';
            const rankIcon  = i===0?'🥇':i===1?'🥈':i===2?'🥉':'';
            const loadColor = p.upcomingCount === 0 ? 'var(--green)' : p.upcomingCount <= 2 ? 'var(--gold)' : 'var(--red)';

            return `
              <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);align-items:center">
                <div style="width:32px;text-align:center;font-size:13px;font-weight:900;color:${rankColor};font-family:'Cairo',sans-serif;flex-shrink:0">
                  ${rankIcon || '#'+(i+1)}
                </div>
                ${userAvatar ? userAvatar(p, 38) : `<div style="width:38px;height:38px;border-radius:10px;background:var(--primary-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fas fa-user" style="color:var(--primary)"></i></div>`}
                <div style="flex:1;min-width:0">
                  <div style="font-weight:700;font-size:13px;display:flex;align-items:center;gap:6px">
                    ${p.name}
                    ${p.hasSig ? `<span title="لديه توقيع رقمي" style="color:var(--green);font-size:11px">✓ موقّع</span>` : ''}
                  </div>
                  <div style="font-size:11px;color:var(--txt3)">${p.deptName} · ${p.role}</div>
                </div>
                <div style="text-align:center;flex-shrink:0">
                  <div style="font-size:16px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--gold)">${p.totalPoints}</div>
                  <div style="font-size:10px;color:var(--txt3)">نقطة</div>
                </div>
                <div style="text-align:center;flex-shrink:0">
                  <div style="font-size:16px;font-weight:900;font-family:'Cairo',sans-serif;color:${loadColor}">${p.upcomingCount}</div>
                  <div style="font-size:10px;color:var(--txt3)">قادم</div>
                </div>
                <div style="flex-shrink:0">
                  <span class="badge ${p.upcomingCount===0?'b-green':p.upcomingCount<=2?'b-gold':'b-red'}">
                    ${p.upcomingCount===0?'متاح':p.upcomingCount<=2?'جزئياً':'محمّل'}
                  </span>
                </div>
              </div>`;
          }).join('')}

          ${low.length > 0 ? `
          <div style="margin-top:16px;padding:12px;background:var(--gold-bg);border-radius:10px;border:1px solid #fde68a">
            <div style="font-weight:800;font-size:13px;color:var(--gold);margin-bottom:6px">
              <i class="fas fa-user-clock" style="margin-left:6px"></i>${low.length} مراقب بدون تكليف هذا الفصل
            </div>
            <div style="font-size:12px;color:var(--txt2)">${low.map(p=>p.name).slice(0,5).join('، ')}${low.length>5?'...':''}</div>
          </div>` : ''}
        </div>
      </div>`;
  }, 700);
}

// ── التحليل الكامل ─────────────────────────────────────────────
function _runFullAIAnalysis() {
  const results = document.getElementById('aiResults');
  if (!results) return;

  results.innerHTML = `<div style="text-align:center;padding:40px">
    <div style="font-size:48px;margin-bottom:16px">🤖</div>
    <div style="font-size:18px;font-weight:800;margin-bottom:8px">التحليل الكامل جارٍ...</div>
    <div id="aiProgress" style="color:var(--txt2);font-size:13px">تحليل التعارضات...</div>
    <div style="margin:20px auto;width:200px;height:6px;background:var(--bg);border-radius:3px;overflow:hidden">
      <div id="aiProgressBar" style="height:100%;background:var(--primary);border-radius:3px;width:0%;transition:width .5s"></div>
    </div>
  </div>`;

  let step = 0;
  const steps = ['تحليل التعارضات...','تحليل الجدول...','تحليل المراقبين...','إعداد التقرير...'];
  const iv = setInterval(() => {
    step++;
    const prog = document.getElementById('aiProgress');
    const bar  = document.getElementById('aiProgressBar');
    if (prog) prog.textContent = steps[step] || 'اكتمل!';
    if (bar)  bar.style.width = (step/4*100)+'%';
    if (step >= 4) {
      clearInterval(iv);
      setTimeout(_buildFullReport, 300);
    }
  }, 500);
}

function _buildFullReport() {
  const exams     = STATE.exams?.filter(e => e.semester === STATE.currentSem) || [];
  const proctors  = STATE.profiles?.filter(p => ['proctor','coordinator','dept_head'].includes(p.role)) || [];
  const conflicts = _countConflicts(exams);
  const pressureLevel = _calcPressureLevel(exams);

  const results = document.getElementById('aiResults');
  if (!results) return;

  results.innerHTML = `
    <div class="card" style="border-right:4px solid var(--primary);margin-bottom:16px">
      <div class="card-h">
        <h3><i class="fas fa-robot" style="color:var(--primary)"></i> تقرير الذكاء الاصطناعي الشامل — ${STATE.currentSem}</h3>
        <span style="font-size:11px;color:var(--txt3)">${new Date().toLocaleString('ar-OM')}</span>
      </div>
      <div class="card-b">
        <!-- درجة الصحة -->
        <div style="text-align:center;padding:20px;margin-bottom:20px;background:linear-gradient(135deg,#f0fdf4,#dcfce7);border-radius:14px">
          <div style="font-size:52px;font-weight:900;font-family:'Cairo',sans-serif;color:${conflicts===0?'var(--green)':conflicts<=3?'var(--gold)':'var(--red)'}">
            ${conflicts===0?'A+':conflicts<=3?'B':'C'}
          </div>
          <div style="font-size:13px;font-weight:700;color:var(--txt2)">تقييم النظام الكلي</div>
          <div style="font-size:12px;color:var(--txt3);margin-top:4px">
            ${conflicts===0?'النظام يعمل بكفاءة ممتازة':conflicts<=3?'يوجد بعض التعارضات التي تحتاج معالجة':'يتطلب مراجعة عاجلة للجدول'}
          </div>
        </div>

        <!-- ملخص النقاط -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:20px">
          <div style="padding:14px;background:${conflicts===0?'var(--green-bg)':'var(--red-bg)'};border-radius:10px;text-align:center">
            <div style="font-size:24px;font-weight:900;font-family:'Cairo',sans-serif;color:${conflicts===0?'var(--green)':'var(--red)'}">${conflicts}</div>
            <div style="font-size:11px;color:var(--txt2)">تعارضات</div>
          </div>
          <div style="padding:14px;background:${pressureLevel<5?'var(--green-bg)':pressureLevel<8?'var(--gold-bg)':'var(--red-bg)'};border-radius:10px;text-align:center">
            <div style="font-size:24px;font-weight:900;font-family:'Cairo',sans-serif;color:${pressureLevel<5?'var(--green)':pressureLevel<8?'var(--gold)':'var(--red)'}">${pressureLevel}</div>
            <div style="font-size:11px;color:var(--txt2)">أعلى ضغط أسبوعي</div>
          </div>
          <div style="padding:14px;background:var(--primary-bg);border-radius:10px;text-align:center">
            <div style="font-size:24px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--primary)">${exams.length}</div>
            <div style="font-size:11px;color:var(--txt2)">امتحانات</div>
          </div>
          <div style="padding:14px;background:var(--purple-bg);border-radius:10px;text-align:center">
            <div style="font-size:24px;font-weight:900;font-family:'Cairo',sans-serif;color:var(--purple)">${proctors.length}</div>
            <div style="font-size:11px;color:var(--txt2)">مراقبون</div>
          </div>
        </div>

        <!-- أزرار التفاصيل -->
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn bd btn-sm" onclick="_analyzeConflicts()">
            <i class="fas fa-exclamation-circle"></i> تفاصيل التعارضات
          </button>
          <button class="btn bp btn-sm" onclick="_generateOptimalSchedule()">
            <i class="fas fa-magic"></i> اقتراحات الجدول
          </button>
          <button class="btn bs btn-sm" onclick="_aiSuggestProctors()">
            <i class="fas fa-user-check"></i> ترتيب المراقبين
          </button>
        </div>
      </div>
    </div>`;
}

function _countConflicts(exams) {
  let count = 0;
  for (let i = 0; i < exams.length; i++) {
    for (let j = i + 1; j < exams.length; j++) {
      if (!_examsOverlap(exams[i], exams[j])) continue;
      const sharedRooms = (exams[i].room_ids||[]).filter(id => (exams[j].room_ids||[]).includes(id));
      const sharedProc  = (exams[i].proctor_ids||[]).filter(id => (exams[j].proctor_ids||[]).includes(id));
      count += sharedRooms.length + sharedProc.length;
    }
  }
  return count;
}

function _calcPressureLevel(exams) {
  const weeks = {};
  exams.forEach(e => {
    const d = new Date(e.date);
    const k = `${d.getFullYear()}-W${Math.ceil(((d - new Date(d.getFullYear(),0,1))/86400000+1)/7)}`;
    weeks[k] = (weeks[k]||0)+1;
  });
  return Math.max(...Object.values(weeks), 0);
}

// ═══════════════════════════════════════════════════════════════
//  FEATURE 4: AI توليد جدول الامتحانات تلقائياً
// ═══════════════════════════════════════════════════════════════
function openAIScheduleGen() {
  const mo = document.getElementById('aiSchedMo') || (() => {
    const m = document.createElement('div'); m.className='mo'; m.id='aiSchedMo'; document.body.appendChild(m); return m;
  })();

  const subjects  = STATE.subjects.map(s => `<option value="${s.id}">${s.name}${s.code?' ('+s.code+')':''}</option>`).join('');
  const sems      = STATE.semesters.map(s => `<option value="${s.code}" ${s.code===STATE.currentSem?'selected':''}>${s.label}</option>`).join('');
  const examTypes = ['final','midterm','quiz'].map(t => `<option value="${t}">${{final:'نهائي',midterm:'منتصف الفصل',quiz:'اختبار'}[t]}</option>`).join('');

  mo.innerHTML = `<div class="md" style="max-width:620px">
    <div class="md-hd">
      <h2>
        <div style="width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--purple2),#7c3aed);display:flex;align-items:center;justify-content:center">
          <i class="fas fa-magic" style="color:white;font-size:15px"></i>
        </div>
        توليد جدول الامتحانات بالذكاء الاصطناعي
      </h2>
      <button class="md-close" onclick="closeMo('aiSchedMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:0">

      <!-- الفصل والتاريخ -->
      <div style="padding:18px 22px;border-bottom:1px solid var(--border)">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">
          <i class="fas fa-calendar" style="color:var(--purple2);margin-left:5px"></i> إعدادات الجدول
        </div>
        <div class="g2">
          <div class="field">
            <label class="field-lbl">الفصل الدراسي</label>
            <select id="aiSchedSem">${sems}</select>
          </div>
          <div class="field">
            <label class="field-lbl">نوع الامتحانات</label>
            <select id="aiSchedType">${examTypes}</select>
          </div>
          <div class="field">
            <label class="field-lbl">تاريخ البداية</label>
            <input type="date" id="aiSchedStart" value="${new Date().toISOString().split('T')[0]}" style="height:40px">
          </div>
          <div class="field">
            <label class="field-lbl">تاريخ النهاية</label>
            <input type="date" id="aiSchedEnd" value="${new Date(Date.now()+21*86400000).toISOString().split('T')[0]}" style="height:40px">
          </div>
          <div class="field">
            <label class="field-lbl">وقت البداية اليومي</label>
            <input type="time" id="aiSchedTime" value="09:00" style="height:40px">
          </div>
          <div class="field">
            <label class="field-lbl">المدة (دقيقة)</label>
            <input type="number" id="aiSchedDur" value="120" min="30" max="240" style="height:40px">
          </div>
        </div>
        <div style="display:flex;gap:12px;margin-top:8px;flex-wrap:wrap">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" id="aiSkipFriday" checked> تخطي الجمعة
          </label>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" id="aiSkipSaturday"> تخطي السبت
          </label>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" id="aiAutoProctor" checked> توزيع المراقبين تلقائياً
          </label>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" id="aiAutoRoom" checked> اقتراح القاعات تلقائياً
          </label>
        </div>
      </div>

      <!-- اختيار المواد -->
      <div style="padding:16px 22px">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">
          <i class="fas fa-book" style="color:var(--gold);margin-left:5px"></i> المواد (${STATE.subjects.length})
          <button class="btn bo btn-xs" style="margin-right:8px" onclick="_aiToggleAllSubjects(true)">الكل</button>
          <button class="btn bo btn-xs" onclick="_aiToggleAllSubjects(false)">لا شيء</button>
        </div>
        <div style="max-height:200px;overflow-y:auto;display:flex;flex-wrap:wrap;gap:6px" id="aiSubjectsContainer">
          ${STATE.subjects.map(s => `
            <label class="exam-check-item" style="font-size:12px">
              <input type="checkbox" class="ai-subj-cb" value="${s.id}" checked>
              <span>${s.name}${s.code?' <span style=color:var(--txt3);font-size:10px>('+s.code+')</span>':''}</span>
            </label>`).join('')}
        </div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('aiSchedMo')">إلغاء</button>
      <button class="btn bp" style="background:linear-gradient(135deg,var(--purple2),#7c3aed);border-color:var(--purple2)" onclick="runAIScheduleGen()">
        <i class="fas fa-magic"></i> توليد الجدول الآن
      </button>
    </div>
  </div>`;
  showMo('aiSchedMo');
}

function _aiToggleAllSubjects(val) {
  document.querySelectorAll('.ai-subj-cb').forEach(cb => cb.checked = val);
}

async function runAIScheduleGen() {
  const sem       = document.getElementById('aiSchedSem')?.value;
  const type      = document.getElementById('aiSchedType')?.value;
  const startStr  = document.getElementById('aiSchedStart')?.value;
  const endStr    = document.getElementById('aiSchedEnd')?.value;
  const time      = document.getElementById('aiSchedTime')?.value || '09:00';
  const dur       = parseInt(document.getElementById('aiSchedDur')?.value || 120);
  const skipFri   = document.getElementById('aiSkipFriday')?.checked;
  const skipSat   = document.getElementById('aiSkipSaturday')?.checked;
  const autoProct = document.getElementById('aiAutoProctor')?.checked;
  const autoRoom  = document.getElementById('aiAutoRoom')?.checked;

  if (!startStr || !endStr) { toast('حدد التاريخ','warning'); return; }

  const selectedSubjIds = [...document.querySelectorAll('.ai-subj-cb:checked')].map(cb => parseInt(cb.value));
  if (!selectedSubjIds.length) { toast('اختر مادة واحدة على الأقل','warning'); return; }

  closeMo('aiSchedMo');
  toast('جارٍ توليد الجدول المثالي...', 'info');

  // ── خوارزمية التوليد الذكي ──
  await new Promise(r => setTimeout(r, 300)); // تأخير مرئي

  const startD = new Date(startStr);
  const endD   = new Date(endStr);
  const skipDays = new Set();
  if (skipFri) skipDays.add(5);
  if (skipSat) skipDays.add(6);

  // بناء قائمة الأيام المتاحة
  const availDays = [];
  for (let d = new Date(startD); d <= endD; d.setDate(d.getDate()+1)) {
    if (!skipDays.has(d.getDay())) availDays.push(new Date(d).toISOString().split('T')[0]);
  }

  if (!availDays.length) { toast('لا توجد أيام متاحة في الفترة المحددة','error'); return; }

  // ترتيب المواد حسب الأهمية (عدد الطلاب)
  const sortedSubjs = [...selectedSubjIds]
    .map(id => STATE.subjects.find(s => s.id === id))
    .filter(Boolean)
    .sort((a, b) => {
      const stA = STATE.sections.filter(s => s.subject_id === a.id).reduce((n,s) => n+(s.student_ids||[]).length, 0);
      const stB = STATE.sections.filter(s => s.subject_id === b.id).reduce((n,s) => n+(s.student_ids||[]).length, 0);
      return stB - stA;
    });

  const generated = [];
  const usedDays  = new Set(); // يوم واحد لكل مادة
  const usedRooms = {}; // room -> Set of [date+time slots]
  const usedProct = {}; // proctor -> Set of date+time slots

  const startNew = new Date(`2000-01-01T${time}`);
  const endNew   = new Date(startNew.getTime() + dur * 60000);

  function _overlaps(dateStr, t1, d1, usedSlots) {
    const s1 = new Date(`${dateStr}T${t1}`);
    const e1 = new Date(s1.getTime() + d1 * 60000);
    for (const slot of (usedSlots||[])) {
      const s2 = new Date(slot.start);
      const e2 = new Date(slot.end);
      if (s1 < e2 && e1 > s2) return true;
    }
    return false;
  }

  let dayIdx = 0;
  for (const subj of sortedSubjs) {
    // اجد يوماً غير مستخدم
    while (dayIdx < availDays.length && usedDays.has(availDays[dayIdx])) dayIdx++;
    if (dayIdx >= availDays.length) {
      // إذا نفدت الأيام، ابدأ من أول يوم مرة ثانية
      dayIdx = 0;
    }

    const dateStr = availDays[dayIdx];
    usedDays.add(dateStr);
    dayIdx++;

    // اقتراح القاعة
    let roomId = null;
    if (autoRoom && STATE.rooms.length) {
      const subjSections = STATE.sections.filter(s => s.subject_id === subj.id);
      const studentCount = subjSections.reduce((n,s) => n+(s.student_ids||[]).length, 0);
      const suitable = STATE.rooms.filter(r => {
        if ((r.cap||0) < studentCount && studentCount > 0) return false;
        const slots = usedRooms[r.id] || [];
        return !_overlaps(dateStr, time, dur, slots);
      }).sort((a,b) => (a.cap||0) - (b.cap||0));
      if (suitable.length) {
        roomId = suitable[0].id;
        if (!usedRooms[roomId]) usedRooms[roomId] = [];
        usedRooms[roomId].push({
          start: new Date(`${dateStr}T${time}`).toISOString(),
          end:   new Date(new Date(`${dateStr}T${time}`).getTime() + dur*60000).toISOString()
        });
      }
    }

    // اقتراح المراقبين
    const proctorIds = [];
    if (autoProct) {
      const available = STATE.profiles
        .filter(p => p.role === 'proctor' && p.active)
        .filter(p => {
          const slots = usedProct[p.id] || [];
          return !_overlaps(dateStr, time, dur, slots);
        })
        .sort((a,b) => {
          const ca = STATE.exams.filter(e => e.semester===sem && (e.proctor_ids||[]).includes(a.id)).length;
          const cb = STATE.exams.filter(e => e.semester===sem && (e.proctor_ids||[]).includes(b.id)).length;
          return ca - cb;
        });
      // خصص مراقبَين
      available.slice(0,2).forEach(p => {
        proctorIds.push(p.id);
        if (!usedProct[p.id]) usedProct[p.id] = [];
        usedProct[p.id].push({
          start: new Date(`${dateStr}T${time}`).toISOString(),
          end:   new Date(new Date(`${dateStr}T${time}`).getTime() + dur*60000).toISOString()
        });
      });
    }

    generated.push({
      subject_id:  subj.id,
      semester:    sem,
      type,
      date:        dateStr,
      time,
      duration:    dur,
      extra_time:  0,
      room_ids:    roomId ? [roomId] : [],
      proctor_ids: proctorIds,
      section_ids: STATE.sections.filter(s => s.subject_id===subj.id && s.semester===sem).map(s=>s.id),
      max_grade:   100,
      notes:       'تم التوليد بالذكاء الاصطناعي'
    });
  }

  if (!generated.length) { toast('لم يتم توليد أي امتحانات','warning'); return; }

  // اعرض معاينة قبل الحفظ
  _showAISchedPreview(generated);
}

function _showAISchedPreview(generated) {
  const mo = document.getElementById('aiPreviewMo') || (() => {
    const m = document.createElement('div'); m.className='mo'; m.id='aiPreviewMo'; document.body.appendChild(m); return m;
  })();

  const rows = generated.map(e => {
    const sub    = getSubject(e.subject_id);
    const rooms  = e.room_ids.map(id => getRoom(id)?.name).filter(Boolean).join(', ');
    const procts = e.proctor_ids.map(id => getProfile(id)?.name?.split(' ').slice(0,2).join(' ')).filter(Boolean).join('، ');
    return `<tr style="border-bottom:1px solid var(--border)">
      <td style="padding:8px 12px;font-weight:700;font-size:12.5px">${sub?.name||'—'}</td>
      <td style="padding:8px 12px;font-size:12px;color:var(--txt2)">${fmtDate(e.date)}</td>
      <td style="padding:8px 12px;font-size:12px;color:var(--txt2)">${fmtTime(e.time)}</td>
      <td style="padding:8px 12px;font-size:11.5px;color:var(--teal)">${rooms||'—'}</td>
      <td style="padding:8px 12px;font-size:11.5px;color:var(--purple2)">${procts||'—'}</td>
    </tr>`;
  }).join('');

  mo.innerHTML = `<div class="md" style="max-width:780px">
    <div class="md-hd">
      <h2><i class="fas fa-list-check" style="color:var(--purple2)"></i> معاينة الجدول المولَّد (${generated.length} امتحان)</h2>
      <button class="md-close" onclick="closeMo('aiPreviewMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:0">
      <div style="padding:12px 20px;background:linear-gradient(135deg,rgba(139,92,246,.08),rgba(30,111,255,.05));border-bottom:1px solid var(--border)">
        <div style="font-size:12.5px;color:var(--txt2)">
          <i class="fas fa-magic" style="color:var(--purple2);margin-left:5px"></i>
          تم التوليد بدون أي تعارضات في القاعات أو المراقبين — راجع الجدول ثم اضغط حفظ.
        </div>
      </div>
      <div style="max-height:440px;overflow-y:auto">
        <table style="width:100%;border-collapse:collapse">
          <thead>
            <tr style="background:var(--bg);position:sticky;top:0">
              <th style="padding:10px 12px;text-align:right;font-size:11.5px;color:var(--txt3)">المادة</th>
              <th style="padding:10px 12px;text-align:right;font-size:11.5px;color:var(--txt3)">التاريخ</th>
              <th style="padding:10px 12px;text-align:right;font-size:11.5px;color:var(--txt3)">الوقت</th>
              <th style="padding:10px 12px;text-align:right;font-size:11.5px;color:var(--txt3)">القاعة</th>
              <th style="padding:10px 12px;text-align:right;font-size:11.5px;color:var(--txt3)">المراقبون</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('aiPreviewMo')">إلغاء</button>
      <button class="btn bp" style="background:linear-gradient(135deg,var(--purple2),#7c3aed);border-color:var(--purple2)" onclick="saveAIGeneratedSchedule(${JSON.stringify(generated).replace(/"/g,'&quot;')})">
        <i class="fas fa-save"></i> حفظ الجدول كاملاً
      </button>
    </div>
  </div>`;
  showMo('aiPreviewMo');
}

async function saveAIGeneratedSchedule(generated) {
  if (typeof generated === 'string') {
    try { generated = JSON.parse(generated); } catch { toast('خطأ في البيانات','error'); return; }
  }
  closeMo('aiPreviewMo');

  let saved = 0, failed = 0;
  for (const exam of generated) {
    try {
      const res = await SB.insert('exams', exam);
      STATE.exams.push(Hydrate.exam(res));
      saved++;
    } catch(e) { failed++; console.warn('AI exam save:', e.message); }
  }

  await addLog('AI جدول', 'exam', `تم توليد وحفظ ${saved} امتحان تلقائياً`);
  toast(`✅ تم حفظ ${saved} امتحان${failed?` (${failed} فشل)`:''}`, 'success');
  if (saved > 0) { renderExams?.(); UI.showPage('exams'); }
}
