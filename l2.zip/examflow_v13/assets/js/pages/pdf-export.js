// ═══════════════════════════════════════════════════════════════
//  pdf-export.js — تصدير التقارير v6 مع شعار SQU وتفاصيل كاملة
// ═══════════════════════════════════════════════════════════════

const SQU_LOGO = 'https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png';

function exportExamPDF(examId) {
  const exam = getExam(examId);
  if (!exam) { toast('الامتحان غير موجود','error'); return; }

  const sub      = getSubject(exam.subject_id);
  const rooms    = (exam.room_ids||[]).map(id => getRoom(id)).filter(Boolean);
  const proctors = (exam.proctor_ids||[]).map(id => getProfile(id)).filter(Boolean);
  const settings = STATE.settings;
  const uniName  = settings?.university_name || 'جامعة السلطان قابوس';
  const collegeName = 'كلية التمريض';
  const systemName  = 'نظام إدارة الامتحانات — ExamFlow';

  // بيانات الحضور
  const attMap   = STATE.attendance[examId] || {};
  const sections = (exam.section_ids||[]).map(id => getSection(id)).filter(Boolean);

  // المنسق: صاحب coord_id في أول شعبة، أو أي coordinator في الشعب
  const coordId  = sections.find(s => s.coord_id)?.coord_id || null;
  const coordinator = coordId ? getProfile(coordId) : STATE.profiles.find(p => p.role === 'coordinator');

  // رئيس القسم: من جدول departments بناءً على قسم المادة
  const subjectDeptId = sub?.dept_id || null;
  const dept = subjectDeptId ? STATE.departments.find(d => d.id === subjectDeptId) : null;
  const deptHead = dept?.head_id ? getProfile(dept.head_id) : STATE.profiles.find(p => p.role === 'dept_head');

  let allStudentIds = [];
  sections.forEach(sec => { allStudentIds.push(...(sec.student_ids||[])); });
  allStudentIds = [...new Set(allStudentIds)];
  const students = allStudentIds.map(id =>
    STATE.students.find(s => s.id===id || s.stud_id===String(id))
  ).filter(Boolean);

  const present = students.filter(s => attMap[s.id]==='present' || attMap[s.id]==='late');
  const absent  = students.filter(s => attMap[s.id]==='absent'  || attMap[s.id]==='excused');
  const unknown = students.filter(s => !attMap[s.id]);

  const examDate    = fmtDate(exam.date);
  const examTime    = fmtTime(exam.time);
  const endTime     = _calcEndTime(exam.time, exam.duration + (exam.extra_time||0));
  const typeLabels  = {final:'نهائي',midterm:'منتصف الفصل',quiz:'اختبار قصير',makeup:'إعادة'};
  const examTypeLbl = typeLabels[exam.type] || exam.type;
  const printedAt   = new Date().toLocaleDateString('ar-OM',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});
  const semLabel    = STATE.semesters.find(s=>s.code===exam.semester)?.label || exam.semester || '';

  // ملاحظات المعلمين/المنسقين
  const examNotes  = exam.exam_notes || {};
  const notesEntries = Object.entries(examNotes);

  const printWin = window.open('', '_blank', 'width=960,height=750');
  if (!printWin) { toast('يرجى السماح بالنوافذ المنبثقة','warning'); return; }

  printWin.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تقرير امتحان — ${sub?.name||''}</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',Tahoma,'Arial Unicode MS',sans-serif; font-size:10.5pt; color:#1e293b; background:#fff; direction:rtl; }
@page { size:A4; margin:15mm 14mm; }

/* ── Header with SQU Logo ── */
.hdr {
  display:flex; align-items:center; justify-content:space-between;
  border-bottom:3px solid #1e3a5f; padding-bottom:14px; margin-bottom:20px;
}
.hdr-logo { flex-shrink:0; }
.hdr-logo img { height:62px; width:auto; object-fit:contain; }
.hdr-info { text-align:center; flex:1; padding:0 20px; }
.hdr-uni  { font-size:14pt; font-weight:700; color:#1e3a5f; margin-bottom:2px; }
.hdr-col  { font-size:11pt; color:#334155; margin-bottom:3px; }
.hdr-sys  { font-size:9pt; color:#64748b; }
.hdr-right{ text-align:left; font-size:8.5pt; color:#64748b; line-height:1.7; flex-shrink:0; }

/* ── Exam Banner ── */
.exam-banner {
  background:linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%);
  color:#fff; border-radius:12px; padding:18px 22px; margin-bottom:18px;
  display:flex; justify-content:space-between; align-items:flex-start;
  box-shadow:0 4px 14px rgba(37,99,235,.3);
}
.exam-banner h1 { font-size:16pt; font-weight:800; margin-bottom:5px; }
.exam-banner .meta { font-size:9pt; opacity:.85; line-height:1.7; }
.badge-type {
  background:rgba(255,255,255,.2); border:1px solid rgba(255,255,255,.3);
  border-radius:8px; padding:6px 16px; font-size:10pt; font-weight:700;
  flex-shrink:0; margin-top:4px;
}

/* ── Info Grid ── */
.info-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:18px; }
.info-box { border:1px solid #e2e8f0; border-radius:10px; padding:10px 12px; text-align:center; }
.info-box .lbl { font-size:8.5pt; color:#64748b; margin-bottom:4px; }
.info-box .val { font-size:12pt; font-weight:800; color:#1e293b; }
.info-box .val.green { color:#059669; }
.info-box .val.red   { color:#dc2626; }
.info-box .val.blue  { color:#2563eb; }

/* ── Section Title ── */
.sec-title {
  font-size:11pt; font-weight:700; color:#1e3a5f;
  border-right:4px solid #2563eb; padding:7px 12px;
  background:#f8fafc; border-radius:0 8px 8px 0;
  margin:18px 0 12px; display:flex; align-items:center; gap:8px;
}

/* ── Proctors ── */
.proctor-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; margin-bottom:8px; }
.proctor-card {
  border:1px solid #e2e8f0; border-radius:10px; padding:13px 16px;
  display:flex; align-items:flex-start; justify-content:space-between; gap:16px;
}
.proctor-name { font-weight:700; font-size:11pt; margin-bottom:4px; }
.proctor-id   { font-size:9pt; color:#64748b; }
.sig-area { text-align:center; flex-shrink:0; }
.sig-box  { border-bottom:1.5px solid #94a3b8; width:100px; min-height:40px; }
.sig-lbl  { font-size:8pt; color:#94a3b8; margin-top:4px; }

/* ── Notes ── */
.notes-box {
  padding:12px 16px; background:#fffbeb; border:1px solid #fcd34d;
  border-radius:10px; font-size:10pt; margin-bottom:12px; line-height:1.7;
}
.teacher-note {
  padding:10px 14px; background:#f0f9ff; border:1px solid #bae6fd;
  border-radius:8px; margin-bottom:8px;
}
.teacher-note .tn-author { font-size:9pt; font-weight:700; color:#0369a1; margin-bottom:3px; }
.teacher-note .tn-text   { font-size:10pt; color:#1e293b; }

/* ── Students Table ── */
table { width:100%; border-collapse:collapse; font-size:9.5pt; }
th {
  background:#1e3a5f; color:#fff; padding:8px 10px;
  text-align:right; font-weight:600; font-size:9pt;
}
td { padding:7px 10px; border-bottom:1px solid #f1f5f9; }
tr:nth-child(even) td { background:#f8fafc; }
.s-p { color:#059669; font-weight:700; }
.s-a { color:#dc2626; font-weight:700; }
.s-l { color:#d97706; font-weight:700; }
.s-e { color:#7c3aed; font-weight:700; }
.s-u { color:#94a3b8; }

/* ── Stat Row ── */
.stat-row { display:flex; gap:10px; margin-bottom:16px; }
.stat-mini { flex:1; border-radius:10px; padding:12px 8px; text-align:center; }
.stat-mini .n { font-size:22pt; font-weight:900; }
.stat-mini .l { font-size:8.5pt; margin-top:2px; }
.s-blue  { background:#eff6ff; color:#2563eb; }
.s-green { background:#f0fdf4; color:#059669; }
.s-red   { background:#fef2f2; color:#dc2626; }
.s-gold  { background:#fffbeb; color:#b45309; }
.s-gray  { background:#f8fafc; color:#64748b; }

/* ── Absent Section ── */
.absent-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; }
.absent-card {
  border:1px solid #fecaca; border-radius:8px; padding:10px 12px;
  background:#fef2f2;
}
.absent-name { font-weight:700; font-size:10pt; margin-bottom:2px; }
.absent-id   { font-size:8.5pt; color:#dc2626; }

/* ── Footer ── */
.footer {
  margin-top:20px; padding-top:12px; border-top:1px solid #e2e8f0;
  display:flex; justify-content:space-between; align-items:center;
  font-size:8.5pt; color:#94a3b8;
}
.footer img { height:24px; opacity:.4; }

.page-break { page-break-before:always; margin-top:20px; }

@media print {
  body { -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; }
}
</style>
</head>
<body>

<!-- ═══ PAGE 1: Exam Report ═══ -->

<!-- Header with SQU Logo -->
<div class="hdr">
  <div class="hdr-logo">
    <img src="${SQU_LOGO}" alt="SQU" onerror="this.style.display='none'">
  </div>
  <div class="hdr-info">
    <div class="hdr-uni">${uniName}</div>
    <div class="hdr-col">${collegeName}</div>
    <div class="hdr-sys">${systemName}</div>
  </div>
  <div class="hdr-right">
    <div>تاريخ الطباعة:</div>
    <div>${printedAt}</div>
  </div>
</div>

<!-- Exam Banner -->
<div class="exam-banner">
  <div>
    <h1>${sub?.name || '—'}</h1>
    <div class="meta">
      ${sub?.code ? `رمز المادة: ${sub.code}` : ''}
      ${sub?.code && semLabel ? ' &nbsp;|&nbsp; ' : ''}
      ${semLabel ? `الفصل الدراسي: ${semLabel}` : ''}
      ${exam.is_holiday ? ' &nbsp;|&nbsp; <b>📅 يوم عطلة / إجازة</b>' : ''}
    </div>
  </div>
  <div class="badge-type">امتحان ${examTypeLbl}</div>
</div>

<!-- Info Grid -->
<div class="info-grid">
  <div class="info-box">
    <div class="lbl">📅 التاريخ</div>
    <div class="val">${examDate}</div>
  </div>
  <div class="info-box">
    <div class="lbl">🕐 وقت البدء</div>
    <div class="val">${examTime}</div>
  </div>
  <div class="info-box">
    <div class="lbl">🕐 وقت الانتهاء</div>
    <div class="val">${endTime}</div>
  </div>
  <div class="info-box">
    <div class="lbl">⏱ المدة الكلية</div>
    <div class="val">${exam.duration} دقيقة${exam.extra_time ? ` <span style="font-size:9pt;color:#059669">+${exam.extra_time}</span>` : ''}</div>
  </div>
  <div class="info-box">
    <div class="lbl">📊 الدرجة القصوى</div>
    <div class="val blue">${exam.max_grade || 100}</div>
  </div>
  <div class="info-box">
    <div class="lbl">👥 الطلاب المقيّدون</div>
    <div class="val">${students.length}</div>
  </div>
  <div class="info-box">
    <div class="lbl">✅ الحاضرون</div>
    <div class="val green">${present.length}</div>
  </div>
  <div class="info-box">
    <div class="lbl">❌ الغائبون</div>
    <div class="val red">${absent.length}</div>
  </div>
</div>

<!-- Rooms -->
<div class="sec-title">📍 القاعات المخصصة</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
  ${rooms.length
    ? rooms.map(r=>`<div style="border:1px solid #e2e8f0;border-radius:20px;padding:5px 16px;font-size:10pt;background:#f8fafc">
        🚪 ${r.name}${r.cap ? ` (${r.cap} مقعد)` : ''}
      </div>`).join('')
    : '<div style="color:#94a3b8;font-size:10pt">لم تُحدد قاعات</div>'}
</div>

<!-- Exam Notes -->
${exam.notes ? `
<div class="notes-box">
  <b>📝 ملاحظات الامتحان:</b> ${exam.notes}
</div>` : ''}

<!-- Teacher/Coordinator Notes -->
${notesEntries.length ? `
<div class="sec-title">💬 ملاحظات المعلمين</div>
${notesEntries.map(([authorId, note]) => {
  const author = STATE.profiles.find(p=>p.id===authorId);
  const noteText = typeof note === 'string' ? note : (note?.text || String(note));
  const noteTime = note?.time ? new Date(note.time).toLocaleString('ar-OM') : '';
  return `<div class="teacher-note">
    <div class="tn-author">${author?.name || 'المعلم'} ${noteTime ? `· ${noteTime}` : ''}</div>
    <div class="tn-text">${noteText}</div>
  </div>`;
}).join('')}` : ''}

<!-- Sections Info -->
${sections.length ? `
<div class="sec-title">📚 الشعب والمواد</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
  ${sections.map(sec => {
    const subj = getSubject(sec.subject_id);
    return `<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px 14px;font-size:10pt;background:#f8fafc">
      <b>${sec.name}</b>
      ${subj ? `<span style="color:#64748b;font-size:9pt"> · ${subj.code||''} ${subj.name||''}</span>` : ''}
      <span style="color:#94a3b8;font-size:9pt"> (${(sec.student_ids||[]).length} طالب)</span>
    </div>`;
  }).join('')}
</div>` : ''}

<!-- Proctors Signatures -->
<div class="sec-title">👔 المراقبون وتوقيعاتهم</div>
${proctors.length ? `
<div class="proctor-grid">
  ${proctors.map((p,i) => `
  <div class="proctor-card">
    <div style="flex:1">
      <div class="proctor-name">${i+1}. ${p.name}</div>
      <div class="proctor-id">
        ${p.emp_id ? `الرقم الوظيفي: ${p.emp_id}` : ''}
        ${p.phone  ? ` &nbsp;|&nbsp; ${p.phone}` : ''}
      </div>
    </div>
    <div class="sig-area">
      <div class="sig-box" style="width:120px;min-height:50px;border-bottom:1.5px solid #94a3b8;position:relative">
        <div style="position:absolute;bottom:-18px;right:0;left:0;text-align:center;font-size:7.5pt;color:#94a3b8">التوقيع</div>
      </div>
    </div>
  </div>`).join('')}
</div>
<!-- Empty signature rows if needed -->
${proctors.length < 2 ? `<div style="margin-top:12px;display:grid;grid-template-columns:repeat(2,1fr);gap:10px">
  ${Array(2 - proctors.length).fill(0).map((_,i) => `
  <div class="proctor-card">
    <div style="flex:1">
      <div class="proctor-name" style="color:#94a3b8">${proctors.length+i+1}. ___________________________</div>
      <div class="proctor-id" style="color:#94a3b8">الرقم الوظيفي: __________</div>
    </div>
    <div class="sig-area">
      <div class="sig-box" style="width:120px;min-height:50px;border-bottom:1.5px solid #d1d5db;position:relative">
        <div style="position:absolute;bottom:-18px;right:0;left:0;text-align:center;font-size:7.5pt;color:#94a3b8">التوقيع</div>
      </div>
    </div>
  </div>`).join('')}
</div>` : ''}` : `
<!-- Empty proctor rows for manual fill -->
<div class="proctor-grid">
  ${[1,2].map(i => `
  <div class="proctor-card">
    <div style="flex:1">
      <div class="proctor-name" style="color:#94a3b8">${i}. ___________________________</div>
      <div class="proctor-id" style="color:#94a3b8">الرقم الوظيفي: __________</div>
    </div>
    <div class="sig-area">
      <div class="sig-box" style="width:120px;min-height:50px;border-bottom:1.5px solid #d1d5db;position:relative">
        <div style="position:absolute;bottom:-18px;right:0;left:0;text-align:center;font-size:7.5pt;color:#94a3b8">التوقيع</div>
      </div>
    </div>
  </div>`).join('')}
</div>`}

<!-- Footer Page 1 -->
<div class="footer">
  <span>${uniName} · ${collegeName}</span>
  <img src="${SQU_LOGO}" alt="SQU" onerror="this.style.display='none'">
  <span>ExamFlow · تقرير امتحان</span>
</div>

<!-- ═══ PAGE 2: Attendance List ═══ -->
<div class="page-break"></div>

<!-- Header Page 2 -->
<div class="hdr">
  <div class="hdr-logo">
    <img src="${SQU_LOGO}" alt="SQU" onerror="this.style.display='none'">
  </div>
  <div class="hdr-info">
    <div class="hdr-uni">${uniName} · ${collegeName}</div>
    <div class="hdr-col">كشف الحضور والغياب</div>
    <div class="hdr-sys">
      ${sub?.code ? `<b style="font-family:monospace">${sub.code}</b> · ` : ''}${sub?.name || '—'} — ${examDate} — امتحان ${examTypeLbl}
    </div>
    ${sections.length ? `<div style="font-size:8pt;color:#64748b;margin-top:2px">الشعب: ${sections.map(s=>s.name).join('، ')}</div>` : ''}
  </div>
  <div class="hdr-right">
    <div>الوقت: ${examTime} — ${endTime}</div>
    ${semLabel ? `<div>الفصل: ${semLabel}</div>` : ''}
  </div>
</div>

<!-- Attendance Stats -->
<div class="stat-row">
  <div class="stat-mini s-blue">
    <div class="n">${students.length}</div>
    <div class="l">إجمالي المقيّدين</div>
  </div>
  <div class="stat-mini s-green">
    <div class="n">${present.length}</div>
    <div class="l">حاضر / متأخر</div>
  </div>
  <div class="stat-mini s-red">
    <div class="n">${absent.length}</div>
    <div class="l">غائب / معذور</div>
  </div>
  <div class="stat-mini s-gray">
    <div class="n">${unknown.length}</div>
    <div class="l">لم يُسجّل</div>
  </div>
  <div class="stat-mini s-gold">
    <div class="n">${students.length ? Math.round(present.length/students.length*100) : 0}%</div>
    <div class="l">نسبة الحضور</div>
  </div>
</div>

<!-- Full Attendance Table -->
${students.length ? `
<div class="sec-title">📋 قائمة الطلاب الكاملة</div>
<table>
  <thead>
    <tr>
      <th style="width:36px;text-align:center">#</th>
      <th>اسم الطالب</th>
      <th style="width:110px;text-align:center">الرقم الجامعي</th>
      <th style="width:65px;text-align:center">الدفعة</th>
      <th style="width:85px;text-align:center">الحالة</th>
      <th style="width:120px">ملاحظة</th>
    </tr>
  </thead>
  <tbody>
    ${students.sort((a,b)=>a.name?.localeCompare(b.name)).map((s,i) => {
      const status = attMap[s.id];
      const stMap  = { present:['حاضر','s-p'], late:['متأخر','s-l'], absent:['غائب','s-a'], excused:['معذور','s-e'] };
      const [lbl,cls] = stMap[status] || ['—','s-u'];
      return `<tr>
        <td style="text-align:center;color:#94a3b8;font-size:9pt">${i+1}</td>
        <td style="font-weight:600">${s.name}</td>
        <td style="text-align:center;font-family:monospace;font-size:9pt">${s.stud_id||'—'}</td>
        <td style="text-align:center;font-size:9pt">${s.batch||'—'}</td>
        <td class="${cls}" style="text-align:center;font-size:9pt">${lbl}</td>
        <td style="border-bottom:1px dashed #e2e8f0"></td>
      </tr>`;
    }).join('')}
  </tbody>
</table>` : '<div style="text-align:center;padding:30px;color:#94a3b8">لم تُضاف شعب لهذا الامتحان</div>'}

<!-- Absent Students Section -->
${absent.length ? `
<div class="sec-title" style="margin-top:20px">❌ قائمة الغائبين (${absent.length})</div>
<div class="absent-grid">
  ${absent.map(s => `
  <div class="absent-card">
    <div class="absent-name">${s.name}</div>
    <div class="absent-id">${s.stud_id||'—'} ${attMap[s.id]==='excused'?' · معذور':''}</div>
  </div>`).join('')}
</div>` : ''}

<!-- Signature Section -->
<div style="margin-top:30px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;page-break-inside:avoid">

  <!-- المنسق -->
  <div style="text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:12px 8px">
    <div style="font-size:9pt;font-weight:700;color:#1e293b;margin-bottom:4px">منسق الكلية</div>
    <div style="font-size:8.5pt;color:#475569;margin-bottom:8px">${coordinator?.name || '—'}</div>
    ${coordinator?.signature
      ? `<img src="${coordinator.signature}" style="max-width:120px;max-height:48px;object-fit:contain;display:block;margin:0 auto 8px">`
      : `<div style="height:48px;border-bottom:1.5px solid #94a3b8;margin-bottom:8px"></div>`}
    <div style="font-size:7.5pt;color:#94a3b8">التوقيع</div>
  </div>

  <!-- رئيس القسم -->
  <div style="text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:12px 8px">
    <div style="font-size:9pt;font-weight:700;color:#1e293b;margin-bottom:4px">رئيس القسم</div>
    <div style="font-size:8.5pt;color:#475569;margin-bottom:8px">${deptHead?.name || (dept?.name ? 'قسم: '+dept.name : '—')}</div>
    ${deptHead?.signature
      ? `<img src="${deptHead.signature}" style="max-width:120px;max-height:48px;object-fit:contain;display:block;margin:0 auto 8px">`
      : `<div style="height:48px;border-bottom:1.5px solid #94a3b8;margin-bottom:8px"></div>`}
    <div style="font-size:7.5pt;color:#94a3b8">التوقيع</div>
  </div>

  <!-- الختم -->
  <div style="text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:12px 8px">
    <div style="font-size:9pt;font-weight:700;color:#1e293b;margin-bottom:4px">الختم الرسمي</div>
    <div style="height:60px;margin-bottom:8px"></div>
    <div style="font-size:7.5pt;color:#94a3b8">الختم</div>
  </div>

</div>

<!-- Footer Page 2 -->
<div class="footer">
  <span>${uniName} · ${collegeName} · ${printedAt}</span>
  <img src="${SQU_LOGO}" alt="SQU" onerror="this.style.display='none'">
  <span>ExamFlow · كشف حضور</span>
</div>

<script>window.onload=()=>{setTimeout(()=>{window.print();},600);}</script>
</body></html>`);
  printWin.document.close();
}

function _calcEndTime(startTime, totalMinutes) {
  if (!startTime) return '—';
  const [h,m] = startTime.split(':').map(Number);
  const total  = h*60 + m + totalMinutes;
  const hh     = Math.floor(total/60) % 24;
  const mm     = total % 60;
  const ampm   = hh < 12 ? 'ص' : 'م';
  return `${hh%12||12}:${String(mm).padStart(2,'0')} ${ampm}`;
}

// ═══════════════════════════════════════════════════════════════
//  FEATURE 5: تقارير PDF مع رسوم بيانية - تقرير الفصل الكامل
// ═══════════════════════════════════════════════════════════════

function exportSemesterReportPDF() {
  const sem      = STATE.currentSem;
  const semLabel = STATE.semesters.find(s=>s.code===sem)?.label || sem;
  const exams    = STATE.exams.filter(e => e.semester === sem);
  const proctors = STATE.profiles.filter(p => p.role==='proctor' && p.active);
  const uniName  = STATE.settings?.university_name || 'جامعة السلطان قابوس';

  if (!exams.length) { toast('لا توجد امتحانات في هذا الفصل','warning'); return; }

  // ─── إحصاءات ─────────────────────────────────────────────────
  const totalExams    = exams.length;
  const completed     = exams.filter(e => examStatus(e)==='completed').length;
  const upcoming      = exams.filter(e => examStatus(e)==='upcoming').length;
  const active        = exams.filter(e => examStatus(e)==='active').length;

  // حضور كلي
  let totalStuds = 0, presentStuds = 0;
  exams.forEach(e => {
    const att = STATE.attendance[e.id] || {};
    Object.values(att).forEach(s => {
      totalStuds++;
      if (s==='present'||s==='late') presentStuds++;
    });
  });
  const attRate = totalStuds > 0 ? Math.round(presentStuds/totalStuds*100) : 0;

  // توزيع الأنواع
  const byType = { final:0, midterm:0, quiz:0, makeup:0 };
  exams.forEach(e => { if (byType[e.type]!==undefined) byType[e.type]++; });

  // أعلى المراقبين مراقبةً
  const proctLoad = {};
  exams.forEach(e => (e.proctor_ids||[]).forEach(id => { proctLoad[id] = (proctLoad[id]||0)+1; }));
  const topProcts = proctors
    .map(p => ({ ...p, load: proctLoad[p.id]||0 }))
    .filter(p => p.load > 0)
    .sort((a,b) => b.load-a.load)
    .slice(0, 10);

  // ─── بيانات الرسوم البيانية (SVG inline) ──────────────────────
  const barChart = _buildBarChartSVG(
    ['نهائي','منتصف الفصل','اختبار','إعادة'],
    [byType.final, byType.midterm, byType.quiz, byType.makeup],
    ['#2563eb','#d97706','#0891b2','#7c3aed'],
    'توزيع أنواع الامتحانات', 520, 180
  );

  const proctBarChart = topProcts.length ? _buildBarChartSVG(
    topProcts.map(p => p.name?.split(' ').slice(0,2).join(' ')),
    topProcts.map(p => p.load),
    topProcts.map((_,i) => ['#2563eb','#059669','#d97706','#7c3aed','#ef4444','#0891b2','#f59e0b','#8b5cf6','#10b981','#3b82f6'][i%10]),
    'عدد مراقبات كل مراقب هذا الفصل', 520, 200
  ) : '';

  const attendanceDonut = _buildDonutSVG(
    presentStuds, totalStuds - presentStuds,
    ['#10b981','#ef4444'], 'حاضر', 'غائب', 130
  );

  // ─── HTML التقرير ─────────────────────────────────────────────
  const html = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'Tajawal',sans-serif; background:#fff; color:#1e293b; font-size:12px; direction:rtl; }
  .page { width:210mm; min-height:297mm; padding:16mm 14mm; margin:0 auto; }
  .header { display:flex; align-items:center; justify-content:space-between; border-bottom:2.5px solid #2563eb; padding-bottom:14px; margin-bottom:20px; }
  .logo { height:52px; object-fit:contain; }
  .header-mid { text-align:center; }
  .uni-name { font-size:14px; font-weight:900; color:#1e3a5f; }
  .rep-title { font-size:19px; font-weight:900; color:#2563eb; margin:4px 0; }
  .rep-sub { font-size:11px; color:#64748b; }
  .stats-row { display:grid; grid-template-columns:repeat(5,1fr); gap:10px; margin-bottom:20px; }
  .stat-box { text-align:center; padding:12px 8px; border-radius:10px; border:1.5px solid; }
  .stat-num { font-size:26px; font-weight:900; }
  .stat-lbl { font-size:10px; margin-top:2px; }
  .section { margin-bottom:22px; }
  .sec-title { font-size:13px; font-weight:900; color:#1e3a5f; padding:7px 14px; background:#eff6ff; border-radius:8px; border-right:4px solid #2563eb; margin-bottom:12px; }
  .charts-row { display:grid; grid-template-columns:1fr auto; gap:16px; align-items:center; }
  table { width:100%; border-collapse:collapse; font-size:11px; }
  th { background:#f1f5f9; padding:7px 10px; text-align:right; font-weight:800; font-size:10.5px; color:#475569; }
  td { padding:7px 10px; border-bottom:1px solid #f1f5f9; }
  tr:hover td { background:#f8fafc; }
  .badge { display:inline-block; padding:2px 9px; border-radius:20px; font-size:10px; font-weight:700; }
  .bg { color:#059669; background:#ecfdf5; border:1px solid #bbf7d0; }
  .br { color:#dc2626; background:#fef2f2; border:1px solid #fecaca; }
  .bb { color:#2563eb; background:#eff6ff; border:1px solid #bfdbfe; }
  .by { color:#d97706; background:#fffbeb; border:1px solid #fde68a; }
  .footer { margin-top:24px; padding-top:12px; border-top:1px solid #e2e8f0; display:flex; justify-content:space-between; font-size:9.5px; color:#94a3b8; }
  @media print { body{print-color-adjust:exact;-webkit-print-color-adjust:exact} }
</style>
</head>
<body>
<div class="page">

  <div class="header">
    <img src="${SQU_LOGO}" class="logo" onerror="this.style.display='none'">
    <div class="header-mid">
      <div class="uni-name">${uniName} · كلية التمريض</div>
      <div class="rep-title">تقرير الفصل الدراسي الشامل</div>
      <div class="rep-sub">${semLabel}</div>
    </div>
    <div style="text-align:left;font-size:10px;color:#94a3b8">
      <div>ExamFlow v10</div>
      <div>${new Date().toLocaleDateString('ar-OM',{year:'numeric',month:'long',day:'numeric'})}</div>
    </div>
  </div>

  <!-- إحصاءات سريعة -->
  <div class="stats-row">
    <div class="stat-box" style="border-color:#bfdbfe;background:#eff6ff">
      <div class="stat-num" style="color:#2563eb">${totalExams}</div>
      <div class="stat-lbl" style="color:#2563eb">إجمالي الامتحانات</div>
    </div>
    <div class="stat-box" style="border-color:#bbf7d0;background:#ecfdf5">
      <div class="stat-num" style="color:#059669">${completed}</div>
      <div class="stat-lbl" style="color:#059669">مكتملة</div>
    </div>
    <div class="stat-box" style="border-color:#fde68a;background:#fffbeb">
      <div class="stat-num" style="color:#d97706">${upcoming}</div>
      <div class="stat-lbl" style="color:#d97706">قادمة</div>
    </div>
    <div class="stat-box" style="border-color:#c4b5fd;background:#f5f3ff">
      <div class="stat-num" style="color:#7c3aed">${proctors.filter(p=>proctLoad[p.id]).length}</div>
      <div class="stat-lbl" style="color:#7c3aed">مراقبون نشطون</div>
    </div>
    <div class="stat-box" style="border-color:${attRate>=80?'#bbf7d0':'#fecaca'};background:${attRate>=80?'#ecfdf5':'#fef2f2'}">
      <div class="stat-num" style="color:${attRate>=80?'#059669':'#dc2626'}">${attRate}%</div>
      <div class="stat-lbl" style="color:${attRate>=80?'#059669':'#dc2626'}">نسبة الحضور</div>
    </div>
  </div>

  <!-- الرسوم البيانية -->
  <div class="section">
    <div class="sec-title">📊 الرسوم البيانية والتحليلات</div>
    <div class="charts-row">
      <div>
        ${barChart}
        ${proctBarChart}
      </div>
      <div style="text-align:center">
        ${attendanceDonut}
        <div style="font-size:11px;font-weight:800;margin-top:8px">نسبة الحضور الكلية</div>
        <div style="font-size:10px;color:#64748b;margin-top:4px">${presentStuds} حاضر / ${totalStuds} إجمالي</div>
      </div>
    </div>
  </div>

  <!-- قائمة الامتحانات -->
  <div class="section">
    <div class="sec-title">📋 قائمة الامتحانات</div>
    <table>
      <thead>
        <tr>
          <th>#</th><th>المادة</th><th>النوع</th><th>التاريخ</th><th>الوقت</th><th>المدة</th><th>القاعات</th><th>الحالة</th>
        </tr>
      </thead>
      <tbody>
        ${exams.sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`)).map((e,i) => {
          const sub   = getSubject(e.subject_id);
          const rooms = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join(', ');
          const st    = examStatus(e);
          const stLbl = {active:'جارٍ',upcoming:'قادم',completed:'مكتمل'};
          const stCls = {active:'by',upcoming:'bb',completed:'bg'};
          const typeLbl={final:'نهائي',midterm:'منتصف',quiz:'اختبار',makeup:'إعادة'};
          return `<tr>
            <td style="color:#94a3b8">${i+1}</td>
            <td style="font-weight:700">${sub?.name||'—'}</td>
            <td><span class="badge bb">${typeLbl[e.type]||e.type}</span></td>
            <td>${e.date}</td>
            <td>${fmtTime(e.time)}</td>
            <td>${e.duration}د</td>
            <td style="color:#0891b2">${rooms||'—'}</td>
            <td><span class="badge ${stCls[st]||'bb'}">${stLbl[st]||st}</span></td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  </div>

  <!-- جدول المراقبين -->
  ${topProcts.length ? `<div class="section">
    <div class="sec-title">👔 أداء المراقبين</div>
    <table>
      <thead><tr><th>#</th><th>المراقب</th><th>القسم</th><th>عدد المراقبات</th><th>النقاط</th><th>التقييم</th></tr></thead>
      <tbody>
        ${topProcts.map((p,i) => {
          const dept = STATE.departments.find(d=>d.id===p.dept_id);
          const stars = '★'.repeat(Math.round(p.avg_rating||0)) + '☆'.repeat(5-Math.round(p.avg_rating||0));
          return `<tr>
            <td style="color:#94a3b8">${i+1}</td>
            <td style="font-weight:700">${p.name}</td>
            <td style="color:#7c3aed">${dept?.name||'—'}</td>
            <td style="text-align:center;font-weight:900;color:#2563eb">${p.load}</td>
            <td style="text-align:center;font-weight:900;color:#d97706">${p.points||0}</td>
            <td style="color:#d97706;letter-spacing:2px">${stars}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  </div>` : ''}

  <div class="footer">
    <span>ExamFlow v10 · ${uniName} · كلية التمريض</span>
    <span>طُبع: ${new Date().toLocaleString('ar-OM')}</span>
  </div>
</div>
<script>window.onload=()=>window.print();</script>
</body></html>`;

  const win = window.open('','_blank','width=900,height=700');
  if (!win) { toast('يرجى السماح بالنوافذ المنبثقة','warning'); return; }
  win.document.write(html);
  win.document.close();
}

// ── مساعد رسم الأعمدة (SVG inline) ─────────────────────────────
function _buildBarChartSVG(labels, values, colors, title, w, h) {
  const max    = Math.max(...values, 1);
  const barW   = Math.floor((w - 60) / labels.length) - 8;
  const padL   = 50, padB = 40, padT = 30;
  const chartH = h - padT - padB;

  const bars = labels.map((lbl, i) => {
    const bh  = Math.round((values[i] / max) * chartH);
    const x   = padL + i * (barW + 8);
    const y   = padT + chartH - bh;
    const col = colors[i % colors.length];
    return `<rect x="${x}" y="${y}" width="${barW}" height="${bh}" fill="${col}" rx="4"/>
      <text x="${x+barW/2}" y="${y-5}" text-anchor="middle" font-size="11" font-weight="700" fill="${col}">${values[i]}</text>
      <text x="${x+barW/2}" y="${h-8}" text-anchor="middle" font-size="9" fill="#64748b">${lbl.slice(0,7)}</text>`;
  }).join('');

  // خطوط الشبكة
  const grids = [0,.25,.5,.75,1].map(f => {
    const y = padT + chartH * (1-f);
    return `<line x1="${padL}" y1="${y}" x2="${w-10}" y2="${y}" stroke="#e2e8f0" stroke-width="1"/>
      <text x="${padL-6}" y="${y+4}" text-anchor="end" font-size="9" fill="#94a3b8">${Math.round(max*f)}</text>`;
  }).join('');

  return `<div style="margin-bottom:14px">
    <div style="font-size:11px;font-weight:800;color:#475569;margin-bottom:6px;text-align:center">${title}</div>
    <svg width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg" style="overflow:visible">
      ${grids}${bars}
      <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${padT+chartH}" stroke="#e2e8f0" stroke-width="1.5"/>
      <line x1="${padL}" y1="${padT+chartH}" x2="${w-10}" y2="${padT+chartH}" stroke="#e2e8f0" stroke-width="1.5"/>
    </svg>
  </div>`;
}

// ── مساعد الدونات (SVG) ──────────────────────────────────────────
function _buildDonutSVG(v1, v2, colors, l1, l2, size) {
  const total = v1 + v2;
  if (!total) return `<div style="width:${size}px;height:${size}px;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:11px">لا بيانات</div>`;
  const r = size/2 - 8;
  const cx = size/2, cy = size/2;
  const pct1 = v1 / total;
  const a1 = pct1 * 2 * Math.PI;
  const x1 = cx + r * Math.sin(a1), y1 = cy - r * Math.cos(a1);
  const big = pct1 > 0.5 ? 1 : 0;

  const arc = total===v1
    ? `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${colors[0]}" stroke-width="22"/>`
    : `<path d="M ${cx} ${cy-r} A ${r} ${r} 0 ${big} 1 ${x1} ${y1} L ${cx} ${cy} Z" fill="${colors[0]}"/>
       <path d="M ${cx} ${cy-r} A ${r} ${r} 0 ${1-big} 0 ${x1} ${y1} L ${cx} ${cy} Z" fill="${colors[1]}"/>
       <circle cx="${cx}" cy="${cy}" r="${r*0.55}" fill="white"/>`;

  return `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
    ${arc}
    <text x="${cx}" y="${cy+4}" text-anchor="middle" font-size="14" font-weight="900" fill="#1e293b">${Math.round(pct1*100)}%</text>
    <text x="${cx}" y="${size-2}" text-anchor="middle" font-size="9" fill="${colors[0]}">${l1}: ${v1}</text>
  </svg>`;
}

// ─── زر تقرير الفصل من داخل Analytics ──────────────────────────
function _addSemesterReportBtn() {
  const el = document.getElementById('anaActs');
  if (!el || el.querySelector('.semrep-btn')) return;
  const btn = document.createElement('button');
  btn.className = 'btn bo btn-sm semrep-btn';
  btn.innerHTML = '<i class="fas fa-file-pdf" style="color:var(--red2)"></i> تقرير الفصل PDF';
  btn.onclick = exportSemesterReportPDF;
  el.insertBefore(btn, el.firstChild);
}
