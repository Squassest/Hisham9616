// ═══════════════════════════════════════════════════════════════
//  exam-wizard.js — معالج إنشاء الامتحانات v3 (محسّن)
//  4 خطوات: المعلومات → القاعات → المراقبون + الشعب → المراجعة
//  ✓ فلتر القسم للمراقبين  ✓ معاينة الاقتراح التلقائي
//  ✓ dropdowns ثابتة Position  ✓ chips احترافية
// ═══════════════════════════════════════════════════════════════

let _WIZ = {
  step: 1, editId: null, subjectId: null,
  date: '', time: '', duration: 120, type: 'final', notes: '',
  rooms: [],        // [rid, ...]
  roomMap: {},      // { rid: [uid, ...] }  — مراقبو كل قاعة
  roomSections: {}, // { rid: [sid, ...] }  — شعب كل قاعة
  procDeptFilter: null // فلتر القسم الحالي لاختيار المراقبين
};

// ══ الدخول للمعالج ════════════════════════════════════════════
function openAddExam() {
  // ✅ صلاحية: المسؤول والمنسق فقط
  if (typeof canCreateExam === 'function' && !canCreateExam()) {
    toast('غير مصرح — فقط المسؤول والمنسقون يمكنهم إنشاء الامتحانات', 'error', 4500);
    return;
  }
  // ✅ فحص حماية: التأكد أن البيانات الأساسية محمَّلة
  if (!STATE.subjects?.length) {
    toast('جارٍ تحميل بيانات المواد، يرجى الانتظار قليلاً ثم المحاولة مجدداً', 'warning', 4000);
    return;
  }
  if (!STATE.rooms?.length) {
    toast('لا توجد قاعات في النظام — أضف قاعات أولاً من صفحة "القاعات"', 'warning', 5000);
    return;
  }
  const now = new Date();
  _WIZ = {
    step: 1, editId: null, subjectId: null,
    date: now.toISOString().split('T')[0],
    time: `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`,
    duration: 120, type: 'final', notes: '',
    rooms: [], roomMap: {}, roomSections: {},
    procDeptFilter: null
  };
  _showWizard();
}

function openEditExam(id) {
  const e = getExam(id);
  if (!e) return;
  if (examStatus(e) === 'active') { toast('لا يمكن تعديل امتحان جارٍ','warning'); return; }
  _WIZ = {
    step: 1, editId: id,
    subjectId: e.subject_id,
    date: e.date,
    time: e.time?.slice(0,5) || '08:00',
    duration: e.duration || 120,
    type: e.type || 'final',
    notes: e.notes || '',
    rooms: [...(e.room_ids||[])],
    roomMap: JSON.parse(JSON.stringify(e.room_proctors||{})),
    roomSections: JSON.parse(JSON.stringify(e.room_sections||{}))
  };
  _showWizard();
}

// ══ عرض المعالج ═══════════════════════════════════════════════
function _showWizard() {
  let mo = document.getElementById('examWizardMo');
  if (!mo) {
    mo = document.createElement('div'); mo.className='mo'; mo.id='examWizardMo';
    document.body.appendChild(mo);
  }
  _renderWizardStep();
  showMo('examWizardMo');
}

function _renderWizardStep() {
  const mo = document.getElementById('examWizardMo');
  if (!mo) return;
  const isEdit = !!_WIZ.editId;
  const steps  = ['المعلومات الأساسية','القاعات','المراقبون والشعب','المراجعة'];

  mo.innerHTML = `
  <div class="md" style="max-width:780px;max-height:92vh;display:flex;flex-direction:column">

    <!-- رأس المعالج -->
    <div class="md-hd" style="padding:16px 22px;flex-shrink:0">
      <h2>
        <div style="width:34px;height:34px;border-radius:10px;background:var(--primary)15;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-${isEdit?'edit':'plus-circle'}" style="color:var(--primary2)"></i>
        </div>
        ${isEdit?'تعديل الامتحان':'امتحان جديد'}
      </h2>
      <button class="md-close" onclick="closeMo('examWizardMo')"><i class="fas fa-times"></i></button>
    </div>

    <!-- شريط الخطوات -->
    <div style="padding:0 22px 14px;flex-shrink:0;border-bottom:1px solid var(--border)">
      <div style="display:flex;gap:0;position:relative">
        <div style="position:absolute;top:16px;right:0;left:0;height:2px;background:var(--border);z-index:0"></div>
        <div style="position:absolute;top:16px;right:0;height:2px;background:var(--primary2);z-index:1;
          width:${(_WIZ.step-1)/3*100}%;transition:width .4s"></div>
        ${steps.map((s,i) => {
          const n=i+1, done=_WIZ.step>n, active=_WIZ.step===n;
          return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;position:relative;z-index:2;cursor:${done?'pointer':'default'}" onclick="${done?`_wizGoTo(${n})`:''}">
            <div style="width:32px;height:32px;border-radius:50%;border:2.5px solid ${active||done?'var(--primary2)':'var(--border)'};
              background:${active||done?'var(--primary2)':'var(--card)'};
              display:flex;align-items:center;justify-content:center;transition:all .35s">
              ${done?`<i class="fas fa-check" style="color:white;font-size:12px"></i>`:`<span style="font-size:12px;font-weight:900;color:${active?'white':'var(--txt3)'}">${n}</span>`}
            </div>
            <div style="font-size:10.5px;font-weight:${active?800:600};color:${active?'var(--primary2)':'var(--txt3)'};white-space:nowrap">${s}</div>
          </div>`;
        }).join('')}
      </div>
    </div>

    <!-- محتوى الخطوة -->
    <div class="md-bd" style="flex:1;overflow-y:auto;padding:0" id="wizBody">
      ${_wizStepHTML()}
    </div>

    <!-- أزرار التنقل -->
    <div class="md-ft" style="flex-shrink:0;justify-content:space-between">
      <div>
        ${_WIZ.step>1?`<button class="btn bo" onclick="_wizPrev()"><i class="fas fa-arrow-right"></i> السابق</button>`:`<button class="btn bo" onclick="closeMo('examWizardMo')">إلغاء</button>`}
      </div>
      <div style="display:flex;gap:8px">
        ${_WIZ.step<4
          ?`<button class="btn bp" onclick="_wizNext()" id="wizNextBtn">التالي <i class="fas fa-arrow-left"></i></button>`
          :`<button class="btn bp" id="wizSaveBtn" onclick="_saveExamWizard()">
              <i class="fas fa-save"></i> ${isEdit?'تحديث الامتحان':'تأكيد وإبلاغ المراقبين'}
            </button>`}
      </div>
    </div>
  </div>`;

  requestAnimationFrame(() => _wizAfterRender());
}

// ══ محتوى كل خطوة ════════════════════════════════════════════
function _wizStepHTML() {
  switch (_WIZ.step) {
    case 1: return _wizStep1HTML();
    case 2: return _wizStep2HTML();
    case 3: return _wizStep3HTML();
    case 4: return _wizStep4HTML();
    default: return '';
  }
}

// ══ الخطوة 1: المعلومات الأساسية ════════════════════════════
function _wizStep1HTML() {
  const pts = typeof _calcExamPoints==='function'
    ? _calcExamPoints({date:_WIZ.date,time:_WIZ.time,type:_WIZ.type,is_holiday:_isAutoHoliday?.(_WIZ.date)||false}) : 0;

  return `<div style="padding:20px 22px">
    <div style="font-size:12px;color:var(--txt3);margin-bottom:16px;padding:10px 14px;background:var(--primary)06;border-radius:9px;border:1px solid var(--primary2)15">
      <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
      حدد المقرر والتاريخ والوقت للمتابعة لاختيار القاعات المتاحة
    </div>

    <div class="g2">
      <div class="field" style="grid-column:1/-1">
        <label class="field-lbl">المقرر الدراسي <span class="req">*</span></label>
        <select id="wz_subj" style="height:46px;font-size:14px" onchange="_wizSubjChange(this.value)">
          <option value="">— اختر المقرر —</option>
          ${(()=>{
            // ✅ المنسق يرى فقط مواد قسمه (إجباري)
            // المسؤول يرى كل المواد
            const myDeptId = STATE.currentUser?.dept_id;
            const filterByDept = isCoord();   // المنسق دائماً مقيَّد بقسمه

            if (filterByDept && !myDeptId) {
              return '<option value="" disabled>قسمك غير محدد — تواصل مع المسؤول</option>';
            }

            const filteredSubjects = filterByDept
              ? STATE.subjects.filter(s => String(s.dept_id) === String(myDeptId))
              : STATE.subjects.slice();

            // ✅ حالة الطوارئ: لا توجد مواد على الإطلاق
            if (!filteredSubjects.length) {
              return `<option value="" disabled>لا توجد مواد متاحة${filterByDept?' لقسمك':''}</option>`;
            }

            // ✅ ترتيب: مجموعات الأقسام أولاً، ثم بقية المواد
            const grouped = {};
            const orphan  = [];
            const knownDeptIds = new Set(STATE.departments.map(d => String(d.id)));

            filteredSubjects.forEach(s => {
              const k = String(s.dept_id || '');
              if (k && knownDeptIds.has(k)) {
                if (!grouped[k]) grouped[k] = [];
                grouped[k].push(s);
              } else {
                orphan.push(s);
              }
            });

            let html = '';
            STATE.departments.forEach(d => {
              const items = grouped[String(d.id)] || [];
              if (!items.length) return;
              html += `<optgroup label="${esc(d.name)}">`;
              items
                .sort((a,b) => (a.name||'').localeCompare(b.name||'','ar'))
                .forEach(s => {
                  html += `<option value="${s.id}" ${s.id==_WIZ.subjectId?'selected':''}>${esc(s.name)}${s.code?' ('+esc(s.code)+')':''}</option>`;
                });
              html += '</optgroup>';
            });
            if (orphan.length) {
              html += '<optgroup label="مواد أخرى">';
              orphan
                .sort((a,b) => (a.name||'').localeCompare(b.name||'','ar'))
                .forEach(s => {
                  html += `<option value="${s.id}" ${s.id==_WIZ.subjectId?'selected':''}>${esc(s.name)}${s.code?' ('+esc(s.code)+')':''}</option>`;
                });
              html += '</optgroup>';
            }
            return html;
          })()}
        </select>
      </div>

      <div class="field">
        <label class="field-lbl">نوع الامتحان</label>
        <select id="wz_type" style="height:46px" onchange="_WIZ.type=this.value;_wizRefreshPoints()">
          ${[['final','📋 نهائي'],['midterm','📝 منتصف الفصل'],['quiz','📄 اختبار'],['makeup','🔄 إعادة']]
            .map(([v,l])=>`<option value="${v}" ${_WIZ.type===v?'selected':''}>${l}</option>`).join('')}
        </select>
      </div>

      <div class="field">
        <label class="field-lbl">التاريخ <span class="req">*</span></label>
        <input type="date" id="wz_date" value="${_WIZ.date}" style="height:46px"
          min="${new Date().toISOString().split('T')[0]}"
          onchange="_WIZ.date=this.value;_wizRefreshPoints()">
      </div>

      <div class="field">
        <label class="field-lbl">وقت البدء <span class="req">*</span></label>
        <input type="time" id="wz_time" value="${_WIZ.time}" style="height:46px"
          onchange="_WIZ.time=this.value;_wizRefreshPoints()">
        <div style="font-size:10.5px;color:var(--primary2);margin-top:4px">
          <i class="fas fa-clock" style="font-size:10px"></i> الوقت الحالي: ${new Date().toTimeString().slice(0,5)}
        </div>
      </div>

      <div class="field" style="grid-column:1/-1">
        <label class="field-lbl">مدة الامتحان</label>
        <div style="display:flex;gap:7px;margin-bottom:9px;flex-wrap:wrap">
          ${[[60,'ساعة'],[90,'90 دق'],[120,'ساعتان'],[180,'3 ساعات']].map(([v,l])=>`
            <button type="button" class="btn bo btn-sm wz-dur" data-v="${v}"
              style="${_WIZ.duration===v?'background:var(--primary2);color:white;border-color:var(--primary2)':''}"
              onclick="_wizSetDur(${v})">${l}</button>`).join('')}
          <button type="button" class="btn bo btn-sm wz-dur" data-v="custom" onclick="_wizSetDur('custom')">
            <i class="fas fa-edit" style="font-size:11px"></i> يدوي
          </button>
        </div>
        <input type="number" id="wz_dur" value="${_WIZ.duration}" min="30" max="480"
          style="height:42px;max-width:160px"
          oninput="_WIZ.duration=parseInt(this.value)||120;document.querySelectorAll('.wz-dur').forEach(b=>{b.style.background='';b.style.color='';b.style.borderColor=''})">
        <span style="font-size:11.5px;color:var(--txt3);margin-right:8px">دقيقة</span>
      </div>
    </div>

    <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap">
      <div id="wz_holiday" style="flex:1;min-width:150px;padding:10px 14px;border-radius:10px;border:1.5px solid var(--border);background:var(--bg);font-size:12.5px;display:flex;align-items:center;gap:8px">
        <i class="fas fa-calendar-check" style="font-size:15px;color:var(--txt3)" id="wz_holidayIco"></i>
        <span id="wz_holidayLbl">—</span>
      </div>
      <div style="flex:1;min-width:150px;padding:10px 14px;border-radius:10px;border:1.5px solid var(--gold)40;background:var(--gold)08;display:flex;align-items:center;gap:8px">
        <i class="fas fa-trophy" style="color:var(--gold);font-size:15px"></i>
        <div>
          <div style="font-size:9.5px;color:var(--txt3)">نقاط المراقب</div>
          <div style="font-weight:900;color:var(--gold);font-size:19px" id="wz_pts">${pts}</div>
        </div>
      </div>
    </div>

    <div class="field" style="margin-top:14px">
      <label class="field-lbl">ملاحظات تظهر للمراقبين</label>
      <textarea id="wz_notes" rows="2" placeholder="اختياري..."
        onchange="_WIZ.notes=this.value">${_WIZ.notes}</textarea>
    </div>
  </div>`;
}

// ══ الخطوة 2: القاعات المتاحة ════════════════════════════════
function _wizStep2HTML() {
  const endTime = _wizCalcEnd(_WIZ.date, _WIZ.time, _WIZ.duration);
  const editId  = _WIZ.editId;
  const startTs = new Date(`${_WIZ.date}T${_WIZ.time}`).getTime();
  const endTs   = new Date(`${_WIZ.date}T${endTime}`).getTime();
  const dow     = new Date(_WIZ.date).getDay();

  // ── جمع كل التعارضات المحتملة لكل قاعة ──────────────────────
  const roomsData = STATE.rooms.map(r => {
    const conflicts = [];

    // 1) امتحانات أخرى
    STATE.exams.forEach(e => {
      if (e.id === editId) return;
      if (e.date !== _WIZ.date) return;
      if (!(e.room_ids||[]).includes(r.id)) return;
      const eS = e.time?.slice(0,5)||'00:00';
      const eE = _wizCalcEnd(e.date, eS, (e.duration||60)+(e.extra_time||0));
      if (_WIZ.time < eE && endTime > eS) {
        const s = getSubject(e.subject_id);
        conflicts.push({ type:'exam', label:`امتحان "${s?.name||'—'}"`, time:`${eS}—${eE}` });
      }
    });

    // 2) حجوزات قاعات (محاضرات/فعاليات)
    (STATE.bookings||[]).forEach(b => {
      if (b.date !== _WIZ.date) return;
      if (b.room_id !== r.id) return;
      const bs = new Date(`${b.date}T${b.start_time||'00:00'}`).getTime();
      const be = new Date(`${b.date}T${b.end_time||'23:59'}`).getTime();
      if (startTs < be && endTs > bs) {
        const purp = APP_CONFIG.BOOKING_PURPOSES?.[b.purpose]?.label || b.purpose;
        conflicts.push({ type:'booking', label:`حجز ${purp}: "${b.title||'—'}"`, time:`${b.start_time}—${b.end_time}` });
      }
    });

    // 3) جدول المحاضرات الأسبوعي
    const schedSrc = STATE.semesterSchedules?.length
      ? STATE.semesterSchedules
      : STATE.schedules;
    (schedSrc||[]).forEach(sc => {
      if (sc.is_active === false) return;
      if (Number(sc.room_id) !== Number(r.id)) return;
      if (Number(sc.day_of_week) !== dow) return;
      const ss = new Date(`${_WIZ.date}T${sc.start_time||'00:00'}`).getTime();
      const se = new Date(`${_WIZ.date}T${sc.end_time||'23:59'}`).getTime();
      if (startTs < se && endTs > ss) {
        const sub = sc.subject_id ? getSubject(sc.subject_id) : null;
        conflicts.push({ type:'lecture', label:`محاضرة "${sub?.name||'—'}"`, time:`${sc.start_time}—${sc.end_time}` });
      }
    });

    return { room:r, conflicts, isSelected:_WIZ.rooms.includes(r.id) };
  });

  const free = roomsData.filter(x => !x.conflicts.length);
  const busy = roomsData.filter(x =>  x.conflicts.length);

  return `<div style="padding:20px 22px">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      <div style="font-size:13px;font-weight:700">
        <i class="fas fa-clock" style="color:var(--primary2);margin-left:5px"></i>
        ${fmtTime(_WIZ.time)} — ${fmtTime(endTime)} · ${_WIZ.duration} دقيقة
      </div>
      <div style="font-size:12px;color:var(--txt3)">في: <strong>${fmtDate(_WIZ.date)}</strong></div>
      <span class="badge b-green" style="margin-right:auto">${free.length} قاعة متاحة</span>
      <span class="badge b-red">${busy.length} محجوزة</span>
    </div>

    <!-- ── ملاحظة الإجبار ── -->
    <div style="padding:10px 13px;background:var(--gold)08;border-radius:9px;border:1px solid var(--gold)25;margin-bottom:14px;font-size:12px;color:var(--txt2)">
      <i class="fas fa-info-circle" style="color:var(--gold);margin-left:5px"></i>
      <b>الامتحان له الأولوية</b> على المحاضرات والحجوزات. يمكنك اختيار قاعة <b>مشغولة</b> بمحاضرة وسيتم إخطار صاحب الحجز تلقائياً.
    </div>

    <!-- ── القاعات المتاحة ── -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-bottom:16px">
      ${free.map(({room,isSelected}) => {
        const info=typeof getRoomTypeInfo==='function'?getRoomTypeInfo(room.type):{icon:'fa-door-open',color:'var(--teal)',label:''};
        return `<div onclick="_wizToggleRoom(${room.id})"
          style="padding:14px;border-radius:13px;border:2px solid ${isSelected?'var(--primary2)':'var(--border)'};
            background:${isSelected?'var(--primary2)08':'var(--card)'};cursor:pointer;transition:all .2s;position:relative"
          onmouseover="if(!this.style.borderColor.includes('primary'))this.style.borderColor='var(--primary2)60'"
          onmouseout="if(!${isSelected})this.style.borderColor='var(--border)'">
          ${isSelected?`<div style="position:absolute;top:8px;left:8px;width:22px;height:22px;border-radius:50%;background:var(--primary2);display:flex;align-items:center;justify-content:center">
            <i class="fas fa-check" style="color:white;font-size:10px"></i></div>`:'' }
          <div style="display:flex;align-items:center;gap:9px;margin-bottom:8px">
            <div style="width:36px;height:36px;border-radius:9px;background:${info.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fas ${info.icon}" style="color:${info.color};font-size:15px"></i>
            </div>
            <div>
              <div style="font-weight:800;font-size:13.5px">${esc(room.name)}</div>
              <div style="font-size:10.5px;color:var(--txt3)">${info.label||room.type||''}</div>
            </div>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--txt2)">
            <span><i class="fas fa-users" style="margin-left:3px"></i>${room.cap} مقعد</span>
            <span class="badge b-green" style="font-size:10px">✓ متاحة</span>
          </div>
        </div>`;
      }).join('')}
    </div>

    ${busy.length?`<details ${free.length?'':'open'}>
      <summary style="font-size:12.5px;font-weight:700;color:var(--gold);cursor:pointer;padding:8px 12px;background:var(--gold)08;border-radius:9px;border:1px solid var(--gold)30;list-style:none;display:flex;align-items:center;gap:7px">
        <i class="fas fa-exclamation-triangle"></i> قاعات بها تعارض (${busy.length}) — يمكن إجبار الحجز
        <i class="fas fa-chevron-down" style="margin-right:auto;font-size:11px"></i>
      </summary>
      <div style="margin-top:8px;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px">
        ${busy.map(({room,conflicts,isSelected})=>{
          const info=typeof getRoomTypeInfo==='function'?getRoomTypeInfo(room.type):{icon:'fa-door-open',color:'var(--gold)',label:''};
          // أنواع التعارض: امتحان آخر يمنع — محاضرة/حجز يمكن تجاوزه
          const hasExamConflict = conflicts.some(c => c.type === 'exam');
          return `<div onclick="${hasExamConflict?'':`_wizToggleRoom(${room.id})`}"
            style="padding:12px;border-radius:11px;border:2px solid ${isSelected?'var(--gold)':hasExamConflict?'var(--red2)40':'var(--gold)40'};background:${isSelected?'var(--gold)15':'var(--card)'};${hasExamConflict?'opacity:.55;cursor:not-allowed':'cursor:pointer'};position:relative;transition:all .15s">
            ${isSelected?`<div style="position:absolute;top:6px;left:6px;width:20px;height:20px;border-radius:50%;background:var(--gold);display:flex;align-items:center;justify-content:center">
              <i class="fas fa-check" style="color:white;font-size:9px"></i></div>`:''}
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:7px">
              <i class="fas ${info.icon}" style="color:${info.color}"></i>
              <b style="font-size:13px">${esc(room.name)}</b>
              <span style="font-size:10px;color:var(--txt3);margin-right:auto">${room.cap} مقعد</span>
            </div>
            <div style="font-size:10.5px;color:var(--txt2);line-height:1.5">
              ${conflicts.map(c => {
                const colors = { exam:'var(--red2)', booking:'var(--gold)', lecture:'var(--purple2)' };
                const icons  = { exam:'fa-file-alt',  booking:'fa-calendar-check', lecture:'fa-chalkboard-teacher' };
                return `<div style="display:flex;align-items:center;gap:5px;padding:3px 0">
                  <i class="fas ${icons[c.type]||'fa-circle'}" style="color:${colors[c.type]||'#666'};font-size:10px;flex-shrink:0"></i>
                  <span>${esc(c.label)} <span style="color:var(--txt3)">(${c.time})</span></span>
                </div>`;
              }).join('')}
            </div>
            ${hasExamConflict
              ? `<div style="margin-top:6px;font-size:10.5px;color:var(--red2);font-weight:700">⛔ غير قابلة — تعارض مع امتحان آخر</div>`
              : `<div style="margin-top:6px;font-size:10.5px;color:var(--gold);font-weight:700">⚠️ ${isSelected?'مختارة (سيتم الإخطار)':'اضغط للإجبار'}</div>`
            }
          </div>`;
        }).join('')}
      </div>
    </details>`:''}

    ${!free.length && !busy.length?`<div style="padding:30px;text-align:center;color:var(--txt3)">
      <i class="fas fa-door-closed" style="font-size:36px;opacity:.3;display:block;margin-bottom:12px"></i>
      لا توجد قاعات في النظام
    </div>`:''}
  </div>`;
}

// ══ الخطوة 3: المراقبون والشعب — Tag Picker ════════════════
function _wizStep3HTML() {
  if (!_WIZ.rooms.length) {
    return `<div style="padding:40px;text-align:center;color:var(--txt3)">
      <i class="fas fa-arrow-right" style="font-size:32px;opacity:.3;display:block;margin-bottom:12px"></i>
      عد للخطوة السابقة واختر قاعة على الأقل
    </div>`;
  }

  const subj    = STATE.subjects.find(s => s.id == _WIZ.subjectId);
  const endTime = _wizCalcEnd(_WIZ.date, _WIZ.time, _WIZ.duration);

  // فلتر القسم: افتراضياً قسم المادة
  if (_WIZ.procDeptFilter === null && subj?.dept_id) {
    _WIZ.procDeptFilter = String(subj.dept_id);
  }

  const allProcts = STATE.profiles.filter(p => p.role==='proctor' && p.active);
  const available = allProcts.filter(p => {
    const hasConf = (typeof hasUserConflict==='function' && hasUserConflict(p.id,_WIZ.date,_WIZ.time,endTime,null)) ||
      STATE.exams.some(e=>{
        if(e.id===_WIZ.editId) return false;
        if(!(e.proctor_ids||[]).includes(p.id)||e.date!==_WIZ.date) return false;
        const eS=e.time?.slice(0,5)||'00:00';
        const eE=_wizCalcEnd(e.date,eS,(e.duration||60)+(e.extra_time||0));
        return _WIZ.time<eE && endTime>eS;
      });
    return !hasConf;
  }).map(p=>({...p,
    _sc: STATE.exams.filter(e=>(e.proctor_ids||[]).includes(p.id)&&e.semester===STATE.currentSem).length,
    _inDept: String(p.dept_id)===String(subj?.dept_id)
  })).sort((a,b)=>b._inDept-a._inDept||a._sc-b._sc);

  const allSecs = STATE.sections.filter(s =>
    s.semester===STATE.currentSem && s.subject_id==_WIZ.subjectId
  );

  const totalAssigned = [...new Set(Object.values(_WIZ.roomMap||{}).flat())].length;
  const totalSecs     = [...new Set(Object.values(_WIZ.roomSections||{}).flat())].length;
  const totalAvailInDept = available.filter(p => _WIZ.procDeptFilter==='all' || String(p.dept_id)===_WIZ.procDeptFilter).length;

  // بناء شريط فلتر الأقسام
  const deptFilter = `
    <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:12px;
      padding:10px 14px;background:var(--bg);border-radius:11px;border:1px solid var(--border)">
      <span style="font-size:11px;font-weight:800;color:var(--txt3);margin-left:6px">
        <i class="fas fa-filter" style="color:var(--purple2)"></i> عرض مراقبي:
      </span>
      <button onclick="_wizSetProcDeptFilter('all')"
        style="padding:4px 12px;border-radius:20px;font-size:11.5px;font-weight:700;cursor:pointer;border:1.5px solid ${_WIZ.procDeptFilter==='all'?'var(--purple2)':'var(--border)'};
               background:${_WIZ.procDeptFilter==='all'?'var(--purple2)':'transparent'};color:${_WIZ.procDeptFilter==='all'?'white':'var(--txt2)'}">
        الكل (${available.length})
      </button>
      ${STATE.departments.map(d=>{
        const cnt = available.filter(p=>String(p.dept_id)===String(d.id)).length;
        if(!cnt) return '';
        const sel = _WIZ.procDeptFilter===String(d.id);
        const isSubjDept = String(d.id)===String(subj?.dept_id);
        return `<button onclick="_wizSetProcDeptFilter('${d.id}')"
          style="padding:4px 12px;border-radius:20px;font-size:11.5px;font-weight:700;cursor:pointer;
                 border:1.5px solid ${sel?(d.color||'var(--primary2)'):'var(--border)'};
                 background:${sel?(d.color||'var(--primary2)'):'transparent'};
                 color:${sel?'white':'var(--txt2)'}">
          ${isSubjDept?'⭐ ':''}${esc(d.name)} (${cnt})
        </button>`;
      }).join('')}
    </div>`;

  return `<div style="padding:16px 22px">
    <!-- شريط الإحصاءات والأدوات -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;padding:10px 14px;
      background:var(--primary)06;border-radius:11px;border:1px solid var(--primary2)18;flex-wrap:wrap">
      <i class="fas fa-info-circle" style="color:var(--primary2);flex-shrink:0"></i>
      <span style="font-size:12px;color:var(--txt2);flex:1">اضغط <strong>+</strong> للإضافة · <strong>×</strong> للإزالة</span>
      <div style="display:flex;gap:7px;flex-wrap:wrap;align-items:center">
        <span class="badge b-purple">${totalAssigned} مراقب</span>
        <span class="badge b-gold">${totalSecs} شعبة</span>
        <button class="btn bp btn-sm" onclick="_wizShowSuggestDialog()"
          style="background:linear-gradient(135deg,var(--primary2),var(--purple2));border:none;color:white">
          <i class="fas fa-magic"></i> اقتراح تلقائي
        </button>
      </div>
    </div>

    ${deptFilter}

    ${_WIZ.rooms.map(rid => _buildWizRoomBlock(rid, available, allSecs)).join('')}
  </div>`;
}

// ── تغيير فلتر القسم ─────────────────────────────────────────
function _wizSetProcDeptFilter(deptId) {
  _WIZ.procDeptFilter = String(deptId);
  const body = document.getElementById('wizBody');
  if (body) body.innerHTML = _wizStep3HTML();
}

// ── بناء بلوك قاعة واحدة (Tag Picker v2) ────────────────────
function _buildWizRoomBlock(rid, available, allSecs) {
  const room = getRoom(rid);
  if (!room) return '';
  const info = typeof getRoomTypeInfo==='function' ? getRoomTypeInfo(room.type) : {icon:'fa-door-open',color:'var(--teal)'};
  const k    = String(rid);

  const assignedIds  = _WIZ.roomMap[k] || [];
  const assignedSecs = (_WIZ.roomSections||{})[k] || [];

  const assignedProcts = assignedIds.map(uid=>STATE.profiles.find(p=>p.id===uid)).filter(Boolean);
  const assignedSecObs = assignedSecs.map(sid=>STATE.sections.find(s=>s.id===sid)).filter(Boolean);

  // ✅ المراقبون المستخدمون في أي قاعة (للامتحان نفسه) — لا يحقّ تكرارهم
  const procUsedAnywhere = new Set(
    Object.values(_WIZ.roomMap||{}).flat()
  );

  // تطبيق الفلتر على المراقبين المتاحين
  const deptF = _WIZ.procDeptFilter;
  const availFiltered = available.filter(p =>
    !procUsedAnywhere.has(p.id) &&    // ✅ لا يكون مستخدماً في أي قاعة أخرى
    (deptF === 'all' || !deptF || String(p.dept_id) === deptF)
  );
  const availForRoom = availFiltered;

  // الشعب المستخدمة في قاعات أخرى
  const usedElsewhere = new Set(
    Object.entries(_WIZ.roomSections||{})
      .filter(([r])=>r!==k).flatMap(([,sids])=>sids)
  );
  const availSecs = allSecs.filter(s => !assignedSecs.includes(s.id) && !usedElsewhere.has(s.id));

  const totalStudents = assignedSecObs.reduce((a,s)=>a+(s.student_ids||[]).length, 0);

  // ── Chips المراقبين ──
  const procChips = assignedProcts.map(p => {
    const sc  = STATE.exams.filter(e=>(e.proctor_ids||[]).includes(p.id)&&e.semester===STATE.currentSem).length;
    const dept= STATE.departments.find(d=>d.id===p.dept_id);
    const col = sc>=3?'var(--red2)':sc>=2?'var(--gold)':'var(--purple2)';
    return `<span style="display:inline-flex;align-items:center;gap:5px;padding:5px 11px 5px 7px;
        background:${col}12;border:1.5px solid ${col}35;border-radius:20px;font-size:12px;font-weight:700;color:${col};white-space:nowrap;animation:chip-pop .2s ease">
      <i class="fas fa-user-tie" style="font-size:10px;opacity:.8"></i>
      ${esc(p.name?.split(' ').slice(0,2).join(' '))}
      <span style="font-size:9px;opacity:.55">${dept?`· ${esc(dept.name?.substring(0,8))}`:''} (${sc})</span>
      <button onclick="event.stopPropagation();_wizRemoveProctorFromRoom(${rid},'${p.id}')"
        style="border:none;background:${col}25;color:${col};cursor:pointer;width:17px;height:17px;border-radius:50%;font-size:9px;
               display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s;margin-right:2px"
        onmouseover="this.style.background='${col}55'" onmouseout="this.style.background='${col}25'">
        <i class="fas fa-times"></i>
      </button>
    </span>`;
  }).join('');

  // ── Chips الشعب ──
  const secChips = assignedSecObs.map(s => {
    const cnt = (s.student_ids||[]).length;
    return `<span style="display:inline-flex;align-items:center;gap:5px;padding:5px 11px 5px 7px;
        background:var(--gold)12;border:1.5px solid var(--gold)35;border-radius:20px;font-size:12px;font-weight:700;color:var(--gold);white-space:nowrap;animation:chip-pop .2s ease">
      <i class="fas fa-layer-group" style="font-size:10px;opacity:.8"></i>
      ${esc(s.name)} <span style="font-size:9px;opacity:.55">(${cnt}ط)</span>
      <button onclick="event.stopPropagation();_wizRemoveSectionFromRoom(${rid},${s.id})"
        style="border:none;background:var(--gold)25;color:var(--gold);cursor:pointer;width:17px;height:17px;border-radius:50%;font-size:9px;
               display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s;margin-right:2px"
        onmouseover="this.style.background='var(--gold)55'" onmouseout="this.style.background='var(--gold)25'">
        <i class="fas fa-times"></i>
      </button>
    </span>`;
  }).join('');

  // ── محتوى Dropdown المراقبين (grouped by dept filter) ──
  const procDrop = availForRoom.length
    ? `<div style="padding:7px 14px 5px;font-size:10px;font-weight:800;color:var(--txt3);background:var(--bg);border-bottom:1px solid var(--border);letter-spacing:.5px;display:flex;align-items:center;justify-content:space-between">
        <span>المراقبون المتاحون</span>
        <span style="color:var(--purple2)">${availForRoom.length}</span>
      </div>` +
      availForRoom.map(p => {
        const dept= STATE.departments.find(d=>d.id===p.dept_id);
        return `<div onclick="event.stopPropagation();_wizAddProctorToRoom(${rid},'${p.id}')"
          style="display:flex;align-items:center;gap:9px;padding:9px 14px;cursor:pointer;transition:background .12s;border-bottom:1px solid var(--border)"
          onmouseover="this.style.background='var(--purple2)08'" onmouseout="this.style.background=''">
          ${userAvatar(p, 32)}
          <div style="flex:1;min-width:0">
            <div style="font-size:12.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(p.name?.split(' ').slice(0,3).join(' '))}</div>
            <div style="font-size:10px;color:var(--txt3)">
              ${p._inDept?'⭐ ':''}<span style="color:var(--teal)">${esc(dept?.name||'—')}</span>
              · ${p._sc} امتحان/الفصل
            </div>
          </div>
          <span class="badge ${p._sc>=3?'b-red':p._sc>=2?'b-gold':'b-green'}" style="font-size:9.5px">${p._sc}</span>
          <i class="fas fa-plus-circle" style="color:var(--purple2);font-size:15px;flex-shrink:0"></i>
        </div>`;
      }).join('')
    : `<div style="padding:16px;text-align:center;color:var(--txt3);font-size:12px">
        <i class="fas fa-check-circle" style="color:var(--green2);margin-left:5px"></i>
        ${available.filter(p=>!assignedIds.includes(p.id)).length
          ? 'غيّر فلتر القسم لرؤية مراقبين آخرين'
          : 'لا يوجد مراقبون متاحون إضافيون'}
      </div>`;

  // ── Dropdown الشعب ──
  const secDrop = availSecs.length
    ? `<div style="padding:7px 14px 5px;font-size:10px;font-weight:800;color:var(--txt3);background:var(--bg);border-bottom:1px solid var(--border);letter-spacing:.5px;display:flex;align-items:center;justify-content:space-between">
        <span>الشعب المتاحة</span>
        <span style="color:var(--gold)">${availSecs.length}</span>
      </div>` +
      availSecs.map(s => {
        const cnt=(s.student_ids||[]).length;
        return `<div onclick="event.stopPropagation();_wizAddSectionToRoom(${rid},${s.id})"
          style="display:flex;align-items:center;gap:9px;padding:10px 14px;cursor:pointer;transition:background .12s;border-bottom:1px solid var(--border)"
          onmouseover="this.style.background='var(--gold)08'" onmouseout="this.style.background=''">
          <div style="width:32px;height:32px;border-radius:9px;background:var(--gold)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-layer-group" style="color:var(--gold);font-size:13px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:12.5px;font-weight:700">${esc(s.name)}</div>
            <div style="font-size:10.5px;color:var(--txt3)"><i class="fas fa-users" style="font-size:9px;margin-left:3px"></i>${cnt} طالب</div>
          </div>
          <i class="fas fa-plus-circle" style="color:var(--gold);font-size:15px;flex-shrink:0"></i>
        </div>`;
      }).join('')
    : `<div style="padding:16px;text-align:center;color:var(--txt3);font-size:12px">
        <i class="fas fa-check-circle" style="color:var(--green2);margin-left:5px"></i>
        ${!_WIZ.subjectId?'اختر المقرر في الخطوة الأولى':'تم اختيار جميع الشعب المتاحة'}
      </div>`;

  return `<div id="wiz-room-block-${rid}" style="border:1.5px solid var(--border);border-radius:14px;background:var(--card);margin-bottom:12px;overflow:visible;box-shadow:0 2px 8px rgba(0,0,0,.04)">
    <!-- رأس القاعة -->
    <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:${info.color}08;border-bottom:1.5px solid ${info.color}20;border-radius:13px 13px 0 0">
      <div style="width:40px;height:40px;border-radius:11px;background:${info.color}20;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas ${info.icon}" style="color:${info.color};font-size:17px"></i>
      </div>
      <div style="flex:1">
        <div style="font-weight:900;font-size:14px">${esc(room.name)}</div>
        <div style="font-size:11px;color:var(--txt3);display:flex;gap:10px;flex-wrap:wrap;margin-top:3px">
          <span><i class="fas fa-chair" style="font-size:9px;margin-left:3px"></i>سعة ${room.cap}</span>
          ${assignedProcts.length
            ?`<span style="color:var(--purple2)"><i class="fas fa-user-tie" style="font-size:9px;margin-left:3px"></i>${assignedProcts.length} مراقب</span>`
            :'<span style="color:var(--red2)"><i class="fas fa-exclamation-circle" style="font-size:9px;margin-left:3px"></i>بدون مراقب</span>'}
          ${assignedSecObs.length?`<span style="color:var(--gold)"><i class="fas fa-layer-group" style="font-size:9px;margin-left:3px"></i>${assignedSecObs.length} شعبة · ${totalStudents} طالب</span>`:''}
        </div>
      </div>
    </div>
    <div style="padding:14px 16px">

      <!-- § المراقبون -->
      <div style="margin-bottom:16px">
        <div style="font-size:11px;font-weight:800;color:var(--purple2);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
          <span><i class="fas fa-user-tie" style="margin-left:5px;opacity:.8"></i>المراقبون</span>
          <span style="font-size:10px;color:var(--txt3);font-weight:500">${assignedProcts.length} مختار · ${availForRoom.length} متاح بالفلتر الحالي</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;min-height:32px;margin-bottom:8px;padding:6px;background:var(--bg);border-radius:9px;border:1.5px dashed ${assignedProcts.length?'var(--purple2)30':'var(--border)'}">
          ${procChips || `<span style="font-size:11.5px;color:var(--txt3);opacity:.6;padding:2px 4px"><i class="fas fa-user-plus" style="margin-left:5px;font-size:11px"></i>لم يُختر مراقب بعد</span>`}
        </div>
        <div style="position:relative">
          <button id="wiz-proc-btn-${rid}" onclick="event.stopPropagation();_wizTogglePickerFixed('wiz-proc-dd-${rid}',this)"
            style="display:flex;align-items:center;justify-content:center;gap:7px;padding:8px 14px;width:100%;
            border:1.5px ${availForRoom.length?'solid':'dashed'} var(--purple2)${availForRoom.length?'60':'40'};
            border-radius:10px;background:var(--purple2)05;
            color:var(--purple2);font-size:12.5px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit"
            onmouseover="this.style.background='var(--purple2)12'"
            onmouseout="this.style.background='var(--purple2)05'">
            <i class="fas fa-user-plus"></i> إضافة مراقب
            ${availForRoom.length?`<span class="badge" style="background:var(--purple2);color:white;font-size:9.5px">${availForRoom.length}</span>`:''}
          </button>
          <div id="wiz-proc-dd-${rid}" style="display:none;background:var(--card);border:1.5px solid var(--border);border-radius:11px;max-height:260px;overflow-y:auto;min-width:280px">
            ${procDrop}
          </div>
        </div>
      </div>

      <!-- § الشعب -->
      <div>
        <div style="font-size:11px;font-weight:800;color:var(--gold);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
          <span><i class="fas fa-layer-group" style="margin-left:5px;opacity:.8"></i>الشعب المخصصة</span>
          <span style="font-size:10px;color:var(--txt3);font-weight:500">${assignedSecObs.length} شعبة · ${totalStudents} طالب</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;min-height:32px;margin-bottom:8px;padding:6px;background:var(--bg);border-radius:9px;border:1.5px dashed ${assignedSecObs.length?'var(--gold)40':'var(--border)'}">
          ${secChips || `<span style="font-size:11.5px;color:var(--txt3);opacity:.6;padding:2px 4px"><i class="fas fa-layer-group" style="margin-left:5px;font-size:11px"></i>لم تُختر شعبة بعد</span>`}
        </div>
        <div style="position:relative">
          <button id="wiz-sec-btn-${rid}" onclick="event.stopPropagation();_wizTogglePickerFixed('wiz-sec-dd-${rid}',this)"
            style="display:flex;align-items:center;justify-content:center;gap:7px;padding:8px 14px;width:100%;
            border:1.5px ${availSecs.length?'solid':'dashed'} var(--gold)${availSecs.length?'60':'40'};
            border-radius:10px;background:var(--gold)05;
            color:var(--gold);font-size:12.5px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit"
            onmouseover="this.style.background='var(--gold)12'"
            onmouseout="this.style.background='var(--gold)05'">
            <i class="fas fa-plus-circle"></i> إضافة شعبة
            ${availSecs.length?`<span class="badge" style="background:var(--gold);color:white;font-size:9.5px">${availSecs.length}</span>`:''}
          </button>
          <div id="wiz-sec-dd-${rid}" style="display:none;background:var(--card);border:1.5px solid var(--border);border-radius:11px;max-height:260px;overflow-y:auto;min-width:260px">
            ${secDrop}
          </div>
        </div>
      </div>

    </div>
  </div>`;
}

// ── Toggle Picker (fixed position — يتجنب قطع الـ modal) ─────
function _wizTogglePickerFixed(ddId, btn) {
  // إغلاق كل الـ dropdowns الأخرى
  document.querySelectorAll('[id^="wiz-proc-dd-"],[id^="wiz-sec-dd-"]').forEach(el=>{
    if (el.id !== ddId) {
      el.style.display = 'none';
      el.style.position = '';
      el.style.top = '';
      el.style.left = '';
      el.style.right = '';
      el.style.width = '';
    }
  });
  const dd = document.getElementById(ddId);
  if (!dd) return;
  const willOpen = dd.style.display==='none' || !dd.style.display;
  if (willOpen) {
    // حساب الموضع الفعلي
    const rect = btn.getBoundingClientRect();
    const vpH  = window.innerHeight;
    const ddH  = 270;
    const spaceBelow = vpH - rect.bottom;
    const showAbove  = spaceBelow < ddH && rect.top > ddH;

    dd.style.cssText = `
      display:block;
      position:fixed;
      z-index:60000;
      width:${rect.width}px;
      left:${rect.left}px;
      ${showAbove
        ? `bottom:${vpH - rect.top + 4}px;top:auto;`
        : `top:${rect.bottom + 4}px;bottom:auto;`}
      background:var(--card);
      border:1.5px solid var(--border);
      border-radius:11px;
      max-height:260px;
      overflow-y:auto;
      box-shadow:0 16px 40px rgba(0,0,0,.22);
    `;
    const handler = e => {
      if (!dd.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        dd.style.display = 'none';
        document.removeEventListener('click', handler, true);
      }
    };
    setTimeout(() => document.addEventListener('click', handler, true), 10);
  } else {
    dd.style.display = 'none';
  }
}

// Alias for compatibility
function _wizTogglePicker(ddId) {
  const dd = document.getElementById(ddId);
  if (!dd) return;
  const btn = dd.previousElementSibling;
  _wizTogglePickerFixed(ddId, btn);
}

// ── إضافة / إزالة مراقب ──────────────────────────────────────
function _wizAddProctorToRoom(rid, procId) {
  const k = String(rid);
  // ✅ منع التكرار في أي قاعة من الامتحان نفسه
  for (const [otherRid, list] of Object.entries(_WIZ.roomMap||{})) {
    if (otherRid !== k && (list||[]).includes(procId)) {
      const otherRoom = getRoom(parseInt(otherRid));
      const proc = STATE.profiles.find(p => p.id === procId);
      toast(`⚠️ "${proc?.name||'المراقب'}" مُعيَّن أصلاً في قاعة "${otherRoom?.name||'أخرى'}"`, 'warning', 4000);
      return;
    }
  }
  if (!_WIZ.roomMap[k]) _WIZ.roomMap[k]=[];
  if (!_WIZ.roomMap[k].includes(procId)) _WIZ.roomMap[k].push(procId);
  const dd=document.getElementById(`wiz-proc-dd-${rid}`);if(dd)dd.style.display='none';
  // ✅ إعادة بناء كل القاعات لإخفاء المراقب من قوائمها أيضاً
  _rerenderAllWizRoomBlocks();
}

function _wizRemoveProctorFromRoom(rid, procId) {
  const k=String(rid);
  if (_WIZ.roomMap[k]) _WIZ.roomMap[k]=_WIZ.roomMap[k].filter(id=>id!==procId);
  // ✅ إعادة بناء كل القاعات حتى يعود المراقب لقوائمها
  _rerenderAllWizRoomBlocks();
}

// إعادة بناء جميع كتل القاعات لتعكس التغييرات (إخفاء/إظهار المراقبين)
function _rerenderAllWizRoomBlocks() {
  const body = document.getElementById('wizBody');
  if (body) body.innerHTML = _wizStep3HTML();
}

// ── إضافة / إزالة شعبة (مع منع التكرار) ─────────────────────
function _wizAddSectionToRoom(rid, secId) {
  const dupRid = Object.entries(_WIZ.roomSections||{}).find(([r,sids])=>String(r)!==String(rid)&&sids.includes(secId))?.[0];
  if (dupRid) {
    toast(`⚠️ هذه الشعبة موجودة في قاعة: "${getRoom(parseInt(dupRid))?.name||'أخرى'}"`, 'warning', 3000);
    return;
  }
  if (!_WIZ.roomSections) _WIZ.roomSections={};
  const k=String(rid);
  if (!_WIZ.roomSections[k]) _WIZ.roomSections[k]=[];
  if (!_WIZ.roomSections[k].includes(secId)) _WIZ.roomSections[k].push(secId);
  const dd=document.getElementById(`wiz-sec-dd-${rid}`);if(dd)dd.style.display='none';
  // ✅ إعادة رسم كل الكتل لتعكس أن الشعبة لم تعد متاحة في القاعات الأخرى
  _rerenderAllWizRoomBlocks();
}

function _wizRemoveSectionFromRoom(rid, secId) {
  const k=String(rid);
  if (_WIZ.roomSections?.[k]) _WIZ.roomSections[k]=_WIZ.roomSections[k].filter(id=>id!==secId);
  _rerenderAllWizRoomBlocks();
}

// ── إعادة رسم بلوك قاعة واحدة ────────────────────────────────
function _rerenderWizRoomBlock(rid) {
  const block = document.getElementById(`wiz-room-block-${rid}`);
  if (!block) return;
  const subj    = STATE.subjects.find(s=>s.id==_WIZ.subjectId);
  const endTime =_wizCalcEnd(_WIZ.date,_WIZ.time,_WIZ.duration);
  const allProcts=STATE.profiles.filter(p=>p.role==='proctor'&&p.active);
  const available=allProcts.filter(p=>{
    const hasConf=(typeof hasUserConflict==='function'&&hasUserConflict(p.id,_WIZ.date,_WIZ.time,endTime,null))||
      STATE.exams.some(e=>{if(e.id===_WIZ.editId)return false;if(!(e.proctor_ids||[]).includes(p.id)||e.date!==_WIZ.date)return false;const eS=e.time?.slice(0,5)||'00:00';const eE=_wizCalcEnd(e.date,eS,(e.duration||60)+(e.extra_time||0));return _WIZ.time<eE&&endTime>eS;});
    return !hasConf;
  }).map(p=>({...p,_sc:STATE.exams.filter(e=>(e.proctor_ids||[]).includes(p.id)&&e.semester===STATE.currentSem).length,_inDept:String(p.dept_id)===String(subj?.dept_id)})).sort((a,b)=>b._inDept-a._inDept||a._sc-b._sc);
  const allSecs=STATE.sections.filter(s=>s.semester===STATE.currentSem&&s.subject_id==_WIZ.subjectId);
  const tmp=document.createElement('div');
  tmp.innerHTML=_buildWizRoomBlock(rid,available,allSecs);
  block.replaceWith(tmp.firstElementChild);
}

// ══ الخطوة 4: المراجعة والتأكيد ══════════════════════════════
function _wizStep4HTML() {
  const subj = STATE.subjects.find(s=>s.id==_WIZ.subjectId);
  const dept = STATE.departments.find(d=>d.id==subj?.dept_id);
  const endTime = _wizCalcEnd(_WIZ.date,_WIZ.time,_WIZ.duration);
  const typeLabels={final:'نهائي',midterm:'منتصف الفصل',quiz:'اختبار',makeup:'إعادة'};
  const typeColors={final:'#2563eb',midterm:'#d97706',quiz:'#0891b2',makeup:'#7c3aed'};
  const c=typeColors[_WIZ.type]||'#2563eb';
  const allAssignedIds=[...new Set(Object.values(_WIZ.roomMap||{}).flat())];
  const allProctors=allAssignedIds.map(uid=>getProfile(uid)).filter(Boolean);
  const pts=typeof _calcExamPoints==='function'?_calcExamPoints({date:_WIZ.date,time:_WIZ.time,type:_WIZ.type,is_holiday:_isAutoHoliday?.(_WIZ.date)||false}):0;

  return `<div style="padding:20px 22px">
    <div style="padding:18px;border-radius:14px;background:linear-gradient(135deg,${c}12,${c}06);border:2px solid ${c}25;margin-bottom:18px">
      <div style="font-size:12px;font-weight:800;color:${c};margin-bottom:10px;text-transform:uppercase;letter-spacing:1px">
        <i class="fas fa-clipboard-check" style="margin-left:5px"></i>مراجعة الامتحان
      </div>
      <div style="font-size:19px;font-weight:900;margin-bottom:6px">${esc(subj?.name||'—')}</div>
      <div style="display:flex;gap:14px;font-size:12.5px;color:var(--txt2);flex-wrap:wrap">
        <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(_WIZ.date)}</span>
        <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(_WIZ.time)} — ${fmtTime(endTime)}</span>
        <span><i class="fas fa-hourglass" style="color:var(--teal)"></i> ${_WIZ.duration} دقيقة</span>
        <span><i class="fas fa-tag" style="color:${c}"></i> ${typeLabels[_WIZ.type]||'—'}</span>
        <span><i class="fas fa-trophy" style="color:var(--gold)"></i> ${pts} نقطة للمراقب</span>
        ${dept?`<span><i class="fas fa-sitemap" style="color:var(--purple2)"></i> ${esc(dept.name)}</span>`:''}
      </div>
    </div>

    <div style="margin-bottom:16px">
      <div style="font-size:12.5px;font-weight:800;color:var(--txt2);margin-bottom:10px">
        <i class="fas fa-door-open" style="color:var(--teal);margin-left:5px"></i>القاعات والمراقبون
      </div>
      ${_WIZ.rooms.map(rid=>{
        const room=getRoom(rid);if(!room)return'';
        const info=typeof getRoomTypeInfo==='function'?getRoomTypeInfo(room.type):{icon:'fa-door-open',color:'var(--teal)'};
        const prIds=_WIZ.roomMap[String(rid)]||[];
        const procs=prIds.map(uid=>getProfile(uid)).filter(Boolean);
        const rsSecs=(_WIZ.roomSections||{})[String(rid)]||[];
        const secs=rsSecs.map(sid=>getSection(sid)).filter(Boolean);
        const studCount=rsSecs.reduce((acc,sid)=>{const s=getSection(sid);return acc+(s?.student_ids||[]).length;},0);
        return `<div style="display:flex;align-items:start;gap:10px;padding:12px 14px;border:1.5px solid var(--border);border-radius:12px;margin-bottom:8px;background:var(--card)">
          <div style="width:38px;height:38px;border-radius:10px;background:${info.color}15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas ${info.icon}" style="color:${info.color};font-size:15px"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:800;font-size:13.5px;margin-bottom:4px">${esc(room.name)}</div>
            ${procs.length
              ?`<div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:4px">${procs.map(p=>`<span style="font-size:11.5px;padding:3px 9px;background:var(--primary2)12;color:var(--primary2);border-radius:20px;border:1px solid var(--primary2)20"><i class="fas fa-user-tie" style="font-size:10px;margin-left:3px"></i>${esc(p.name?.split(' ').slice(0,2).join(' '))}</span>`).join('')}</div>`
              :`<div style="font-size:11.5px;color:var(--red2);margin-bottom:4px"><i class="fas fa-exclamation-circle" style="margin-left:4px"></i>لا يوجد مراقبون في هذه القاعة</div>`}
            ${secs.length?`<div style="font-size:11px;color:var(--txt3)"><i class="fas fa-layer-group" style="color:var(--gold);margin-left:4px"></i>${secs.map(s=>esc(s.name)).join('، ')} · ${studCount} طالب</div>`:''}
          </div>
        </div>`;
      }).join('')||`<div style="padding:16px;text-align:center;color:var(--red2);font-size:13px;border:1.5px dashed var(--red2);border-radius:10px"><i class="fas fa-exclamation-triangle" style="margin-left:5px"></i>لم تُختَر أي قاعة</div>`}
    </div>

    ${allProctors.length?`<div style="padding:12px 14px;background:var(--purple2)08;border-radius:11px;border:1px solid var(--purple2)20;margin-bottom:14px">
      <div style="font-size:11px;font-weight:800;color:var(--purple2);margin-bottom:8px">
        <i class="fas fa-user-check" style="margin-left:5px"></i>
        إجمالي المراقبين (${allProctors.length}) — سيتم إبلاغهم فوراً
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${allProctors.map(p=>`<div style="display:flex;align-items:center;gap:6px;padding:5px 10px;background:var(--card);border-radius:20px;border:1px solid var(--border)">
          ${userAvatar(p,24)}<span style="font-size:12px;font-weight:600">${esc(p.name?.split(' ').slice(0,2).join(' '))}</span>
        </div>`).join('')}
      </div>
    </div>`:''}

    ${_wizValidate().length?`<div style="padding:12px 14px;background:var(--gold)10;border:1.5px solid var(--gold)40;border-radius:11px;margin-bottom:14px">
      <div style="font-size:12px;font-weight:800;color:var(--gold);margin-bottom:6px"><i class="fas fa-exclamation-triangle" style="margin-left:5px"></i>تنبيهات</div>
      ${_wizValidate().map(w=>`<div style="font-size:12px;color:var(--txt2);margin-bottom:3px">• ${w}</div>`).join('')}
    </div>`:`<div style="padding:10px 14px;background:var(--green2)10;border:1.5px solid var(--green2)30;border-radius:10px;font-size:12.5px;color:var(--green2);display:flex;align-items:center;gap:8px">
      <i class="fas fa-check-circle" style="font-size:16px"></i>كل شيء سليم — جاهز للحفظ وإبلاغ المراقبين
    </div>`}

    ${_WIZ.notes?`<div style="margin-top:12px;padding:9px 12px;background:var(--bg);border-radius:9px;font-size:12.5px;color:var(--txt2);border-right:3px solid var(--gold)">
      <i class="fas fa-sticky-note" style="color:var(--gold);margin-left:5px"></i>${esc(_WIZ.notes)}</div>`:''}
  </div>`;
}

// ══ دوال منطق المعالج ════════════════════════════════════════

function _wizCalcEnd(date, startTime, durationMin) {
  if (!date||!startTime) return '—';
  const d=new Date(`${date}T${startTime}`);
  d.setMinutes(d.getMinutes()+(durationMin||0));
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

function _wizSubjChange(val) {
  _WIZ.subjectId=parseInt(val)||null;
  _wizRefreshPoints();
}

function _wizSetDur(val) {
  if (val==='custom'){document.getElementById('wz_dur')?.focus();return;}
  _WIZ.duration=val;
  document.getElementById('wz_dur').value=val;
  document.querySelectorAll('.wz-dur').forEach(b=>{const isA=parseInt(b.getAttribute('data-v'))===val;b.style.background=isA?'var(--primary2)':'';b.style.color=isA?'white':'';b.style.borderColor=isA?'var(--primary2)':'';});
  _wizRefreshPoints();
}

function _wizRefreshPoints() {
  const date=document.getElementById('wz_date')?.value||_WIZ.date;
  const time=document.getElementById('wz_time')?.value||_WIZ.time;
  const type=document.getElementById('wz_type')?.value||_WIZ.type;
  _WIZ.date=date;_WIZ.time=time;_WIZ.type=type;
  const isHol=typeof _isAutoHoliday==='function'?_isAutoHoliday(date):false;
  const pts=typeof _calcExamPoints==='function'?_calcExamPoints({date,time,type,is_holiday:isHol}):0;
  const elPts=document.getElementById('wz_pts');if(elPts)elPts.textContent=pts;
  const elHol=document.getElementById('wz_holidayLbl');
  const elHolIco=document.getElementById('wz_holidayIco');
  if(elHol){
    const dayName=date?new Date(date+'T12:00:00').toLocaleDateString('ar-SA',{weekday:'long'}):'—';
    elHol.textContent=isHol?`${dayName} — يوم عطلة 🏖️`:dayName;
  }
  if(elHolIco){elHolIco.className=isHol?'fas fa-umbrella-beach':'fas fa-calendar-check';elHolIco.style.color=isHol?'var(--red2)':'var(--green2)';}
}

function _wizToggleRoom(rid) {
  const idx=_WIZ.rooms.indexOf(rid);
  if(idx===-1){_WIZ.rooms.push(rid);if(!_WIZ.roomMap[String(rid)])_WIZ.roomMap[String(rid)]=[];if(!_WIZ.roomSections)_WIZ.roomSections={};if(!_WIZ.roomSections[String(rid)])_WIZ.roomSections[String(rid)]=[];}
  else{_WIZ.rooms.splice(idx,1);delete _WIZ.roomMap[String(rid)];if(_WIZ.roomSections)delete _WIZ.roomSections[String(rid)];}
  const body=document.getElementById('wizBody');if(body)body.innerHTML=_wizStep2HTML();
}

// ── حوار الاقتراح الذكي (معاينة قبل التطبيق) ───────────────
function _wizShowSuggestDialog() {
  const subj    = STATE.subjects.find(s => s.id == _WIZ.subjectId);
  const endTime = _wizCalcEnd(_WIZ.date, _WIZ.time, _WIZ.duration);

  // المراقبون المتاحون مرتّبون: نفس القسم أولاً، ثم الأقل تعييناً
  const available = STATE.profiles.filter(p => {
    if (p.role !== 'proctor' || !p.active) return false;
    const hasConf = (typeof hasUserConflict === 'function' && hasUserConflict(p.id, _WIZ.date, _WIZ.time, endTime, null)) ||
      STATE.exams.some(e => {
        if (e.id === _WIZ.editId) return false;
        if (!(e.proctor_ids || []).includes(p.id) || e.date !== _WIZ.date) return false;
        const eS = e.time?.slice(0,5) || '00:00';
        const eE = _wizCalcEnd(e.date, eS, (e.duration||60) + (e.extra_time||0));
        return _WIZ.time < eE && endTime > eS;
      });
    return !hasConf;
  }).map(p => ({
    ...p,
    _sc: STATE.exams.filter(e => (e.proctor_ids||[]).includes(p.id) && e.semester === STATE.currentSem).length,
    _inDept: String(p.dept_id) === String(subj?.dept_id)
  })).sort((a,b) => b._inDept - a._inDept || a._sc - b._sc);

  const allSecs = STATE.sections.filter(s => s.semester === STATE.currentSem && s.subject_id == _WIZ.subjectId);
  const roomCount = _WIZ.rooms.length;

  // الاقتراح: مراقب واحد لكل قاعة + شعبة لكل قاعة
  const suggestedProctors = available.slice(0, roomCount);
  const suggestedSecs     = allSecs.slice(0, roomCount);

  const moId = 'wizSuggestMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  mo.innerHTML = `
  <div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2><i class="fas fa-magic" style="color:var(--primary2)"></i> اقتراح تلقائي للمراقبين</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px 22px">

      <div style="padding:10px 14px;background:var(--primary)08;border-radius:10px;border:1px solid var(--primary2)20;font-size:12.5px;margin-bottom:16px">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        النظام يقترح ${roomCount} مراقب (بناءً على الأولوية والتاريخ). يمكنك تعديل العدد والاختيار ثم تطبيق الاقتراح.
      </div>

      <!-- عدد المراقبين المطلوبين -->
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;padding:10px 14px;background:var(--bg);border-radius:10px;border:1px solid var(--border)">
        <div style="flex:1">
          <div style="font-size:12px;font-weight:800;color:var(--txt2);margin-bottom:4px">عدد المراقبين المطلوبين</div>
          <div style="font-size:11px;color:var(--txt3)">1 مراقب لكل قاعة (${roomCount} قاعة)</div>
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <button onclick="_wizSuggestChangeCount(-1)" style="width:30px;height:30px;border-radius:8px;border:1.5px solid var(--border);background:var(--card);cursor:pointer;font-size:16px;font-weight:900;color:var(--txt2)">−</button>
          <span id="wizSuggestCount" style="font-size:20px;font-weight:900;color:var(--primary2);min-width:24px;text-align:center">${roomCount}</span>
          <button onclick="_wizSuggestChangeCount(1)" style="width:30px;height:30px;border-radius:8px;border:1.5px solid var(--border);background:var(--card);cursor:pointer;font-size:16px;font-weight:900;color:var(--txt2)">+</button>
        </div>
      </div>

      <!-- قائمة المقترحين -->
      <div style="margin-bottom:14px">
        <div style="font-size:12px;font-weight:800;color:var(--txt2);margin-bottom:8px">
          <i class="fas fa-user-tie" style="color:var(--purple2);margin-left:5px"></i>المراقبون المقترحون
          <span style="font-size:10.5px;font-weight:600;color:var(--txt3)"> — يمكنك إزالة التحديد أو التعديل</span>
        </div>
        <div id="wizSuggestList" style="display:flex;flex-direction:column;gap:7px;max-height:280px;overflow-y:auto">
          ${_wizBuildSuggestList(available, roomCount)}
        </div>
        ${!available.length ? `<div style="padding:20px;text-align:center;color:var(--txt3);font-size:13px">
          <i class="fas fa-user-slash" style="font-size:24px;opacity:.3;display:block;margin-bottom:8px"></i>
          لا يوجد مراقبون متاحون في هذا التوقيت
        </div>` : ''}
      </div>

      ${allSecs.length ? `
      <div>
        <div style="font-size:12px;font-weight:800;color:var(--txt2);margin-bottom:8px">
          <i class="fas fa-layer-group" style="color:var(--gold);margin-left:5px"></i>توزيع الشعب تلقائياً
        </div>
        <div style="font-size:12px;color:var(--txt3);padding:8px 12px;background:var(--gold)08;border-radius:8px;border:1px solid var(--gold)20">
          سيتم توزيع ${allSecs.length} شعبة على ${roomCount} قاعة تلقائياً
        </div>
      </div>` : ''}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" onclick="_wizApplySuggestion()">
        <i class="fas fa-check"></i> تطبيق الاقتراح المحدد
      </button>
    </div>
  </div>`;
  showMo(moId);
}

// ── بناء قائمة الاقتراح ────────────────────────────────────
function _wizBuildSuggestList(available, count) {
  if (!available.length) return '';
  return available.slice(0, Math.min(count + 3, available.length)).map((p, i) => {
    const dept = STATE.departments.find(d => d.id === p.dept_id);
    const checked = i < count;
    return `<label class="suggest-preview-item" style="cursor:pointer">
      <input type="checkbox" ${checked ? 'checked' : ''} value="${p.id}"
        style="accent-color:var(--primary2);width:16px;height:16px;cursor:pointer;flex-shrink:0"
        onchange="_wizSuggestCountUpdate()">
      ${userAvatar(p, 36)}
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(p.name?.split(' ').slice(0,3).join(' '))}</div>
        <div style="font-size:11px;color:var(--txt3);margin-top:1px">
          ${p._inDept ? '<span style="color:var(--primary2)">⭐ نفس القسم · </span>' : ''}
          <span style="color:var(--teal)">${esc(dept?.name || '—')}</span>
          · ${p._sc} امتحان/الفصل
        </div>
      </div>
      <span class="badge ${p._sc>=3?'b-red':p._sc>=2?'b-gold':'b-green'}" style="font-size:10px;flex-shrink:0">${p._sc}</span>
    </label>`;
  }).join('');
}

// ── تغيير عدد المراقبين ──────────────────────────────────────
function _wizSuggestChangeCount(delta) {
  const el = document.getElementById('wizSuggestCount');
  if (!el) return;
  const cur = parseInt(el.textContent) || 1;
  const boxes = document.querySelectorAll('#wizSuggestList input[type=checkbox]');
  const newCount = Math.max(1, Math.min(boxes.length, cur + delta));
  el.textContent = newCount;
  boxes.forEach((cb, i) => { cb.checked = i < newCount; });
}

function _wizSuggestCountUpdate() {
  const el = document.getElementById('wizSuggestCount');
  if (!el) return;
  const checked = document.querySelectorAll('#wizSuggestList input[type=checkbox]:checked').length;
  el.textContent = checked;
}

// ── تطبيق الاقتراح على _WIZ.roomMap ─────────────────────────
function _wizApplySuggestion() {
  const selectedIds = [...document.querySelectorAll('#wizSuggestList input[type=checkbox]:checked')]
    .map(cb => cb.value);

  if (!selectedIds.length) { toast('يرجى اختيار مراقب واحد على الأقل', 'warning'); return; }

  const allSecs = STATE.sections.filter(s => s.semester === STATE.currentSem && s.subject_id == _WIZ.subjectId);
  if (!_WIZ.roomSections) _WIZ.roomSections = {};

  // مسح التعيينات القديمة
  _WIZ.rooms.forEach(rid => {
    _WIZ.roomMap[String(rid)]    = [];
    _WIZ.roomSections[String(rid)] = [];
  });

  // توزيع المراقبين المحددين على القاعات
  let procIdx = 0;
  _WIZ.rooms.forEach(rid => {
    if (procIdx < selectedIds.length) {
      _WIZ.roomMap[String(rid)] = [selectedIds[procIdx]];
      procIdx++;
    }
  });

  // توزيع الشعب على القاعات
  let secIdx = 0;
  _WIZ.rooms.forEach(rid => {
    if (secIdx < allSecs.length) {
      _WIZ.roomSections[String(rid)] = [allSecs[secIdx].id];
      secIdx++;
    }
  });

  closeMo('wizSuggestMo');
  const body = document.getElementById('wizBody');
  if (body) body.innerHTML = _wizStep3HTML();
  const totalMr = [...new Set(Object.values(_WIZ.roomMap).flat())].length;
  const totalSc = [...new Set(Object.values(_WIZ.roomSections).flat())].length;
  toast(`✓ تم تطبيق الاقتراح — ${totalMr} مراقب · ${totalSc} شعبة`, 'success', 3000);
}

// ── الاقتراح المباشر (deprecated — يعاد توجيهه للحوار) ──────
function _wizAutoAssign() { _wizShowSuggestDialog(); }

// ── التحقق قبل الحفظ ─────────────────────────────────────────
function _wizValidate() {
  const warns=[];
  if(!_WIZ.subjectId)  warns.push('لم يُختَر المقرر الدراسي');
  if(!_WIZ.date)        warns.push('لم يُحدَّد يوم الامتحان');
  if(!_WIZ.time)        warns.push('لم يُحدَّد وقت الامتحان');
  if(!_WIZ.rooms.length)warns.push('لم تُختَر أي قاعة للامتحان');
  const empty=_WIZ.rooms.filter(rid=>!(_WIZ.roomMap[String(rid)]?.length));
  if(empty.length) warns.push(`قاعات بدون مراقبين: ${empty.map(rid=>getRoom(rid)?.name||rid).join('، ')}`);
  return warns;
}

// ── التنقل ───────────────────────────────────────────────────
function _wizGoTo(step){_wizSaveCurrentStep();_WIZ.step=step;_renderWizardStep();}
function _wizNext(){_wizSaveCurrentStep();const e=_wizValidateStep(_WIZ.step);if(e.length){toast(e[0],'warning');return;}_WIZ.step=Math.min(4,_WIZ.step+1);_renderWizardStep();}
function _wizPrev(){_wizSaveCurrentStep();_WIZ.step=Math.max(1,_WIZ.step-1);_renderWizardStep();}

function _wizSaveCurrentStep() {
  if(_WIZ.step===1){
    _WIZ.subjectId=parseInt(document.getElementById('wz_subj')?.value)||null;
    _WIZ.date=document.getElementById('wz_date')?.value||_WIZ.date;
    _WIZ.time=document.getElementById('wz_time')?.value||_WIZ.time;
    _WIZ.duration=parseInt(document.getElementById('wz_dur')?.value)||120;
    _WIZ.type=document.getElementById('wz_type')?.value||_WIZ.type;
    _WIZ.notes=document.getElementById('wz_notes')?.value||'';
  }
}

function _wizValidateStep(step) {
  if(step===1){
    if(!_WIZ.subjectId) return['يرجى اختيار المقرر أولاً'];
    if(!_WIZ.date)       return['يرجى تحديد التاريخ'];
    if(!_WIZ.time)       return['يرجى تحديد الوقت'];
  }
  if(step===2){if(!_WIZ.rooms.length) return['يرجى اختيار قاعة واحدة على الأقل'];}
  return[];
}

function _wizAfterRender() {
  if(_WIZ.step===1){
    _wizRefreshPoints();
    document.querySelectorAll('.wz-dur').forEach(b=>{const v=parseInt(b.getAttribute('data-v'));const isA=v===_WIZ.duration;b.style.background=isA?'var(--primary2)':'';b.style.color=isA?'white':'';b.style.borderColor=isA?'var(--primary2)':'';});
  }
}

// ── الحفظ النهائي ─────────────────────────────────────────────
async function _saveExamWizard() {
  _wizSaveCurrentStep();
  const errors=_wizValidate().filter(w=>w.includes('لم يُختَر المقرر')||w.includes('لم يُحدَّد'));
  if(errors.length){toast(errors[0],'error');return;}

  const btn=document.getElementById('wizSaveBtn');
  if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> جارٍ الحفظ...';}

  try {
    const allProctorIds=[...new Set(Object.values(_WIZ.roomMap||{}).flat())];
    const allSectionIds=[...new Set(Object.values(_WIZ.roomSections||{}).flat())];
    const proctor_statuses={};
    allProctorIds.forEach(pid=>{proctor_statuses[pid]='pending';});

    // ✅ حالة المراجعة:
    //   - إذا أنشأه المسؤول → موافق عليه مباشرة (approved)
    //   - إذا أنشأه المنسق → معلّق ينتظر مراجعة المسؤول (pending)
    //   - عند التعديل: نحافظ على الحالة الحالية أو نعيدها إلى pending إذا عدّلها منسق
    const isAdmCreator = isAdmin();
    let approval_status = 'approved';
    let approval_by = STATE.currentUser?.id;
    let approval_at = new Date().toISOString();
    if (!isAdmCreator) {
      // منسق ينشئ أو يعدّل
      approval_status = 'pending';
      approval_by = null;
      approval_at = null;
    }

    const payload={
      subject_id:_WIZ.subjectId, semester:STATE.currentSem,
      date:_WIZ.date, time:_WIZ.time, duration:_WIZ.duration,
      extra_time:0, type:_WIZ.type, max_grade:100, notes:_WIZ.notes,
      is_holiday:typeof _isAutoHoliday==='function'?_isAutoHoliday(_WIZ.date):false,
      room_ids:_WIZ.rooms, proctor_ids:allProctorIds,
      section_ids:allSectionIds,
      room_proctors:_WIZ.roomMap||{},
      room_sections:_WIZ.roomSections||{},
      proctor_statuses,
      approval_status, approval_by, approval_at,
      approval_notes: ''
    };

    let savedId;
    if(_WIZ.editId){
      try {
        await dbUpdate('exams',_WIZ.editId,payload);
      } catch(err) {
        // ✅ التراجع: إذا فشلت بسبب أعمدة approval غير موجودة، أعد المحاولة بدونها
        if (err.message && /approval/i.test(err.message)) {
          console.warn('[wizard] approval columns missing in DB — falling back');
          const { approval_status:_a, approval_by:_b, approval_at:_c, approval_notes:_d, ...lite } = payload;
          await dbUpdate('exams',_WIZ.editId,lite);
          // تعطيل ميزة المراجعة لهذه الجلسة
          approval_status = 'approved';
          payload.approval_status = 'approved';
        } else throw err;
      }
      savedId=_WIZ.editId;
      const idx=STATE.exams.findIndex(e=>e.id===_WIZ.editId);
      if(idx>=0)STATE.exams[idx]={...STATE.exams[idx],...payload};
      toast(approval_status==='pending'
        ? '✓ تم تحديث الامتحان — أُرسل للمسؤول للمراجعة'
        : '✓ تم تحديث الامتحان بنجاح','success');
      await addLog('تعديل امتحان','exam',getSubject(_WIZ.subjectId)?.name||'');
    } else {
      let res;
      try {
        res=await dbInsert('exams',payload);
      } catch(err) {
        if (err.message && /approval/i.test(err.message)) {
          console.warn('[wizard] approval columns missing in DB — falling back');
          const { approval_status:_a, approval_by:_b, approval_at:_c, approval_notes:_d, ...lite } = payload;
          res=await dbInsert('exams',lite);
          approval_status = 'approved';
          payload.approval_status = 'approved';
        } else throw err;
      }
      savedId=res?.id||res;
      STATE.exams.push({...payload,id:savedId});
      toast(approval_status==='pending'
        ? '✓ تم إنشاء الامتحان — في انتظار موافقة المسؤول'
        : '✓ تم إضافة الامتحان بنجاح','success', 4500);
      await addLog(approval_status==='pending'?'إنشاء امتحان (معلّق للمراجعة)':'إضافة امتحان','exam',getSubject(_WIZ.subjectId)?.name||'');
      if(savedId&&typeof _syncExamBookings==='function'){try{await _syncExamBookings(savedId,payload);}catch{}}
    }

    // ✅ إشعارات المراقبين تُرسل فقط عند الموافقة
    if(allProctorIds.length && approval_status === 'approved'){
      const sub=getSubject(_WIZ.subjectId);
      const endT=_wizCalcEnd(_WIZ.date,_WIZ.time,_WIZ.duration);
      const rn=_WIZ.rooms.map(rid=>getRoom(rid)?.name).filter(Boolean);
      await addNotif(allProctorIds,'⚡ تعيين مراقبة جديد',
        `تم تعيينك مراقباً لـ "${sub?.name||'—'}" · ${fmtDate(_WIZ.date)} ${fmtTime(_WIZ.time)}—${fmtTime(endT)} · ${rn.join('، ')}`, 'exam');
      setTimeout(()=>toast(`📨 تم إبلاغ ${allProctorIds.length} مراقب`,'info',3000),800);
    }

    // ✅ إذا كان معلّقاً → إخطار المسؤولين للمراجعة
    if (approval_status === 'pending') {
      const admins = STATE.profiles.filter(p => p.role === 'admin' && p.active).map(p => p.id);
      if (admins.length) {
        const sub = getSubject(_WIZ.subjectId);
        await addNotif(admins, '📋 امتحان جديد بحاجة مراجعة',
          `${STATE.currentUser?.name?.split(' ').slice(0,2).join(' ')||'المنسق'} أنشأ امتحاناً للمادة "${sub?.name||'—'}" بتاريخ ${fmtDate(_WIZ.date)} — يحتاج موافقتك`,
          'review');
      }
    }

    // ── إخطار أصحاب الحجوزات/المحاضرات المتعارضة ────────────────
    try {
      await _wizNotifyRoomTakeover(_WIZ.rooms, _WIZ.date, _WIZ.time, _WIZ.duration, _WIZ.editId, getSubject(_WIZ.subjectId)?.name||'');
    } catch(e) { console.warn('[wizard] takeover notify failed:', e); }

    closeMo('examWizardMo');
    renderExams();
    UI._updateAllBadges?.();
    // ✅ البريد فقط عند الموافقة
    if(approval_status === 'approved' && typeof EmailService!=='undefined'){
      try{await EmailService.sendNewExamNotif({...payload,id:savedId});}catch{}
    }
  } catch(e) {
    toast('خطأ أثناء الحفظ: '+e.message,'error');
    if(btn){btn.disabled=false;btn.innerHTML=`<i class="fas fa-save"></i> ${_WIZ.editId?'تحديث الامتحان':'تأكيد وإبلاغ المراقبين'}`;}
  }
}

// ═══════════════════════════════════════════════════════════════
//  إخطار أصحاب الحجوزات/المحاضرات إذا فُرض الامتحان على قاعتهم
// ═══════════════════════════════════════════════════════════════
async function _wizNotifyRoomTakeover(roomIds, date, time, duration, excludeExamId, subjectName) {
  if (!roomIds?.length) return;
  const startTs = new Date(`${date}T${time}`).getTime();
  const endTs   = startTs + duration * 60000;
  const dow     = new Date(date).getDay();
  const affected = new Map();   // userId → [reason]

  // 1) حجوزات قاعات متضاربة
  (STATE.bookings||[]).forEach(b => {
    if (b.date !== date) return;
    if (!roomIds.includes(b.room_id)) return;
    const bs = new Date(`${b.date}T${b.start_time||'00:00'}`).getTime();
    const be = new Date(`${b.date}T${b.end_time||'23:59'}`).getTime();
    if (startTs >= be || endTs <= bs) return;
    if (!b.booked_by) return;
    const room = getRoom(b.room_id);
    const list = affected.get(b.booked_by) || [];
    list.push(`حجز "${b.title||'—'}" في ${room?.name||'—'} (${b.start_time}—${b.end_time})`);
    affected.set(b.booked_by, list);
  });

  // 2) محاضرات الجدول الفصلي (صاحبها = instructor_id)
  const schedSrc = STATE.semesterSchedules?.length ? STATE.semesterSchedules : STATE.schedules;
  (schedSrc||[]).forEach(sc => {
    if (sc.is_active === false) return;
    if (!roomIds.includes(Number(sc.room_id))) return;
    if (Number(sc.day_of_week) !== dow) return;
    const ss = new Date(`${date}T${sc.start_time||'00:00'}`).getTime();
    const se = new Date(`${date}T${sc.end_time||'23:59'}`).getTime();
    if (startTs >= se || endTs <= ss) return;
    const inst = sc.instructor_id;
    if (!inst) return;
    const room = getRoom(sc.room_id);
    const sub  = sc.subject_id ? getSubject(sc.subject_id) : null;
    const list = affected.get(inst) || [];
    list.push(`محاضرة "${sub?.name||'—'}" في ${room?.name||'—'} (${sc.start_time}—${sc.end_time})`);
    affected.set(inst, list);
  });

  if (!affected.size) return;

  // إرسال إشعار لكل صاحب
  for (const [userId, reasons] of affected.entries()) {
    await addNotif([userId],
      '⚠️ تعارض قاعة مع امتحان',
      `تم تثبيت امتحان "${subjectName}" في ${fmtDate(date)} ${fmtTime(time)} على قاعة(قاعات) لديك فيها: ${reasons.join('، ')}. يُرجى التنسيق لنقل المحاضرة.`,
      'warning'
    );
  }
}
