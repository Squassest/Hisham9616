// ═══════════════════════════════════════════════════════════════
//  bookings.js — حجز القاعات الذكي v3 (احترافي)
//  ✓ تصميم بطاقات بصرية متطورة مع رسوم وألوان
//  ✓ بحث ذكي بمعايير متعددة (تاريخ، وقت، سعة، نوع، مبنى)
//  ✓ تكرار متعدد الأيام (أحد + ثلاثاء معاً)
//  ✓ تقويم شهري احترافي بألوان الأغراض
//  ✓ شريط زمني (Timeline) بساعات اليوم
//  ✓ Quick filters + Stats live
//  ✓ كشف تعارض شامل (حجوزات + امتحانات + جدول دراسي)
// ═══════════════════════════════════════════════════════════════

const _BK = {
  view: 'list',                   // list | grid | calendar | timeline
  scope: 'upcoming',              // all | today | upcoming | past | mine | week
  search: '',
  filters: {
    purpose: '',
    building: '',
    type: '',
    minCap: 0
  },
  calMonth: new Date().getMonth(),
  calYear:  new Date().getFullYear(),
  selectedDate: null
};

// ═══════════════════════════════════════════════════════════════
//  الواجهة الرئيسية
// ═══════════════════════════════════════════════════════════════
function renderBookings() {
  const el = document.getElementById('bookingsContent');
  if (!el) return;

  // أزرار الإجراءات في الأعلى
  setHTML('bookingsActs', canEdit() ? `
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn bo btn-sm" onclick="openSmartFinder()" style="border-color:var(--purple)40;background:linear-gradient(135deg,var(--purple)10,var(--primary)08)">
        <i class="fas fa-magic-wand-sparkles" style="color:var(--purple2)"></i> البحث الذكي
      </button>
      <button class="btn bp btn-sm" onclick="openAddBooking()">
        <i class="fas fa-plus"></i> حجز جديد
      </button>
    </div>` : '');

  el.innerHTML = `
    ${_bkBuildHero()}
    ${_bkBuildFilters()}
    <div id="bkResultsArea" class="card" style="overflow:hidden"></div>
  `;
  _bkRender();
}

// ── Hero Section مع إحصاءات بصرية ──────────────────────────────
function _bkBuildHero() {
  const bks   = STATE.bookings || [];
  const today = new Date().toISOString().split('T')[0];
  const me    = STATE.currentUser?.id;

  const todayBks = bks.filter(b => b.date === today).length;
  const upcoming = bks.filter(b => b.date >= today).length;
  const myBks    = bks.filter(b => b.booked_by === me).length;
  const totalRooms = (STATE.rooms||[]).length;

  // قاعات مشغولة الآن
  const now = new Date();
  const nowDate = today;
  const nowTime = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  const busyNow = bks.filter(b =>
    b.date === nowDate && b.start_time <= nowTime && b.end_time >= nowTime
  ).length;
  const freeNow = Math.max(0, totalRooms - busyNow);

  return `
  <div style="background:linear-gradient(135deg,var(--primary)08 0%,var(--purple)08 100%);border-radius:16px;padding:18px;margin-bottom:14px;border:1px solid var(--primary)15;position:relative;overflow:hidden">
    <div style="position:absolute;top:-30px;left:-30px;width:120px;height:120px;background:radial-gradient(circle,var(--primary2)15 0%,transparent 70%);border-radius:50%"></div>
    <div style="position:absolute;bottom:-50px;right:-50px;width:160px;height:160px;background:radial-gradient(circle,var(--purple)10 0%,transparent 70%);border-radius:50%"></div>

    <div style="position:relative;display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:11px">
      ${_bkHeroCard('متاحة الآن', freeNow, 'fa-door-open', '#10b981', '#059669', `${busyNow} مشغولة`)}
      ${_bkHeroCard('اليوم', todayBks, 'fa-calendar-day', '#2563eb', '#1d4ed8', 'إجمالي حجوزات اليوم')}
      ${_bkHeroCard('قادمة', upcoming, 'fa-clock', '#7c3aed', '#6d28d9', 'حجوزات مستقبلية')}
      ${_bkHeroCard('حجوزاتي', myBks, 'fa-user-check', '#d97706', '#b45309', 'أنشأتها أنت')}
    </div>
  </div>`;
}

function _bkHeroCard(label, value, icon, color, color2, sub) {
  return `<div style="background:var(--card);border-radius:13px;padding:13px 15px;display:flex;align-items:center;gap:12px;border:1px solid ${color}20;box-shadow:0 1px 3px ${color}10;transition:transform .15s,box-shadow .15s"
    onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 20px ${color}20'"
    onmouseout="this.style.transform='';this.style.boxShadow='0 1px 3px ${color}10'">
    <div style="width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,${color},${color2});display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 4px 12px ${color}40">
      <i class="fas ${icon}" style="color:white;font-size:18px"></i>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-size:11px;color:var(--txt3);font-weight:700;text-transform:uppercase;letter-spacing:.4px">${label}</div>
      <div style="font-size:24px;font-weight:900;color:${color};line-height:1.1;margin-top:1px">${value}</div>
      <div style="font-size:10.5px;color:var(--txt3);margin-top:2px">${sub}</div>
    </div>
  </div>`;
}

// ── شريط الفلاتر ──────────────────────────────────────────────
function _bkBuildFilters() {
  const buildings = [...new Set((STATE.rooms||[]).map(r=>r.building).filter(Boolean))];
  const hasFilter = _BK.filters.purpose || _BK.filters.building || _BK.filters.type || _BK.filters.minCap || _BK.search;

  return `
  <div class="card" style="margin-bottom:14px;overflow:visible">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <div style="display:flex;gap:5px;flex-wrap:wrap;flex:1">
        ${_bkScopePill('all','الكل','fa-list-ul')}
        ${_bkScopePill('today','اليوم','fa-sun')}
        ${_bkScopePill('week','الأسبوع','fa-calendar-week')}
        ${_bkScopePill('upcoming','قادمة','fa-arrow-right')}
        ${_bkScopePill('mine','حجوزاتي','fa-user-circle')}
        ${_bkScopePill('past','سابقة','fa-history')}
      </div>
      <div style="display:flex;gap:3px;background:var(--bg);border-radius:9px;padding:3px;border:1px solid var(--border)">
        ${_bkViewBtn('list','fa-bars','قائمة')}
        ${_bkViewBtn('grid','fa-th-large','شبكة')}
        ${_bkViewBtn('calendar','fa-calendar-alt','تقويم')}
        ${_bkViewBtn('timeline','fa-stream','شريط زمني')}
      </div>
    </div>

    <div style="padding:12px 16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">
      <div class="sbar" style="grid-column:span 2">
        <i class="fas fa-search" style="color:var(--primary2)"></i>
        <input type="text" id="bkSearch" placeholder="ابحث في العنوان أو القاعة..." value="${esc(_BK.search)}" oninput="_bkSetSearch(this.value)" style="font-size:13px">
      </div>
      <select onchange="_bkSetFilter('purpose', this.value)" style="height:38px;border:1.5px solid var(--border);border-radius:9px;padding:0 11px;font-size:12.5px;background:var(--surface);font-weight:600">
        <option value="">🎯 كل الأغراض</option>
        ${Object.entries(APP_CONFIG.BOOKING_PURPOSES||{}).map(([k,v]) =>
          `<option value="${k}" ${_BK.filters.purpose===k?'selected':''}>${v.label}</option>`).join('')}
      </select>
      <select onchange="_bkSetFilter('building', this.value)" style="height:38px;border:1.5px solid var(--border);border-radius:9px;padding:0 11px;font-size:12.5px;background:var(--surface);font-weight:600">
        <option value="">🏢 كل المباني</option>
        ${buildings.map(b => `<option value="${esc(b)}" ${_BK.filters.building===b?'selected':''}>${esc(b)}</option>`).join('')}
      </select>
      <select onchange="_bkSetFilter('type', this.value)" style="height:38px;border:1.5px solid var(--border);border-radius:9px;padding:0 11px;font-size:12.5px;background:var(--surface);font-weight:600">
        <option value="">🚪 كل الأنواع</option>
        ${Object.entries(APP_CONFIG.ROOM_TYPES||{}).map(([k,v]) =>
          `<option value="${k}" ${_BK.filters.type===k?'selected':''}>${v.label}</option>`).join('')}
      </select>
      <input type="number" min="1" placeholder="👥 سعة دنيا" value="${_BK.filters.minCap||''}"
        onchange="_bkSetFilter('minCap', this.value)" style="height:38px;border:1.5px solid var(--border);border-radius:9px;padding:0 11px;font-size:12.5px;background:var(--surface);font-weight:600">
      ${hasFilter ? `<button class="btn bo btn-sm" onclick="_bkClearFilters()" style="height:38px;color:var(--red2);border-color:var(--red2)40">
        <i class="fas fa-times"></i> مسح الكل
      </button>` : ''}
    </div>
  </div>`;
}

function _bkScopePill(key, label, icon) {
  const active = _BK.scope === key;
  return `<button onclick="_bkSetScope('${key}')" class="btn ${active?'bp':'bo'} btn-sm" style="${active?'box-shadow:0 2px 6px var(--primary)30':''}">
    <i class="fas ${icon}"></i> ${label}
  </button>`;
}
function _bkViewBtn(v, icon, title) {
  const active = _BK.view === v;
  return `<button onclick="_bkSetView('${v}')" title="${title}" style="height:30px;width:36px;border-radius:7px;border:none;background:${active?'var(--primary2)':'transparent'};color:${active?'white':'var(--txt2)'};cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s">
    <i class="fas ${icon}" style="font-size:13px"></i>
  </button>`;
}

function _bkSetScope(s)              { _BK.scope = s; _bkRender(); }
function _bkSetView(v)               { _BK.view = v;  _bkRender(); }
function _bkSetSearch(v)             { _BK.search = v; _bkRender(); }
function _bkSetFilter(key, val)      { _BK.filters[key] = val; _bkRender(); }
function _bkClearFilters() {
  _BK.filters = { purpose:'', building:'', type:'', minCap:0 };
  _BK.search = '';
  renderBookings();
}

// ── تطبيق الفلاتر ─────────────────────────────────────────────
function _bkFilteredList() {
  const today = new Date().toISOString().split('T')[0];
  const weekFromNow = new Date(); weekFromNow.setDate(weekFromNow.getDate()+7);
  const weekStr = weekFromNow.toISOString().split('T')[0];
  const me    = STATE.currentUser?.id;
  let list    = (STATE.bookings || []).slice();

  if (_BK.scope === 'today')    list = list.filter(b => b.date === today);
  if (_BK.scope === 'upcoming') list = list.filter(b => b.date >= today);
  if (_BK.scope === 'past')     list = list.filter(b => b.date < today);
  if (_BK.scope === 'mine')     list = list.filter(b => b.booked_by === me);
  if (_BK.scope === 'week')     list = list.filter(b => b.date >= today && b.date <= weekStr);

  if (_BK.filters.purpose) list = list.filter(b => b.purpose === _BK.filters.purpose);

  if (_BK.filters.type || _BK.filters.building || _BK.filters.minCap) {
    list = list.filter(b => {
      const r = getRoom(b.room_id);
      if (!r) return false;
      if (_BK.filters.type     && r.type     !== _BK.filters.type)     return false;
      if (_BK.filters.building && r.building !== _BK.filters.building) return false;
      if (_BK.filters.minCap   && (r.cap||0) < parseInt(_BK.filters.minCap)) return false;
      return true;
    });
  }

  if (_BK.search) {
    const q = _BK.search.toLowerCase();
    list = list.filter(b => {
      const r = getRoom(b.room_id);
      return (b.title||'').toLowerCase().includes(q) ||
             (r?.name||'').toLowerCase().includes(q) ||
             (b.notes||'').toLowerCase().includes(q);
    });
  }

  return list.sort((a,b) => `${a.date}T${a.start_time||'00:00'}`.localeCompare(`${b.date}T${b.start_time||'00:00'}`));
}

// ── تشغيل العرض ──────────────────────────────────────────────
function _bkRender() {
  const area = document.getElementById('bkResultsArea');
  if (!area) return;
  const list = _bkFilteredList();

  if (!list.length) {
    area.innerHTML = `<div style="padding:80px 20px;text-align:center">
      <div style="width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,var(--primary)10,var(--purple)10);display:flex;align-items:center;justify-content:center;margin:0 auto 18px">
        <i class="fas fa-calendar-xmark" style="font-size:36px;color:var(--primary2)"></i>
      </div>
      <h3 style="margin-bottom:7px;font-size:16px;font-weight:800">لا توجد حجوزات مطابقة</h3>
      <p style="font-size:13px;color:var(--txt3);margin-bottom:18px">جرّب تغيير الفلاتر أو إنشاء حجز جديد</p>
      ${canEdit()?`<button class="btn bp" onclick="openAddBooking()"><i class="fas fa-plus"></i> حجز جديد</button>`:''}
    </div>`;
    return;
  }

  if (_BK.view === 'grid')     return _bkRenderGrid(area, list);
  if (_BK.view === 'calendar') return _bkRenderCalendar(area, list);
  if (_BK.view === 'timeline') return _bkRenderTimeline(area, list);
  return _bkRenderList(area, list);
}

// ── العرض القائمة ────────────────────────────────────────────
function _bkRenderList(area, list) {
  const byDate = {};
  list.forEach(b => { (byDate[b.date] = byDate[b.date] || []).push(b); });
  const dates = Object.keys(byDate).sort();
  const today = new Date().toISOString().split('T')[0];

  area.innerHTML = `
    <div style="padding:12px 18px;background:linear-gradient(90deg,var(--bg),var(--card));border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <div style="font-size:13px;font-weight:800"><i class="fas fa-list-ul" style="color:var(--primary2);margin-left:6px"></i>قائمة الحجوزات</div>
      <span class="badge b-blue">${list.length} حجز</span>
    </div>
    ${dates.map(d => {
      const isToday = d === today;
      const dayBks = byDate[d];
      return `
      <div style="padding:11px 18px;background:${isToday?'var(--primary)08':'var(--bg)'};border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;position:sticky;top:0;z-index:5;backdrop-filter:blur(8px)">
        ${isToday?'<span style="width:8px;height:8px;background:var(--green2);border-radius:50%;box-shadow:0 0 0 0 var(--green2);animation:pulse 2s infinite"></span>':'<i class="fas fa-calendar-day" style="color:var(--primary2);font-size:13px"></i>'}
        <span style="font-weight:800;font-size:13px">${fmtDate(d)}</span>
        ${isToday?'<span class="badge b-green" style="font-size:9.5px">اليوم</span>':''}
        <span style="font-size:11.5px;color:var(--txt3);margin-right:auto">${dayBks.length} حجز</span>
      </div>
      ${dayBks.map(_bkBuildCard).join('')}
      `;
    }).join('')}
  `;
}

// ── العرض الشبكي ──────────────────────────────────────────────
function _bkRenderGrid(area, list) {
  area.innerHTML = `
    <div style="padding:12px 18px;background:linear-gradient(90deg,var(--bg),var(--card));border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <div style="font-size:13px;font-weight:800"><i class="fas fa-th-large" style="color:var(--primary2);margin-left:6px"></i>عرض شبكي</div>
      <span class="badge b-blue">${list.length} حجز</span>
    </div>
    <div style="padding:14px;display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:12px">
      ${list.map(_bkBuildCard).join('')}
    </div>`;
}

// ── العرض الشريط الزمني ──────────────────────────────────────
function _bkRenderTimeline(area, list) {
  // اليوم المحدد (افتراضياً اليوم) — سيُستخدم 24 ساعة
  const today = new Date().toISOString().split('T')[0];
  const targetDate = _BK.selectedDate || today;
  const dayBks = list.filter(b => b.date === targetDate);

  // ساعات العمل: 7 صباحاً إلى 11 مساءً
  const startHour = 7, endHour = 23;
  const totalHours = endHour - startHour;

  // مجموعة القاعات في هذا اليوم
  const roomsInDay = [...new Set(dayBks.map(b => b.room_id))].map(id => getRoom(id)).filter(Boolean);

  area.innerHTML = `
    <div style="padding:12px 18px;background:linear-gradient(90deg,var(--bg),var(--card));border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
      <div style="font-size:13px;font-weight:800"><i class="fas fa-stream" style="color:var(--primary2);margin-left:6px"></i>الشريط الزمني</div>
      <div style="display:flex;gap:8px;align-items:center">
        <input type="date" value="${targetDate}" onchange="_BK.selectedDate=this.value;_bkRender()" style="height:32px;padding:0 10px;border:1.5px solid var(--border);border-radius:8px;font-size:12.5px;background:var(--surface)">
        <span class="badge b-blue">${dayBks.length} حجز</span>
      </div>
    </div>

    ${!roomsInDay.length ? `<div style="padding:60px 20px;text-align:center;color:var(--txt3)">
      <i class="fas fa-calendar-day" style="font-size:36px;opacity:.25;display:block;margin-bottom:11px"></i>
      <div style="font-size:13.5px">لا حجوزات في ${fmtDate(targetDate)}</div>
    </div>` : `
    <div style="padding:14px;overflow-x:auto">
      <div style="min-width:880px">
        <!-- شريط الساعات -->
        <div style="display:grid;grid-template-columns:140px repeat(${totalHours}, 1fr);gap:1px;margin-bottom:6px">
          <div style="font-size:10.5px;font-weight:800;color:var(--txt3);padding:6px;text-align:center">القاعة</div>
          ${Array.from({length:totalHours},(_,i)=>{
            const h = startHour + i;
            return `<div style="font-size:10px;font-weight:800;color:var(--txt3);padding:5px;text-align:center;border-bottom:2px solid var(--border)">${String(h).padStart(2,'0')}:00</div>`;
          }).join('')}
        </div>

        <!-- صفوف القاعات -->
        ${roomsInDay.map(room => {
          const roomBks = dayBks.filter(b => b.room_id === room.id);
          const ti = APP_CONFIG.ROOM_TYPES?.[room.type] || {};
          return `<div style="display:grid;grid-template-columns:140px repeat(${totalHours}, 1fr);gap:1px;margin-bottom:3px;align-items:stretch;position:relative;height:48px">
            <div style="padding:6px 9px;background:var(--bg);border-radius:6px;display:flex;align-items:center;gap:6px;font-size:11.5px;font-weight:700;border-right:3px solid ${ti.color||'var(--primary2)'}">
              <i class="fas ${ti.icon||'fa-door-open'}" style="color:${ti.color||'var(--primary2)'};font-size:11px"></i>
              <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <div style="line-height:1.1">${esc(room.name)}</div>
                <div style="font-size:9px;color:var(--txt3);font-weight:600">${room.cap||0} مقعد</div>
              </div>
            </div>
            ${Array.from({length:totalHours},(_,i)=>`<div style="background:var(--card);border-bottom:1px dashed var(--border);position:relative"></div>`).join('')}
            <!-- البلوكات -->
            ${roomBks.map(b => {
              const sH = parseFloat(b.start_time?.split(':')[0])+parseFloat(b.start_time?.split(':')[1]||0)/60;
              const eH = parseFloat(b.end_time?.split(':')[0])+parseFloat(b.end_time?.split(':')[1]||0)/60;
              const left = ((sH-startHour)/totalHours)*100;
              const width = ((eH-sH)/totalHours)*100;
              const purp = APP_CONFIG.BOOKING_PURPOSES?.[b.purpose] || { label:b.purpose, color:'#64748b' };
              if (left<0 || left>=100) return '';
              return `<div onclick="_bkOpenDetail(${b.id})"
                style="position:absolute;top:4px;bottom:4px;left:calc(140px + 1px + ${left}% * (100% - 140px) / 100);width:calc(${width}% * (100% - 140px) / 100 - 2px);background:linear-gradient(135deg,${purp.color},${purp.color}cc);border-radius:6px;padding:5px 8px;color:white;cursor:pointer;overflow:hidden;font-size:10.5px;font-weight:700;box-shadow:0 2px 8px ${purp.color}50;transition:all .15s"
                onmouseover="this.style.transform='scale(1.03)';this.style.zIndex='10'"
                onmouseout="this.style.transform='';this.style.zIndex=''"
                title="${esc(b.title)} · ${b.start_time}—${b.end_time}">
                <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(b.title)}</div>
                <div style="font-size:9.5px;opacity:.92;font-weight:600">${b.start_time}—${b.end_time}</div>
              </div>`;
            }).join('')}
          </div>`;
        }).join('')}
      </div>
    </div>`}
  `;
}

// ── العرض التقويمي ────────────────────────────────────────────
function _bkRenderCalendar(area, list) {
  const year = _BK.calYear, month = _BK.calMonth;
  const firstDow = new Date(year, month, 1).getDay();
  const days     = new Date(year, month+1, 0).getDate();
  const today    = new Date();
  const isCurrentMonth = today.getMonth()===month && today.getFullYear()===year;

  const monthNames = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];

  const byDay = {};
  list.forEach(b => {
    const d = new Date(b.date);
    if (d.getMonth() === month && d.getFullYear() === year) {
      const day = d.getDate();
      (byDay[day] = byDay[day] || []).push(b);
    }
  });

  let cells = '';
  for (let i = 0; i < firstDow; i++) cells += '<div></div>';
  for (let d = 1; d <= days; d++) {
    const isToday = isCurrentMonth && today.getDate()===d;
    const dayBks = byDay[d] || [];
    const dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const purposes = [...new Set(dayBks.map(b => b.purpose))];
    const isWeekend = ([5,6].includes(new Date(year,month,d).getDay()));

    cells += `
    <div onclick="_bkShowDay('${dateStr}')" style="aspect-ratio:1/1.05;border-radius:11px;padding:7px;background:${isToday?'linear-gradient(135deg,var(--primary)15,var(--purple)10)':isWeekend?'var(--bg)':'var(--card)'};border:${isToday?'2px solid var(--primary2)':'1px solid var(--border)'};cursor:${dayBks.length?'pointer':'default'};display:flex;flex-direction:column;gap:3px;transition:all .15s;position:relative;overflow:hidden"
      ${dayBks.length?`onmouseover="this.style.transform='scale(1.04)';this.style.boxShadow='0 6px 20px var(--primary)20';this.style.zIndex='10'" onmouseout="this.style.transform='';this.style.boxShadow='';this.style.zIndex=''"`:''}>
      ${isToday?'<div style="position:absolute;top:4px;right:4px;width:6px;height:6px;background:var(--primary2);border-radius:50%;box-shadow:0 0 8px var(--primary2)"></div>':''}
      <div style="font-size:13px;font-weight:${isToday?'900':'700'};color:${isToday?'var(--primary2)':isWeekend?'var(--red2)':'var(--txt)'}">${d}</div>
      ${dayBks.length ? `
        <div style="display:flex;gap:2px;flex-wrap:wrap;margin-top:auto;justify-content:flex-end">
          ${purposes.slice(0,4).map(p => {
            const c = APP_CONFIG.BOOKING_PURPOSES?.[p]?.color || '#64748b';
            return `<span style="width:7px;height:7px;border-radius:50%;background:${c}"></span>`;
          }).join('')}
        </div>
        <div style="font-size:10px;color:var(--txt3);font-weight:700;text-align:center;margin-top:2px">${dayBks.length} حجز</div>
      ` : ''}
    </div>`;
  }

  area.innerHTML = `
    <div style="padding:12px 18px;background:linear-gradient(90deg,var(--bg),var(--card));border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <button onclick="_bkCalNav(-1)" class="btn bo btn-sm"><i class="fas fa-chevron-right"></i></button>
      <div style="font-size:14.5px;font-weight:900;color:var(--primary2)">${monthNames[month]} ${year}</div>
      <div style="display:flex;gap:6px">
        <button onclick="_bkCalToday()" class="btn bo btn-sm">اليوم</button>
        <button onclick="_bkCalNav(1)" class="btn bo btn-sm"><i class="fas fa-chevron-left"></i></button>
      </div>
    </div>
    <div style="padding:14px">
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px;margin-bottom:6px">
        ${['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'].map((n,i)=>
          `<div style="text-align:center;font-size:10.5px;font-weight:800;color:${[5,6].includes(i)?'var(--red2)':'var(--txt3)'};padding:6px">${n}</div>`).join('')}
      </div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px">
        ${cells}
      </div>

      <!-- أسطورة الألوان -->
      <div style="margin-top:14px;padding:10px 14px;background:var(--bg);border-radius:9px;display:flex;flex-wrap:wrap;gap:11px;font-size:11px">
        ${Object.entries(APP_CONFIG.BOOKING_PURPOSES||{}).map(([k,v])=>
          `<div style="display:flex;align-items:center;gap:5px"><span style="width:9px;height:9px;border-radius:50%;background:${v.color}"></span>${v.label}</div>`).join('')}
      </div>
    </div>
  `;
}

function _bkCalNav(dir) {
  _BK.calMonth += dir;
  if (_BK.calMonth < 0)  { _BK.calMonth = 11; _BK.calYear--; }
  if (_BK.calMonth > 11) { _BK.calMonth = 0;  _BK.calYear++; }
  _bkRender();
}
function _bkCalToday() {
  const now = new Date();
  _BK.calMonth = now.getMonth();
  _BK.calYear  = now.getFullYear();
  _bkRender();
}

function _bkShowDay(date) {
  const list = (STATE.bookings || []).filter(b => b.date === date);
  if (!list.length) { toast('لا توجد حجوزات في هذا اليوم', 'info'); return; }
  const moId = 'bkDayMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
  mo.innerHTML = `<div class="md" style="max-width:560px;max-height:88vh;display:flex;flex-direction:column">
    <div class="md-hd">
      <h2><i class="fas fa-calendar-day" style="color:var(--primary)"></i> ${fmtDate(date)}</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:14px 18px;overflow-y:auto;flex:1">
      ${list.sort((a,b)=>(a.start_time||'').localeCompare(b.start_time||'')).map(_bkBuildCard).join('')}
    </div>
    <div class="md-ft">
      ${canEdit()?`<button class="btn bo" onclick="closeMo('${moId}');openAddBooking({date:'${date}'})"><i class="fas fa-plus"></i> حجز جديد في هذا اليوم</button>`:''}
      <button class="btn bp" onclick="closeMo('${moId}')">إغلاق</button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

// ── بناء بطاقة الحجز ─────────────────────────────────────────
function _bkBuildCard(b) {
  const room  = getRoom(b.room_id);
  const user  = getProfile(b.booked_by);
  const purp  = APP_CONFIG.BOOKING_PURPOSES?.[b.purpose] || { label:b.purpose||'أخرى', color:'#64748b', icon:'fa-calendar' };
  const me    = STATE.currentUser?.id;
  const canDel= canEdit() && (isAdmin() || isCoord() || b.booked_by === me);

  // الوقت المتبقي
  const now = new Date();
  const start = new Date(`${b.date}T${b.start_time||'00:00'}`);
  const end   = new Date(`${b.date}T${b.end_time||'23:59'}`);
  const isOngoing = now >= start && now <= end;
  const isPast    = now > end;

  // تكرار
  const rec = b.recurrence;
  const recLabel = rec === 'weekly' ? 'أسبوعياً' :
                   rec === 'daily'  ? 'يومياً'    :
                   (rec && typeof rec === 'object' && rec.days) ? `أيام ${rec.days.length}` :
                   null;

  return `<div onclick="_bkOpenDetail(${b.id})" style="margin:8px 14px;border-radius:13px;background:var(--card);border:1px solid var(--border);overflow:hidden;cursor:pointer;transition:all .18s;position:relative;${isPast?'opacity:.65':''}"
    onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 24px ${purp.color}25';this.style.borderColor='${purp.color}50'"
    onmouseout="this.style.transform='';this.style.boxShadow='';this.style.borderColor='var(--border)'">

    <!-- شريط الغرض الأيمن -->
    <div style="position:absolute;top:0;right:0;bottom:0;width:4px;background:linear-gradient(180deg,${purp.color},${purp.color}80)"></div>

    ${isOngoing?`<div style="position:absolute;top:8px;left:8px;display:flex;align-items:center;gap:5px;background:var(--green2)15;border:1px solid var(--green2)40;border-radius:20px;padding:2px 9px;font-size:10px;font-weight:800;color:var(--green2)">
      <span style="width:6px;height:6px;background:var(--green2);border-radius:50%;animation:pulse 1.5s infinite"></span>
      جارٍ الآن
    </div>`:''}

    <div style="padding:13px 16px 13px 14px;display:flex;align-items:start;gap:11px">
      <div style="width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,${purp.color},${purp.color}b3);display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 4px 10px ${purp.color}40">
        <i class="fas ${purp.icon||'fa-calendar-check'}" style="color:white;font-size:18px"></i>
      </div>

      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;flex-wrap:wrap">
          <span style="font-weight:800;font-size:13.5px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(b.title||'حجز')}</span>
          <span class="badge" style="background:${purp.color}20;color:${purp.color};font-size:10px;padding:2px 9px;font-weight:800;border:1px solid ${purp.color}30">${purp.label}</span>
          ${recLabel?`<span class="badge" style="background:var(--purple)15;color:var(--purple2);font-size:10px;padding:2px 9px;font-weight:800;border:1px solid var(--purple)30"><i class="fas fa-repeat" style="font-size:8px;margin-left:3px"></i>${recLabel}</span>`:''}
        </div>

        <div style="display:flex;flex-wrap:wrap;gap:11px;font-size:11.5px;color:var(--txt2);margin-top:6px">
          <span style="display:flex;align-items:center;gap:4px"><i class="fas fa-door-open" style="color:var(--primary2);font-size:11px"></i> ${esc(room?.name||'—')}${room?.building?` <span style="color:var(--txt3);font-size:10.5px">· ${esc(room.building)}</span>`:''}</span>
          <span style="display:flex;align-items:center;gap:4px"><i class="fas fa-clock" style="color:var(--teal);font-size:11px"></i> ${b.start_time||'—'} → ${b.end_time||'—'}</span>
          ${room?.cap?`<span style="display:flex;align-items:center;gap:4px"><i class="fas fa-users" style="color:var(--gold);font-size:11px"></i> ${room.cap} مقعد</span>`:''}
          ${user?`<span style="display:flex;align-items:center;gap:4px;color:var(--txt3)"><i class="fas fa-user" style="font-size:11px"></i> ${esc(user.name?.split(' ').slice(0,2).join(' ')||'—')}</span>`:''}
        </div>

        ${b.notes?`<div style="margin-top:8px;padding:7px 10px;background:var(--bg);border-radius:8px;font-size:11px;color:var(--txt2);border-right:3px solid ${purp.color}50;line-height:1.5">${esc(b.notes)}</div>`:''}
      </div>

      ${canDel?`<button class="btn bd btn-xs" onclick="event.stopPropagation();deleteBooking(${b.id})" title="حذف الحجز" style="flex-shrink:0">
        <i class="fas fa-trash"></i>
      </button>`:''}
    </div>
  </div>`;
}

// ── تفاصيل الحجز ─────────────────────────────────────────────
function _bkOpenDetail(id) {
  const b = (STATE.bookings||[]).find(x => x.id === id);
  if (!b) return;
  const room = getRoom(b.room_id);
  const user = getProfile(b.booked_by);
  const purp = APP_CONFIG.BOOKING_PURPOSES?.[b.purpose] || { label:b.purpose||'أخرى', color:'#64748b', icon:'fa-calendar' };
  const me   = STATE.currentUser?.id;
  const canDel= canEdit() && (isAdmin() || isCoord() || b.booked_by === me);

  // إخوة هذا الحجز (نفس المجموعة المتكررة)
  const siblings = b.recurrence_group
    ? STATE.bookings.filter(x => x.recurrence_group === b.recurrence_group).sort((a,b)=>a.date.localeCompare(b.date))
    : [b];

  const moId = 'bkDetailMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:540px">
    <div class="md-hd" style="background:linear-gradient(135deg,${purp.color}15,${purp.color}05);border-bottom:2px solid ${purp.color}40">
      <h2><i class="fas ${purp.icon||'fa-calendar-check'}" style="color:${purp.color}"></i> ${esc(b.title||'حجز')}</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-bottom:14px">
        ${_bkDetailItem('fa-tag', 'الغرض', purp.label, purp.color)}
        ${_bkDetailItem('fa-door-open', 'القاعة', `${esc(room?.name||'—')}${room?.building?` (${esc(room.building)})`:''}`, 'var(--primary2)')}
        ${_bkDetailItem('fa-calendar', 'التاريخ', fmtDate(b.date), 'var(--gold)')}
        ${_bkDetailItem('fa-clock', 'الوقت', `${b.start_time||'—'} → ${b.end_time||'—'}`, 'var(--teal)')}
        ${room?.cap?_bkDetailItem('fa-users', 'السعة', `${room.cap} مقعد`, 'var(--purple2)'):''}
        ${user?_bkDetailItem('fa-user', 'الحاجز', esc(user.name||'—'), 'var(--txt2)'):''}
      </div>

      ${b.notes?`<div style="margin-bottom:14px;padding:11px 13px;background:var(--bg);border-radius:10px;border-right:3px solid ${purp.color}">
        <div style="font-size:10.5px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px"><i class="fas fa-comment" style="margin-left:5px"></i>ملاحظات</div>
        <div style="font-size:12.5px;line-height:1.6">${esc(b.notes)}</div>
      </div>`:''}

      ${siblings.length > 1 ? `<div style="margin-bottom:14px">
        <div style="font-size:11px;font-weight:800;color:var(--purple2);margin-bottom:8px"><i class="fas fa-repeat"></i> ${siblings.length} تكرار في هذه السلسلة</div>
        <div style="max-height:140px;overflow-y:auto;background:var(--bg);border-radius:9px;padding:6px">
          ${siblings.map(s=>`<div style="padding:5px 9px;font-size:11.5px;display:flex;align-items:center;gap:7px;${s.id===b.id?'background:'+purp.color+'15;border-radius:6px;font-weight:700':''}">
            ${s.id===b.id?'<i class="fas fa-arrow-left" style="color:'+purp.color+';font-size:9px"></i>':'<span style="width:10px"></span>'}
            ${fmtDate(s.date)} · ${s.start_time}—${s.end_time}
          </div>`).join('')}
        </div>
      </div>`:''}
    </div>
    <div class="md-ft">
      ${canDel?`<button class="btn bd" onclick="closeMo('${moId}');deleteBooking(${b.id})"><i class="fas fa-trash"></i> حذف</button>`:''}
      <button class="btn bp" onclick="closeMo('${moId}')">إغلاق</button>
    </div>
  </div>`;
  requestAnimationFrame(()=>mo.classList.add('open'));
}

function _bkDetailItem(icon, label, val, color) {
  return `<div style="padding:10px 12px;background:var(--bg);border-radius:9px;border-right:3px solid ${color}">
    <div style="font-size:9.5px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:.4px;margin-bottom:3px">
      <i class="fas ${icon}" style="color:${color};margin-left:4px"></i>${label}
    </div>
    <div style="font-size:13px;font-weight:700">${val}</div>
  </div>`;
}

// ═══════════════════════════════════════════════════════════════
//  البحث الذكي عن قاعة متاحة
// ═══════════════════════════════════════════════════════════════
function openSmartFinder() {
  const moId = 'smartFinderMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
  const today = new Date().toISOString().split('T')[0];

  mo.innerHTML = `<div class="md" style="max-width:680px;max-height:92vh;display:flex;flex-direction:column">
    <div class="md-hd" style="background:linear-gradient(135deg,var(--purple)15,var(--primary)08);border-bottom:2px solid var(--purple)40">
      <h2><i class="fas fa-magic-wand-sparkles" style="color:var(--purple2)"></i> البحث الذكي عن قاعة متاحة</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px;overflow-y:auto;flex:1">
      <div style="padding:11px 14px;background:linear-gradient(135deg,var(--purple)08,var(--primary)05);border-radius:11px;border:1px solid var(--purple)25;margin-bottom:16px;font-size:12.5px;color:var(--txt2);line-height:1.6">
        <i class="fas fa-info-circle" style="color:var(--purple2);margin-left:5px"></i>
        ابحث عن قاعات <b>متاحة</b> في وقت محدد. النظام يفحص <b>3 مصادر تعارض</b> تلقائياً:
        <span style="display:inline-block;margin:6px 0 0;padding:0 8px">
          <span style="display:inline-block;margin:0 3px;padding:1px 8px;background:var(--card);border-radius:5px;font-size:11px">📅 الحجوزات</span>
          <span style="display:inline-block;margin:0 3px;padding:1px 8px;background:var(--card);border-radius:5px;font-size:11px">📋 الامتحانات</span>
          <span style="display:inline-block;margin:0 3px;padding:1px 8px;background:var(--card);border-radius:5px;font-size:11px">🎓 المحاضرات</span>
        </span>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:11px">
        <div class="field"><label class="field-lbl"><i class="fas fa-calendar" style="color:var(--gold)"></i> التاريخ <span class="req">*</span></label><input type="date" id="sfDate" value="${today}" min="${today}" onchange="_sfAutoSearch()"></div>
        <div class="field"><label class="field-lbl"><i class="fas fa-play" style="color:var(--green2)"></i> من <span class="req">*</span></label><input type="time" id="sfStart" value="08:00" onchange="_sfAutoSearch()"></div>
        <div class="field"><label class="field-lbl"><i class="fas fa-stop" style="color:var(--red2)"></i> إلى <span class="req">*</span></label><input type="time" id="sfEnd" value="10:00" onchange="_sfAutoSearch()"></div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:14px">
        <div class="field"><label class="field-lbl"><i class="fas fa-users" style="color:var(--purple2)"></i> سعة دنيا</label><input type="number" id="sfMinCap" min="1" placeholder="مثال: 30" onchange="_sfAutoSearch()"></div>
        <div class="field"><label class="field-lbl"><i class="fas fa-tag" style="color:var(--teal)"></i> نوع القاعة</label>
          <select id="sfType" onchange="_sfAutoSearch()">
            <option value="">أيّ نوع</option>
            ${Object.entries(APP_CONFIG.ROOM_TYPES||{}).map(([k,v])=>`<option value="${k}">${v.label}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label class="field-lbl"><i class="fas fa-building" style="color:var(--primary2)"></i> المبنى</label>
          <select id="sfBuilding" onchange="_sfAutoSearch()">
            <option value="">أيّ مبنى</option>
            ${[...new Set((STATE.rooms||[]).map(r=>r.building).filter(Boolean))].map(b=>`<option value="${esc(b)}">${esc(b)}</option>`).join('')}
          </select>
        </div>
      </div>

      <button class="btn bp" style="width:100%;margin-bottom:14px;background:linear-gradient(135deg,var(--purple2),var(--primary2));border:none;font-weight:800;height:44px" onclick="_sfSearch()">
        <i class="fas fa-search"></i> ابحث الآن
      </button>

      <div id="sfResults"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إغلاق</button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
  // بحث تلقائي بعد فتح
  setTimeout(_sfSearch, 200);
}

let _sfSearchTimer = null;
function _sfAutoSearch() {
  clearTimeout(_sfSearchTimer);
  _sfSearchTimer = setTimeout(_sfSearch, 350);
}

function _sfSearch() {
  const date  = document.getElementById('sfDate')?.value;
  const start = document.getElementById('sfStart')?.value;
  const end   = document.getElementById('sfEnd')?.value;
  const type  = document.getElementById('sfType')?.value;
  const bldg  = document.getElementById('sfBuilding')?.value;
  const cap   = parseInt(document.getElementById('sfMinCap')?.value) || 0;
  const res   = document.getElementById('sfResults');
  if (!res) return;
  if (!date || !start || !end) return;
  if (start >= end) {
    res.innerHTML = `<div style="padding:14px;background:var(--red2)10;border-radius:10px;color:var(--red2);font-size:13px;text-align:center"><i class="fas fa-exclamation-triangle"></i> وقت البداية يجب أن يكون قبل النهاية</div>`;
    return;
  }

  const startTs = new Date(`${date}T${start}`).getTime();
  const endTs   = new Date(`${date}T${end}`).getTime();

  let candidates = STATE.rooms || [];
  if (type) candidates = candidates.filter(r => r.type === type);
  if (bldg) candidates = candidates.filter(r => r.building === bldg);
  if (cap)  candidates = candidates.filter(r => (r.cap||0) >= cap);

  const results = candidates.map(r => {
    const conflicts = _findRoomConflicts(r.id, date, startTs, endTs);
    return { ...r, _conflicts: conflicts };
  });

  const free = results.filter(r => !r._conflicts.length);
  const busy = results.filter(r =>  r._conflicts.length);

  if (!candidates.length) {
    res.innerHTML = `<div style="padding:40px;text-align:center;color:var(--txt3)">
      <i class="fas fa-door-closed" style="font-size:42px;opacity:.25;display:block;margin-bottom:11px"></i>
      <h3 style="margin-bottom:5px;font-size:14.5px;font-weight:800">لا توجد قاعات بهذه المعايير</h3>
      <p style="font-size:12.5px">جرّب إزالة بعض الفلاتر</p>
    </div>`;
    return;
  }

  // حساب نسبة الإتاحة
  const availPct = Math.round((free.length/candidates.length)*100);
  const availColor = availPct > 60 ? '#10b981' : availPct > 30 ? '#d97706' : '#dc2626';

  res.innerHTML = `
    <div style="padding:13px 16px;background:linear-gradient(135deg,${availColor}10,${availColor}05);border-radius:11px;border:1px solid ${availColor}30;margin-bottom:11px;display:flex;align-items:center;gap:14px">
      <div style="width:54px;height:54px;border-radius:50%;border:3px solid ${availColor}30;display:flex;align-items:center;justify-content:center;background:var(--card);position:relative">
        <div style="font-size:14px;font-weight:900;color:${availColor}">${availPct}%</div>
      </div>
      <div style="flex:1">
        <div style="font-weight:900;font-size:14.5px;color:${availColor}"><i class="fas fa-check-circle"></i> ${free.length} قاعة متاحة</div>
        <div style="font-size:11.5px;color:var(--txt3);margin-top:3px">${busy.length} مشغولة من إجمالي ${candidates.length}</div>
      </div>
      <div style="font-size:10.5px;color:var(--txt3);text-align:left">
        <div>${fmtDate(date)}</div>
        <div style="font-weight:700;color:var(--primary2)">${start} → ${end}</div>
      </div>
    </div>

    ${free.length ? `<div style="margin-bottom:14px">
      <div style="font-size:11.5px;font-weight:800;color:var(--green2);margin-bottom:7px;padding-right:3px"><i class="fas fa-check-double"></i> القاعات المتاحة</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px">
        ${free.map(r => {
          const t = APP_CONFIG.ROOM_TYPES?.[r.type] || {};
          return `<div onclick="_sfBookHere(${r.id},'${date}','${start}','${end}')"
            style="padding:13px;border:2px solid var(--green2)40;border-radius:12px;background:linear-gradient(135deg,var(--green2)08,var(--green2)03);cursor:pointer;transition:all .15s;position:relative;overflow:hidden"
            onmouseover="this.style.borderColor='var(--green2)';this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 22px var(--green2)25'"
            onmouseout="this.style.borderColor='var(--green2)40';this.style.transform='';this.style.boxShadow=''">
            <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--green2),var(--teal))"></div>
            <div style="display:flex;align-items:center;gap:9px;margin-bottom:7px">
              <div style="width:34px;height:34px;border-radius:9px;background:${t.color||'var(--green2)'}20;display:flex;align-items:center;justify-content:center">
                <i class="fas ${t.icon||'fa-door-open'}" style="color:${t.color||'var(--green2)'};font-size:14px"></i>
              </div>
              <div style="flex:1;min-width:0">
                <b style="font-size:13.5px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r.name)}</b>
                <div style="font-size:10.5px;color:var(--txt3)">${t.label||r.type||''}</div>
              </div>
            </div>
            <div style="font-size:11px;color:var(--txt2);display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px">
              ${r.cap?`<span><i class="fas fa-users" style="color:var(--purple2);font-size:10px"></i> ${r.cap} مقعد</span>`:''}
              ${r.building?`<span><i class="fas fa-building" style="color:var(--primary2);font-size:10px"></i> ${esc(r.building)}</span>`:''}
            </div>
            <div style="padding:6px 10px;background:var(--green2);color:white;border-radius:7px;text-align:center;font-size:11.5px;font-weight:800">
              <i class="fas fa-plus-circle"></i> اضغط للحجز الفوري
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>` : `<div style="padding:30px;text-align:center;background:var(--gold)05;border-radius:11px;border:1px solid var(--gold)25;margin-bottom:14px">
      <i class="fas fa-clock" style="font-size:32px;color:var(--gold);opacity:.6;display:block;margin-bottom:10px"></i>
      <h3 style="font-size:14px;color:var(--gold);font-weight:800;margin-bottom:5px">لا توجد قاعات متاحة في هذا الوقت</h3>
      <p style="font-size:12px;color:var(--txt3)">جرّب وقتاً آخر أو خفّف الفلاتر</p>
    </div>`}

    ${busy.length ? `<details>
      <summary style="cursor:pointer;list-style:none;padding:10px 14px;background:var(--red2)08;border-radius:10px;border:1px solid var(--red2)25;font-size:12px;font-weight:800;color:var(--red2);display:flex;align-items:center;gap:7px">
        <i class="fas fa-circle-exclamation"></i> القاعات المشغولة (${busy.length})
        <i class="fas fa-chevron-down" style="margin-right:auto;font-size:10px"></i>
      </summary>
      <div style="margin-top:7px;display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:7px">
        ${busy.map(r => `<div style="padding:10px 12px;border:1px solid var(--red2)25;border-radius:10px;background:var(--red2)05">
          <div style="display:flex;align-items:center;gap:6px;font-size:12.5px;font-weight:700;margin-bottom:5px">
            <i class="fas fa-door-closed" style="color:var(--red2)"></i> ${esc(r.name)}
          </div>
          <div style="font-size:10.5px;color:var(--txt3);line-height:1.5">
            ${r._conflicts.slice(0,2).map(c => `<div>⚠️ ${esc(c)}</div>`).join('')}
            ${r._conflicts.length>2?`<div style="color:var(--red2);font-weight:700">+ ${r._conflicts.length-2} أخرى</div>`:''}
          </div>
        </div>`).join('')}
      </div>
    </details>` : ''}
  `;
}

function _sfBookHere(roomId, date, start, end) {
  closeMo('smartFinderMo');
  setTimeout(() => openAddBooking({ roomId, date, start, end }), 200);
}

// ═══════════════════════════════════════════════════════════════
//  كشف التعارضات لقاعة في وقت معيّن
// ═══════════════════════════════════════════════════════════════
function _findRoomConflicts(roomId, date, startTs, endTs, excludeBookingId = null) {
  const conflicts = [];

  // 1) الحجوزات الموجودة
  (STATE.bookings || []).forEach(b => {
    if (b.id === excludeBookingId) return;
    if (b.date !== date) return;
    if (b.room_id !== roomId) return;
    const bs = new Date(`${b.date}T${b.start_time||'00:00'}`).getTime();
    const be = new Date(`${b.date}T${b.end_time||'23:59'}`).getTime();
    if (startTs < be && endTs > bs) {
      const purp = APP_CONFIG.BOOKING_PURPOSES?.[b.purpose]?.label || b.purpose;
      conflicts.push(`${purp}: "${b.title||'—'}" (${b.start_time}—${b.end_time})`);
    }
  });

  // 2) الامتحانات
  (STATE.exams || []).forEach(e => {
    if (!(e.room_ids||[]).includes(roomId)) return;
    if (e.date !== date) return;
    if (e.approval_status === 'pending' || e.approval_status === 'rejected') return;
    const es = new Date(`${e.date}T${e.time}`).getTime();
    const ee = es + (e.duration + (e.extra_time||0)) * 60000;
    if (startTs < ee && endTs > es) {
      const sub = getSubject(e.subject_id);
      conflicts.push(`امتحان "${sub?.name||'—'}" (${e.time})`);
    }
  });

  // 3) الجدول الدراسي الأسبوعي
  const dow = new Date(date).getDay();
  const schedSrc = STATE.semesterSchedules?.length ? STATE.semesterSchedules : STATE.schedules;
  (schedSrc || []).forEach(sc => {
    if (sc.is_active === false) return;
    if (Number(sc.room_id) !== Number(roomId)) return;
    if (Number(sc.day_of_week) !== dow) return;
    const ss = new Date(`${date}T${sc.start_time||'00:00'}`).getTime();
    const se = new Date(`${date}T${sc.end_time||'23:59'}`).getTime();
    if (startTs < se && endTs > ss) {
      const sub = sc.subject_id ? getSubject(sc.subject_id) : null;
      conflicts.push(`محاضرة "${sub?.name||'—'}" (${sc.start_time}—${sc.end_time})`);
    }
  });

  return conflicts;
}

// ═══════════════════════════════════════════════════════════════
//  حجز جديد — نموذج محسّن مع تكرار متعدد الأيام
// ═══════════════════════════════════════════════════════════════
const _DAY_NAMES = ['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

function openAddBooking(prefill) {
  prefill = prefill || {};
  const moId = 'addBookingMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  const today = new Date().toISOString().split('T')[0];
  // أيام الأسبوع المختارة (مبدئياً اليوم الذي اختاره المستخدم)
  const initDow = prefill.date ? new Date(prefill.date).getDay() : new Date().getDay();

  mo.innerHTML = `<div class="md" style="max-width:620px;max-height:92vh;display:flex;flex-direction:column">
    <div class="md-hd" style="background:linear-gradient(135deg,var(--primary)15,var(--purple)08);border-bottom:2px solid var(--primary)40">
      <h2><i class="fas fa-calendar-plus" style="color:var(--primary2)"></i> حجز قاعة جديد</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px;overflow-y:auto;flex:1">

      <!-- العنوان -->
      <div class="field">
        <label class="field-lbl"><i class="fas fa-heading" style="color:var(--primary2)"></i> عنوان الحجز <span class="req">*</span></label>
        <input type="text" id="bkTitle" placeholder="مثال: محاضرة برمجة 1" autofocus>
      </div>

      <!-- القاعة والغرض -->
      <div style="display:grid;grid-template-columns:1.4fr 1fr;gap:10px">
        <div class="field"><label class="field-lbl"><i class="fas fa-door-open" style="color:var(--teal)"></i> القاعة <span class="req">*</span></label>
          <select id="bkRoom" onchange="_bkCheckConflict()">
            <option value="">-- اختر القاعة --</option>
            ${(STATE.rooms||[]).map(r=>`<option value="${r.id}" ${prefill.roomId==r.id?'selected':''}>${esc(r.name)}${r.building?` · ${esc(r.building)}`:''}${r.cap?` · ${r.cap} مقعد`:''}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label class="field-lbl"><i class="fas fa-tag" style="color:var(--gold)"></i> الغرض <span class="req">*</span></label>
          <select id="bkPurpose">
            ${Object.entries(APP_CONFIG.BOOKING_PURPOSES||{}).map(([k,v])=>`<option value="${k}">${v.label}</option>`).join('')}
          </select>
        </div>
      </div>

      <!-- التاريخ والوقت -->
      <div style="display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:10px">
        <div class="field"><label class="field-lbl"><i class="fas fa-calendar" style="color:var(--purple2)"></i> التاريخ <span class="req">*</span></label>
          <input type="date" id="bkDate" value="${prefill.date||today}" min="${today}" onchange="_bkCheckConflict()">
        </div>
        <div class="field"><label class="field-lbl"><i class="fas fa-play" style="color:var(--green2)"></i> من <span class="req">*</span></label>
          <input type="time" id="bkStart" value="${prefill.start||'08:00'}" onchange="_bkCheckConflict()">
        </div>
        <div class="field"><label class="field-lbl"><i class="fas fa-stop" style="color:var(--red2)"></i> إلى <span class="req">*</span></label>
          <input type="time" id="bkEnd" value="${prefill.end||'10:00'}" onchange="_bkCheckConflict()">
        </div>
      </div>

      <!-- التكرار -->
      <div class="field">
        <label class="field-lbl"><i class="fas fa-repeat" style="color:var(--purple2)"></i> نمط التكرار</label>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px">
          <label class="rec-opt" style="cursor:pointer">
            <input type="radio" name="recMode" value="" checked onchange="_bkRecChange()" style="display:none">
            <div class="rec-opt-box" data-mode="">
              <i class="fas fa-circle"></i> مرة واحدة
            </div>
          </label>
          <label class="rec-opt" style="cursor:pointer">
            <input type="radio" name="recMode" value="daily" onchange="_bkRecChange()" style="display:none">
            <div class="rec-opt-box" data-mode="daily">
              <i class="fas fa-redo"></i> يومياً
            </div>
          </label>
          <label class="rec-opt" style="cursor:pointer">
            <input type="radio" name="recMode" value="weekly" onchange="_bkRecChange()" style="display:none">
            <div class="rec-opt-box" data-mode="weekly">
              <i class="fas fa-calendar-week"></i> أسبوعياً
            </div>
          </label>
          <label class="rec-opt" style="cursor:pointer">
            <input type="radio" name="recMode" value="custom" onchange="_bkRecChange()" style="display:none">
            <div class="rec-opt-box" data-mode="custom">
              <i class="fas fa-cog"></i> أيام محددة
            </div>
          </label>
        </div>
        <style>
          .rec-opt-box {
            padding:9px;border:1.5px solid var(--border);border-radius:9px;
            background:var(--card);text-align:center;font-size:11.5px;font-weight:700;
            transition:all .15s; color:var(--txt2);
          }
          .rec-opt input:checked ~ .rec-opt-box {
            border-color:var(--primary2); background:var(--primary)10; color:var(--primary2);
            box-shadow:0 2px 8px var(--primary)20;
          }
        </style>

        <!-- اختيار أيام الأسبوع (يظهر عند اختيار "أيام محددة") -->
        <div id="bkRecDays" style="display:none;margin-bottom:8px;padding:10px 12px;background:var(--purple)05;border-radius:10px;border:1px solid var(--purple)20">
          <div style="font-size:11px;font-weight:800;color:var(--purple2);margin-bottom:7px"><i class="fas fa-info-circle"></i> اختر الأيام التي يتكرر فيها الحجز</div>
          <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px">
            ${_DAY_NAMES.map((n,i)=>`<label style="cursor:pointer;display:block">
              <input type="checkbox" class="bk-day-cb" data-day="${i}" ${i===initDow?'checked':''} onchange="_bkRefreshRecPreview()" style="display:none">
              <div class="bk-day-box" data-day="${i}" style="padding:8px 4px;border:1.5px solid var(--border);border-radius:8px;background:var(--card);text-align:center;font-size:11px;font-weight:700;transition:all .15s">
                ${n.replace('ال','').slice(0,3)}
              </div>
            </label>`).join('')}
          </div>
          <style>
            .bk-day-cb:checked + .bk-day-box {
              border-color:var(--purple2)!important; background:var(--purple)15!important; color:var(--purple2)!important;
              box-shadow:0 2px 6px var(--purple)25;
            }
          </style>
        </div>

        <!-- نطاق التكرار -->
        <div id="bkRecRange" style="display:none;padding:10px 12px;background:var(--bg);border-radius:10px;border:1px solid var(--border)">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:7px">
            <div>
              <label style="font-size:11px;font-weight:800;color:var(--txt3);margin-bottom:4px;display:block"><i class="fas fa-calendar-check"></i> يستمر حتى</label>
              <input type="date" id="bkRecUntil" min="${today}" onchange="_bkRefreshRecPreview()" style="width:100%">
            </div>
            <div>
              <label style="font-size:11px;font-weight:800;color:var(--txt3);margin-bottom:4px;display:block"><i class="fas fa-list-ol"></i> أو عدد التكرارات</label>
              <input type="number" id="bkRecCount" min="1" max="100" placeholder="مثال: 12" onchange="_bkRefreshRecPreview()" style="width:100%">
            </div>
          </div>
          <div id="bkRecPreview" style="margin-top:8px;font-size:11.5px;color:var(--txt2);padding:7px 10px;background:var(--card);border-radius:8px;border:1px dashed var(--border)"></div>
        </div>
      </div>

      <!-- ملاحظات -->
      <div class="field">
        <label class="field-lbl"><i class="fas fa-comment" style="color:var(--txt3)"></i> ملاحظات</label>
        <textarea id="bkNotes" rows="2" placeholder="ملاحظات إضافية (اختياري)"></textarea>
      </div>

      <!-- منطقة كشف التعارض -->
      <div id="bkConflictBox" style="display:none;padding:12px 14px;border-radius:11px;margin-top:5px;font-size:12.5px"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" id="bkSaveBtn" onclick="_saveBooking('${moId}')" style="background:linear-gradient(135deg,var(--primary2),var(--primary));border:none">
        <i class="fas fa-save"></i> حفظ الحجز
      </button>
    </div>
  </div>`;

  requestAnimationFrame(() => mo.classList.add('open'));
  if (prefill.roomId || prefill.date) setTimeout(_bkCheckConflict, 100);
}

function _bkRecChange() {
  const mode = document.querySelector('input[name="recMode"]:checked')?.value;
  document.getElementById('bkRecDays').style.display    = (mode === 'custom') ? 'block' : 'none';
  document.getElementById('bkRecRange').style.display   = mode ? 'block' : 'none';
  _bkRefreshRecPreview();
}

function _bkRefreshRecPreview() {
  const preview = document.getElementById('bkRecPreview');
  if (!preview) return;
  const dates = _bkComputeRecurrenceDates();
  if (!dates.length) {
    preview.innerHTML = '<i class="fas fa-info-circle" style="color:var(--txt3)"></i> أكمل البيانات لرؤية التواريخ المتولّدة';
    return;
  }
  const total = dates.length;
  preview.innerHTML = `<i class="fas fa-check-circle" style="color:var(--green2)"></i>
    سيتم إنشاء <b style="color:var(--primary2)">${total}</b> حجز:
    <div style="margin-top:6px;max-height:80px;overflow-y:auto;font-size:11px;line-height:1.7">
      ${dates.slice(0,8).map(d => `<span style="display:inline-block;margin:1px 3px;padding:2px 7px;background:var(--card);border-radius:5px;font-weight:700">${fmtDate(d)}</span>`).join('')}
      ${total>8?`<span style="color:var(--txt3);font-weight:700">+ ${total-8} أخرى...</span>`:''}
    </div>`;
}

function _bkComputeRecurrenceDates() {
  const start = document.getElementById('bkDate')?.value;
  const mode  = document.querySelector('input[name="recMode"]:checked')?.value;
  const until = document.getElementById('bkRecUntil')?.value;
  const count = parseInt(document.getElementById('bkRecCount')?.value) || 0;
  if (!start || !mode) return start ? [start] : [];
  if (!until && !count) return [];

  const stop = until ? new Date(until) : null;
  const max  = count || 365;
  const dates = [];

  if (mode === 'daily') {
    let d = new Date(start);
    while (dates.length < max) {
      if (stop && d > stop) break;
      dates.push(d.toISOString().split('T')[0]);
      d.setDate(d.getDate() + 1);
    }
  } else if (mode === 'weekly') {
    let d = new Date(start);
    while (dates.length < max) {
      if (stop && d > stop) break;
      dates.push(d.toISOString().split('T')[0]);
      d.setDate(d.getDate() + 7);
    }
  } else if (mode === 'custom') {
    const days = [...document.querySelectorAll('.bk-day-cb:checked')].map(cb => parseInt(cb.dataset.day));
    if (!days.length) return [];
    let d = new Date(start);
    let safetyLimit = 0;
    while (dates.length < max && safetyLimit < max*10) {
      if (stop && d > stop) break;
      if (days.includes(d.getDay())) {
        dates.push(d.toISOString().split('T')[0]);
      }
      d.setDate(d.getDate() + 1);
      safetyLimit++;
    }
  }

  return dates;
}

function _bkCheckConflict() {
  const roomId = parseInt(document.getElementById('bkRoom')?.value);
  const date   = document.getElementById('bkDate')?.value;
  const start  = document.getElementById('bkStart')?.value;
  const end    = document.getElementById('bkEnd')?.value;
  const box    = document.getElementById('bkConflictBox');
  const btn    = document.getElementById('bkSaveBtn');
  if (!box) return;

  if (!roomId || !date || !start || !end) {
    box.style.display = 'none';
    if (btn) btn.disabled = false;
    return;
  }

  const startTs = new Date(`${date}T${start}`).getTime();
  const endTs   = new Date(`${date}T${end}`).getTime();

  if (startTs >= endTs) {
    box.style.background = 'var(--red2)10';
    box.style.color = 'var(--red2)';
    box.style.border = '2px solid var(--red2)40';
    box.innerHTML = '<i class="fas fa-times-circle"></i> <b>خطأ:</b> وقت البداية يجب أن يكون قبل النهاية';
    box.style.display = 'block';
    if (btn) btn.disabled = true;
    return;
  }

  const conflicts = _findRoomConflicts(roomId, date, startTs, endTs);
  if (!conflicts.length) {
    box.style.background = 'linear-gradient(135deg,var(--green2)10,var(--teal)05)';
    box.style.color = 'var(--green2)';
    box.style.border = '2px solid var(--green2)40';
    box.innerHTML = '<i class="fas fa-check-circle"></i> <b>متاحة!</b> القاعة شاغرة في هذا الوقت';
    box.style.display = 'block';
    if (btn) btn.disabled = false;
  } else {
    box.style.background = 'var(--red2)08';
    box.style.color = 'var(--red2)';
    box.style.border = '2px solid var(--red2)40';
    box.innerHTML = `<div style="font-weight:800;margin-bottom:5px"><i class="fas fa-exclamation-triangle"></i> تعارض في القاعة (${conflicts.length}):</div>
      <ul style="margin:0;padding-right:18px;font-size:11.5px;line-height:1.7">${conflicts.map(c=>`<li>${esc(c)}</li>`).join('')}</ul>`;
    box.style.display = 'block';
    if (btn) btn.disabled = true;
  }
}

async function _saveBooking(moId) {
  const title  = document.getElementById('bkTitle')?.value?.trim();
  const roomId = parseInt(document.getElementById('bkRoom')?.value);
  const date   = document.getElementById('bkDate')?.value;
  const start  = document.getElementById('bkStart')?.value;
  const end    = document.getElementById('bkEnd')?.value;
  const purpose= document.getElementById('bkPurpose')?.value;
  const notes  = document.getElementById('bkNotes')?.value?.trim();
  const recMode = document.querySelector('input[name="recMode"]:checked')?.value;
  const customDays = recMode === 'custom'
    ? [...document.querySelectorAll('.bk-day-cb:checked')].map(cb => parseInt(cb.dataset.day))
    : null;

  if (!title || !roomId || !date || !start || !end) {
    toast('يرجى إكمال الحقول المطلوبة', 'error'); return;
  }
  if (start >= end) { toast('وقت البداية يجب أن يكون قبل النهاية','error'); return; }
  if (recMode && !document.getElementById('bkRecUntil')?.value && !document.getElementById('bkRecCount')?.value) {
    toast('حدّد التاريخ النهائي للتكرار أو عدد المرات','error'); return;
  }
  if (recMode === 'custom' && !customDays?.length) {
    toast('اختر يوماً واحداً على الأقل للتكرار المخصص','error'); return;
  }

  const dates = _bkComputeRecurrenceDates();
  if (!dates.length) { toast('لم يتمكن النظام من توليد تواريخ — تحقق من البيانات','error'); return; }

  // كشف التعارض في كل تاريخ
  const conflicts = [];
  dates.forEach(d => {
    const ss = new Date(`${d}T${start}`).getTime();
    const ee = new Date(`${d}T${end}`).getTime();
    const cs = _findRoomConflicts(roomId, d, ss, ee);
    cs.forEach(c => conflicts.push(`${fmtDate(d)}: ${c}`));
  });
  if (conflicts.length) {
    toast(`تعذّر الحفظ — ${conflicts.length} تعارض. أول واحد:\n${conflicts[0]}`, 'error', 6000);
    return;
  }

  const recGroup = (dates.length > 1) ? crypto.randomUUID() : null;
  // نخزّن التكرار كـ JSON إذا كان مخصصاً، أو نص بسيط
  const recValue = recMode === 'custom'
    ? JSON.stringify({ type:'custom', days: customDays })
    : (recMode || null);

  const baseData = {
    title, room_id:roomId, booked_by:STATE.currentUser?.id,
    start_time:start, end_time:end, purpose:purpose||'lecture',
    notes:notes||'', status:'confirmed',
    recurrence: recValue, recurrence_group: recGroup
  };

  // ✅ إظهار شريط التقدم
  const btn = document.getElementById('bkSaveBtn');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> جارٍ الحفظ (0/${dates.length})...`;
  }

  try {
    const inserted = [];
    let i = 0;
    for (const d of dates) {
      i++;
      if (btn) btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> جارٍ الحفظ (${i}/${dates.length})...`;
      const data = { ...baseData, date: d };
      try {
        const res = await SB.insert('bookings', data);
        const row = (typeof Hydrate !== 'undefined' && Hydrate.booking) ? Hydrate.booking(res) : res;
        STATE.bookings.push(row);
        inserted.push(row);
      } catch (e) {
        // إذا فشل بسبب recurrence_group غير موجود في DB، أعد المحاولة بدونه
        if (e.message && /recurrence_group/i.test(e.message)) {
          const { recurrence_group:_g, ...lite } = data;
          const res = await SB.insert('bookings', lite);
          const row = (typeof Hydrate !== 'undefined' && Hydrate.booking) ? Hydrate.booking(res) : res;
          STATE.bookings.push(row);
          inserted.push(row);
        } else throw e;
      }
    }
    closeMo(moId);
    renderBookings();
    toast(`✓ تم إنشاء ${inserted.length} حجز${inserted.length>1?` متكرّر`:''}`,'success', 4000);
    await addLog(`إضافة حجز${inserted.length>1?` (${inserted.length} تكرار)`:''}`, 'rooms', title);
  } catch(e) {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-save"></i> حفظ الحجز';
    }
    toast('خطأ: ' + e.message, 'error', 5000);
  }
}

async function deleteBooking(id) {
  const b = (STATE.bookings||[]).find(x => x.id === id);
  if (!b) return;

  const groupBks = b.recurrence_group
    ? STATE.bookings.filter(x => x.recurrence_group === b.recurrence_group)
    : [];

  if (groupBks.length > 1) {
    const moId = 'delChoice';
    let mo = document.getElementById(moId);
    if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
    mo.innerHTML = `<div class="md" style="max-width:400px">
      <div class="md-hd" style="background:linear-gradient(135deg,var(--red2)10,var(--gold)05)">
        <h2><i class="fas fa-trash" style="color:var(--red2)"></i> حذف حجز متكرر</h2>
        <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:16px">
        <p style="font-size:13px;margin-bottom:14px">هذا الحجز جزء من سلسلة تتضمن <b style="color:var(--purple2)">${groupBks.length} حجز</b> متكرر.</p>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn bo" onclick="_doDeleteBooking(${id},false);closeMo('${moId}')" style="text-align:right;padding:10px 14px;height:auto">
            <div style="font-weight:800"><i class="fas fa-trash" style="margin-left:5px"></i> حذف هذا الحجز فقط</div>
            <div style="font-size:11px;color:var(--txt3);margin-top:3px">${fmtDate(b.date)} · ${b.start_time}—${b.end_time}</div>
          </button>
          <button class="btn bd" onclick="_doDeleteBooking(${id},true);closeMo('${moId}')" style="text-align:right;padding:10px 14px;height:auto">
            <div style="font-weight:800"><i class="fas fa-times-circle" style="margin-left:5px"></i> حذف السلسلة كاملة (${groupBks.length} حجز)</div>
            <div style="font-size:11px;opacity:.85;margin-top:3px">سيُحذف كل حجوزات هذه السلسلة</div>
          </button>
        </div>
      </div>
    </div>`;
    requestAnimationFrame(() => mo.classList.add('open'));
    return;
  }

  confirmDelete('هل تريد حذف هذا الحجز؟', () => _doDeleteBooking(id, false));
}

async function _doDeleteBooking(id, all) {
  try {
    if (all) {
      const b = (STATE.bookings||[]).find(x => x.id === id);
      const grp = b?.recurrence_group;
      const ids = STATE.bookings.filter(x => x.recurrence_group === grp).map(x => x.id);
      for (const i of ids) await SB.del('bookings', i);
      STATE.bookings = STATE.bookings.filter(x => !ids.includes(x.id));
      toast(`✓ تم حذف ${ids.length} حجز`,'success');
    } else {
      await SB.del('bookings', id);
      STATE.bookings = STATE.bookings.filter(b => b.id !== id);
      toast('✓ تم الحذف','success');
    }
    renderBookings();
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}
