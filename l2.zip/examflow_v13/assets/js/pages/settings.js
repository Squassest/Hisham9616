// settings.js — إعدادات النظام

function renderSettings() {
  const el = document.getElementById('settingsContent');
  if (!el) return;
  const s = STATE.settings || {};
  const sems = STATE.semesters || [];
  const activeSem = sems.find(x=>x.is_active);

  // ✅ تصحيح ثغرة: الشرط القديم كان `!isAdmin() && !isCoord && !isCoord()`
  // والذي كان يساوي false دائماً (لأن isCoord بدون أقواس دالة موجودة)
  // فيمكن لأي مستخدم رؤية وتعديل إعدادات النظام. الإصلاح:
  if (!isAdmin() && !isCoord()) {
    el.innerHTML = `<div class="card"><div class="card-b" style="padding:24px;text-align:center;color:var(--txt3)"><i class="fas fa-lock" style="font-size:32px;opacity:.3;display:block;margin-bottom:12px"></i>إعدادات النظام للمسؤول/المنسق فقط</div></div>`;
    return;
  }

  el.innerHTML = `
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px">

    <!-- الفصول الدراسية -->
    <div class="card">
      <div class="card-h"><h3><i class="fas fa-calendar" style="color:var(--primary2)"></i> الفصول الدراسية</h3>
        ${isAdmin()?`<button class="btn bp btn-xs" onclick="_addSemester()"><i class="fas fa-plus"></i> إضافة</button>`:''}
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${sems.map(sem=>`
          <div style="display:flex;align-items:center;gap:10px;padding:8px;border-radius:9px;background:var(--bg);margin-bottom:6px">
            <div style="flex:1">
              <div style="font-weight:700;font-size:13px">${esc(sem.label||sem.code)}</div>
              <div style="font-size:11px;color:var(--txt3)">${sem.code}</div>
            </div>
            ${sem.is_active?`<span class="badge b-green" style="font-size:10px">نشط</span>`:''}
            ${sem.is_closed?`<span class="badge b-gray" style="font-size:10px">مغلق</span>`:''}
            ${isAdmin()&&!sem.is_active?`<button class="btn bp btn-xs" onclick="_activateSem('${sem.code}')">تفعيل</button>`:''}
          </div>`).join('') || `<div style="text-align:center;color:var(--txt3);padding:16px">لا توجد فصول</div>`}
      </div>
    </div>

    <!-- إعدادات عامة -->
    <div class="card">
      <div class="card-h"><h3><i class="fas fa-cog" style="color:var(--gold)"></i> إعدادات عامة</h3></div>
      <div class="card-b" style="padding:16px">
        <div class="field">
          <label class="field-lbl">اسم الجامعة / الكلية</label>
          <input type="text" id="stgUniName" value="${esc(s.university_name||'')}" placeholder="${APP_CONFIG.APP_SUBTITLE}">
        </div>
        <div class="field">
          <label class="field-lbl">نقاط المراقبة - صباح</label>
          <input type="number" id="stgPtsMorn" value="${s.pts_morning||1}" min="1" max="10">
        </div>
        <div class="field">
          <label class="field-lbl">نقاط المراقبة - مساء</label>
          <input type="number" id="stgPtsAfter" value="${s.pts_afternoon||2}" min="1" max="10">
        </div>
        <div class="field">
          <label class="field-lbl">علاوة الامتحان النهائي</label>
          <input type="number" id="stgPtsFinal" value="${s.pts_final_bonus||1}" min="0" max="5">
        </div>
        <div class="field">
          <label class="field-lbl">نقاط العطل الرسمية</label>
          <input type="number" id="stgPtsHol" value="${s.pts_holiday||3}" min="0" max="10">
        </div>
        <div class="field">
          <label class="field-lbl">
            الحد الأعلى للنقاط في الفصل
            <span style="font-size:10.5px;color:var(--txt3);font-weight:600">(0 = مفتوح بلا حد)</span>
          </label>
          <input type="number" id="stgPtsLimit" value="${s.pts_sem_limit ?? 0}" min="0" max="100" placeholder="0 (مفتوح)">
        </div>
        ${isAdmin()||isCoord()?`<button class="btn bp" style="width:100%" onclick="_saveSettings()"><i class="fas fa-save"></i> حفظ الإعدادات</button>`:''}
      </div>
    </div>

    <!-- تغيير كلمة المرور -->
    <div class="card">
      <div class="card-h"><h3><i class="fas fa-key" style="color:var(--purple2)"></i> كلمة المرور</h3></div>
      <div class="card-b" style="padding:16px">
        <div class="field">
          <label class="field-lbl">كلمة المرور الجديدة</label>
          <div class="pass-wrap">
            <input type="password" id="stgNewPass" placeholder="••••••••" oninput="checkPassStrength('stgNewPass','stgPassStr','stgPassLbl')">
            <i class="fas fa-eye pass-eye" onclick="togglePassEye('stgNewPass',this)"></i>
          </div>
          <div class="pass-strength"><div class="pass-bar"><div class="pass-bar-fill" id="stgPassStr"></div></div><div class="pass-lbl" id="stgPassLbl"></div></div>
        </div>
        <div class="field">
          <label class="field-lbl">تأكيد كلمة المرور</label>
          <div class="pass-wrap">
            <input type="password" id="stgNewPass2" placeholder="••••••••" oninput="checkPassMatch('stgNewPass','stgNewPass2','stgPassMatch')">
            <i class="fas fa-eye pass-eye" onclick="togglePassEye('stgNewPass2',this)"></i>
          </div>
          <div class="pass-match" id="stgPassMatch"></div>
        </div>
        <button class="btn bp" style="width:100%" onclick="_saveMyPass()"><i class="fas fa-key"></i> تغيير كلمة المرور</button>
      </div>
    </div>

  </div>`;
}

async function _saveSettings() {
  const data = {
    university_name: document.getElementById('stgUniName')?.value?.trim()||'',
    pts_morning:     parseInt(document.getElementById('stgPtsMorn')?.value)||1,
    pts_afternoon:   parseInt(document.getElementById('stgPtsAfter')?.value)||2,
    pts_final_bonus: parseInt(document.getElementById('stgPtsFinal')?.value)||1,
    pts_holiday:     parseInt(document.getElementById('stgPtsHol')?.value)||3,
    pts_sem_limit:   parseInt(document.getElementById('stgPtsLimit')?.value) || 0,  // ✅ 0 = مفتوح
  };
  try {
    const db = SB.getClient();
    if (STATE.settings?.id) {
      await db.from('app_settings').update(data).eq('id', STATE.settings.id);
    } else {
      await db.from('app_settings').insert(data);
    }
    Object.assign(STATE.settings||{}, data);
    toast('✓ تم حفظ الإعدادات','success');
    await addLog('تحديث إعدادات النظام','settings','');
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

async function _saveMyPass() {
  const p1 = document.getElementById('stgNewPass')?.value;
  const p2 = document.getElementById('stgNewPass2')?.value;
  if (!p1||p1.length<4) { toast('كلمة المرور يجب أن تكون 4 أحرف على الأقل','error'); return; }
  if (p1!==p2) { toast('كلمتا المرور غير متطابقتين','error'); return; }
  try {
    await AUTH.changePassword(p1);
    toast('✓ تم تغيير كلمة المرور بنجاح','success');
    document.getElementById('stgNewPass').value='';
    document.getElementById('stgNewPass2').value='';
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

async function _activateSem(code) {
  try {
    const db = SB.getClient();
    await db.from('semesters').update({is_active:false}).neq('code',code);
    await db.from('semesters').update({is_active:true}).eq('code',code);
    STATE.semesters.forEach(s => { s.is_active = s.code===code; });
    STATE.currentSem = code;
    toast('✓ تم تفعيل الفصل الدراسي','success');
    renderSettings();
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

function _addSemester() {
  const code  = prompt('رمز الفصل (مثال: 2025-1)');
  const label = prompt('اسم الفصل (مثال: الفصل الأول 2025-2026)');
  if (!code||!label) return;
  SB.getClient().from('semesters').insert({code,label,is_active:false,is_closed:false})
    .then(()=>{ STATE.semesters.push({code,label,is_active:false,is_closed:false}); renderSettings(); toast('✓ تمت الإضافة','success'); })
    .catch(e=>toast('خطأ: '+e.message,'error'));
}
