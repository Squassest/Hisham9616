// ═══════════════════════════════════════════════════════════════
//  monitor.js — شاشة المراقبة المطورة v5
//  - عداد ضخم، وضع أبيض، لوحة إعلانات، تنبيهات مباشرة
// ═══════════════════════════════════════════════════════════════

let _monWhiteMode = false;

// ── فتح شاشة المراقبة مع دعم التصفية بالقاعة ─────────────────
// roomId: undefined = كشف تلقائي | رقم = قاعة محددة | null = كل القاعات
function openCountdown(examId, roomId) {
  const e = getExam(examId);
  if (!e) return;

  if (isProctor()) {
    // المراقب: كشف قاعته المعيَّنة تلقائياً
    const uid = STATE.currentUser?.id;
    const rp  = e.room_proctors || {};
    const assignedRid = (e.room_ids || []).find(rid => {
      const arr = rp[String(rid)];
      return arr && arr.includes(uid);
    });
    STATE._monRoomId = assignedRid !== undefined ? assignedRid : null;
  } else if (roomId !== undefined) {
    // المسؤول/المنسق اختار قاعة محددة أو null = كل القاعات
    STATE._monRoomId = roomId || null;
  } else if ((e.room_ids || []).length > 1) {
    // امتحان متعدد القاعات بدون تحديد: أظهر منتقي القاعات
    _openRoomSelector(examId);
    return;
  } else {
    STATE._monRoomId = (e.room_ids || [])[0] || null;
  }

  STATE._monExamId = examId;
  const ct = document.getElementById('ctOv');
  if (!ct) return;
  ct.classList.add('open');
  _renderMonitor();
  _startCountdown(examId);
}

function closeCT() {
  const ct = document.getElementById('ctOv');
  if (ct) ct.classList.remove('open');
  if (STATE._ctInterval) { clearInterval(STATE._ctInterval); STATE._ctInterval = null; }
  STATE._ctRunning = false;
  STATE._monExamId = null;
  STATE._monRoomId = null;
}

// ── منتقي القاعة لامتحانات متعددة القاعات ─────────────────────
function _openRoomSelector(examId) {
  const e = getExam(examId);
  if (!e) return;

  const roomItems = (e.room_ids || []).map(rid => {
    const room = getRoom(rid);
    return room ? { id: rid, name: room.name } : null;
  }).filter(Boolean);

  if (!roomItems.length) {
    STATE._monRoomId = null;
    STATE._monExamId = examId;
    const ct = document.getElementById('ctOv');
    if (ct) ct.classList.add('open');
    _renderMonitor();
    _startCountdown(examId);
    return;
  }

  const moId = 'monRoomSelectMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  const rp = e.room_proctors || {};
  const rs = e.room_sections || {};

  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-door-open" style="color:var(--primary)"></i> اختر القاعة للمراقبة</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:16px">
      <p style="color:var(--txt2);font-size:13px;margin-bottom:14px">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        هذا الامتحان في <b>${roomItems.length}</b> قاعات — اختر القاعة لعرض شاشتها:
      </p>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${roomItems.map(r => {
          const proctIds   = rp[String(r.id)] || [];
          const secIds     = rs[String(r.id)]  || [];
          const proctNames = proctIds.map(uid => getProfile(uid)?.name?.split(' ').slice(0,2).join(' ')).filter(Boolean);
          const studCnt    = secIds.reduce((acc, sid) => {
            const sec = getSection(sid);
            return acc + (sec?.student_ids || []).length;
          }, 0);
          return `<button class="btn bo" style="width:100%;text-align:right;padding:14px 16px;border-radius:12px;display:flex;flex-direction:column;gap:4px"
            onclick="closeMo('${moId}');openCountdown(${examId},${r.id})">
            <div style="display:flex;align-items:center;gap:8px">
              <i class="fas fa-door-open" style="color:var(--primary);font-size:16px"></i>
              <span style="font-weight:800;font-size:14px">${esc(r.name)}</span>
              ${studCnt ? `<span class="badge b-blue" style="font-size:10px;margin-right:auto">${studCnt} طالب</span>` : ''}
            </div>
            ${proctNames.length ? `<div style="font-size:11px;color:var(--txt3);padding-right:24px"><i class="fas fa-user-check" style="margin-left:4px"></i>${esc(proctNames.join(' · '))}</div>` : ''}
          </button>`;
        }).join('')}
        <button class="btn bo" style="width:100%;text-align:center;padding:10px 16px;border-radius:10px;border-style:dashed;color:var(--txt2)"
          onclick="closeMo('${moId}');openCountdown(${examId},null)">
          <i class="fas fa-layer-group" style="margin-left:6px"></i>عرض كل القاعات معاً
        </button>
      </div>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

// ── بناء شاشة المراقبة ───────────────────────────────────────
function _renderMonitor() {
  const id   = STATE._monExamId;
  const e    = getExam(id);
  if (!e) return;

  const sub    = getSubject(e.subject_id);
  const roomId = STATE._monRoomId;
  const atts   = STATE.attendance[id] || {};

  // ✅ تصفية البيانات حسب القاعة المحددة
  let rooms, procts, studs;
  if (roomId) {
    const room    = getRoom(roomId);
    rooms  = room ? [room.name] : [];
    const rp      = e.room_proctors || {};
    const proctIds= rp[String(roomId)] || [];
    procts = proctIds.map(uid => getProfile(uid)).filter(Boolean);
    studs  = _getExamStudentsForRoom(e, roomId);
  } else {
    rooms  = (e.room_ids||[]).map(rid => getRoom(rid)?.name).filter(Boolean);
    procts = (e.proctor_ids||[]).map(uid => getProfile(uid)).filter(Boolean);
    studs  = _getExamStudents(e);
  }

  const present = studs.filter(sid => atts[sid]==='present'||atts[sid]==='late').length;
  const status  = examStatus(e);
  const isActive= status==='active';
  const isUpcoming= status==='upcoming';

  // إرشادات الامتحان
  const instructions = STATE.settings?.exam_instructions || [
    'يُمنع استخدام الهاتف المحمول أثناء الامتحان',
    'يُرجى قراءة الأسئلة بعناية قبل الإجابة',
    'لا يُسمح بالتحدث مع الزملاء',
    'يجب تسليم ورقة الإجابة قبل مغادرة القاعة',
    'يُمنع الغش أو استخدام أي مواد غير مصرح بها',
  ];

  // التنبيهات الأخيرة للامتحان
  const examNotifs = (STATE.examNotifications||[]).filter(n=>n.exam_id==id).slice(-3);

  const uniName = STATE.settings?.university_name || APP_CONFIG.APP_SUBTITLE;

  const ctOv = document.getElementById('ctOv');
  if (!ctOv) return;

  ctOv.className = `open${_monWhiteMode?' mon-white':''}`;

  const monWrap = document.getElementById('monWrap');
  if (!monWrap) return;

  if (isUpcoming) {
    // ═══ شاشة ما قبل الامتحان: لوحة الإرشادات ═══
    _renderPreExamScreen(monWrap, e, sub, rooms, procts, instructions, uniName, roomId);
  } else if (isActive) {
    // ═══ شاشة الامتحان الجاري ═══
    _renderActiveScreen(monWrap, e, sub, rooms, procts, present, studs.length, examNotifs, uniName, roomId);
  } else {
    // ═══ انتهى الامتحان ═══
    monWrap.innerHTML = `
      <div style="text-align:center;padding:60px 20px">
        <img src="https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png" 
             alt="SQU" style="height:60px;object-fit:contain;background:white;border-radius:12px;padding:6px 14px;margin-bottom:20px"
             onerror="this.style.display='none'">
        <div style="font-size:72px;margin-bottom:16px">✅</div>
        <div style="font-size:36px;font-weight:900;margin-bottom:8px">انتهى الامتحان</div>
        <div style="opacity:.7;font-size:18px">${sub?.name||'—'}</div>
        <button class="mon-btn" style="margin-top:32px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);padding:14px 32px;font-size:16px" onclick="closeCT()">
          <i class="fas fa-times" style="margin-left:8px"></i>إغلاق
        </button>
      </div>`;
  }
}

// ── شاشة ما قبل الامتحان ─────────────────────────────────────
function _renderPreExamScreen(wrap, e, sub, rooms, procts, instructions, uniName, roomId) {
  const start  = new Date(`${e.date}T${e.time}`);
  const now    = new Date();
  const diffMs = Math.max(0, start - now);
  const diffH  = Math.floor(diffMs/3600000);
  const diffM  = Math.floor((diffMs%3600000)/60000);
  const diffS  = Math.floor((diffMs%60000)/1000);

  wrap.innerHTML = `
  <div class="mon-pre-screen">
    <!-- رأس الشاشة -->
    <div class="mon-header">
      <div style="display:flex;align-items:center;gap:12px">
        <img src="https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png"
             alt="SQU" style="height:44px;object-fit:contain;background:white;border-radius:10px;padding:5px 10px"
             onerror="this.style.display='none'">
        <div class="mon-uni-badge">🎓 ${uniName}</div>
        ${roomId && rooms[0] ? `<div style="background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);border-radius:8px;padding:5px 12px;font-size:13px;font-weight:700"><i class="fas fa-door-open" style="margin-left:6px;opacity:.8"></i>${rooms[0]}</div>` : ''}
      </div>
      <div style="font-size:14px;opacity:.6">${fmtDate(e.date)}</div>
    </div>

    <div class="mon-pre-grid">
      <!-- القسم الأيمن: العداد والمعلومات -->
      <div class="mon-pre-right">
        <!-- شعار كبير فوق اسم المقرر -->
        <div style="text-align:center;margin-bottom:20px">
          <img src="https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png"
               alt="SQU"
               style="height:90px;object-fit:contain;background:white;border-radius:18px;padding:10px 20px;box-shadow:0 8px 32px rgba(0,0,0,.35)"
               onerror="this.style.display='none'">
        </div>

        <div style="text-align:center;margin-bottom:32px">
          <div style="font-size:16px;opacity:.6;margin-bottom:8px;text-transform:uppercase;letter-spacing:2px">يبدأ الامتحان بعد</div>
          <div id="preCountdown" style="font-family:'Cairo',sans-serif;font-size:clamp(52px,8vw,96px);font-weight:900;letter-spacing:-2px;line-height:1">
            ${String(diffH).padStart(2,'0')}:${String(diffM).padStart(2,'0')}:${String(diffS).padStart(2,'0')}
          </div>
        </div>

        <div class="mon-exam-info-card">
          <div class="mon-info-title">${sub?.name||'—'}</div>
          <div class="mon-info-sub">${getTypeLabel(e.type)} · ${fmtDate(e.date)}</div>
          <div class="mon-info-row">
            <span><i class="fas fa-clock"></i> ${fmtTime(e.time)}</span>
            <span><i class="fas fa-hourglass"></i> ${e.duration} دقيقة</span>
          </div>
          ${rooms.length?`<div class="mon-info-row" style="margin-top:8px">
            ${rooms.map(r=>`<span><i class="fas fa-door-open"></i> ${r}</span>`).join('')}
          </div>`:''}
          ${procts.length?`<div class="mon-info-row" style="margin-top:6px">
            ${procts.map(p=>`<span><i class="fas fa-user-check"></i> ${p.name?.split(' ').slice(0,2).join(' ')}</span>`).join('')}
          </div>`:''}
        </div>
      </div>

      <!-- القسم الأيسر: الإرشادات -->
      <div class="mon-pre-left">
        <div class="mon-board-title">
          <i class="fas fa-clipboard-list" style="margin-left:10px"></i>
          إرشادات الامتحان
        </div>
        <div class="mon-instructions-list">
          ${instructions.map((inst,i)=>`
            <div class="mon-inst-item" style="animation-delay:${i*0.1}s">
              <div class="mon-inst-num">${i+1}</div>
              <div class="mon-inst-text">${inst}</div>
            </div>`).join('')}
        </div>
        ${e.notes?`<div class="mon-notes-box">
          <i class="fas fa-info-circle" style="margin-left:8px"></i>
          <strong>ملاحظة:</strong> ${e.notes}
        </div>`:''}
      </div>
    </div>

    <!-- أزرار التحكم -->
    <div class="mon-controls">
      ${(isAdmin()||isCoord())?`
        <button class="mon-ctrl-btn mon-ctrl-notif" onclick="_openMonNotifPanel(${e.id})">
          <i class="fas fa-paper-plane"></i> إرسال إشعار
        </button>
      `:''}
      <button class="mon-ctrl-btn" onclick="_toggleMonWhiteMode()">
        <i class="fas fa-${_monWhiteMode?'moon':'sun'}"></i> ${_monWhiteMode?'وضع داكن':'وضع فاتح'}
      </button>
      <button class="mon-ctrl-btn mon-ctrl-close" onclick="closeCT()">
        <i class="fas fa-times"></i> إغلاق
      </button>
    </div>
  </div>`;
}

// ── شاشة الامتحان الجاري ─────────────────────────────────────
function _renderActiveScreen(wrap, e, sub, rooms, procts, present, total, notifs, uniName, roomId) {
  const start    = new Date(`${e.date}T${e.time}`);
  const totalSec = (e.duration+(e.extra_time||0))*60;
  const end      = new Date(start.getTime()+totalSec*1000);
  const now      = new Date();
  const remMs    = Math.max(0, end-now);
  const remMin   = Math.floor(remMs/60000);
  const remSec   = Math.floor((remMs%60000)/1000);
  const pct      = Math.min(100, Math.round((1-remMs/(totalSec*1000))*100));
  const isWarning= remMin < 15;
  const isDanger = remMin < 5;

  wrap.innerHTML = `
  <div class="mon-active-screen">
    <!-- رأس الشاشة -->
    <div class="mon-header">
      <div style="display:flex;align-items:center;gap:12px">
        <img src="https://conferences.squ.edu.om/Portals/151/ThemePlugin/uploads/2026/1/6/logo.png"
             alt="SQU" style="height:40px;object-fit:contain;background:white;border-radius:10px;padding:4px 10px"
             onerror="this.style.display='none'">
        <div class="mon-uni-badge">🎓 ${uniName}</div>
        ${roomId && rooms[0] ? `<div style="background:rgba(59,130,246,.25);border:1px solid rgba(59,130,246,.4);border-radius:8px;padding:4px 12px;font-size:13px;font-weight:700"><i class="fas fa-door-open" style="margin-left:6px;opacity:.8"></i>${rooms[0]}</div>` : ''}
      </div>
      <div style="display:flex;align-items:center;gap:12px">
        <span style="font-size:13px;opacity:.6">${fmtDate(e.date)}</span>
        <span style="display:flex;align-items:center;gap:6px;font-size:13px;color:#34d399">
          <span style="width:8px;height:8px;border-radius:50%;background:#34d399;animation:pulse 1s infinite"></span>
          جارٍ الآن
        </span>
      </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="mon-active-main">
      <!-- العداد الضخم -->
      <div class="mon-timer-section">
        <div class="mon-subject-name">${sub?.name||'—'}</div>
        <div class="mon-type-badge">${getTypeLabel(e.type)}</div>

        <!-- حلقة العداد -->
        <div class="mon-ring-wrap">
          <svg class="mon-ring-svg" viewBox="0 0 280 280">
            <circle cx="140" cy="140" r="120" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="18"/>
            <circle id="monArc" cx="140" cy="140" r="120" fill="none"
              stroke="${isDanger?'#ef4444':isWarning?'#fbbf24':'#3b82f6'}"
              stroke-width="18" stroke-linecap="round"
              stroke-dasharray="753.98"
              stroke-dashoffset="${753.98*(pct/100)}"
              transform="rotate(-90 140 140)"
              style="transition:stroke-dashoffset 1s linear,stroke .5s"/>
          </svg>
          <div class="mon-ring-inner">
            <div class="mon-countdown ${isDanger?'danger':isWarning?'warn':''}" id="monTime">
              ${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}
            </div>
            <div class="mon-countdown-lbl">الوقت المتبقي</div>
          </div>
        </div>

        <!-- شريط التقدم -->
        <div class="mon-progress-bar">
          <div class="mon-progress-fill ${isDanger?'danger':isWarning?'warn':''}" id="monBar" style="width:${pct}%"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;opacity:.5;margin-top:6px">
          <span>${fmtTime(e.time)}</span>
          <span>${pct}% مضى</span>
          <span>${_timeEndStr(e.time, e.duration+(e.extra_time||0))}</span>
        </div>
      </div>

      <!-- الشريط الجانبي الأيسر -->
      <div class="mon-side-panel">
        <!-- إحصاءات الحضور -->
        <div class="mon-stat-box">
          <div class="mon-stat-title"><i class="fas fa-users"></i> الحضور</div>
          <div class="mon-stat-grid">
            <div class="mon-stat-item">
              <div id="monCountPresent" style="font-size:32px;font-weight:900;color:#34d399">${present}</div>
              <div style="font-size:11px;opacity:.6">حاضر</div>
            </div>
            <div class="mon-stat-item">
              <div id="monCountAbsent" style="font-size:32px;font-weight:900;color:#f87171">${total-present}</div>
              <div style="font-size:11px;opacity:.6">غائب</div>
            </div>
            <div class="mon-stat-item">
              <div id="monCountTotal" style="font-size:32px;font-weight:900">${total}</div>
              <div style="font-size:11px;opacity:.6">الكل</div>
            </div>
          </div>
        </div>

        <!-- القاعات والمراقبون -->
        ${rooms.length?`<div class="mon-info-chips">
          ${rooms.map(r=>`<div class="mon-chip"><i class="fas fa-door-open"></i>${r}</div>`).join('')}
        </div>`:''}
        ${procts.length?`<div class="mon-info-chips">
          ${procts.map(p=>`<div class="mon-chip"><i class="fas fa-user-check"></i>${p.name?.split(' ').slice(0,2).join(' ')}</div>`).join('')}
        </div>`:''}

        <!-- التنبيهات الأخيرة -->
        <div id="monNotifPanel" style="margin-top:12px">
          ${_buildMonNotifList()}
        </div>

        <!-- أزرار التحكم -->
        <div class="mon-side-actions">
          <button class="mon-action-btn" onclick="_openAttInFullscreen(${e.id})">
            <i class="fas fa-clipboard-check"></i> تسجيل الحضور
          </button>
          ${(isAdmin()||isCoord())?`
            <button class="mon-action-btn warn" onclick="_addTimeModal()">
              <i class="fas fa-plus"></i> وقت إضافي
            </button>
            <button class="mon-action-btn notif" onclick="_openMonNotifPanel(${e.id})">
              <i class="fas fa-paper-plane"></i> إرسال إشعار
            </button>
          `:''}
          <button class="mon-action-btn" onclick="_toggleMonWhiteMode()" style="opacity:.7">
            <i class="fas fa-${_monWhiteMode?'moon':'sun'}"></i> ${_monWhiteMode?'داكن':'فاتح'}
          </button>
          <button class="mon-action-btn" onclick="closeCT()" style="opacity:.6">
            <i class="fas fa-compress"></i> تصغير
          </button>
        </div>
      </div>
    </div>
  </div>`;
}

function _buildMonNotifList() {
  const examId = STATE._monExamId;
  // ✅ إظهار إشعارات الامتحان الحالي فقط
  const notifs = (STATE.monitorNotifications||[])
    .filter(n => !examId || n.exam_id == examId)
    .slice(-5).reverse();
  if (!notifs.length) return `<div style="font-size:11px;opacity:.4;text-align:center;padding:8px">لا توجد إشعارات</div>`;
  return notifs.map(n=>`
    <div style="padding:8px 10px;background:rgba(255,255,255,.08);border-radius:8px;margin-bottom:5px;font-size:12px;border-right:3px solid rgba(251,191,36,.5)">
      <div style="font-weight:700;margin-bottom:2px">${n.title}</div>
      ${n.body?`<div style="opacity:.6;font-size:11px">${n.body}</div>`:''}
      <div style="font-size:10px;opacity:.4;margin-top:3px">${fmtDateTime(n.created_at)}</div>
    </div>`).join('');
}

// ── صوت التنبيه والتوست ────────────────────────────────────────
function _playNotifSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    // نغمة تنبيه بسيطة: ثلاث نبضات
    [0, 0.18, 0.36].forEach((delay, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type = 'sine';
      o.frequency.value = i === 1 ? 880 : 660;
      g.gain.setValueAtTime(0, ctx.currentTime + delay);
      g.gain.linearRampToValueAtTime(0.4, ctx.currentTime + delay + 0.05);
      g.gain.linearRampToValueAtTime(0, ctx.currentTime + delay + 0.15);
      o.start(ctx.currentTime + delay);
      o.stop(ctx.currentTime + delay + 0.2);
    });
  } catch(e) { /* متصفح لا يدعم AudioContext */ }
}

function _showMonToast(title, body) {
  let container = document.getElementById('monToastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'monToastContainer';
    container.style.cssText = 'position:fixed;top:16px;left:16px;z-index:9999;display:flex;flex-direction:column;gap:8px;max-width:320px';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.style.cssText = `
    background:linear-gradient(135deg,#1e293b,#0f172a);
    color:white;border-radius:12px;padding:14px 16px;
    box-shadow:0 8px 32px rgba(0,0,0,.4);
    border-right:4px solid #3b82f6;
    display:flex;gap:10px;align-items:flex-start;
    animation:slideIn .3s ease;font-family:inherit;
    direction:rtl
  `;
  toast.innerHTML = `
    <div style="width:32px;height:32px;border-radius:8px;background:rgba(59,130,246,.2);display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <i class="fas fa-bell" style="color:#3b82f6;font-size:14px"></i>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:13px;margin-bottom:2px">${title}</div>
      ${body ? `<div style="font-size:11px;opacity:.7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${body}</div>` : ''}
    </div>
    <button onclick="this.closest('div[style]').remove()" style="background:none;border:none;color:rgba(255,255,255,.5);cursor:pointer;font-size:14px;padding:0;flex-shrink:0">✕</button>
  `;
  container.appendChild(toast);
  setTimeout(() => { if (toast.parentNode) toast.style.opacity = '0'; toast.style.transition = 'opacity .4s'; setTimeout(()=>toast.remove(), 400); }, 5000);
}

// ── تشغيل العداد ─────────────────────────────────────────────
function _startCountdown(examId) {
  if (STATE._ctInterval) clearInterval(STATE._ctInterval);
  const e = getExam(examId); if (!e) return;
  STATE._ctHalfNotified = false;
  STATE._ct10Notified   = false;
  STATE._ct5Notified    = false;
  STATE._ctEndNotified  = false;

  STATE._ctInterval = setInterval(async () => {
    const exam    = getExam(examId);
    if (!exam) { clearInterval(STATE._ctInterval); return; }
    const status  = examStatus(exam);
    const start   = new Date(`${exam.date}T${exam.time}`);
    const totalMs = (exam.duration+(exam.extra_time||0))*60000;
    const end     = new Date(start.getTime()+totalMs);
    const now     = new Date();

    // تحديث بيانات الحضور تلقائياً كل 15 ثانية في وضع الشاشة الكاملة
    if (!STATE._monRefreshCounter) STATE._monRefreshCounter = 0;
    STATE._monRefreshCounter++;
    if (STATE._monRefreshCounter % 15 === 0) {
      try {
        const sb = typeof SB !== 'undefined' ? SB.getClient?.() : null;
        if (sb) {
          const { data: attRows } = await sb.from('attendance').select('*').eq('exam_id', examId);
          if (attRows) {
            STATE.attendance[examId] = {};
            attRows.forEach(r => { STATE.attendance[examId][r.student_id] = r.status; });
            // ✅ استخدام طلاب القاعة المحددة فقط
            const monRid  = STATE._monRoomId;
            const studs   = monRid ? _getExamStudentsForRoom(exam, monRid) : _getExamStudents(exam);
            const atts    = STATE.attendance[examId] || {};
            const present = studs.filter(sid => atts[sid]==='present'||atts[sid]==='late').length;
            const total   = studs.length;
            const pEl  = document.getElementById('monCountPresent');
            const aEl  = document.getElementById('monCountAbsent');
            const tEl2 = document.getElementById('monCountTotal');
            if (pEl) pEl.textContent = present;
            if (aEl) aEl.textContent = total - present;
            if (tEl2) tEl2.textContent = total;
          }
          // ✅ إصلاح: تتبع IDs الإشعارات من قاعدة البيانات بشكل منفصل لمنع التكرار
          const { data: notifRows } = await sb.from('notifications')
            .select('*').order('created_at', { ascending: false }).limit(20);
          if (notifRows) {
            // ✅ إصلاح: تتبع IDs الإشعارات - لا نُظهر إشعارات DB على الشاشة
            // الإشعارات على الشاشة تأتي فقط من _doSendMonNotif (STATE.monitorNotifications)
            if (!STATE._monitorSeenNotifIds) STATE._monitorSeenNotifIds = new Set();
            if (notifRows) notifRows.forEach(n => { if (n.id) STATE._monitorSeenNotifIds.add(n.id); });
            // تحديث قائمة إشعارات الشاشة (monitorNotifications فقط، مفلترة حسب الامتحان الحالي)
            const npEl = document.getElementById('monNotifPanel');
            if (npEl) npEl.innerHTML = _buildMonNotifList();
          }
        }
      } catch(e) { /* silent */ }
    }
    if (status === 'upcoming') {
      const diffMs = Math.max(0, start-now);
      const h = Math.floor(diffMs/3600000);
      const m = Math.floor((diffMs%3600000)/60000);
      const s = Math.floor((diffMs%60000)/1000);
      const el = document.getElementById('preCountdown');
      if (el) el.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      if (diffMs <= 0) { _renderMonitor(); return; }
      return;
    }

    if (status === 'active') {
      const remMs  = Math.max(0, end-now);
      const remMin = Math.floor(remMs/60000);
      const remSec = Math.floor((remMs%60000)/1000);
      const pct    = Math.min(100,Math.round((1-remMs/totalMs)*100));
      const isDanger  = remMin < 5;
      const isWarning = remMin < 15;

      const timeEl = document.getElementById('monTime');
      const arcEl  = document.getElementById('monArc');
      const barEl  = document.getElementById('monBar');

      if (timeEl) {
        timeEl.textContent = `${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}`;
        timeEl.className = `mon-countdown${isDanger?' danger':isWarning?' warn':''}`;
      }
      if (arcEl) {
        arcEl.style.strokeDashoffset = 753.98*(pct/100);
        arcEl.style.stroke = isDanger?'#ef4444':isWarning?'#fbbf24':'#3b82f6';
      }
      if (barEl) {
        barEl.style.width = pct+'%';
        barEl.className = `mon-progress-fill${isDanger?' danger':isWarning?' warn':''}`;
      }

      // تنبيهات
      if (!STATE._ctHalfNotified && remMin <= Math.floor(exam.duration/2)) {
        _flashTimer(); STATE._ctHalfNotified=true;
      }
      if (!STATE._ct10Notified && remMin<=10 && remMin>5) {
        toast('⏰ تبقّت 10 دقائق','warning',6000);
        STATE._ct10Notified=true;
      }
      if (!STATE._ct5Notified && remMin<=5 && remMin>0) {
        toast('🔴 تبقّت 5 دقائق!','error',8000);
        STATE._ct5Notified=true;
      }
      if (!STATE._ctEndNotified && remMs<=0) {
        toast('🔔 انتهى وقت الامتحان!','error',15000);
        STATE._ctEndNotified=true;
        clearInterval(STATE._ctInterval);
        // ✅ حذف إشعارات الشاشة عند انتهاء الامتحان
        STATE.monitorNotifications = (STATE.monitorNotifications||[]).filter(n=>n.exam_id!=examId);
        _renderMonitor();
      }
    } else {
      // انتهى — حذف الإشعارات
      STATE.monitorNotifications = (STATE.monitorNotifications||[]).filter(n=>n.exam_id!=examId);
      clearInterval(STATE._ctInterval);
      _renderMonitor();
    }
  }, 1000);
}

function _flashTimer() {
  const el = document.getElementById('monTime');
  if (!el) return;
  let count = 0;
  const fl = setInterval(()=>{
    el.style.opacity = el.style.opacity==='0'?'1':'0';
    if(++count>5) { clearInterval(fl); el.style.opacity='1'; }
  }, 300);
}

function _timeEndStr(startTime, totalMins) {
  if (!startTime) return '';
  const [h,m] = startTime.split(':').map(Number);
  const t = h*60+m+totalMins;
  const hh = Math.floor(t/60)%24, mm = t%60;
  return `${hh%12||12}:${String(mm).padStart(2,'0')} ${hh<12?'ص':'م'}`;
}

// ── وضع الشاشة الفاتحة/الداكنة ───────────────────────────────
function _toggleMonWhiteMode() {
  _monWhiteMode = !_monWhiteMode;
  const ct = document.getElementById('ctOv');
  if (ct) ct.className = `open${_monWhiteMode?' mon-white':''}`;
  _renderMonitor();
}

// ── لوحة إرسال الإشعارات ────────────────────────────────────
function _openMonNotifPanel(examId) {
  const e = getExam(examId); if (!e) return;
  const ctOv = document.getElementById('ctOv');

  let panel = document.getElementById('monNotifSendPanel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'monNotifSendPanel';
    panel.className = 'mo';
    (ctOv||document.body).appendChild(panel);
  }

  const proctorCount = (e.proctor_ids||[]).length;

  panel.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-paper-plane" style="color:var(--gold)"></i> إشعار مباشر</h2>
      <button class="md-close" onclick="document.getElementById('monNotifSendPanel').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="padding:10px 14px;background:var(--bg);border-radius:9px;margin-bottom:14px;font-size:12.5px;border:1px solid var(--border)">
        <b>${getSubject(e.subject_id)?.name||'—'}</b> · ${fmtDate(e.date)} ${fmtTime(e.time)}
      </div>

      <!-- قوالب سريعة -->
      <div style="margin-bottom:12px">
        <div style="font-size:11.5px;color:var(--txt2);margin-bottom:6px">قوالب سريعة:</div>
        <div style="display:flex;flex-wrap:wrap;gap:5px">
          ${['تنبيه: تبقّت 10 دقائق','يُرجى الهدوء وعدم التحدث','الامتحان بدأ الآن','وقت إضافي 10 دقائق','يُرجى تسليم الأوراق'].map(t=>
            `<button class="btn bo btn-xs" onclick="document.getElementById('mnTitle').value=\`${t}\`">${t}</button>`
          ).join('')}
        </div>
      </div>

      <div class="field">
        <label class="field-lbl">نص الإشعار <span class="req">*</span></label>
        <input type="text" id="mnTitle" placeholder="اكتب إشعاراً..." style="font-size:14px">
      </div>
      <div class="field">
        <label class="field-lbl">تفاصيل (اختياري)</label>
        <textarea id="mnBody" rows="2" placeholder=""></textarea>
      </div>
      <div style="padding:10px 14px;background:var(--primary-bg);border-radius:10px;border:1.5px solid var(--primary)20;display:flex;align-items:center;gap:10px;font-size:12.5px">
        <i class="fas fa-users" style="color:var(--primary2);font-size:16px"></i>
        <span>سيُرسَل لـ <b>${STATE.profiles.filter(p=>p.active).length}</b> مستخدم نشط</span>
        <i class="fas fa-check-circle" style="color:var(--green);margin-right:auto"></i>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="this.closest('.mo').classList.remove('open')">إلغاء</button>
      <button class="btn bp" style="background:var(--gold);border-color:var(--gold)" onclick="_doSendMonNotif(${examId})">
        <i class="fas fa-paper-plane"></i> إرسال
      </button>
    </div>
  </div>`;

  requestAnimationFrame(()=>panel.classList.add('open'));
}

async function _doSendMonNotif(examId) {
  const title = document.getElementById('mnTitle')?.value?.trim();
  const body  = document.getElementById('mnBody')?.value?.trim();
  if (!title) { toast('اكتب نص الإشعار','error'); return; }

  // ✅ إغلاق اللوحة فوراً
  const panel = document.getElementById('monNotifSendPanel');
  if (panel) panel.classList.remove('open');

  // ✅ إضافة الإشعار محلياً في شاشة المراقبة فقط — لا يُرسَل للمستخدمين
  if (!STATE.monitorNotifications) STATE.monitorNotifications = [];
  const localNotif = { title, body: body||'', exam_id: examId, created_at: new Date().toISOString() };
  STATE.monitorNotifications.push(localNotif);

  // ✅ تحديث فوري لقائمة الإشعارات في الشاشة
  const npEl = document.getElementById('monNotifPanel');
  if (npEl) npEl.innerHTML = _buildMonNotifList();

  // ✅ عرض الإشعار بملء الشاشة فوراً
  _showFullscreenAlert(title, body);

  // ✅ حذف الإشعارات عند انتهاء الامتحان (راجع _startCountdown)
  toast('✓ تم عرض الإشعار على الشاشة', 'success');
}

// ── الحضور داخل الشاشة الكاملة ──────────────────────────────
function _openAttInFullscreen(examId) {
  const ctOv = document.getElementById('ctOv');
  const e    = getExam(examId);
  if (!e) return;

  // تحميل بيانات الحضور من قاعدة البيانات أولاً ثم فتح النافذة
  (async () => {
    try {
      const { data } = await SB.getClient().from('attendance').select('*').eq('exam_id', examId);
      if (data?.length) {
        if (!STATE.attendance[examId]) STATE.attendance[examId] = {};
        data.forEach(row => { STATE.attendance[examId][row.student_id] = row.status; });
      }
    } catch(err) { console.warn('[att fetch]', err); }

    openAttendance(examId);
    requestAnimationFrame(() => {
      const mo = document.getElementById('attendanceMo');
      if (mo && ctOv && !ctOv.contains(mo)) ctOv.appendChild(mo);
    });
  })();
}

// ── إضافة وقت ───────────────────────────────────────────────
function _addTimeModal() {
  const examId = STATE._monExamId; if (!examId) return;
  const ctOv = document.getElementById('ctOv');
  const moId = 'monAddTimeMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo=document.createElement('div');mo.className='mo';mo.id=moId;(ctOv||document.body).appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:340px;text-align:center">
    <div class="md-hd"><h2><i class="fas fa-plus-circle" style="color:var(--gold)"></i> إضافة وقت</h2>
      <button class="md-close" onclick="this.closest('.mo').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="display:flex;gap:8px;justify-content:center;margin-bottom:16px;flex-wrap:wrap">
        ${[5,10,15,20,30].map(m=>`<button class="btn bo" onclick="document.getElementById('monAddTimeVal').value=${m}" style="width:52px;font-size:16px;font-weight:800">${m}</button>`).join('')}
      </div>
      <input type="number" id="monAddTimeVal" value="10" min="1" max="120"
        style="width:100%;padding:16px;text-align:center;font-size:32px;font-weight:900;border:2px solid var(--border);border-radius:12px;background:var(--bg)">
      <div style="font-size:13px;color:var(--txt2);margin-top:8px">دقائق</div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="this.closest('.mo').classList.remove('open')">إلغاء</button>
      <button class="btn bp" style="background:var(--gold);border-color:var(--gold)" onclick="_doAddTime(${examId})">
        <i class="fas fa-plus"></i> إضافة
      </button>
    </div>
  </div>`;
  requestAnimationFrame(()=>mo.classList.add('open'));
}

async function _doAddTime(examId) {
  const mins = parseInt(document.getElementById('monAddTimeVal')?.value||0);
  if (!mins||mins<1) { toast('أدخل عدد دقائق صحيح','error'); return; }
  const e = getExam(examId); if (!e) return;
  try {
    const newExtra = (e.extra_time||0)+mins;
    await dbUpdate('exams',examId,{extra_time:newExtra});
    e.extra_time = newExtra;
    document.getElementById('monAddTimeMo')?.classList.remove('open');
    _renderMonitor();
    _startCountdown(examId);
    toast(`✓ تمت إضافة ${mins} دقيقة`,'success');
    if (!STATE.monitorNotifications) STATE.monitorNotifications=[];
    STATE.monitorNotifications.push({title:`تمت إضافة ${mins} دقيقة إضافية`,body:'',exam_id:examId,created_at:new Date().toISOString()});
    const npEl = document.getElementById('monNotifPanel');
    if (npEl) npEl.innerHTML = _buildMonNotifList();
  } catch(err) { toast('خطأ: '+err.message,'error'); }
}

function _confirmEndExam(examId) {
  const ctOv = document.getElementById('ctOv');
  const moId = 'monEndMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo=document.createElement('div');mo.className='mo';mo.id=moId;(ctOv||document.body).appendChild(mo); }
  mo.innerHTML = `<div class="md" style="max-width:360px;text-align:center">
    <div class="md-bd" style="padding:36px 24px">
      <div style="font-size:48px;margin-bottom:16px">⏹️</div>
      <h3 style="font-size:18px;font-weight:900;margin-bottom:10px">إنهاء الامتحان؟</h3>
      <p style="color:var(--txt2);font-size:13.5px;margin-bottom:24px">سيتم إغلاق شاشة المراقبة وتسجيل انتهاء الامتحان</p>
      <div style="display:flex;gap:10px">
        <button class="btn bo" style="flex:1" onclick="this.closest('.mo').classList.remove('open')">إلغاء</button>
        <button class="btn bd" style="flex:1" onclick="_doEndExam(${examId})">
          <i class="fas fa-stop"></i> إنهاء
        </button>
      </div>
    </div>
  </div>`;
  requestAnimationFrame(()=>mo.classList.add('open'));
}

async function _doEndExam(examId) {
  document.getElementById('monEndMo')?.classList.remove('open');
  // إظهار عداد تنازلي لدقيقة ثم إنهاء الامتحان
  _showEndCountdown(examId);
}

function _showEndCountdown(examId) {
  // ✅ إصلاح: منع تشغيل أكثر من عداد واحد في نفس الوقت
  if (STATE._endCountdownInterval) {
    clearInterval(STATE._endCountdownInterval);
    STATE._endCountdownInterval = null;
  }
  // ✅ علامة لمنع الاستدعاء المتكرر
  if (STATE._endCountdownFired) return;

  const ctOv = document.getElementById('ctOv') || document.body;
  const moId = 'examEndCountdownMo';
  document.getElementById(moId)?.remove(); // إزالة أي عداد سابق
  const mo = document.createElement('div');
  mo.id = moId;
  mo.style.cssText = `position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.85)`;
  ctOv.appendChild(mo);

  let secs = 60;
  const update = () => {
    const m = Math.floor(secs/60), s = secs%60;
    mo.innerHTML = `
      <div style="text-align:center;color:white;padding:40px">
        <div style="font-size:100px;font-weight:900;line-height:1;color:#ef4444;font-family:monospace;
          text-shadow:0 0 40px rgba(239,68,68,.5)">
          ${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}
        </div>
        <div style="font-size:22px;font-weight:700;margin-top:20px;opacity:.9">⏹️ جارٍ إنهاء الامتحان...</div>
        <div style="font-size:14px;opacity:.6;margin-top:8px">سيتم تسجيل انتهاء الامتحان تلقائياً</div>
        <button onclick="_cancelEndCountdown('${examId}')"
          style="margin-top:24px;padding:12px 28px;background:rgba(255,255,255,.15);color:white;border:1px solid rgba(255,255,255,.3);border-radius:10px;cursor:pointer;font-size:14px">
          ⟵ إلغاء الإنهاء
        </button>
      </div>`;
  };
  update();

  STATE._endCountdownInterval = setInterval(() => {
    secs--;
    if (secs <= 0) {
      clearInterval(STATE._endCountdownInterval);
      STATE._endCountdownInterval = null;
      mo.remove();
      _finalizeEndExam(examId);
    } else { update(); }
  }, 1000);
}

function _cancelEndCountdown(examId) {
  if (STATE._endCountdownInterval) { clearInterval(STATE._endCountdownInterval); STATE._endCountdownInterval=null; }
  STATE._endCountdownFired = false;
  document.getElementById('examEndCountdownMo')?.remove();
  toast('تم إلغاء الإنهاء','info');
}

async function _finalizeEndExam(examId) {
  // ✅ إصلاح: منع الاستدعاء المزدوج تماماً
  if (STATE._endCountdownFired) return;
  STATE._endCountdownFired = true;

  // ✅ إيقاف جميع الـ intervals دفعة واحدة
  [STATE._ctInterval, STATE._endCountdownInterval, _livePageInterval, _monRefreshInterval].forEach(iv => {
    if (iv) clearInterval(iv);
  });
  STATE._ctInterval = null;
  STATE._endCountdownInterval = null;
  _livePageInterval = null;
  _monRefreshInterval = null;
  STATE._ctEndNotified = true; // منع أي toast إضافي

  // ✅ تسجيل الإنهاء محلياً فوراً قبل أي شيء آخر (يوقف examStatus من إرجاع 'active')
  const endTime = new Date().toISOString();
  const examObj = getExam(examId);
  if (examObj) examObj.end_override = endTime;

  // حفظ في قاعدة البيانات
  try {
    await dbUpdate('exams', examId, { end_override: endTime });
  } catch(err) { console.warn('[endExam] DB update failed:', err); }

  closeCT();
  // إعادة تعيين العلامة بعد الإغلاق للسماح بإنهاء امتحانات أخرى مستقبلاً
  setTimeout(() => { STATE._endCountdownFired = false; }, 2000);

  toast('✓ تم إنهاء الامتحان وتسجيل انتهائه','success');
  await addLog('إنهاء امتحان','exam', getSubject(examObj?.subject_id)?.name||'');

  // إرسال تقرير الامتحان (مرة واحدة فقط)
  if (typeof EmailService !== 'undefined') {
    try {
      const ok = await EmailService.sendExamReport(examId);
      if (ok) toast('📧 تم إرسال تقرير الامتحان بالبريد','info');
    } catch(e) {}
  }

  // تحديث الصفحة
  setTimeout(() => renderExams && renderExams(), 500);
}

// ── دالة renderMonitor الرئيسية (تُستدعى من shell) ──────────────
let _monFilterDept = '';
let _monFilterProctor = '';
let _monFilterStatus = 'all';
let _monAutoRefresh = true;
let _monRefreshInterval = null;

function renderMonitor() {
  const isAr = typeof I18N !== 'undefined' ? I18N.isAr() : true;
  const allSemExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const active   = allSemExams.filter(e => examStatus(e) === 'active');
  const upcoming = allSemExams.filter(e => examStatus(e) === 'upcoming')
    .sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));
  const completed = allSemExams.filter(e => examStatus(e) === 'completed');

  const liveEl = document.getElementById('liveContent');
  if (!liveEl) return;

  // شريط الإجراءات
  setHTML('liveActs', `
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <span style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--green);font-weight:700">
        <span style="width:8px;height:8px;border-radius:50%;background:var(--green);animation:pulse 1s infinite"></span>
        ${isAr ? 'مباشر' : 'Live'}
      </span>
      <button class="btn bo btn-sm" onclick="renderMonitor()" title="${isAr ? 'تحديث' : 'Refresh'}">
        <i class="fas fa-sync-alt"></i>
      </button>
      <button id="autoRefreshBtn" class="btn btn-sm ${_monAutoRefresh ? '' : 'bo'}" 
        style="${_monAutoRefresh ? 'background:var(--green);color:white;border-color:var(--green)' : ''}"
        onclick="toggleMonAutoRefresh()">
        <i class="fas fa-${_monAutoRefresh ? 'pause' : 'play'}"></i> ${isAr ? 'تلقائي' : 'Auto'}
      </button>
    </div>`);

  // إحصاءات الرأس — للمراقب: احسب طلاب قاعته فقط
  let totalPresent = 0, totalStudents = 0;
  active.forEach(e => {
    let studs;
    if (isProctor()) {
      const uid   = STATE.currentUser?.id;
      const rp    = e.room_proctors || {};
      const myRid = (e.room_ids||[]).find(rid => { const a = rp[String(rid)]; return a && a.includes(uid); });
      studs = myRid ? _getExamStudentsForRoom(e, myRid) : _getExamStudents(e);
    } else {
      studs = _getExamStudents(e);
    }
    const att = STATE.attendance[e.id] || {};
    totalStudents += studs.length;
    totalPresent += studs.filter(sid => att[sid] === 'present' || att[sid] === 'late').length;
  });

  liveEl.innerHTML = `
    <!-- الإحصاءات العليا -->
    <div class="stats-grid" style="margin-bottom:16px">
      <div class="stat-card">
        <div class="stat-ic ic-green"><i class="fas fa-tv"></i></div>
        <div><div class="stat-val">${active.length}</div><div class="stat-lbl">${isAr ? 'جارية الآن' : 'Active Now'}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-gold"><i class="fas fa-clock"></i></div>
        <div><div class="stat-val">${upcoming.length}</div><div class="stat-lbl">${isAr ? 'قادمة' : 'Upcoming'}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-blue"><i class="fas fa-users"></i></div>
        <div><div class="stat-val">${totalPresent}/${totalStudents}</div><div class="stat-lbl">${isAr ? 'الحضور' : 'Attendance'}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-teal"><i class="fas fa-user-check"></i></div>
        <div><div class="stat-val">${[...new Set(active.flatMap(e=>e.proctor_ids||[]))].length}</div><div class="stat-lbl">${isAr ? 'مراقبون نشطون' : 'Active Proctors'}</div></div>
      </div>
    </div>

    <!-- فلاتر متقدمة -->
    <div class="card" style="margin-bottom:14px;padding:12px 16px">
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <div style="font-size:11.5px;font-weight:700;color:var(--txt2);margin-inline-end:4px"><i class="fas fa-filter" style="color:var(--primary2)"></i> ${isAr ? 'فلترة:' : 'Filter:'}</div>
        <select id="monStatusF" onchange="_monFilterStatus=this.value;_renderMonitorContent()" 
          style="height:32px;border:1.5px solid var(--border);border-radius:7px;padding:0 8px;font-size:12px;background:var(--surface)">
          <option value="all">${isAr ? 'كل الحالات' : 'All Status'}</option>
          <option value="active">${isAr ? 'جارية فقط' : 'Active Only'}</option>
          <option value="upcoming">${isAr ? 'قادمة فقط' : 'Upcoming Only'}</option>
        </select>
        <select id="monDeptF" onchange="_monFilterDept=this.value;_renderMonitorContent()" 
          style="height:32px;border:1.5px solid var(--border);border-radius:7px;padding:0 8px;font-size:12px;background:var(--surface)">
          <option value="">${isAr ? 'كل الأقسام' : 'All Depts'}</option>
          ${STATE.departments.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}
        </select>
        <select id="monProctF" onchange="_monFilterProctor=this.value;_renderMonitorContent()"
          style="height:32px;border:1.5px solid var(--border);border-radius:7px;padding:0 8px;font-size:12px;background:var(--surface)">
          <option value="">${isAr ? 'كل المراقبين' : 'All Proctors'}</option>
          ${STATE.profiles.filter(p=>p.role==='proctor').map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}
        </select>
        <button class="btn bo btn-xs" onclick="_monFilterDept='';_monFilterProctor='';_monFilterStatus='all';document.getElementById('monDeptF').value='';document.getElementById('monProctF').value='';document.getElementById('monStatusF').value='all';_renderMonitorContent()">
          <i class="fas fa-undo"></i>
        </button>
      </div>
    </div>

    <!-- محتوى المراقبة المنظم بالأقسام -->
    <div id="monitorBody"></div>`;

  _renderMonitorContent();
  _startLivePageTimers(active);
  _startMonAutoRefresh();
}

function toggleMonAutoRefresh() {
  _monAutoRefresh = !_monAutoRefresh;
  if (!_monAutoRefresh && _monRefreshInterval) {
    clearInterval(_monRefreshInterval);
    _monRefreshInterval = null;
  } else {
    _startMonAutoRefresh();
  }
  const btn = document.getElementById('autoRefreshBtn');
  const isAr = I18N.isAr();
  if (btn) {
    btn.style.background = _monAutoRefresh ? 'var(--green)' : '';
    btn.style.color = _monAutoRefresh ? 'white' : '';
    btn.style.borderColor = _monAutoRefresh ? 'var(--green)' : '';
    btn.innerHTML = `<i class="fas fa-${_monAutoRefresh ? 'pause' : 'play'}"></i> ${isAr ? 'تلقائي' : 'Auto'}`;
  }
}

function _startMonAutoRefresh() {
  if (_monRefreshInterval) clearInterval(_monRefreshInterval);
  if (!_monAutoRefresh) return;
  _monRefreshInterval = setInterval(() => {
    if (STATE.currentPage !== 'live') { clearInterval(_monRefreshInterval); return; }
    _renderMonitorContent();
  }, 30000); // تحديث كل 30 ثانية
}

function _renderMonitorContent() {
  const el = document.getElementById('monitorBody');
  if (!el) return;
  const isAr = I18N.isAr();

  let exams = STATE.exams.filter(e => e.semester === STATE.currentSem);

  // فلتر الصلاحيات: المراقبون يرون فقط امتحاناتهم المعيّنون فيها
  const user = STATE.currentUser;
  const isProctorOnly = user?.role === 'proctor';
  const isDeptHeadOnly = user?.role === 'dept_head';
  if (isProctorOnly) {
    exams = exams.filter(e => (e.proctor_ids||[]).includes(user.id));
  } else if (isDeptHeadOnly) {
    // رئيس القسم يرى فقط امتحانات قسمه
    const deptSubjectIds = STATE.subjects.filter(s=>s.dept_id===user.dept_id).map(s=>s.id);
    exams = exams.filter(e => deptSubjectIds.includes(e.subject_id));
  }
  // المنسقون والمسؤولون يرون كل شيء

  // تطبيق الفلاتر
  if (_monFilterStatus === 'active')   exams = exams.filter(e => examStatus(e) === 'active');
  else if (_monFilterStatus === 'upcoming') exams = exams.filter(e => examStatus(e) === 'upcoming');
  else exams = exams.filter(e => ['active','upcoming'].includes(examStatus(e)));

  if (_monFilterDept) {
    const deptSubjectIds = STATE.subjects.filter(s=>s.dept_id===parseInt(_monFilterDept)).map(s=>s.id);
    exams = exams.filter(e => deptSubjectIds.includes(e.subject_id));
  }
  if (_monFilterProctor) {
    exams = exams.filter(e => (e.proctor_ids||[]).includes(_monFilterProctor));
  }

  const active   = exams.filter(e => examStatus(e) === 'active').sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`));
  const upcoming = exams.filter(e => examStatus(e) === 'upcoming').sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`));

  if (!active.length && !upcoming.length) {
    el.innerHTML = `<div style="text-align:center;padding:60px 20px;max-width:500px;margin:0 auto">
      <div style="font-size:72px;margin-bottom:16px">📺</div>
      <h2 style="font-size:22px;font-weight:900;margin-bottom:8px">${isAr ? 'لا توجد امتحانات' : 'No Exams Found'}</h2>
      <p style="color:var(--txt2)">${isAr ? 'جرب تغيير الفلاتر أو انتظر بدء الامتحانات' : 'Try changing filters or wait for exams to start'}</p>
    </div>`;
    return;
  }

  // تجميع حسب الأقسام
  const deptGroups = {};
  const getDeptForExam = (e) => {
    const sub = getSubject(e.subject_id);
    const deptId = sub?.dept_id;
    return deptId ? STATE.departments.find(d=>d.id===deptId) : null;
  };

  [...active, ...upcoming].forEach(e => {
    const dept = getDeptForExam(e);
    const key = dept ? `dept_${dept.id}` : 'no_dept';
    if (!deptGroups[key]) deptGroups[key] = { dept, exams: [] };
    deptGroups[key].exams.push(e);
  });

  let html = '';

  // الامتحانات الجارية أولاً (مجمعة بالأقسام)
  const activeDepts = Object.values(deptGroups).filter(g => g.exams.some(e=>examStatus(e)==='active'));
  if (activeDepts.length) {
    html += `<div style="font-size:11px;font-weight:800;color:var(--green);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;display:flex;align-items:center;gap:6px">
      <span style="width:8px;height:8px;border-radius:50%;background:var(--green);animation:pulse 1s infinite"></span>
      ${isAr ? 'جارية الآن' : 'ACTIVE NOW'}
    </div>`;

    activeDepts.forEach(g => {
      const activeExams = g.exams.filter(e=>examStatus(e)==='active');
      if (!activeExams.length) return;
      const dept = g.dept;
      const col = dept?.color || '#2563eb';
      html += `
      <div style="margin-bottom:20px">
        ${dept ? `<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;padding:8px 14px;background:${col}15;border-radius:10px;border-right:3px solid ${col}">
          <div style="width:8px;height:8px;border-radius:50%;background:${col}"></div>
          <span style="font-weight:800;font-size:13px;color:${col}">${dept.name}</span>
          <span class="badge" style="background:${col}20;color:${col};font-size:10px">${activeExams.length} ${isAr?'امتحان':'exam'}</span>
        </div>` : `<div style="font-size:12px;font-weight:700;color:var(--txt2);margin-bottom:8px">${isAr?'بدون قسم':'No Department'}</div>`}
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px">
          ${activeExams.map(e => _buildMonitorCard(e, isAr)).join('')}
        </div>
      </div>`;
    });
  }

  // الامتحانات القادمة
  const upcomingDepts = Object.values(deptGroups).filter(g => g.exams.some(e=>examStatus(e)==='upcoming'));
  if (upcomingDepts.length) {
    html += `<div style="font-size:11px;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;margin-top:${activeDepts.length?'24px':'0'};display:flex;align-items:center;gap:6px">
      <i class="fas fa-clock"></i>
      ${isAr ? 'قادمة قريباً' : 'UPCOMING'}
    </div>`;

    upcomingDepts.forEach(g => {
      const upcomingExams = g.exams.filter(e=>examStatus(e)==='upcoming');
      if (!upcomingExams.length) return;
      const dept = g.dept;
      const col = dept?.color || '#f59e0b';
      html += `
      <div style="margin-bottom:16px">
        ${dept ? `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:7px 12px;background:var(--bg);border-radius:8px;border-right:3px solid ${col}">
          <span style="font-weight:700;font-size:12px">${dept.name}</span>
          <span class="badge b-gold" style="font-size:9px">${upcomingExams.length}</span>
        </div>` : ''}
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:10px">
          ${upcomingExams.map(e => _buildUpcomingCard(e, isAr)).join('')}
        </div>
      </div>`;
    });
  }

  el.innerHTML = html;
}

function _buildMonitorCard(e, isAr) {
  const sub = getSubject(e.subject_id);

  // ✅ للمراقب: أظهر فقط قاعته وطلابه
  let rooms, procts, studs;
  if (isProctor()) {
    const uid    = STATE.currentUser?.id;
    const rp     = e.room_proctors || {};
    const myRid  = (e.room_ids||[]).find(rid => {
      const arr = rp[String(rid)];
      return arr && arr.includes(uid);
    });
    const room   = myRid ? getRoom(myRid) : null;
    rooms  = room ? [room.name] : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
    const proctIds = myRid ? (rp[String(myRid)]||[]) : (e.proctor_ids||[]);
    procts = proctIds.map(id=>getProfile(id)).filter(Boolean);
    studs  = myRid ? _getExamStudentsForRoom(e, myRid) : _getExamStudents(e);
  } else {
    rooms  = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
    procts = (e.proctor_ids||[]).map(id=>getProfile(id)).filter(Boolean);
    studs  = _getExamStudents(e);
  }

  const att    = STATE.attendance[e.id] || {};
  const present= studs.filter(sid=>att[sid]==='present'||att[sid]==='late').length;
  const end    = new Date(new Date(`${e.date}T${e.time}`).getTime()+(e.duration+(e.extra_time||0))*60000);
  const remMin = Math.max(0, Math.floor((end-new Date())/60000));
  const remSec = Math.max(0, Math.floor(((end-new Date())%60000)/1000));
  const pct    = Math.min(100, Math.round((1-(end-new Date())/((e.duration+(e.extra_time||0))*60000))*100));
  const isDanger = remMin < 5, isWarn = remMin < 15;
  const barColor = isDanger?'#ef4444':isWarn?'#f59e0b':'#3b82f6';
  const attPct = studs.length ? Math.round(present/studs.length*100) : 0;

  return `<div class="card" style="overflow:hidden;border-right:4px solid ${barColor}">
    <div style="padding:14px 16px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="width:8px;height:8px;border-radius:50%;background:var(--green);animation:pulse 1s infinite;flex-shrink:0"></span>
        <div style="flex:1;min-width:0">
          <div style="font-weight:800;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${sub?.name||'—'}</div>
          <div style="font-size:10.5px;color:var(--txt3)">${fmtDate(e.date)} · ${fmtTime(e.time)} · ${e.duration}${isAr?'د':'m'}</div>
        </div>
        ${getTypeBadge(e.type)}
      </div>
      <div style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--txt2);margin-bottom:4px">
          <span>${isAr?'الوقت المتبقي':'Time Left'}</span>
          <span style="color:${barColor};font-weight:800;font-size:13px" id="liveTimer_${e.id}">${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}</span>
        </div>
        <div style="background:var(--bg);border-radius:4px;height:5px;overflow:hidden">
          <div id="liveBar_${e.id}" style="width:${pct}%;height:100%;background:${barColor};border-radius:4px"></div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:10px">
        <div style="text-align:center;background:var(--green-bg);border-radius:7px;padding:6px 2px">
          <div style="font-size:18px;font-weight:900;color:var(--green)">${present}</div>
          <div style="font-size:9px;color:var(--txt3)">${isAr?'حاضر':'Present'}</div>
        </div>
        <div style="text-align:center;background:#fef2f2;border-radius:7px;padding:6px 2px">
          <div style="font-size:18px;font-weight:900;color:var(--red)">${studs.length-present}</div>
          <div style="font-size:9px;color:var(--txt3)">${isAr?'غائب':'Absent'}</div>
        </div>
        <div style="text-align:center;background:var(--bg);border-radius:7px;padding:6px 2px">
          <div style="font-size:18px;font-weight:900">${attPct}%</div>
          <div style="font-size:9px;color:var(--txt3)">${isAr?'النسبة':'Rate'}</div>
        </div>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">
        ${rooms.map(r=>`<span class="badge b-blue" style="font-size:10px"><i class="fas fa-door-open"></i> ${r}</span>`).join('')}
        ${procts.slice(0,2).map(p=>`<span class="badge b-green" style="font-size:10px"><i class="fas fa-user-check"></i> ${p.name?.split(' ')[0]}</span>`).join('')}
        ${procts.length>2?`<span class="badge b-gray" style="font-size:10px">+${procts.length-2}</span>`:''}
      </div>
      <div style="display:flex;gap:5px">
        <button class="btn btn-sm" style="flex:1;background:var(--primary);color:white;border-color:var(--primary)" onclick="openCountdown(${e.id})">
          <i class="fas fa-tv"></i> ${isAr?'شاشة حية':'Live Screen'}
        </button>
        <button class="btn bo btn-sm" onclick="openAttendance(${e.id})" title="${isAr?'تسجيل الحضور':'Attendance'}">
          <i class="fas fa-clipboard-check"></i>
        </button>
        ${isAdminOrCoord()?`<button class="btn btn-sm" style="background:var(--gold);color:white;border-color:var(--gold)" onclick="_openMonNotifPanel(${e.id})" title="${isAr?'إشعار':'Notify'}">
          <i class="fas fa-paper-plane"></i>
        </button>`:''}
      </div>
    </div>
  </div>`;
}

function _buildUpcomingCard(e, isAr) {
  const sub = getSubject(e.subject_id);

  // ✅ للمراقب: أظهر فقط قاعته
  let rooms, procts;
  if (isProctor()) {
    const uid   = STATE.currentUser?.id;
    const rp    = e.room_proctors || {};
    const myRid = (e.room_ids||[]).find(rid => {
      const arr = rp[String(rid)];
      return arr && arr.includes(uid);
    });
    const room  = myRid ? getRoom(myRid) : null;
    rooms  = room ? [room.name] : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
    const proctIds = myRid ? (rp[String(myRid)]||[]) : (e.proctor_ids||[]);
    procts = proctIds.map(id=>getProfile(id)).filter(Boolean);
  } else {
    rooms  = (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
    procts = (e.proctor_ids||[]).map(id=>getProfile(id)).filter(Boolean);
  }

  const start  = new Date(`${e.date}T${e.time}`);
  const diffMin= Math.max(0, Math.floor((start-new Date())/60000));
  const diffH  = Math.floor(diffMin/60), diffM = diffMin%60;

  return `<div class="card" style="border:1.5px solid var(--border);opacity:.9">
    <div style="padding:12px 14px;display:flex;align-items:center;gap:10px">
      <div style="width:40px;height:40px;border-radius:10px;background:var(--gold-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-clock" style="color:var(--gold);font-size:16px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${sub?.name||'—'}</div>
        <div style="font-size:11px;color:var(--txt2)">${fmtDate(e.date)} ${fmtTime(e.time)} · ${e.duration}${isAr?'د':'m'}</div>
        <div style="font-size:10.5px;color:var(--txt3);margin-top:2px">
          ${rooms.slice(0,2).map(r=>`<span class="badge b-blue" style="font-size:9px">${r}</span>`).join(' ')}
          ${procts.slice(0,2).map(p=>`<span class="badge b-gray" style="font-size:9px">${p.name?.split(' ')[0]}</span>`).join(' ')}
        </div>
      </div>
      <div style="text-align:center;flex-shrink:0">
        <span class="badge b-gold">${diffH>0?`${diffH}h${diffM}m`:`${diffMin}m`}</span>
        <div style="margin-top:4px">
          <button class="btn btn-xs" style="background:var(--primary);color:white;border-color:var(--primary)" onclick="openCountdown(${e.id})">
            <i class="fas fa-tv"></i>
          </button>
        </div>
      </div>
    </div>
  </div>`;
}



let _livePageInterval = null;
function _startLivePageTimers(exams) {
  if (_livePageInterval) clearInterval(_livePageInterval);
  _livePageInterval = setInterval(() => {
    if (STATE.currentPage !== 'live') { clearInterval(_livePageInterval); return; }
    exams.forEach(e => {
      const end    = new Date(new Date(`${e.date}T${e.time}`).getTime() + (e.duration + (e.extra_time || 0)) * 60000);
      const remMs  = Math.max(0, end - new Date());
      const remMin = Math.floor(remMs / 60000);
      const remSec = Math.floor((remMs % 60000) / 1000);
      const pct    = Math.min(100, Math.round((1 - remMs / ((e.duration + (e.extra_time || 0)) * 60000)) * 100));
      const isDanger  = remMin < 5;
      const isWarning = remMin < 15;
      const barColor  = isDanger ? '#ef4444' : isWarning ? '#f59e0b' : '#3b82f6';
      const tEl = document.getElementById(`liveTimer_${e.id}`);
      const bEl = document.getElementById(`liveBar_${e.id}`);
      if (tEl) { tEl.textContent = `${String(remMin).padStart(2,'0')}:${String(remSec).padStart(2,'0')}`; tEl.style.color = barColor; }
      if (bEl) { bEl.style.width = pct + '%'; bEl.style.background = barColor; }
    });
  }, 1000);
}
function _getExamStudents(exam) {
  const sids = new Set();
  (exam.section_ids||[]).forEach(secId=>{
    const sec=getSection(secId);
    (sec?.student_ids||[]).forEach(id=>sids.add(id));
  });
  return [...sids];
}

// ✅ جلب طلاب قاعة بعينها عبر room_sections
function _getExamStudentsForRoom(exam, roomId) {
  if (!roomId) return _getExamStudents(exam);
  const rs = exam.room_sections || {};
  const secIds = rs[String(roomId)] || [];
  if (!secIds.length) return [];
  const sids = new Set();
  secIds.forEach(secId => {
    const sec = getSection(secId);
    (sec?.student_ids||[]).forEach(id => sids.add(id));
  });
  return [...sids];
}

// ── إشعار ملء الشاشة ─────────────────────────────────────────
function _showFullscreenAlert(title, body) {
  // إزالة أي إشعار سابق
  document.getElementById('fsAlertOverlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'fsAlertOverlay';
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:99999;
    display:flex;align-items:center;justify-content:center;
    background:rgba(0,0,0,0);backdrop-filter:blur(0px);
    transition:all .4s;pointer-events:all
  `;

  overlay.innerHTML = `
    <div id="fsAlertBox" style="
      background:linear-gradient(135deg,#1e3a5f,#1e40af);
      color:white;text-align:center;padding:60px 80px;
      border-radius:28px;max-width:700px;width:90%;
      transform:scale(.6);opacity:0;transition:all .4s cubic-bezier(.34,1.56,.64,1);
      box-shadow:0 40px 100px rgba(0,0,0,.6);
      border:2px solid rgba(255,255,255,.15)
    ">
      <div style="font-size:64px;margin-bottom:24px;animation:pulseEmoji 1s infinite">📢</div>
      <div style="font-size:32px;font-weight:900;margin-bottom:16px;letter-spacing:-.5px">${title}</div>
      ${body ? `<div style="font-size:18px;opacity:.85;margin-bottom:28px;max-width:480px;margin-inline:auto;line-height:1.6">${body}</div>` : ''}
      <div style="font-size:13px;opacity:.55;margin-bottom:28px">${new Date().toLocaleTimeString('ar-SA')}</div>
      <button onclick="document.getElementById('fsAlertOverlay')?.remove()"
        style="padding:14px 40px;background:rgba(255,255,255,.18);color:white;
          border:1.5px solid rgba(255,255,255,.35);border-radius:12px;
          cursor:pointer;font-size:16px;font-weight:700;transition:all .2s"
        onmouseover="this.style.background='rgba(255,255,255,.28)'"
        onmouseout="this.style.background='rgba(255,255,255,.18)'">
        ✓ تم الاستلام
      </button>
    </div>`;

  // Try to append inside the fullscreen monitor overlay first
  const ctOv = document.getElementById('ctOv');
  (ctOv || document.body).appendChild(overlay);

  // Animate in
  requestAnimationFrame(() => {
    overlay.style.background = 'rgba(0,0,0,.75)';
    overlay.style.backdropFilter = 'blur(8px)';
    const box = document.getElementById('fsAlertBox');
    if (box) { box.style.transform='scale(1)'; box.style.opacity='1'; }
  });

  // صوت تنبيهي
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    [880, 660, 880].forEach((freq, i) => {
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.connect(gain); gain.connect(ac.destination);
      osc.frequency.value = freq;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.3, ac.currentTime + i * 0.25);
      gain.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + i * 0.25 + 0.3);
      osc.start(ac.currentTime + i * 0.25);
      osc.stop(ac.currentTime + i * 0.25 + 0.35);
    });
  } catch(e) {}

  // عداد تنازلي 15 ثانية مع شريط تقدم
  const countdownEl = document.createElement('div');
  countdownEl.style.cssText = 'margin-top:20px;font-size:13px;opacity:.7;display:flex;align-items:center;gap:10px;justify-content:center;flex-direction:column';
  const barWrap = document.createElement('div');
  barWrap.style.cssText = 'width:200px;height:4px;background:rgba(255,255,255,.2);border-radius:4px;overflow:hidden';
  const bar = document.createElement('div');
  bar.style.cssText = 'height:100%;width:100%;background:#34d399;border-radius:4px;transition:width 1s linear';
  barWrap.appendChild(bar);
  countdownEl.innerHTML = '<span id="fsCountdownTxt">يختفي بعد <b>15</b> ثانية</span>';
  countdownEl.appendChild(barWrap);
  const box = document.getElementById('fsAlertBox');
  if (box) box.appendChild(countdownEl);

  let remaining = 15;
  const _cti = setInterval(() => {
    remaining--;
    const txt = document.getElementById('fsCountdownTxt');
    if (txt) txt.innerHTML = 'يختفي بعد <b>' + remaining + '</b> ثانية';
    bar.style.width = (remaining / 15 * 100) + '%';
    if (remaining <= 0) {
      clearInterval(_cti);
      overlay.style.opacity='0';
      setTimeout(()=>overlay.remove(), 400);
    }
  }, 1000);

  // إغلاق يدوي يلغي العداد
  const closeBtn = overlay.querySelector('button');
  if (closeBtn) {
    const origClick = closeBtn.onclick;
    closeBtn.onclick = () => { clearInterval(_cti); if(origClick) origClick(); overlay.remove(); };
  }

  // أخفِ بعد 15 ثانية كحد أقصى
  setTimeout(() => {
    clearInterval(_cti);
    overlay.style.opacity='0';
    setTimeout(()=>overlay.remove(), 400);
  }, 15000);
}
