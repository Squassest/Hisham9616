// students.js v14 — إدارة الطلاب (كلمة المرور SHA-256 + مقررات + شعب)

let _studTab = 'all';
function setStudTab(tab, el) {
  _studTab = tab;
  document.querySelectorAll('#studTabs .tab').forEach(t => t.classList.remove('active'));
  el?.classList.add('active');
  renderStudents();
}

function renderStudents() {
  const isAr = I18N.isAr();
  if (!canEdit() && !isProctor()) {
    setHTML('studentsContent', emptyState('fa-lock', isAr ? 'غير مصرح' : 'Unauthorized'));
    return;
  }

  // المراقب: عرض طلابهم فقط — بدون أزرار إدارة
  if (isProctor() && !canEdit()) {
    _renderProctorStudentsView();
    return;
  }

  setHTML('studentsActs', `
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn bp btn-sm" onclick="openAddStudent()">
        <i class="fas fa-user-plus"></i> ${isAr ? 'طالب جديد' : 'New Student'}
      </button>
      <button class="btn bo btn-sm" onclick="openImportStudents()">
        <i class="fas fa-file-import"></i> ${isAr ? 'استيراد' : 'Import'}
      </button>
      <button class="btn bo btn-sm" onclick="exportStudentsCSV()">
        <i class="fas fa-file-csv"></i> ${isAr ? 'تصدير CSV' : 'Export CSV'}
      </button>
    </div>`);

  // رئيس القسم يرى فقط طلاب موادهم
  let allStudents = STATE.students;
  if (isDeptHead()) {
    const mySubjIds = STATE.subjects.filter(s=>s.dept_id===STATE.currentUser?.dept_id).map(s=>s.id);
    const mySectionIds = STATE.sections.filter(s=>mySubjIds.includes(s.subject_id)).map(s=>s.id);
    allStudents = allStudents.filter(s=>(s.subject_ids||[]).some(id=>mySubjIds.includes(id))||(s.section_ids||[]).some(id=>mySectionIds.includes(id)));
  }
  // المراقب يرى طلاب موادهم وشعبهم التي يراقب فيها
  if (isProctor()) {
    const mySections = getProctorScopeSections();
    const secIds = new Set(mySections.map(s => s.id));
    const directStudIds = new Set(mySections.flatMap(sec => sec.student_ids || []));
    allStudents = allStudents.filter(s =>
      directStudIds.has(s.id) ||
      (s.section_ids || []).some(id => secIds.has(id))
    );
  }
  const batches = [...new Set(allStudents.map(s=>s.batch).filter(Boolean))].sort((a,b)=>b-a);
  const sections = STATE.sections || [];
  const subjects = STATE.subjects || [];

  setHTML('studentsContent', `
    <div class="stats-grid" style="margin-bottom:18px">
      <div class="stat-card">
        <div class="stat-ic ic-teal"><i class="fas fa-user-graduate"></i></div>
        <div><div class="stat-val">${allStudents.length}</div><div class="stat-lbl">${isAr ? 'إجمالي الطلاب' : 'Total Students'}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-green"><i class="fas fa-check-circle"></i></div>
        <div><div class="stat-val">${allStudents.filter(s=>s.active&&!s.banned).length}</div><div class="stat-lbl">${isAr ? 'نشطون' : 'Active'}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-gold"><i class="fas fa-graduation-cap"></i></div>
        <div><div class="stat-val">${batches.length}</div><div class="stat-lbl">${isAr ? 'دفعات' : 'Batches'}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-red"><i class="fas fa-ban"></i></div>
        <div><div class="stat-val">${allStudents.filter(s=>s.banned).length}</div><div class="stat-lbl">${isAr ? 'موقوفون' : 'Banned'}</div></div>
      </div>
    </div>

    <div class="card">
      <div style="padding:14px 18px;border-bottom:1px solid var(--border)">
        <div style="font-weight:800;font-size:13px;margin-bottom:10px;display:flex;align-items:center;gap:8px">
          <i class="fas fa-search-plus" style="color:var(--teal)"></i>
          ${isAr ? 'بحث ذكي متقدم' : 'Advanced Smart Search'}
        </div>
        <!-- مقترحات سريعة -->
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">
          <button class="btn bo btn-xs" onclick="applyStudentFilter('active')" style="border-color:var(--green);color:var(--green)">
            <i class="fas fa-check"></i> ${isAr ? 'نشطون' : 'Active'}
          </button>
          <button class="btn bo btn-xs" onclick="applyStudentFilter('banned')" style="border-color:var(--red);color:var(--red)">
            <i class="fas fa-ban"></i> ${isAr ? 'موقوفون' : 'Banned'}
          </button>
          <button class="btn bo btn-xs" onclick="applyStudentFilter('no_sections')" style="border-color:var(--gold);color:var(--gold)">
            <i class="fas fa-exclamation"></i> ${isAr ? 'بدون شعبة' : 'No Section'}
          </button>
          <button class="btn bo btn-xs" onclick="applyStudentFilter('no_subjects')" style="border-color:var(--purple);color:var(--purple)">
            <i class="fas fa-book-open"></i> ${isAr ? 'بدون مواد' : 'No Subjects'}
          </button>
          <button class="btn bo btn-xs" onclick="applyStudentFilter('reset')">
            <i class="fas fa-undo"></i> ${isAr ? 'إعادة' : 'Reset'}
          </button>
        </div>
        <!-- حقول البحث المتقدم -->
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px">
          <div class="sbar" style="grid-column:span 2">
            <i class="fas fa-search"></i>
            <input type="text" id="studSrch" placeholder="${isAr ? 'اسم أو رقم أو بريد...' : 'Name, ID, or email...'}"
              oninput="filterStudents()" value="">
          </div>
          <div>
            <select id="studBatchF" onchange="filterStudents()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;width:100%;background:var(--surface)">
              <option value="">${isAr ? 'كل الدفعات' : 'All Batches'}</option>
              ${batches.map(b=>`<option value="${b}">${b}</option>`).join('')}
            </select>
          </div>
          <div>
            <select id="studSectionF" onchange="filterStudents()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;width:100%;background:var(--surface)">
              <option value="">${isAr ? 'كل الشعب' : 'All Sections'}</option>
              ${sections.filter(s=>s.semester===STATE.currentSem).map(s=>{
                const sub=getSubject(s.subject_id);
                return `<option value="${s.id}">${sub?.code||'?'} · ${s.name}</option>`;
              }).join('')}
            </select>
          </div>
          <div>
            <select id="studSubjF" onchange="filterStudents()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;width:100%;background:var(--surface)">
              <option value="">${isAr ? 'كل المواد' : 'All Subjects'}</option>
              ${subjects.map(s=>`<option value="${s.id}">${s.code} · ${s.name}</option>`).join('')}
            </select>
          </div>
          <div>
            <select id="studStatusF" onchange="filterStudents()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;width:100%;background:var(--surface)">
              <option value="">${isAr ? 'كل الحالات' : 'All Status'}</option>
              <option value="active">${isAr ? 'نشط' : 'Active'}</option>
              <option value="banned">${isAr ? 'موقوف' : 'Banned'}</option>
              <option value="inactive">${isAr ? 'غير نشط' : 'Inactive'}</option>
            </select>
          </div>
          <div>
            <select id="studDeptF" onchange="filterStudents()" style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;width:100%;background:var(--surface)">
              <option value="">${isAr ? 'كل الأقسام' : 'All Depts'}</option>
              ${STATE.departments.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}
            </select>
          </div>
        </div>
      </div>
      <div id="studList" style="max-height:600px;overflow-y:auto"></div>
      <div id="studFooter" style="padding:12px 20px;border-top:1px solid var(--border);font-size:12px;color:var(--txt3)">
        ${isAr ? `إجمالي: ${allStudents.length} طالب` : `Total: ${allStudents.length} students`}
      </div>
    </div>`);

  filterStudents();
}

function applyStudentFilter(type) {
  const isAr = I18N.isAr();
  let allStudents = STATE.students;
  let filtered = [];
  let msg = '';
  switch(type) {
    case 'active':
      document.getElementById('studStatusF') && (document.getElementById('studStatusF').value='active');
      filtered = allStudents.filter(s=>s.active&&!s.banned); msg=isAr?'نشطون':'Active'; break;
    case 'banned':
      document.getElementById('studStatusF') && (document.getElementById('studStatusF').value='banned');
      filtered = allStudents.filter(s=>s.banned); msg=isAr?'موقوفون':'Banned'; break;
    case 'no_sections':
      filtered = allStudents.filter(s=>!(s.section_ids||[]).length); msg=isAr?'بدون شعبة':'No section'; break;
    case 'no_subjects':
      filtered = allStudents.filter(s=>!(s.subject_ids||[]).length); msg=isAr?'بدون مواد':'No subjects'; break;
    case 'reset':
      ['studSrch','studBatchF','studSectionF','studSubjF','studStatusF','studDeptF'].forEach(id=>{
        const el=document.getElementById(id); if(el) { el.value=''; }
      });
      filtered = allStudents; msg=isAr?'تم إعادة التعيين':'Reset'; break;
  }
  _renderStudentList(filtered);
  toast(`✓ ${msg} · ${filtered.length} ${isAr?'طالب':'students'}`, 'success');
}

function filterStudents() {
  const q       = (document.getElementById('studSrch')?.value||'').toLowerCase();
  const batch   = document.getElementById('studBatchF')?.value||'';
  const secId   = document.getElementById('studSectionF')?.value||'';
  const subjId  = document.getElementById('studSubjF')?.value||'';
  const status  = document.getElementById('studStatusF')?.value||'';
  const deptId  = document.getElementById('studDeptF')?.value||'';

  // الحد المسموح به حسب الدور
  let _baseStudents = STATE.students;
  if (isDeptHead()) {
    const mySubjIds = STATE.subjects.filter(s=>s.dept_id===STATE.currentUser?.dept_id).map(s=>s.id);
    const mySecIds = STATE.sections.filter(s=>mySubjIds.includes(s.subject_id)).map(s=>s.id);
    _baseStudents = _baseStudents.filter(s=>(s.subject_ids||[]).some(id=>mySubjIds.includes(id))||(s.section_ids||[]).some(id=>mySecIds.includes(id)));
  } else if (isProctor()) {
    // المراقب يرى فقط طلاب الشعب التي يُدرِّسها (staff_ids) — لا طلاب المواد التي راقب فيها فقط
    const myScStudents = getProctorScopeStudents();
    const myStudIds = new Set(myScStudents.map(s => s.id));
    _baseStudents = _baseStudents.filter(s => myStudIds.has(s.id));
  }
  let f = _baseStudents;
  if (q)      f = f.filter(s => s.name?.toLowerCase().includes(q) || s.stud_id?.includes(q) || s.email?.toLowerCase().includes(q));
  if (batch)  f = f.filter(s => String(s.batch) === batch);
  if (secId)  f = f.filter(s => (s.section_ids||[]).includes(parseInt(secId)));
  if (subjId) f = f.filter(s => (s.subject_ids||[]).includes(parseInt(subjId)));
  if (status === 'active')   f = f.filter(s =>  s.active && !s.banned);
  if (status === 'banned')   f = f.filter(s =>  s.banned);
  if (status === 'inactive') f = f.filter(s => !s.active && !s.banned);
  if (deptId) {
    // الطلاب في قسم معين عبر الشعب والمواد
    const deptSubjIds = STATE.subjects.filter(s=>s.dept_id===parseInt(deptId)).map(s=>s.id);
    f = f.filter(s => (s.subject_ids||[]).some(id=>deptSubjIds.includes(id)));
  }

  _renderStudentList(f);
  const foot = document.getElementById('studFooter');
  const isAr = I18N.isAr();
  if (foot) foot.textContent = isAr ? `عرض: ${f.length} من ${STATE.students.length} طالب` : `Showing: ${f.length} of ${STATE.students.length} students`;
}

function _renderStudentList(filtered) {
  const el = document.getElementById('studList');
  const isAr = I18N.isAr();
  if (!el) return;
  if (!filtered.length) { el.innerHTML = emptyState('fa-user-graduate', isAr ? 'لا يوجد طلاب مطابقون' : 'No students found'); return; }

  el.innerHTML = filtered.map(s => {
    const sects = (s.section_ids||[]).map(id => STATE.sections?.find(sec=>sec.id===id)).filter(Boolean);
    const secNames = sects.slice(0,2).map(sec => { const sub=getSubject(sec.subject_id); return sub?.code||''; }).filter(Boolean);
    return `<div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--border);transition:background .15s" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
      <div style="width:40px;height:40px;border-radius:10px;background:var(--teal);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:900;color:white;flex-shrink:0">
        ${getInitials(s.name)}
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13.5px">${s.name}</div>
        <div style="font-size:11.5px;color:var(--txt2)">${s.stud_id||'—'} · ${isAr?'دفعة':'Batch'} ${s.batch||'—'}</div>
        ${s.email?`<div style="font-size:11px;color:var(--txt3)">${s.email}</div>`:''}
        ${secNames.length ? `<div style="display:flex;gap:4px;margin-top:4px">${secNames.map(c=>`<span class="badge b-teal" style="font-size:9px">${c}</span>`).join('')}${sects.length>2?`<span class="badge b-gray" style="font-size:9px">+${sects.length-2}</span>`:''}</div>` : ''}
      </div>
      <div style="display:flex;align-items:center;gap:5px;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end">
        ${_studentSubjectsBadges(s)}
        <span class="badge ${s.active&&!s.banned?'b-green':s.banned?'b-red':'b-gray'}" style="font-size:10px">${s.active&&!s.banned?(isAr?'نشط':'Active'):s.banned?(isAr?'موقوف':'Banned'):(isAr?'غير نشط':'Inactive')}</span>
        <button class="btn bo btn-xs" onclick="openEditStudent(${s.id})" title="${isAr?'تعديل':'Edit'}"><i class="fas fa-edit"></i></button>
        <button class="btn bo btn-xs" onclick="openStudentSubjects(${s.id})" title="${isAr?'المقررات':'Subjects'}"><i class="fas fa-book"></i></button>
        <button class="btn bo btn-xs" onclick="openStudentSections(${s.id})" title="${isAr?'الشعب':'Sections'}"><i class="fas fa-layer-group"></i></button>
        <button class="btn bo btn-xs" onclick="openStudentLogin(${s.id})" title="${isAr?'كلمة المرور':'Password'}"><i class="fas fa-key"></i></button>
        <button class="btn ${s.banned?'bs':'bd'} btn-xs" onclick="toggleStudentBan(${s.id})">
          <i class="fas fa-${s.banned?'check':'ban'}"></i>
        </button>
        ${isAdmin()?`<button class="btn bd btn-xs" onclick="deleteStudent(${s.id})"><i class="fas fa-trash"></i></button>`:''}
      </div>
    </div>`;
  }).join('');
}

function exportStudentsCSV() {
  const isAr = I18N.isAr();
  let students = STATE.students;
  const rows = [['الاسم','الرقم الجامعي','البريد','الدفعة','الحالة','عدد المواد','عدد الشعب']];
  students.forEach(s => {
    rows.push([s.name,s.stud_id||'',s.email||'',s.batch||'',(s.active&&!s.banned)?'نشط':s.banned?'موقوف':'غير نشط',(s.subject_ids||[]).length,(s.section_ids||[]).length]);
  });
  const csv = rows.map(r=>r.map(v=>`"${v}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});
  const a = Object.assign(document.createElement('a'),{href:URL.createObjectURL(blob),download:'students.csv'});
  document.body.appendChild(a);a.click();a.remove();
  toast(isAr?'✓ تم تصدير بيانات الطلاب':'✓ Students exported','success');
}

function _studentSubjectsBadges(s) {
  const subIds = s.subject_ids || [];
  if (!subIds.length) return '';
  const names = subIds.slice(0,2).map(id => getSubject(id)?.code || '').filter(Boolean);
  const more  = subIds.length > 2 ? `+${subIds.length-2}` : '';
  return `<span style="font-size:10.5px;color:var(--txt3)">${names.join('، ')}${more?` ${more}`:''}</span>`;
}

// ── إضافة طالب مع كلمة مرور للدخول ───────────────────────
function openAddStudent() {
  const mo = _getMo('addStudMo');
  mo.innerHTML = `<div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2>
        <div style="width:34px;height:34px;border-radius:10px;background:var(--teal)20;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-user-graduate" style="color:var(--teal)"></i>
        </div>
        إضافة طالب جديد
      </h2>
      <button class="md-close" onclick="closeMo('addStudMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <!-- معلومات أساسية -->
      <div style="background:var(--bg);border-radius:12px;padding:16px;margin-bottom:14px">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">
          <i class="fas fa-id-card" style="margin-left:5px;color:var(--teal)"></i>البيانات الأساسية
        </div>
        <div class="g2">
          <div class="field" style="grid-column:1/-1">
            <label class="field-lbl">الاسم الكامل <span class="req">*</span></label>
            <input type="text" id="snName" placeholder="محمد أحمد العامري" style="height:44px">
          </div>
          <div class="field">
            <label class="field-lbl">الرقم الجامعي <span class="req">*</span></label>
            <input type="text" id="snStudId" placeholder="SQU00000" style="height:44px">
          </div>
          <div class="field">
            <label class="field-lbl">دفعة القبول</label>
            <input type="number" id="snBatch" value="${new Date().getFullYear()}" style="height:44px">
          </div>
        </div>
      </div>

      <!-- بيانات تسجيل الدخول -->
      <div style="background:var(--bg);border-radius:12px;padding:16px">
        <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">
          <i class="fas fa-key" style="margin-left:5px;color:var(--primary2)"></i>بيانات تسجيل الدخول
        </div>
        <div style="padding:10px 14px;background:var(--primary)08;border:1px solid var(--primary)20;border-radius:9px;margin-bottom:12px;font-size:12.5px">
          <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
          البريد الإلكتروني يجب أن ينتهي بـ <b>@student.squ.edu.om</b>
        </div>
        <div class="field">
          <label class="field-lbl">البريد الإلكتروني <span class="req">*</span></label>
          <input type="email" id="snEmail" placeholder="s123456@student.squ.edu.om" style="height:44px"
            oninput="this.style.borderColor=this.value.endsWith('@student.squ.edu.om')?'var(--green)':this.value.length>5?'var(--red)':'var(--border)'">
          <div id="snEmailHint" style="font-size:11.5px;margin-top:4px;color:var(--txt3)"></div>
        </div>
        <div class="field">
          <label class="field-lbl">كلمة المرور <span class="req">*</span></label>
          <div class="pass-wrap">
            <input type="password" id="snPass" placeholder="••••••••" style="height:44px"
              oninput="checkPassStrength(document.getElementById('snPass'),'snPassStr','snPassLbl')">
            <i class="fas fa-eye pass-eye" onclick="togglePassEye('snPass',this)"></i>
          </div>
          <div class="pass-strength">
            <div class="pass-bar"><div class="pass-bar-fill" id="snPassStr"></div></div>
            <div class="pass-lbl" id="snPassLbl"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('addStudMo')">إلغاء</button>
      <button class="btn bp" onclick="saveStudent()" id="saveStudBtn" style="min-width:140px">
        <i class="fas fa-user-plus"></i> إضافة الطالب
      </button>
    </div>
  </div>`;
  showMo('addStudMo');
}

async function saveStudent() {
  const name   = document.getElementById('snName')?.value?.trim();
  const studId = document.getElementById('snStudId')?.value?.trim();
  const email  = document.getElementById('snEmail')?.value?.trim().toLowerCase();
  const batch  = parseInt(document.getElementById('snBatch')?.value) || new Date().getFullYear();
  const phone  = document.getElementById('snPhone')?.value?.trim() || '';
  // ✅ إصلاح: قراءة كلمة المرور من الحقل
  const pass   = document.getElementById('snPass')?.value?.trim() || '';

  if (!name || !studId) { toast('الاسم والرقم الجامعي مطلوبان','error'); return; }

  // التحقق من الإيميل
  if (!email) { toast('البريد الإلكتروني مطلوب','error'); return; }
  if (!email.endsWith('@student.squ.edu.om')) {
    toast('البريد يجب أن ينتهي بـ @student.squ.edu.om','error');
    document.getElementById('snEmail').style.borderColor='var(--red)';
    return;
  }

  // التحقق من كلمة المرور
  if (!pass) { toast('كلمة المرور مطلوبة','error'); document.getElementById('snPass')?.focus(); return; }
  if (pass.length < 6) { toast('كلمة المرور يجب أن تكون 6 أحرف على الأقل','error'); return; }

  // التحقق من التكرار
  const existEmail = STATE.students.find(s=>s.email===email);
  const existId    = STATE.students.find(s=>s.stud_id===studId);
  if (existEmail) { toast(`البريد "${email}" مستخدم مسبقاً`,'error'); return; }
  if (existId)    { toast(`الرقم الجامعي "${studId}" مسجّل مسبقاً`,'error'); return; }

  const btn = document.getElementById('saveStudBtn');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> جارٍ الإنشاء...'; }

  try {
    // تشفير كلمة المرور قبل الحفظ
    const passHash = await AUTH.hashPassword(pass);
    await dbInsert('students', {
      stud_id: studId, name, batch, email,
      phone: phone || '', active: true, banned: false,
      subject_ids: [], section_ids: [],
      password: passHash
    });

    closeMo('addStudMo');
    renderStudents();
    toast(`✓ تمت إضافة الطالب "${name}"`, 'success');
    await addLog('إضافة طالب','student', name);
  } catch (e) {
    toast('خطأ: '+e.message,'error');
    if (btn) { btn.disabled=false; btn.innerHTML='<i class="fas fa-user-plus"></i> إضافة الطالب'; }
  }
}

// ── تعديل طالب ────────────────────────────────────────────
function openEditStudent(id) {
  const s = getStudent(id); if (!s) return;
  const mo = _getMo('editStudMo');
  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-user-edit" style="color:var(--gold)"></i> تعديل: ${s.name}</h2>
      <button class="md-close" onclick="closeMo('editStudMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="g2">
        <div class="field"><label class="field-lbl">الاسم</label><input type="text" id="esName" value="${esc(s.name)}"></div>
        <div class="field"><label class="field-lbl">الرقم الجامعي</label><input type="text" id="esStudId" value="${esc(s.stud_id||'')}"></div>
        <div class="field"><label class="field-lbl">البريد</label><input type="email" id="esEmail" value="${esc(s.email||'')}"></div>
        <div class="field"><label class="field-lbl">الدفعة</label><input type="number" id="esBatch" value="${s.batch||''}"></div>
      </div>
      <div style="display:flex;align-items:center;gap:10px;margin-top:8px">
        <label class="toggle"><input type="checkbox" id="esActive" ${s.active?'checked':''}><span class="toggle-sl"></span></label>
        <span style="font-size:13px;font-weight:600">الحساب نشط</span>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('editStudMo')">إلغاء</button>
      <button class="btn bp" onclick="saveEditStudent(${id})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('editStudMo');
}

async function saveEditStudent(id) {
  const name   = document.getElementById('esName')?.value?.trim();
  const studId = document.getElementById('esStudId')?.value?.trim();
  const email  = document.getElementById('esEmail')?.value?.trim();
  const batch  = parseInt(document.getElementById('esBatch')?.value);
  const active = document.getElementById('esActive')?.checked;
  if (!name || !studId) { toast('الاسم والرقم مطلوبان','error'); return; }
  try {
    await dbUpdate('students', id, { name, stud_id:studId, email:email||'', batch, active });
    closeMo('editStudMo'); renderStudents();
    toast('✓ تم التعديل','success');
  } catch (e) { toast('خطأ: '+e.message,'error'); }
}

// ── إدارة مقررات الطالب (مع الشعب تحت كل مادة) ────────────────
function openStudentSubjects(id) {
  const s = getStudent(id); if (!s) return;
  const currentSubjIds = s.subject_ids || [];
  const currentSecIds  = (STATE.sections || [])
    .filter(sec => (sec.student_ids||[]).includes(id)).map(sec => sec.id);

  const mo = _getMo('studSubjMo');
  mo.innerHTML = `<div class="md" style="max-width:600px">
    <div class="md-hd">
      <h2><i class="fas fa-book" style="color:var(--gold)"></i> مقررات وشعب: ${s.name}</h2>
      <button class="md-close" onclick="closeMo('studSubjMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="max-height:65vh;overflow-y:auto">
      <div style="padding:10px 14px;background:var(--primary-bg);border:1.5px solid var(--primary)20;border-radius:10px;margin-bottom:16px;font-size:12.5px">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        فعّل المادة أولاً ثم اختر الشعبة المناسبة من القائمة التي ستظهر تحتها
      </div>
      <div id="subjSecList" style="display:flex;flex-direction:column;gap:10px">
        ${STATE.subjects.map(sub => {
          const semSecs = (STATE.sections||[]).filter(sec =>
            sec.subject_id === sub.id && sec.semester === STATE.currentSem
          );
          const isChecked = currentSubjIds.includes(sub.id);
          return `<div class="subj-sec-block" id="subjBlock_${sub.id}"
            style="border:1.5px solid ${isChecked?'var(--primary)':'var(--border)'};border-radius:12px;overflow:hidden;transition:border-color .2s">
            <!-- رأس المادة -->
            <label style="display:flex;align-items:center;gap:10px;padding:12px 16px;cursor:pointer;background:${isChecked?'var(--primary-bg)':'var(--surface)'};transition:background .2s">
              <input type="checkbox" id="ssj_${sub.id}" ${isChecked?'checked':''}
                style="accent-color:var(--primary);width:16px;height:16px;flex-shrink:0"
                onchange="_toggleSubjBlock(${sub.id},${id})">
              <div style="flex:1;min-width:0">
                <div style="font-weight:700;font-size:13px">${sub.name}</div>
                <div style="font-size:11px;color:var(--txt3)">${sub.code}${semSecs.length?` · ${semSecs.length} شعبة في الفصل الحالي`:' · لا توجد شعب في الفصل الحالي'}</div>
              </div>
              <span class="badge ${isChecked?'b-blue':'b-gray'}" id="subjBadge_${sub.id}" style="font-size:10px">${isChecked?'مفعّلة':'معطّلة'}</span>
            </label>
            <!-- قائمة الشعب (تظهر فقط إذا المادة مفعّلة) -->
            <div id="secsOf_${sub.id}"
              style="display:${isChecked&&semSecs.length?'block':'none'};border-top:1px solid var(--border);padding:10px 16px;background:var(--bg)">
              <div style="font-size:11.5px;color:var(--txt2);margin-bottom:8px;font-weight:600">
                <i class="fas fa-layer-group" style="margin-left:4px;color:var(--purple2)"></i>اختر الشعبة:
              </div>
              <div style="display:flex;flex-wrap:wrap;gap:7px">
                ${semSecs.length ? semSecs.map(sec => {
                  const inSec = currentSecIds.includes(sec.id);
                  return `<label id="secLbl_${sec.id}" style="display:flex;align-items:center;gap:6px;padding:7px 14px;border:1.5px solid ${inSec?'var(--primary)':'var(--border)'};background:${inSec?'var(--primary-bg)':''};border-radius:8px;cursor:pointer;font-size:12.5px;transition:all .18s">
                    <input type="checkbox" id="sss_${sec.id}" ${inSec?'checked':''}
                      style="accent-color:var(--primary);width:14px;height:14px"
                      onchange="this.closest('label').style.borderColor=this.checked?'var(--primary)':'var(--border)';this.closest('label').style.background=this.checked?'var(--primary-bg)':''">
                    <i class="fas fa-users" style="font-size:10px;color:var(--purple2)"></i>
                    ${sec.name}
                    <span style="font-size:10px;color:var(--txt3)">(${(sec.student_ids||[]).length})</span>
                  </label>`;
                }).join('') : `<span style="font-size:12px;color:var(--txt3)">لا توجد شعب في الفصل الحالي</span>`}
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('studSubjMo')">إلغاء</button>
      <button class="btn bp" onclick="saveStudentSubjectsAndSections(${id})">
        <i class="fas fa-save"></i> حفظ المقررات والشعب
      </button>
    </div>
  </div>`;
  showMo('studSubjMo');
}

// ── تبديل ظهور شعب المادة عند تفعيلها/تعطيلها ──────────────
function _toggleSubjBlock(subId, studentId) {
  const cb    = document.getElementById(`ssj_${subId}`);
  const block = document.getElementById(`subjBlock_${subId}`);
  const badge = document.getElementById(`subjBadge_${subId}`);
  const secsDiv = document.getElementById(`secsOf_${subId}`);
  const label = cb?.closest('label');
  const checked = cb?.checked;

  if (block) block.style.borderColor = checked ? 'var(--primary)' : 'var(--border)';
  if (label) label.style.background  = checked ? 'var(--primary-bg)' : 'var(--surface)';
  if (badge) {
    badge.textContent = checked ? 'مفعّلة' : 'معطّلة';
    badge.className   = `badge ${checked ? 'b-blue' : 'b-gray'}`;
  }
  // إظهار/إخفاء الشعب
  const semSecs = (STATE.sections||[]).filter(s => s.subject_id === subId && s.semester === STATE.currentSem);
  if (secsDiv) secsDiv.style.display = (checked && semSecs.length) ? 'block' : 'none';

  // إذا أُلغيت المادة → ألغِ اختيار شعبها تلقائياً
  if (!checked) {
    semSecs.forEach(sec => {
      const secCb = document.getElementById(`sss_${sec.id}`);
      if (secCb) {
        secCb.checked = false;
        const lbl = document.getElementById(`secLbl_${sec.id}`);
        if (lbl) { lbl.style.borderColor='var(--border)'; lbl.style.background=''; }
      }
    });
  }
}

// ── حفظ المقررات والشعب معاً ───────────────────────────────
async function saveStudentSubjectsAndSections(studentId) {
  // المواد المختارة
  const selectedSubjIds = STATE.subjects
    .filter(sub => document.getElementById(`ssj_${sub.id}`)?.checked)
    .map(s => s.id);

  // الشعب المختارة من الفصل الحالي
  const semSections = (STATE.sections||[]).filter(sec => sec.semester === STATE.currentSem);
  const selectedSecIds = semSections
    .filter(sec => document.getElementById(`sss_${sec.id}`)?.checked)
    .map(sec => sec.id);

  try {
    // تحديث مصفوفة المواد في الطالب
    await dbUpdate('students', studentId, { subject_ids: selectedSubjIds });

    // تحديث student_ids في كل شعبة
    for (const sec of semSections) {
      const wasIn   = (sec.student_ids||[]).includes(studentId);
      const isNowIn = selectedSecIds.includes(sec.id);
      if (wasIn !== isNowIn) {
        let ids = [...(sec.student_ids||[])];
        if (isNowIn) ids.push(studentId); else ids = ids.filter(x => x !== studentId);
        await dbUpdate('sections', sec.id, { student_ids: ids });
        sec.student_ids = ids;
      }
    }

    closeMo('studSubjMo');
    renderStudents();
    toast('✓ تم تحديث المقررات والشعب','success');
  } catch(e) { toast('خطأ: '+e.message,'error'); }
}

async function saveStudentSubjects(id) {
  const selected = STATE.subjects.filter(sub => document.getElementById(`ssj_${sub.id}`)?.checked).map(s=>s.id);
  try {
    await dbUpdate('students', id, { subject_ids: selected });
    closeMo('studSubjMo'); renderStudents();
    toast('✓ تم تحديث مقررات الطالب','success');
  } catch (e) { toast('خطأ: '+e.message,'error'); }
}

// ── إدارة شعب الطالب ──────────────────────────────────────
function openStudentSections(id) {
  const s = getStudent(id); if (!s) return;
  const semSections = STATE.sections.filter(sec => sec.semester === STATE.currentSem);
  const mo = _getMo('studSecMo');
  mo.innerHTML = `<div class="md" style="max-width:520px">
    <div class="md-hd">
      <h2><i class="fas fa-layer-group" style="color:var(--purple2)"></i> شعب: ${s.name}</h2>
      <button class="md-close" onclick="closeMo('studSecMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="font-size:12.5px;color:var(--txt2);margin-bottom:14px">اختر الشعب التي ينتمي إليها الطالب في الفصل الحالي</div>
      ${!semSections.length ? `<div style="text-align:center;color:var(--txt3);padding:24px">لا توجد شعب في الفصل الحالي. أضف شعباً من صفحة المواد.</div>` :
      `<div style="display:flex;flex-direction:column;gap:8px">
        ${semSections.map(sec => {
          const subj = getSubject(sec.subject_id);
          const inSec = (sec.student_ids||[]).includes(id);
          return `<label style="display:flex;align-items:center;gap:10px;padding:12px 14px;border:1.5px solid ${inSec?'var(--primary)':'var(--border)'};background:${inSec?'var(--primary-bg)':''};border-radius:10px;cursor:pointer;transition:all .18s">
            <input type="checkbox" id="sss_${sec.id}" ${inSec?'checked':''} style="accent-color:var(--primary);width:16px;height:16px">
            <div style="flex:1">
              <div style="font-weight:700;font-size:13px">${sec.name}</div>
              <div style="font-size:11.5px;color:var(--txt2)">${subj?.name||'—'}</div>
            </div>
            <span style="font-size:11px;color:var(--txt3)">${(sec.student_ids||[]).length} طالب</span>
          </label>`;
        }).join('')}
      </div>`}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('studSecMo')">إلغاء</button>
      <button class="btn bp" onclick="saveStudentSections(${id})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  showMo('studSecMo');
}

async function saveStudentSections(studentId) {
  const semSections = STATE.sections.filter(sec => sec.semester === STATE.currentSem);
  try {
    for (const sec of semSections) {
      const cb = document.getElementById(`sss_${sec.id}`);
      if (!cb) continue;
      const wasIn  = (sec.student_ids||[]).includes(studentId);
      const isNowIn = cb.checked;
      if (wasIn !== isNowIn) {
        let ids = [...(sec.student_ids||[])];
        if (isNowIn) ids.push(studentId);
        else ids = ids.filter(id => id !== studentId);
        await dbUpdate('sections', sec.id, { student_ids: ids });
        sec.student_ids = ids;
      }
    }
    closeMo('studSecMo'); renderStudents();
    toast('✓ تم تحديث شعب الطالب','success');
  } catch (e) { toast('خطأ: '+e.message,'error'); }
}

// ── كلمة مرور دخول الطالب ────────────────────────────────
function openStudentLogin(id) {
  const s = getStudent(id); if (!s) return;
  const mo = _getMo('studLoginMo');
  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-key" style="color:var(--teal)"></i> بيانات دخول: ${s.name}</h2>
      <button class="md-close" onclick="closeMo('studLoginMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      ${s.email?`
      <div style="padding:10px 14px;background:var(--bg);border-radius:10px;margin-bottom:14px;font-size:12.5px">
        <i class="fas fa-envelope" style="color:var(--primary2);margin-left:6px"></i>
        البريد الحالي: <strong>${s.email}</strong>
      </div>
      <div class="field"><label class="field-lbl">كلمة المرور الجديدة</label>
        <div class="pass-wrap">
          <input type="password" id="slPass" placeholder="••••••••" oninput="checkPassStrength('slPass','slStr','slLbl')">
          <i class="fas fa-eye pass-eye" onclick="togglePassEye('slPass',this)"></i>
        </div>
        <div class="pass-strength">
          <div class="pass-bar"><div class="pass-bar-fill" id="slStr"></div></div>
          <div class="pass-lbl" id="slLbl"></div>
        </div>
      </div>
      <button class="btn bp" style="width:100%" onclick="resetStudentPass(${s.id})">
        <i class="fas fa-key"></i> تغيير كلمة المرور
      </button>`:`
      <div style="padding:14px;background:var(--gold-bg);border:1px solid #fde68a;border-radius:10px;font-size:12.5px;margin-bottom:16px">
        <i class="fas fa-exclamation-triangle" style="color:var(--gold);margin-left:6px"></i>
        الطالب ليس لديه بريد إلكتروني. أضف بريداً أولاً لتمكين الدخول.
      </div>
      <div class="field"><label class="field-lbl">البريد الإلكتروني</label>
        <input type="email" id="slEmail" placeholder="student@squ.edu.om"></div>
      <div class="field"><label class="field-lbl">كلمة المرور</label>
        <div class="pass-wrap">
          <input type="password" id="slPass2" placeholder="••••••••">
          <i class="fas fa-eye pass-eye" onclick="togglePassEye('slPass2',this)"></i>
        </div>
      </div>
      <button class="btn bp" style="width:100%" onclick="createStudentAccount(${id})">
        <i class="fas fa-user-plus"></i> إنشاء حساب الدخول
      </button>`}
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('studLoginMo')">إغلاق</button>
    </div>
  </div>`;
  showMo('studLoginMo');
}

async function resetStudentPass(studentId) {
  const s = getStudent(studentId);
  if (!s) return;
  const mo = _getMo('resetPassMo');
  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-key" style="color:var(--teal)"></i> تعيين كلمة مرور جديدة: ${s.name}</h2>
      <button class="md-close" onclick="closeMo('resetPassMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field"><label class="field-lbl">كلمة المرور الجديدة <span class="req">*</span></label>
        <div class="pass-wrap">
          <input type="password" id="rpPass" placeholder="••••••••">
          <i class="fas fa-eye pass-eye" onclick="togglePassEye('rpPass',this)"></i>
        </div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('resetPassMo')">إلغاء</button>
      <button class="btn bp" onclick="_doResetStudentPass(${s.id})"><i class="fas fa-save"></i> حفظ</button>
    </div>
  </div>`;
  closeMo('studLoginMo');
  showMo('resetPassMo');
}

async function _doResetStudentPass(id) {
  const pass = document.getElementById('rpPass')?.value;
  if (!pass || pass.length < 6) { toast('كلمة المرور 6 أحرف على الأقل', 'warning'); return; }
  try {
    await AUTH.setPasswordForStudent(id, pass);
    toast('✓ تم تحديث كلمة المرور', 'success');
    closeMo('resetPassMo');
  } catch (e) { toast('خطأ: ' + e.message, 'error'); }
}

async function createStudentAccount(id) {
  const s = getStudent(id); if (!s) return;
  const email = document.getElementById('slEmail')?.value?.trim().toLowerCase();
  // ✅ إصلاح: قراءة كلمة المرور من الحقل الصحيح slPass2
  const pass  = document.getElementById('slPass2')?.value?.trim();
  if (!email) { toast('البريد الإلكتروني مطلوب','error'); return; }
  if (!pass)  { toast('كلمة المرور مطلوبة','error'); return; }
  if (pass.length < 6) { toast('كلمة المرور 6 أحرف على الأقل','error'); return; }
  try {
    const passHash = await AUTH.hashPassword(pass);
    await dbUpdate('students', id, { email, password: passHash });
    toast('✓ تم إنشاء حساب الدخول للطالب', 'success');
    closeMo('studLoginMo'); renderStudents();
  } catch (e) { toast('خطأ: ' + e.message, 'error'); }
}

async function toggleStudentBan(id) {
  const s = getStudent(id); if (!s) return;
  try {
    await dbUpdate('students', id, { banned: !s.banned, active: s.banned });
    toast(s.banned ? '✓ تم رفع الإيقاف' : 'تم إيقاف الطالب', s.banned?'success':'warning');
    renderStudents();
  } catch (e) { toast('خطأ: '+e.message,'error'); }
}

async function deleteStudent(id) {
  const s = getStudent(id); if (!s) return;
  confirmDelete(`حذف الطالب "${s.name}" (${s.stud_id})؟ سيتم حذف جميع بياناته نهائياً.`, async () => {
    try {
      await dbDelete('students', id);
      toast('تم حذف الطالب','info');
      renderStudents();
      await addLog('حذف طالب','student', s.name);
    } catch(e) { toast('فشل الحذف: '+e.message,'error'); }
  });
}

// ── Helper: Parse CSV properly (handles quoted values with commas) ──
function _parseCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i+1] === '"') { current += '"'; i++; }
      else { inQuotes = !inQuotes; }
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim()); current = '';
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

async function openImportStudents() {
  const mo = _getMo('importStudMo');
  mo.innerHTML = `<div class="md" style="max-width:620px">
    <div class="md-hd">
      <h2>
        <div style="width:34px;height:34px;border-radius:10px;background:var(--teal)20;display:flex;align-items:center;justify-content:center">
          <i class="fas fa-file-import" style="color:var(--teal)"></i>
        </div>
        استيراد الطلاب من ملف CSV / Excel
      </h2>
      <button class="md-close" onclick="closeMo('importStudMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="padding:14px;background:var(--primary)08;border:1.5px solid var(--primary)20;border-radius:12px;margin-bottom:14px">
        <div style="font-weight:700;font-size:13px;margin-bottom:8px"><i class="fas fa-info-circle" style="color:var(--primary2);margin-inline-end:5px"></i>تنسيق الأعمدة المطلوبة:</div>
        <code style="font-size:11.5px;display:block;background:var(--bg);padding:10px;border-radius:8px;direction:ltr;text-align:left;line-height:1.9;font-family:monospace">
          name, student_id, email, batch, phone, password
        </code>
        <div style="margin-top:8px;font-size:12px;color:var(--txt2)">
          <i class="fas fa-lightbulb" style="color:var(--gold);margin-inline-end:4px"></i>
          الحقول الإلزامية: الاسم، الرقم الجامعي، البريد.
          الحقول الاختيارية: الهاتف، كلمة المرور (تُنشأ تلقائياً إذا تركت فارغة)
        </div>
        <div style="margin-top:6px;font-size:12px;color:var(--txt2)">
          <i class="fas fa-shield-alt" style="color:var(--teal);margin-inline-end:4px"></i>
          إذا تركت كلمة المرور فارغة، سيتم إنشاء كلمة مرور تلقائية: <b>SQU@رقم_الطالب</b>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
        <button class="btn bo btn-sm" onclick="downloadStudentsTemplate()">
          <i class="fas fa-download"></i> نموذج CSV (عربي)
        </button>
        <button class="btn bo btn-sm" onclick="downloadStudentsTemplateEN()">
          <i class="fas fa-download"></i> Sample CSV (English)
        </button>
      </div>
      <div class="field">
        <label class="field-lbl">ارفع ملف CSV</label>
        <input type="file" id="importFile" accept=".csv,.txt" onchange="previewImport(this)" style="padding:10px;border:1.5px solid var(--border);border-radius:10px;width:100%">
      </div>
      <div id="importPreview"></div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('importStudMo')">إلغاء</button>
      <button class="btn bp" id="doImportBtn" onclick="doImportStudents()" disabled>
        <i class="fas fa-upload"></i> استيراد الطلاب
      </button>
    </div>
  </div>`;
  showMo('importStudMo');
}

function downloadStudentsTemplate() {
  const headers = ['الاسم الكامل','الرقم الجامعي','البريد الإلكتروني','السنة/الدفعة','رقم الهاتف','كلمة المرور'];
  const sample  = [
    ['محمد أحمد الرحبي','S123456','s123456@student.squ.edu.om','2022','96812345678','Pass@123456'],
    ['سارة خالد البلوشي','S123457','s123457@student.squ.edu.om','2022','96887654321',''],
    ['أحمد علي الزدجالي','S123458','s123458@student.squ.edu.om','2023','96899887766','MyPass@2024'],
  ];
  const csv = [headers,...sample].map(r=>r.map(c=>`"${String(c||'').replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a'); a.href=url; a.download='students_template_ar.csv';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('✓ تم تنزيل نموذج الطلاب','success');
}

function downloadStudentsTemplateEN() {
  const headers = ['Full Name','Student ID','Email','Batch Year','Phone','Password'];
  const sample  = [
    ['Mohammed Al-Rahbi','S123456','s123456@student.squ.edu.om','2022','96812345678','Pass@123456'],
    ['Sara Al-Balushi','S123457','s123457@student.squ.edu.om','2022','96887654321',''],
    ['Ahmed Al-Zadjali','S123458','s123458@student.squ.edu.om','2023','96899887766','MyPass@2024'],
  ];
  const csv = [headers,...sample].map(r=>r.map(c=>`"${String(c||'').replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a'); a.href=url; a.download='students_template_en.csv';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('✓ Downloaded English student template','success');
}

let _importValidRows = [], _importInvalidRows = [];

function previewImport(input) {
  const file = input.files[0]; if (!file) return;

  const label = document.querySelector('label[for="importFile"]') || {};
  const statusEl = document.getElementById('importPreview');
  if (statusEl) statusEl.innerHTML = `<div style="text-align:center;padding:20px;color:var(--txt2)"><i class="fas fa-spinner fa-spin" style="font-size:20px"></i><br><br>جارٍ قراءة الملف...</div>`;

  const reader = new FileReader();
  reader.onload = ev => {
    try {
      let text = ev.target.result;
      // Remove BOM if present
      if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

      const lines = text.split(/\r?\n/).filter(l => l.trim());
      if (!lines.length) { toast('الملف فارغ','error'); return; }

      // Detect header row (skip it if it looks like headers)
      const firstCols = _parseCSVLine(lines[0]);
      const isHeader  = isNaN(parseInt(firstCols[3])) ||
        firstCols[0].includes('اسم') || firstCols[0].toLowerCase().includes('name') ||
        firstCols[1].includes('رقم') || firstCols[1].toLowerCase().includes('id');
      const dataLines = isHeader ? lines.slice(1) : lines;

      _importValidRows = []; _importInvalidRows = [];
      const seenEmails = new Set();
      const seenIds    = new Set();

      dataLines.forEach((l, i) => {
        if (!l.trim()) return;
        const cols    = _parseCSVLine(l);
        const name    = (cols[0]||'').trim();
        const stud_id = (cols[1]||'').trim();
        const email   = (cols[2]||'').trim().toLowerCase();
        const batch   = parseInt(cols[3]) || new Date().getFullYear();
        const phone   = (cols[4]||'').trim();
        const password = (cols[5]||'').trim() || stud_id; // كلمة المرور من العمود السادس أو الرقم الجامعي افتراضياً
        const rowNum  = i + (isHeader ? 2 : 1);

        const errors = [];
        if (!name)    errors.push('الاسم مفقود');
        if (!stud_id) errors.push('الرقم الجامعي مفقود');
        if (!email)   errors.push('البريد مفقود');
        else if (!email.includes('@')) errors.push('البريد غير صحيح');

        // Duplicates within file
        if (email && seenEmails.has(email)) errors.push('بريد مكرر في الملف');
        if (stud_id && seenIds.has(stud_id)) errors.push('رقم جامعي مكرر في الملف');

        // Duplicates in DB
        if (email && STATE.students.find(s=>s.email===email)) errors.push('البريد موجود مسبقاً');
        if (stud_id && STATE.students.find(s=>s.stud_id===stud_id)) errors.push('الرقم الجامعي موجود');

        if (email)   seenEmails.add(email);
        if (stud_id) seenIds.add(stud_id);

        const row = { name, stud_id, email, batch, phone, password, _row: rowNum };
        if (errors.length) _importInvalidRows.push({ ...row, _errors: errors });
        else _importValidRows.push(row);
      });

      _renderImportPreview();
      const btn = document.getElementById('doImportBtn');
      if (btn) btn.disabled = !_importValidRows.length;
    } catch(err) {
      toast('خطأ في قراءة الملف: ' + err.message, 'error');
    }
  };
  reader.onerror = () => toast('فشل قراءة الملف','error');
  reader.readAsText(file, 'utf-8');
}

function _renderImportPreview() {
  const prev = document.getElementById('importPreview'); if (!prev) return;
  const total = _importValidRows.length + _importInvalidRows.length;
  prev.innerHTML = `
    <div style="margin-top:14px">
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
        <div style="text-align:center;padding:12px 8px;background:var(--bg);border-radius:10px;border:1.5px solid var(--border)">
          <div style="font-size:22px;font-weight:900">${total}</div>
          <div style="font-size:11px;color:var(--txt2)">إجمالي</div>
        </div>
        <div style="text-align:center;padding:12px 8px;background:#f0fdf4;border-radius:10px;border:1.5px solid #bbf7d0">
          <div style="font-size:22px;font-weight:900;color:#059669">${_importValidRows.length}</div>
          <div style="font-size:11px;color:#059669">صالح للاستيراد ✓</div>
        </div>
        <div style="text-align:center;padding:12px 8px;background:#fef2f2;border-radius:10px;border:1.5px solid #fecaca">
          <div style="font-size:22px;font-weight:900;color:#dc2626">${_importInvalidRows.length}</div>
          <div style="font-size:11px;color:#dc2626">يحتوي أخطاء ✗</div>
        </div>
      </div>

      ${_importValidRows.length ? `
      <div style="font-size:12px;font-weight:700;color:var(--txt2);margin-bottom:6px">
        <i class="fas fa-check-circle" style="color:var(--green2);margin-inline-end:4px"></i>
        سيتم استيرادهم (${_importValidRows.length})
      </div>
      <div style="max-height:180px;overflow-y:auto;border:1px solid var(--border);border-radius:10px">
        <table style="width:100%;font-size:11px;border-collapse:collapse">
          <tr style="background:var(--bg);position:sticky;top:0">
            <th style="padding:6px 8px;text-align:right;font-weight:700">الاسم</th>
            <th style="padding:6px 8px;font-weight:700">الرقم</th>
            <th style="padding:6px 8px;font-weight:700">البريد</th>
            <th style="padding:6px 8px;font-weight:700">الهاتف</th>
          </tr>
          ${_importValidRows.map(r=>`<tr style="border-top:1px solid var(--border)">
            <td style="padding:6px 8px;font-weight:600">${esc(r.name)}</td>
            <td style="padding:6px 8px;text-align:center;font-family:monospace;font-size:10px">${esc(r.stud_id)}</td>
            <td style="padding:6px 8px;font-size:10px;color:var(--txt2)">${esc(r.email)}</td>
            <td style="padding:6px 8px;font-size:10px;color:var(--txt3)">${esc(r.phone||'—')}</td>
          </tr>`).join('')}
        </table>
      </div>` : ''}

      ${_importInvalidRows.length ? `
      <div style="font-size:12px;font-weight:700;color:var(--red2);margin:10px 0 6px">
        <i class="fas fa-times-circle" style="margin-inline-end:4px"></i>
        سيتم تجاهلهم (${_importInvalidRows.length})
      </div>
      <div style="max-height:130px;overflow-y:auto;border:1px solid #fecaca;border-radius:10px">
        <table style="width:100%;font-size:11px;border-collapse:collapse">
          ${_importInvalidRows.map(r=>`<tr style="border-top:1px solid #fee2e2">
            <td style="padding:5px 8px;font-weight:600">${esc(r.name||'—')} <span style="color:var(--txt3);font-weight:400">(صف ${r._row})</span></td>
            <td style="padding:5px 8px;color:var(--red2);font-size:10.5px">${r._errors.join(' ، ')}</td>
          </tr>`).join('')}
        </table>
      </div>` : ''}
    </div>`;
}

async function doImportStudents() {
  if (!_importValidRows.length) return;
  const btn = document.getElementById('doImportBtn');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> جارٍ الاستيراد...'; }

  let success=[], failed=[];
  const sb = SB.getClient();

  for (const row of _importValidRows) {
    try {
      // Insert student record
      const existing = STATE.students.find(s=>s.stud_id===row.stud_id||s.email===row.email);
      if (!existing) {
        const rawPw = row.password && row.password.trim() ? row.password.trim() : row.stud_id;
        const pw = await AUTH.hashPassword(rawPw);
        await dbInsert('students', {
          stud_id: row.stud_id, name: row.name, batch: row.batch,
          email: row.email, phone: row.phone || '', active: true, banned: false,
          subject_ids: [], password: pw
        });
      }
      success.push(row);
    } catch(e) {
      failed.push({ ...row, _err: e.message });
    }
  }

  closeMo('importStudMo');
  await SB.manualSync?.();
  renderStudents();
  _showImportResults(success, failed);
  await addLog('استيراد طلاب','student',`${success.length} ناجح, ${failed.length} فشل`);
}

function _showImportResults(success, failed) {
  const mo = _getMo('importResultsMo');
  mo.innerHTML = `<div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2><i class="fas fa-chart-bar" style="color:var(--primary2)"></i> نتيجة الاستيراد</h2>
      <button class="md-close" onclick="closeMo('importResultsMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div style="display:flex;gap:12px;margin-bottom:16px">
        <div style="flex:1;text-align:center;padding:20px;background:#f0fdf4;border-radius:12px;border:2px solid #bbf7d0">
          <div style="font-size:40px;font-weight:900;color:#059669">${success.length}</div>
          <div style="font-size:13px;font-weight:700;color:#059669">تم الاستيراد بنجاح ✅</div>
        </div>
        <div style="flex:1;text-align:center;padding:20px;background:#fef2f2;border-radius:12px;border:2px solid #fecaca">
          <div style="font-size:40px;font-weight:900;color:#dc2626">${failed.length}</div>
          <div style="font-size:13px;font-weight:700;color:#dc2626">فشل الاستيراد ❌</div>
        </div>
      </div>
      ${success.length ? `<div style="padding:10px 14px;background:var(--primary)08;border-radius:9px;margin-bottom:10px;font-size:12.5px;color:var(--txt2)">
        <i class="fas fa-key" style="color:var(--gold)"></i>
        كلمة المرور الأولية لكل طالب لم تُحدد كلمة مروره: <b>SQU@رقم_الطالب</b>
      </div>`:''}
      ${failed.length ? `
        <div style="font-size:12px;font-weight:700;color:var(--txt2);margin-bottom:8px">الطلاب الذين فشل استيرادهم:</div>
        <div style="max-height:200px;overflow-y:auto;border:1px solid var(--border);border-radius:10px">
          ${failed.map(r=>`<div style="padding:8px 12px;border-bottom:1px solid var(--border);font-size:12px">
            <span style="font-weight:600">${r.name}</span> (${r.stud_id}) —
            <span style="color:var(--red2);font-size:11px">${r._err||'خطأ غير معروف'}</span>
          </div>`).join('')}
        </div>` : '<div style="text-align:center;padding:16px;color:var(--green2);font-weight:700">🎉 تم استيراد جميع الطلاب بنجاح!</div>'}
    </div>
    <div class="md-ft"><button class="btn bp" onclick="closeMo('importResultsMo')">تمام</button></div>
  </div>`;
  showMo('importResultsMo');
}


function togglePassEye(inputId, btn) {
  const inp = document.getElementById(inputId); if (!inp) return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
  if (btn) btn.className = `fas fa-eye${inp.type === 'password' ? '' : '-slash'} pass-eye`;
}

function _getMo(id) {
  let mo = document.getElementById(id);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = id; document.body.appendChild(mo); }
  return mo;
}

// ═══════════════════════════════════════════════════════════════
//  عرض المراقب للطلاب — قراءة فقط مع تاريخ الطالب وشعبه
// ═══════════════════════════════════════════════════════════════
function _renderProctorStudentsView() {
  const mySections = getProctorScopeSections();
  const secIds     = new Set(mySections.map(s => s.id));
  const directStudIds = new Set(mySections.flatMap(sec => sec.student_ids || []));
  const allStudents = STATE.students.filter(s =>
    directStudIds.has(s.id) ||
    (s.section_ids || []).some(id => secIds.has(id))
  );

  setHTML('studentsActs', '');

  setHTML('studentsContent', `
    <div class="stats-grid" style="margin-bottom:18px">
      <div class="stat-card">
        <div class="stat-ic ic-teal"><i class="fas fa-user-graduate"></i></div>
        <div><div class="stat-val">${allStudents.length}</div><div class="stat-lbl">طلابي</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-green"><i class="fas fa-check-circle"></i></div>
        <div><div class="stat-val">${allStudents.filter(s=>s.active&&!s.banned).length}</div><div class="stat-lbl">نشطون</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-purple"><i class="fas fa-layer-group"></i></div>
        <div><div class="stat-val">${mySections.length}</div><div class="stat-lbl">شعبي</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-ic ic-red"><i class="fas fa-ban"></i></div>
        <div><div class="stat-val">${allStudents.filter(s=>s.banned).length}</div><div class="stat-lbl">موقوفون</div></div>
      </div>
    </div>

    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-user-graduate" style="color:var(--teal)"></i> طلابي (${allStudents.length})</h3>
      </div>
      <div style="padding:10px 14px;border-bottom:1px solid var(--border);display:flex;gap:8px">
        <div class="sbar" style="flex:1">
          <i class="fas fa-search"></i>
          <input type="text" id="studSrch" placeholder="بحث بالاسم أو الرقم..."
            oninput="_filterProctorStudents()" value="">
        </div>
        <select id="proctorSecFilter" onchange="_filterProctorStudents()"
          style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12px;background:var(--surface)">
          <option value="">كل الشعب</option>
          ${mySections.map(sec => {
            const subj = getSubject(sec.subject_id);
            return `<option value="${sec.id}">${esc(subj?.code||'?')} · ${esc(sec.name)}</option>`;
          }).join('')}
        </select>
      </div>
      <div id="studList" style="max-height:600px;overflow-y:auto"></div>
      <div id="studFooter" style="padding:12px 20px;border-top:1px solid var(--border);font-size:12px;color:var(--txt3)">
        إجمالي: ${allStudents.length} طالب
      </div>
    </div>`);

  _filterProctorStudents();
}

function _filterProctorStudents() {
  const mySections = getProctorScopeSections();
  const secIds     = new Set(mySections.map(s => s.id));
  const directStudIds = new Set(mySections.flatMap(sec => sec.student_ids || []));
  let students = STATE.students.filter(s =>
    directStudIds.has(s.id) ||
    (s.section_ids || []).some(id => secIds.has(id))
  );

  const q       = (document.getElementById('studSrch')?.value || '').toLowerCase();
  const secFilter = document.getElementById('proctorSecFilter')?.value;
  if (q) students = students.filter(s =>
    s.name?.toLowerCase().includes(q) ||
    s.stud_id?.toLowerCase().includes(q) ||
    s.email?.toLowerCase().includes(q)
  );
  if (secFilter) {
    const sec = getSection(parseInt(secFilter));
    const secStudIds = new Set(sec?.student_ids || []);
    students = students.filter(s => secStudIds.has(s.id));
  }

  const el = document.getElementById('studList'); if (!el) return;
  if (!students.length) { el.innerHTML = emptyState('fa-search','لا توجد نتائج'); return; }

  el.innerHTML = students.map(s => {
    const myStudSecs = mySections.filter(sec => (sec.student_ids||[]).includes(s.id));
    const subjNames  = [...new Set(myStudSecs.map(sec => getSubject(sec.subject_id)?.name).filter(Boolean))].join('، ');
    const secNames   = myStudSecs.map(sec => sec.name).join('، ');
    return `<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s"
                 onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"
                 onclick="_proctorOpenStudentDetail('${s.id}')">
      <div style="width:40px;height:40px;border-radius:11px;background:var(--teal)20;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:var(--teal);flex-shrink:0">
        ${getInitials(s.name||'?')}
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:800;font-size:13.5px">${esc(s.name)}</div>
        <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">
          ${s.stud_id?`<span class="badge b-gold" style="font-size:10px">${esc(s.stud_id)}</span> `:''}
          ${s.batch?`<span style="color:var(--txt3)">دفعة ${s.batch}</span>`:''}
        </div>
        ${subjNames?`<div style="font-size:11px;color:var(--txt3);margin-top:3px">
          <i class="fas fa-book" style="color:var(--gold);margin-left:4px"></i>${esc(subjNames)}</div>`:''}
        ${secNames?`<div style="font-size:11px;color:var(--txt3);margin-top:1px">
          <i class="fas fa-layer-group" style="color:var(--purple2);margin-left:4px"></i>${esc(secNames)}</div>`:''}
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
        <span class="badge ${s.banned?'b-red':s.active?'b-green':'b-gray'}">${s.banned?'موقوف':s.active?'نشط':'غير نشط'}</span>
        <i class="fas fa-chevron-left" style="color:var(--txt3);font-size:11px"></i>
      </div>
    </div>`;
  }).join('');
}

function _proctorOpenStudentDetail(studId) {
  const s    = STATE.students.find(x => x.id == studId);
  if (!s) return;
  const mySections = getProctorScopeSections();
  const myStudSecs = mySections.filter(sec => (sec.student_ids||[]).includes(s.id));
  const myExams    = STATE.exams.filter(e =>
    (e.section_ids||[]).some(sid => myStudSecs.some(sec => sec.id == sid))
  );
  const moId = 'proctorStudDetailMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }
  mo.innerHTML = `
    <div class="md" style="max-width:500px">
      <div class="md-hd">
        <h2><i class="fas fa-user-graduate" style="color:var(--teal)"></i> بيانات الطالب</h2>
        <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:0">
        <!-- معلومات الطالب -->
        <div style="padding:16px 18px;background:var(--bg);border-bottom:1px solid var(--border)">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">
            <div style="width:52px;height:52px;border-radius:14px;background:var(--teal)20;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:var(--teal)">
              ${getInitials(s.name||'?')}
            </div>
            <div>
              <div style="font-weight:800;font-size:16px">${esc(s.name)}</div>
              <div style="font-size:12px;color:var(--txt2)">${esc(s.stud_id||'')} ${s.batch?'· دفعة '+s.batch:''}</div>
              <span class="badge ${s.banned?'b-red':s.active?'b-green':'b-gray'}" style="margin-top:4px">${s.banned?'موقوف':s.active?'نشط':'غير نشط'}</span>
            </div>
          </div>
          ${s.email?`<div style="font-size:12.5px;color:var(--txt2);margin-bottom:5px"><i class="fas fa-envelope" style="color:var(--primary2);margin-left:6px"></i>${esc(s.email)}</div>`:''}
          ${s.phone?`<div style="font-size:12.5px;color:var(--txt2)"><i class="fas fa-phone" style="color:var(--green);margin-left:6px"></i>${esc(s.phone)}</div>`:''}
        </div>

        <!-- الشعب -->
        <div style="padding:14px 18px;border-bottom:1px solid var(--border)">
          <div style="font-weight:800;font-size:12.5px;color:var(--txt2);margin-bottom:10px">
            <i class="fas fa-layer-group" style="color:var(--purple2);margin-left:6px"></i>الشعب المسجّلة (${myStudSecs.length})
          </div>
          ${myStudSecs.length ? myStudSecs.map(sec => {
            const subj = getSubject(sec.subject_id);
            return `<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-weight:700;font-size:12.5px">${esc(sec.name)}</div>
                <div style="font-size:11px;color:var(--txt3)">${esc(subj?.name||'—')} · ${esc(subj?.code||'')}</div>
              </div>
              <span style="font-size:11px;color:var(--txt3)">${esc(STATE.semesters.find(x=>x.code===sec.semester)?.label||sec.semester)}</span>
            </div>`;
          }).join('') : '<div style="font-size:12px;color:var(--txt3);padding:6px 0">لا توجد شعب مشتركة</div>'}
        </div>

        <!-- الامتحانات -->
        <div style="padding:14px 18px">
          <div style="font-weight:800;font-size:12.5px;color:var(--txt2);margin-bottom:10px">
            <i class="fas fa-file-alt" style="color:var(--primary2);margin-left:6px"></i>الامتحانات المشتركة (${myExams.length})
          </div>
          <div style="max-height:200px;overflow-y:auto">
            ${myExams.length ? myExams.sort((a,b)=>new Date(`${b.date}T${b.time}`)-new Date(`${a.date}T${a.time}`)).map(e => {
              const sub = getSubject(e.subject_id);
              const st  = examStatus(e);
              const att = STATE.attendance[e.id]?.[s.id];
              const attBadge = att === 'present'?'<span class="badge b-green">حاضر</span>'
                :att==='absent'?'<span class="badge b-red">غائب</span>'
                :att==='late'?'<span class="badge b-gold">متأخر</span>':'';
              return `<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--border);font-size:12px">
                <div>
                  <div style="font-weight:700">${esc(sub?.name||'—')}</div>
                  <div style="font-size:11px;color:var(--txt3)">${fmtDate(e.date)} · ${fmtTime(e.time)}</div>
                </div>
                <div style="display:flex;gap:5px;align-items:center">
                  ${getStatusBadge(st)}
                  ${attBadge}
                </div>
              </div>`;
            }).join('') : '<div style="font-size:12px;color:var(--txt3);padding:6px 0">لا امتحانات مشتركة</div>'}
          </div>
        </div>
      </div>
      <div class="md-ft">
        <button class="btn bo" onclick="closeMo('${moId}')">إغلاق</button>
      </div>
    </div>`;
  showMo(moId);
}
