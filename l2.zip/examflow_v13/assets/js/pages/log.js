// log.js v10 — سجل النشاط (stub — renderLog defined in utils.js)
// renderLog() is already implemented in core/utils.js
// This file exists to satisfy the script load order only.
