// ═══════════════════════════════════════════════════════════════
//  signature-student.js (v13.1 — محسّنة)
//  1. التوقيع الإلكتروني الإلزامي
//  2. بوابة الطالب — حفظ session في localStorage
//  3. معالجة أفضل لتحميل البيانات
// ═══════════════════════════════════════════════════════════════

// ────────────────────────────────────────────────────────────────
//  التوقيع الإلكتروني
// ────────────────────────────────────────────────────────────────

let _sigCanvas = null;
let _sigCtx    = null;
let _sigDrawing = false;
let _sigIsUpdate = false;

function checkSignatureRequired() {
  const u = STATE.currentUser;
  if (!u) return;
  // لا نطلب التوقيع من الطلاب
  if (u.role === 'student') return;
  if (!u.signature || u.signature.trim() === '') {
    setTimeout(() => openSignatureModal(false, true), 800);
  }
}

function openSignatureModal(isUpdate = false, isMandatory = false) {
  _sigIsUpdate = isUpdate;
  const moId = 'signatureMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2><i class="fas fa-signature" style="color:var(--primary2)"></i> ${isUpdate ? 'تحديث التوقيع' : 'التوقيع الإلكتروني'}</h2>
      ${!isMandatory ? `<button class="md-close" onclick="closeMo('signatureMo')"><i class="fas fa-times"></i></button>` : ''}
    </div>
    <div class="md-bd">
      ${isMandatory ? `<div style="padding:10px 14px;background:var(--gold-bg);border-radius:9px;border:1px solid var(--gold);margin-bottom:14px;font-size:13px">
        <i class="fas fa-exclamation-triangle" style="color:var(--gold);margin-inline-end:6px"></i>
        <strong>مطلوب:</strong> يجب إضافة توقيعك الإلكتروني قبل استخدام النظام. التوقيع يُستخدم في وثائق الامتحانات الرسمية.
      </div>` : ''}
      
      <p style="font-size:12.5px;color:var(--txt2);margin-bottom:10px">ارسم توقيعك في المنطقة أدناه باستخدام الماوس أو إصبعك</p>
      
      <div style="position:relative;border:2px solid var(--border);border-radius:12px;overflow:hidden;background:white;cursor:crosshair">
        <canvas id="sigCanvas" width="500" height="180" style="display:block;width:100%;touch-action:none"></canvas>
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none;opacity:.15;font-size:13px;color:#000;white-space:nowrap" id="sigPlaceholder">ارسم توقيعك هنا...</div>
      </div>

      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="btn bo btn-sm" onclick="_sigClear()"><i class="fas fa-eraser"></i> مسح</button>
        <button class="btn bo btn-sm" onclick="_sigUndo()"><i class="fas fa-undo"></i> تراجع</button>
        <div style="flex:1"></div>
        <div style="font-size:11px;color:var(--txt3);align-self:center">يُحفظ بصيغة صورة آمنة</div>
      </div>
    </div>
    <div class="md-ft">
      ${!isMandatory ? `<button class="btn bo" onclick="closeMo('signatureMo')">إلغاء</button>` : ''}
      <button class="btn bp" onclick="saveSignature(${isMandatory})">
        <i class="fas fa-save"></i> حفظ التوقيع
      </button>
    </div>
  </div>`;

  requestAnimationFrame(() => {
    mo.classList.add('open');
    _initSigCanvas();
  });
}

function _initSigCanvas() {
  _sigCanvas = document.getElementById('sigCanvas');
  if (!_sigCanvas) return;
  _sigCtx = _sigCanvas.getContext('2d');
  _sigCtx.lineWidth   = 2.5;
  _sigCtx.lineCap     = 'round';
  _sigCtx.lineJoin    = 'round';
  _sigCtx.strokeStyle = '#1a1a2e';
  _sigHistory = [];

  const getPos = (e) => {
    const rect = _sigCanvas.getBoundingClientRect();
    const scaleX = _sigCanvas.width  / rect.width;
    const scaleY = _sigCanvas.height / rect.height;
    const src = e.touches ? e.touches[0] : e;
    return { x: (src.clientX - rect.left) * scaleX, y: (src.clientY - rect.top) * scaleY };
  };

  _sigCanvas.addEventListener('mousedown', e => { _sigDrawing=true; const p=getPos(e); _sigCtx.beginPath(); _sigCtx.moveTo(p.x,p.y); document.getElementById('sigPlaceholder').style.display='none'; });
  _sigCanvas.addEventListener('mousemove', e => { if (!_sigDrawing) return; const p=getPos(e); _sigCtx.lineTo(p.x,p.y); _sigCtx.stroke(); });
  _sigCanvas.addEventListener('mouseup',   () => { _sigDrawing=false; _sigHistory.push(_sigCanvas.toDataURL()); });
  _sigCanvas.addEventListener('mouseleave',() => { _sigDrawing=false; });
  _sigCanvas.addEventListener('touchstart', e => { e.preventDefault(); _sigDrawing=true; const p=getPos(e); _sigCtx.beginPath(); _sigCtx.moveTo(p.x,p.y); document.getElementById('sigPlaceholder').style.display='none'; }, {passive:false});
  _sigCanvas.addEventListener('touchmove',  e => { e.preventDefault(); if (!_sigDrawing) return; const p=getPos(e); _sigCtx.lineTo(p.x,p.y); _sigCtx.stroke(); }, {passive:false});
  _sigCanvas.addEventListener('touchend',   () => { _sigDrawing=false; _sigHistory.push(_sigCanvas.toDataURL()); });
}

let _sigHistory = [];

function _sigClear() {
  if (!_sigCtx || !_sigCanvas) return;
  _sigCtx.clearRect(0, 0, _sigCanvas.width, _sigCanvas.height);
  _sigHistory = [];
  const ph = document.getElementById('sigPlaceholder');
  if (ph) ph.style.display = '';
}

function _sigUndo() {
  if (!_sigCtx || !_sigCanvas || _sigHistory.length < 2) { _sigClear(); return; }
  _sigHistory.pop();
  const prev = _sigHistory[_sigHistory.length-1];
  if (prev) {
    const img = new Image();
    img.onload = () => { _sigCtx.clearRect(0,0,_sigCanvas.width,_sigCanvas.height); _sigCtx.drawImage(img,0,0); };
    img.src = prev;
  } else {
    _sigClear();
  }
}

async function saveSignature(isMandatory = false) {
  if (!_sigCanvas) { toast('خطأ في لوحة التوقيع', 'error'); return; }
  const blank = _sigHistory.length === 0;
  if (blank) { toast('الرجاء رسم توقيعك أولاً', 'warning'); return; }

  const dataUrl = _sigCanvas.toDataURL('image/png');
  try {
    await dbUpdate('profiles', STATE.currentUser.id, {
      signature: dataUrl,
      signature_updated_at: new Date().toISOString()
    });
    STATE.currentUser.signature = dataUrl;
    toast('✓ تم حفظ التوقيع', 'success');
    closeMo('signatureMo');
    if (STATE.currentPage === 'settings') renderSettings();
  } catch(e) { toast('خطأ: '+e.message, 'error'); }
}

// ────────────────────────────────────────────────────────────────
//  بوابة الطالب
// ────────────────────────────────────────────────────────────────

// ── عميل Supabase مستقل لشاشة الدخول (يعمل قبل بوت التطبيق) ──
function _studentSB() {
  if (window._studAnonSB) return window._studAnonSB;
  try {
    const c = (typeof SB !== 'undefined' && SB?.getClient?.()) || null;
    if (c) { window._studAnonSB = c; return c; }
  } catch {}
  if (!window.supabase || typeof window.supabase.createClient !== 'function') {
    throw new Error('Supabase library غير محمَّلة');
  }
  window._studAnonSB = window.supabase.createClient(
    APP_CONFIG.SUPABASE_URL, APP_CONFIG.SUPABASE_ANON_KEY
  );
  return window._studAnonSB;
}

async function studentLogin() {
  console.log('[studentLogin] click');
  const email = (document.getElementById('studEmailInput')?.value || '').trim().toLowerCase();
  const pass  = (document.getElementById('studPassInput')?.value  || '').trim();
  if (!email) { _setStudErr('أدخل البريد الإلكتروني'); return; }
  if (!pass)  { _setStudErr('أدخل كلمة المرور'); return; }

  const btnEl = document.getElementById('studLoginBtn');
  const _setBusy = (b) => {
    if (!btnEl) return;
    btnEl.disabled = b;
    btnEl.innerHTML = b
      ? '<i class="fas fa-spinner fa-spin"></i> جارٍ التحقق...'
      : '<i class="fas fa-sign-in-alt"></i> دخول الطالب';
  };

  _setBusy(true);
  _setStudErr('');

  try {
    const sb = _studentSB();
    let student = null;

    // ── 1. RPC الآمن أولاً (يتجاوز RLS) ──────────────────────
    try {
      const { data, error } = await sb.rpc('student_login', {
        p_email: email, p_password: pass
      });
      if (!error && data && data.ok) {
        student = data.student;
      } else if (!error && data && data.error === 'invalid_credentials') {
        throw new Error('البريد أو كلمة المرور غير صحيحة');
      }
    } catch (rpcErr) {
      console.warn('[studentLogin] RPC fallback:', rpcErr.message);
    }

    // ── 2. Fallback: قراءة مباشرة ────────────────────────────
    if (!student) {
      const { data: rows, error: e2 } = await sb
        .from('students').select('*').eq('email', email).limit(1);
      if (e2) throw new Error('فشل الاتصال: ' + (e2.message || ''));
      if (!rows?.length) throw new Error('البريد الإلكتروني غير موجود');
      const s = rows[0];
      if (!s.active)  throw new Error('الحساب معطَّل');
      if (s.banned)   throw new Error('الحساب محظور. تواصل مع الإدارة');
      const stored = s.password || s.pin || '';
      if (!stored)    throw new Error('لم تُعيَّن كلمة مرور — راجع الإدارة');
      if (stored !== pass) throw new Error('كلمة المرور غير صحيحة');
      student = s;
    }

    if (!student) throw new Error('تعذّر تسجيل الدخول');

    // ── 3. حالة الطالب ────────────────────────────────────────
    STATE._studentUser = student;
    STATE.currentUser  = null;

    // ── 3.5 حفظ الجلسة في localStorage (لاستعادتها عند refresh) ──
    try {
      // الصيغة الجديدة (_ef_session) — تُستعاد تلقائياً عند refresh
      if (typeof AUTH !== 'undefined' && AUTH.saveStudentSession) {
        AUTH.saveStudentSession(student);
      }
      // الصيغة القديمة كـ fallback للتوافق
      localStorage.setItem('_studentSession', JSON.stringify({
        student: student,
        timestamp: Date.now()
      }));
    } catch (e) {
      console.warn('[studentLogin] Could not save session:', e.message);
    }

    // ── 4. تحميل البيانات اللازمة ─────────────────────────────
    try {
      await _loadStudentData(student);
    } catch (loadErr) {
      console.error('[student data load error]', loadErr);
      // إذا فشل التحميل — حاول مرة أخرى بعد تأخير قصير
      try {
        await new Promise(r => setTimeout(r, 500));
        await _loadStudentData(student);
      } catch (e2) {
        console.error('[student data retry failed]', e2);
        // تابع على أي حال — البيانات قد تُحمَّل من state موجود أو placeholder
      }
    }

    // ── 5. بناء وعرض الواجهة ─────────────────────────────────
    const ls = document.getElementById('loadingScreen'); if (ls) ls.remove();
    const loginEl = document.getElementById('loginScreen');
    const appEl   = document.getElementById('app');
    if (loginEl) loginEl.style.display = 'none';
    if (appEl)   { appEl.style.display = 'block'; appEl.innerHTML = ''; }

    if (typeof buildAppShell === 'function') buildAppShell();
    if (window.UI?.buildNav)      UI.buildNav();
    if (window.UI?.renderSidebar) UI.renderSidebar();

    // اضمن وجود حاوية الصفحة قبل عرضها
    if (window.UI?.showPage) {
      STATE.currentPage = null;
      UI.showPage('student-portal');
    } else if (typeof renderStudentPortal === 'function') {
      renderStudentPortal();
    }

    if (typeof toast === 'function') toast(`مرحباً ${student.name?.split(' ')[0] || ''} 👋`, 'success');
    _setBusy(false);

  } catch (e) {
    console.error('[studentLogin]', e);
    _setStudErr(e.message || 'خطأ غير متوقَّع');
    _setBusy(false);
  }
}

async function _loadStudentData(student) {
  if (!student?.id) {
    throw new Error('Student ID missing');
  }

  const sb = _studentSB();
  const results = await Promise.allSettled([
    sb.from('exams').select('*'),
    sb.from('semesters').select('*'),
    sb.from('subjects').select('*'),
    sb.from('rooms').select('id,name,building,floor,cap,type'),
    sb.from('sections').select('id,name,subject_id,semester,student_ids')
  ]);

  // استخرج البيانات مع معالجة الأخطاء
  const [exams, semesters, subjects, rooms, sections] = results.map(r =>
    r.status === 'fulfilled' ? (r.value.data || []) : []
  );

  STATE.exams     = (exams     || []).map(Hydrate.exam);
  STATE.semesters = semesters  || [];
  STATE.subjects  = subjects   || [];
  STATE.rooms     = rooms      || [];
  STATE.sections  = (sections  || []).map(Hydrate.section);

  const activeSem = STATE.semesters.find(s => s.is_active);
  if (activeSem) STATE.currentSem = activeSem.code;

  // حضور الطالب — قراءة مباشرة من جدول attendance
  await _refreshStudentAttendance(student.id, sb);

  console.log('[_loadStudentData] completed', {
    exams: STATE.exams.length,
    semesters: STATE.semesters.length,
    sections: STATE.sections.length
  });
}

function _setStudErr(msg) {
  const el = document.getElementById('studLoginErr');
  if (!el) return;
  el.textContent   = msg || '';
  el.style.display = msg ? 'block' : 'none';
}

// ── تحديث سجل حضور الطالب من DB ─────────────────────────────
async function _refreshStudentAttendance(studentId, sb) {
  if (!studentId) return;
  const client = sb || (SB?.getClient?.()) || window._efSB;
  if (!client) return;
  STATE._studentAttendance = {};
  try {
    const { data: rows } = await client
      .from('attendance')
      .select('exam_id,status')
      .eq('student_id', studentId);
    (rows || []).forEach(r => {
      STATE._studentAttendance[Number(r.exam_id)] = r.status;
    });
  } catch(e) { console.warn('[att-refresh]', e.message); }
}
window._refreshStudentAttendance = _refreshStudentAttendance;

// ── تأكد من تعريضها عالمياً ──────────────────────────────────
window.studentLogin     = studentLogin;
window._loadStudentData = _loadStudentData;

// ── استعادة جلسة الطالب من localStorage (للاستخدام من main.js) ──
function restoreStudentSession() {
  try {
    const sessionStr = localStorage.getItem('_studentSession');
    if (!sessionStr) return null;
    const session = JSON.parse(sessionStr);
    // التحقق من صحة الجلسة (اختياري: تحقق من التاريخ/الوقت)
    if (session && session.student && session.student.id) {
      return session.student;
    }
  } catch (e) {
    console.warn('[restoreStudentSession]', e.message);
  }
  return null;
}
window.restoreStudentSession = restoreStudentSession;

// ════════════════════════════════════════════════════════════════
//  بوابة الطالب — نظام التابات المدمج
// ════════════════════════════════════════════════════════════════

let _spTab = 'overview'; // overview | exams | subjects | log

// ── مساعد: استخراج بيانات الطالب للفصل الدراسي المحدَّد ──────
function _getStudentSemData(student, sem) {
  // 1. شُعَب الطالب في هذا الفصل فقط (لا تنتقل للفصول الأخرى)
  const mySemSections = STATE.sections.filter(s =>
    s.semester === sem &&
    (s.student_ids || []).some(id => String(id) === String(student.id) || String(id) === String(student.stud_id))
  );

  // 2. المواد المستمَدَّة من الشُّعَب (مشترَطة بالفصل)
  const subjMap = new Map();
  mySemSections.forEach(s => {
    const subj = getSubject(s.subject_id);
    if (subj) subjMap.set(subj.id, { subj, section: s });
  });
  // إضافة المواد المرتبطة مباشرة بالطالب
  (student.subject_ids||[]).forEach(sid => {
    const subj = getSubject(Number(sid));
    if (subj && !subjMap.has(subj.id)) subjMap.set(subj.id, { subj, section: null });
  });
  const mySubjects = [...subjMap.values()];
  const mySubjIds = new Set([...subjMap.keys()]);
  const mySemSecIds = new Set(mySemSections.map(s => Number(s.id)));

  // 3. امتحانات هذا الفصل المرتبطة بشُعَب الطالب فقط
  // ⚠ الإصلاح: الامتحان بدون شعب لا يظهر لأي طالب
  const seenExamIds = new Set();
  const myExams = STATE.exams.filter(e => {
    if (e.semester !== sem) return false;
    if (seenExamIds.has(e.id)) return false;
    const eSecIds = (e.section_ids||[]).map(Number);
    // الامتحان يجب أن يحتوي على شعبة واحدة على الأقل
    if (!eSecIds.length) return false;
    // الطالب يجب أن ينتمي لإحدى شعب الامتحان
    if (eSecIds.some(sid => mySemSecIds.has(sid))) { seenExamIds.add(e.id); return true; }
    return false;
  });

  // 4. الأقسام
  const deptIds = [...new Set(mySubjects.map(({subj}) => subj.dept_id).filter(Boolean))];
  const myDepts = deptIds.map(id => STATE.departments.find(d => d.id === id)).filter(Boolean);

  // 5. إحصاءات الحضور في هذا الفصل
  const pastExams = myExams.filter(e => examStatus(e) === 'completed');
  let totalAtt = 0, presentAtt = 0, absentAtt = 0, lateAtt = 0;
  pastExams.forEach(e => {
    const st = STATE._studentAttendance?.[e.id];
    if (st) {
      totalAtt++;
      if (st === 'present') presentAtt++;
      else if (st === 'absent') absentAtt++;
      else if (st === 'late')   lateAtt++;
    }
  });
  const attPct = totalAtt > 0 ? Math.round(presentAtt / totalAtt * 100) : 100;

  return { mySemSections, mySubjects, myExams, myDepts, pastExams, totalAtt, presentAtt, absentAtt, lateAtt, attPct };
}

// ── تحديث سجل الحضور وإعادة رسم البوابة ────────────────────
function _spRefreshLog() {
  const student = STATE._studentUser;
  if (!student) return;
  _refreshStudentAttendance(student.id).then(() => renderStudentPortal()).catch(() => {});
}

function renderStudentPortal() {
  const student = STATE._studentUser;
  if (!student) { setHTML('student-portalContent', '<p>يرجى تسجيل الدخول كطالب.</p>'); return; }

  const isAr = I18N.isAr();
  const sem  = STATE.currentSem;
  const semObj = STATE.semesters.find(s => s.code === sem);
  const semLabel = semObj?.label || sem;

  const { mySemSections, mySubjects, myExams, myDepts, pastExams, totalAtt, presentAtt, absentAtt, lateAtt, attPct }
    = _getStudentSemData(student, sem);

  const upcoming = myExams.filter(e => examStatus(e) === 'upcoming')
    .sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));
  const activeNow = myExams.filter(e => examStatus(e) === 'active');

  // ── رأس الصفحة ─────────────────────────────────────────────
  const headerHTML = `
    <div class="card" style="margin-bottom:14px;background:linear-gradient(135deg,#0ea5e9,#2563eb);color:white;overflow:hidden">
      <div style="padding:20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <div style="width:58px;height:58px;border-radius:14px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:900;flex-shrink:0">
          ${getInitials(student.name || '?')}
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-size:19px;font-weight:900">${esc(student.name)}</div>
          <div style="opacity:.8;font-size:12.5px">
            <i class="fas fa-id-card" style="margin-left:4px"></i>${student.stud_id}
            ${student.email ? ` · <i class="fas fa-envelope" style="margin-right:6px;margin-left:4px"></i>${student.email}` : ''}
          </div>
          <div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
            <span style="background:rgba(255,255,255,.2);border-radius:20px;padding:3px 10px;font-size:11px;font-weight:700">
              <i class="fas fa-calendar-alt" style="margin-left:4px"></i>${semLabel}
            </span>
            ${myDepts.map(d => `<span style="background:rgba(255,255,255,.15);border-radius:20px;padding:3px 10px;font-size:11px">${esc(d.name)}</span>`).join('')}
          </div>
        </div>
        <!-- مبدّل الفصل الدراسي -->
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
          <select onchange="STATE.currentSem=this.value;renderStudentPortal()"
                  style="background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.35);color:white;border-radius:8px;padding:6px 10px;font-size:12px;cursor:pointer;outline:none;font-family:inherit">
            ${STATE.semesters.map(s => `<option value="${s.code}" ${s.code===sem?'selected':''} style="background:#1a56db;color:white">${s.label}</option>`).join('')}
          </select>
          <button style="background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);color:white;border-radius:8px;padding:5px 12px;font-size:12px;cursor:pointer;font-family:inherit" onclick="openStudentBioSelf()" title="إدارة البصمة">
            <i class="fas fa-fingerprint"></i>
          </button>
          <button style="background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);color:white;border-radius:8px;padding:5px 12px;font-size:12px;cursor:pointer;font-family:inherit" onclick="APP.studentLogout()">
            <i class="fas fa-sign-out-alt"></i> خروج
          </button>
        </div>
      </div>
    </div>`;

  // ── شريط إحصاءات سريع ─────────────────────────────────────
  const statsHTML = `
    <div class="stats-grid" style="margin-bottom:14px">
      <div class="stat-card" onclick="_spTab='subjects';renderStudentPortal()" style="cursor:pointer">
        <div class="stat-ic ic-blue"><i class="fas fa-book"></i></div>
        <div><div class="stat-val">${mySubjects.length}</div><div class="stat-lbl">موادي</div></div>
      </div>
      <div class="stat-card" onclick="_spTab='exams';renderStudentPortal()" style="cursor:pointer">
        <div class="stat-ic ic-gold"><i class="fas fa-calendar-check"></i></div>
        <div><div class="stat-val">${upcoming.length}</div><div class="stat-lbl">امتحانات قادمة</div></div>
      </div>
      ${activeNow.length ? `
      <div class="stat-card" style="border:2px solid var(--red);animation:pulse 2s infinite">
        <div class="stat-ic ic-red"><i class="fas fa-circle" style="color:var(--red)"></i></div>
        <div><div class="stat-val" style="color:var(--red)">${activeNow.length}</div><div class="stat-lbl">جارٍ الآن!</div></div>
      </div>` : `
      <div class="stat-card" onclick="_spTab='log';renderStudentPortal()" style="cursor:pointer">
        <div class="stat-ic ic-green"><i class="fas fa-user-check"></i></div>
        <div><div class="stat-val">${attPct}%</div><div class="stat-lbl">نسبة حضوري</div></div>
      </div>`}
      <div class="stat-card" onclick="_spTab='log';renderStudentPortal()" style="cursor:pointer">
        <div class="stat-ic ic-purple"><i class="fas fa-clipboard-list"></i></div>
        <div><div class="stat-val">${pastExams.length}</div><div class="stat-lbl">امتحانات منتهية</div></div>
      </div>
    </div>`;

  // ── شريط التابات ───────────────────────────────────────────
  const tabs = [
    { id: 'overview',  icon: 'fa-home',           label: 'نظرة عامة' },
    { id: 'exams',     icon: 'fa-file-alt',        label: 'امتحاناتي' },
    { id: 'subjects',  icon: 'fa-book',            label: 'موادي' },
    { id: 'log',       icon: 'fa-clipboard-check', label: 'سجل حضوري' },
  ];
  const tabsHTML = `
    <div style="display:flex;gap:4px;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:4px;margin-bottom:16px;overflow-x:auto;align-items:center">
      ${tabs.map(t => `
        <button onclick="_spTab='${t.id}';${t.id==='log'?'_spRefreshLog();':''}renderStudentPortal()"
                style="flex:1;min-width:fit-content;padding:8px 14px;border:none;border-radius:9px;font-size:12.5px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .2s;font-family:inherit;
                       background:${_spTab===t.id?'var(--primary)':'transparent'};color:${_spTab===t.id?'white':'var(--txt2)'}">
          <i class="fas ${t.icon}"></i> ${t.label}
        </button>`).join('')}
    </div>`;

  // ── محتوى التاب ───────────────────────────────────────────
  let contentHTML = '';
  if      (_spTab === 'overview')  contentHTML = _spOverview(student, sem, semLabel, mySemSections, mySubjects, myExams, upcoming, activeNow, pastExams, attPct, myDepts, isAr);
  else if (_spTab === 'exams')     contentHTML = _spExams(myExams, upcoming, activeNow, pastExams, isAr);
  else if (_spTab === 'subjects')  contentHTML = _spSubjects(mySubjects, sem, semLabel, isAr);
  else if (_spTab === 'log')       contentHTML = _spLog(myExams, pastExams, student, sem, semLabel, totalAtt, presentAtt, absentAtt, lateAtt, attPct, isAr);

  setHTML('student-portalContent', `<div style="max-width:960px;margin:0 auto">${headerHTML}${statsHTML}${tabsHTML}${contentHTML}</div>`);
}

// ── تاب: نظرة عامة ────────────────────────────────────────────
function _spOverview(student, sem, semLabel, mySemSections, mySubjects, myExams, upcoming, activeNow, pastExams, attPct, myDepts, isAr) {
  const now3 = upcoming.slice(0, 3);
  const past3 = pastExams.slice(-3).reverse();
  return `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start">
      <!-- الامتحانات القادمة -->
      <div class="card">
        <div class="card-h">
          <h3><i class="fas fa-calendar-alt" style="color:var(--gold)"></i> أقرب الامتحانات</h3>
          <button class="btn bo btn-xs" onclick="_spTab='exams';renderStudentPortal()">الكل</button>
        </div>
        ${activeNow.length ? activeNow.map(e => _spExamCard(e, true)).join('') : ''}
        ${now3.length ? now3.map(e => _spExamCard(e, false)).join('') :
          `<div style="text-align:center;padding:28px;color:var(--txt3)">
            <i class="fas fa-calendar-check" style="font-size:28px;opacity:.3;margin-bottom:8px"></i>
            <div style="font-size:13px">لا توجد امتحانات قادمة</div>
          </div>`}
      </div>

      <!-- تقدم الفصل -->
      <div>
        <div class="card" style="margin-bottom:14px">
          <div class="card-h"><h3><i class="fas fa-chart-circle" style="color:var(--primary2)"></i> تقدم الفصل</h3></div>
          <div style="padding:16px">
            ${_spProgressBar('الامتحانات المنتهية', pastExams.length, myExams.length, 'var(--green)')}
            ${_spProgressBar('نسبة الحضور', attPct, 100, attPct>=75?'var(--green)':attPct>=50?'var(--gold)':'var(--red)')}
            ${_spProgressBar('المواد المسجّلة', mySubjects.length, Math.max(mySubjects.length, 6), 'var(--primary2)')}
          </div>
        </div>

        <!-- آخر سجل حضور -->
        <div class="card">
          <div class="card-h">
            <h3><i class="fas fa-history" style="color:var(--teal)"></i> آخر سجلات الحضور</h3>
            <button class="btn bo btn-xs" onclick="_spTab='log';renderStudentPortal()">الكل</button>
          </div>
          ${past3.length ? past3.map(e => {
            const sub = getSubject(e.subject_id);
            const st  = STATE._studentAttendance?.[e.id];
            const stInfo = {
              present: { label:'حاضر',   color:'var(--green)',  icon:'fa-check-circle' },
              late:    { label:'متأخر',   color:'var(--gold)',   icon:'fa-clock' },
              absent:  { label:'غائب',    color:'var(--red)',    icon:'fa-times-circle' },
              excused: { label:'معذور',   color:'var(--purple)', icon:'fa-info-circle' },
            }[st] || { label:'غير مسجل', color:'var(--txt3)', icon:'fa-minus-circle' };
            return `<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;border-bottom:1px solid var(--border)">
              <div style="flex:1;min-width:0">
                <div style="font-weight:700;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(sub?.name||'—')}</div>
                <div style="font-size:11px;color:var(--txt2)">${fmtDate(e.date)}</div>
              </div>
              <span style="color:${stInfo.color};font-size:12px;font-weight:700;display:flex;align-items:center;gap:4px;white-space:nowrap">
                <i class="fas ${stInfo.icon}"></i> ${stInfo.label}
              </span>
            </div>`;
          }).join('') : `<div style="text-align:center;padding:28px;color:var(--txt3);font-size:13px">لا سجلات بعد</div>`}
        </div>
      </div>
    </div>`;
}

function _spProgressBar(label, val, max, color) {
  const pct = max > 0 ? Math.min(100, Math.round(val / max * 100)) : 0;
  return `
    <div style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;margin-bottom:5px">
        <span>${label}</span>
        <span style="color:${color}">${val}${max===100?'%':' / '+max}</span>
      </div>
      <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden">
        <div style="width:${pct}%;height:100%;background:${color};border-radius:4px;transition:width .6s ease"></div>
      </div>
    </div>`;
}

// ── تاب: امتحاناتي ────────────────────────────────────────────
function _spExams(myExams, upcoming, activeNow, pastExams, isAr) {
  const sections = [
    { title: '🔴 جارٍ الآن', exams: activeNow,  border: 'var(--red)',    badge: 'b-red' },
    { title: '⏰ قادمة',      exams: upcoming,   border: 'var(--gold)',   badge: 'b-gold' },
    { title: '✅ منتهية',     exams: [...pastExams].reverse(), border: 'var(--txt3)', badge: 'b-gray' },
  ];

  if (!myExams.length) return `
    <div style="text-align:center;padding:60px;color:var(--txt3)">
      <i class="fas fa-calendar-times" style="font-size:48px;opacity:.25;margin-bottom:14px"></i>
      <div style="font-size:15px;font-weight:700">لا توجد امتحانات في هذا الفصل</div>
      <div style="font-size:12px;margin-top:6px">تحقق من الفصل الدراسي المختار</div>
    </div>`;

  return sections.filter(s => s.exams.length).map(s => `
    <div class="card" style="margin-bottom:14px">
      <div class="card-h" style="border-right:4px solid ${s.border};padding-right:14px">
        <h3>${s.title} <span class="badge ${s.badge}">${s.exams.length}</span></h3>
      </div>
      ${s.exams.map(e => _spExamCard(e, s.title.includes('جارٍ'))).join('')}
    </div>`).join('');
}

function _spExamCard(e, isActive) {
  const sub   = getSubject(e.subject_id);
  const rooms = (e.room_ids || []).map(rid => getRoom(rid)?.name).filter(Boolean);
  const now   = new Date();
  const start = new Date(`${e.date}T${e.time}`);
  const diffDays = Math.ceil((start - now) / (1000 * 60 * 60 * 24));
  const typeColors = { final:'#2563eb', midterm:'#d97706', quiz:'#0891b2', makeup:'#7c3aed' };
  const typeLabels = { final:'نهائي', midterm:'منتصف الفصل', quiz:'اختبار', makeup:'تعويضي' };

  return `<div style="padding:14px 16px;border-bottom:1px solid var(--border);${isActive?'background:var(--red)08':''}">
    <div style="display:flex;align-items:start;gap:12px">
      <div style="width:48px;height:48px;border-radius:12px;background:${typeColors[e.type]||'#7c3aed'}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas fa-file-alt" style="color:${typeColors[e.type]||'#7c3aed'};font-size:18px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">
          <span style="font-weight:800;font-size:14px">${esc(sub?.name || '—')}</span>
          <span class="badge" style="background:${typeColors[e.type]||'#7c3aed'}20;color:${typeColors[e.type]||'#7c3aed'};font-size:10.5px">${typeLabels[e.type]||e.type}</span>
          ${isActive ? `<span class="badge b-red" style="animation:pulse 1.5s infinite">🔴 جارٍ الآن</span>` : ''}
        </div>
        <div style="font-size:12px;color:var(--txt2);display:flex;gap:12px;flex-wrap:wrap">
          <span><i class="fas fa-calendar" style="color:var(--primary2);margin-left:4px"></i>${fmtDate(e.date)}</span>
          <span><i class="fas fa-clock" style="color:var(--gold);margin-left:4px"></i>${fmtTime(e.time)}</span>
          <span><i class="fas fa-hourglass-half" style="color:var(--teal);margin-left:4px"></i>${e.duration} دقيقة</span>
          ${e.max_grade ? `<span><i class="fas fa-star" style="color:var(--gold);margin-left:4px"></i>الدرجة الكلية: ${e.max_grade}</span>` : ''}
        </div>
        ${rooms.length ? `<div style="font-size:11px;color:var(--txt3);margin-top:5px"><i class="fas fa-door-open" style="margin-left:4px"></i>${rooms.join(' · ')}</div>` : ''}
        ${!isActive && diffDays >= 0 && diffDays <= 7 ? `
          <div style="margin-top:7px">
            <span class="badge ${diffDays===0?'b-red':diffDays<=3?'b-gold':'b-blue'}" style="font-size:11px">
              ${diffDays===0?'اليوم':diffDays===1?'غداً':`خلال ${diffDays} أيام`}
            </span>
          </div>` : ''}
      </div>
    </div>
  </div>`;
}

// ── تاب: موادي (مقيَّد بالفصل الدراسي) ──────────────────────
function _spSubjects(mySubjects, sem, semLabel, isAr) {
  if (!mySubjects.length) return `
    <div style="text-align:center;padding:60px;color:var(--txt3)">
      <i class="fas fa-book-open" style="font-size:48px;opacity:.25;margin-bottom:14px"></i>
      <div style="font-size:15px;font-weight:700">لا توجد مواد مسجَّلة في الفصل الحالي</div>
      <div style="font-size:12px;margin-top:6px;color:var(--primary)">${semLabel}</div>
      <div style="font-size:12px;margin-top:4px">جرّب تغيير الفصل الدراسي من الأعلى</div>
    </div>`;

  return `
    <div class="card">
      <div class="card-h" style="border-bottom:1px solid var(--border)">
        <h3><i class="fas fa-book" style="color:var(--gold)"></i> موادي في <span style="color:var(--primary)">${esc(semLabel)}</span></h3>
        <span class="badge b-blue">${mySubjects.length} مادة</span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;padding:16px">
        ${mySubjects.map(({ subj, section }) => {
          const dept     = STATE.departments.find(d => d.id === subj.dept_id);
          const examCount = STATE.exams.filter(e =>
            e.semester === sem &&
            (e.section_ids||[]).some(sid => String(sid) === String(section.id))
          ).length;
          return `
            <div style="border:1px solid var(--border);border-radius:12px;padding:14px;background:var(--bg);transition:box-shadow .2s"
                 onmouseover="this.style.boxShadow='0 4px 16px rgba(0,0,0,.08)'" onmouseout="this.style.boxShadow=''">
              <div style="display:flex;align-items:start;gap:10px">
                <div style="width:44px;height:44px;border-radius:10px;background:var(--primary)15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                  <i class="fas fa-book" style="color:var(--primary);font-size:18px"></i>
                </div>
                <div style="flex:1;min-width:0">
                  <div style="font-weight:800;font-size:13.5px">${esc(subj.name)}</div>
                  <div style="font-size:11px;color:var(--txt3);margin-top:2px">${esc(subj.code)} · ${esc(dept?.name||'—')}</div>
                  <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
                    <span class="badge b-blue">${subj.hours||3} ساعات</span>
                    <span class="badge b-teal">شعبة: ${esc(section.name)}</span>
                    ${examCount ? `<span class="badge b-gold">${examCount} امتحان</span>` : '<span class="badge b-gray">لا امتحانات</span>'}
                  </div>
                </div>
              </div>
            </div>`;
        }).join('')}
      </div>
    </div>`;
}

// ── تاب: سجل الحضور (مربوط بالفصل) ──────────────────────────
function _spLog(myExams, pastExams, student, sem, semLabel, totalAtt, presentAtt, absentAtt, lateAtt, attPct, isAr) {
  const statusMap = {
    present: { label:'حاضر',    color:'var(--green)',   icon:'fa-check-circle',   badge:'b-green' },
    late:    { label:'متأخر',    color:'var(--gold)',    icon:'fa-clock',          badge:'b-gold' },
    absent:  { label:'غائب',     color:'var(--red)',     icon:'fa-times-circle',   badge:'b-red' },
    excused: { label:'معذور',    color:'var(--purple2)', icon:'fa-info-circle',    badge:'b-purple' },
  };

  // إحصاءات الحضور للفصل
  const statsRow = `
    <div class="card" style="margin-bottom:14px">
      <div class="card-h">
        <h3><i class="fas fa-chart-bar" style="color:var(--primary2)"></i> ملخص حضور الفصل — ${esc(semLabel)}</h3>
        <button class="btn bo btn-xs" onclick="_spRefreshLog()" title="تحديث السجل">
          <i class="fas fa-sync-alt"></i> تحديث
        </button>
      </div>
      <div style="padding:16px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
        ${[
          { label:'حاضر',  val:presentAtt, color:'var(--green)',   icon:'fa-check-circle' },
          { label:'متأخر',  val:lateAtt,   color:'var(--gold)',    icon:'fa-clock' },
          { label:'غائب',   val:absentAtt, color:'var(--red)',     icon:'fa-times-circle' },
          { label:'إجمالي', val:totalAtt,  color:'var(--primary2)', icon:'fa-list-ol' },
        ].map(s => `
          <div style="text-align:center;padding:10px;background:var(--bg);border-radius:10px">
            <div style="font-size:22px;font-weight:900;color:${s.color}">${s.val}</div>
            <div style="font-size:11px;color:var(--txt3);margin-top:2px"><i class="fas ${s.icon}" style="margin-left:3px"></i>${s.label}</div>
          </div>`).join('')}
      </div>
      ${totalAtt > 0 ? `
        <div style="padding:0 16px 16px">
          <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;margin-bottom:5px">
            <span>نسبة الحضور الكلية</span>
            <span style="color:${attPct>=75?'var(--green)':attPct>=50?'var(--gold)':'var(--red)'}">${attPct}%</span>
          </div>
          <div style="height:10px;background:var(--border);border-radius:5px;overflow:hidden">
            <div style="width:${attPct}%;height:100%;background:${attPct>=75?'var(--green)':attPct>=50?'var(--gold)':'var(--red)'};border-radius:5px;transition:width .6s"></div>
          </div>
          ${attPct < 75 ? `<div style="font-size:11px;color:var(--red);margin-top:6px"><i class="fas fa-exclamation-triangle" style="margin-left:4px"></i>نسبة الحضور أقل من 75%</div>` : ''}
        </div>` : ''}
    </div>`;

  // سجل تفصيلي
  const allPast = [...pastExams].reverse();
  const logRows = allPast.length ? allPast.map(e => {
    const sub    = getSubject(e.subject_id);
    const st     = STATE._studentAttendance?.[e.id];
    const stInfo = statusMap[st] || { label:'غير مسجل', color:'var(--txt3)', icon:'fa-minus-circle', badge:'b-gray' };
    return `
      <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);transition:background .15s"
           onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
        <div style="width:40px;height:40px;border-radius:10px;background:${stInfo.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas ${stInfo.icon}" style="color:${stInfo.color};font-size:16px"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:13px">${esc(sub?.name || '—')}</div>
          <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">
            <i class="fas fa-calendar" style="color:var(--primary2);margin-left:4px"></i>${fmtDate(e.date)}
            <i class="fas fa-clock" style="color:var(--gold);margin-right:8px;margin-left:4px"></i>${fmtTime(e.time)}
          </div>
        </div>
        <span class="badge ${stInfo.badge}" style="white-space:nowrap">${stInfo.label}</span>
      </div>`;
  }).join('') : `
    <div style="text-align:center;padding:40px;color:var(--txt3)">
      <i class="fas fa-history" style="font-size:36px;opacity:.25;margin-bottom:12px"></i>
      <div style="font-size:13px;font-weight:700">لا سجلات حضور في هذا الفصل</div>
    </div>`;

  return statsRow + `
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-clipboard-check" style="color:var(--green)"></i> تفاصيل سجل الحضور</h3>
        <span class="badge b-blue">${allPast.length} سجل</span>
      </div>
      ${logRows}
    </div>`;
}

// ════════════════════════════════════════════════════════════════
//  تسجيل بصمة الطالب من بوابته الشخصية
// ════════════════════════════════════════════════════════════════

async function openStudentBioSelf() {
  const student = STATE._studentUser;
  if (!student) return;
  const supported = await BIO.isAvailable();
  let creds = [];
  try { creds = await BIO.listForStudent(student.id); } catch {}

  const mo = document.createElement('div');
  mo.className = 'mo';
  mo.id = 'stuBioSelfMo';
  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-fingerprint" style="color:var(--purple2)"></i> تسجيل الدخول بالبصمة</h2>
      <button class="md-close" onclick="this.closest('.mo').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:20px">
      ${!supported ? `
        <div style="padding:18px;border:1px solid var(--red);background:var(--red-bg);border-radius:12px;color:var(--red2);text-align:center">
          <i class="fas fa-exclamation-triangle" style="font-size:24px"></i>
          <div style="margin-top:8px;font-weight:700">جهازك لا يدعم البصمة</div>
          <div style="font-size:12px;margin-top:4px">استخدم هاتفاً به Touch ID / Face ID</div>
        </div>` : `
        <div style="text-align:center;margin-bottom:20px">
          <div style="width:80px;height:80px;background:var(--purple2)18;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px">
            <i class="fas fa-fingerprint" style="font-size:36px;color:var(--purple2)"></i>
          </div>
          <div style="font-size:13px;color:var(--txt2);line-height:1.7">
            سجّل بصمتك لتسجيل الدخول السريع<br>ولتسجيل حضور الامتحانات تلقائياً
          </div>
        </div>

        ${creds.length ? `
          <div style="margin-bottom:14px;font-size:12.5px">
            <div style="font-weight:700;margin-bottom:8px">البصمات المسجلة (${creds.length}):</div>
            ${creds.map(c => `
              <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid var(--border);border-radius:9px;margin-bottom:6px;background:var(--bg)">
                <i class="fas fa-fingerprint" style="color:var(--purple2)"></i>
                <div style="flex:1;">
                  <div style="font-weight:600;font-size:12px">${esc(c.device_label||'جهاز')}</div>
                  <div style="font-size:10.5px;color:var(--txt3)">${c.created_at?new Date(c.created_at).toLocaleDateString('ar'):'—'}</div>
                </div>
              </div>`).join('')}
          </div>
          <button class="btn bp btn-sm" style="width:100%" onclick="_registerStudentBioSelf()">
            <i class="fas fa-plus"></i> إضافة جهاز آخر
          </button>
        ` : `
          <button class="btn bp" style="width:100%;padding:14px;font-size:14px" id="stuBioBtnReg" onclick="_registerStudentBioSelf()">
            <i class="fas fa-fingerprint" style="font-size:20px;margin-left:8px"></i>
            تسجيل بصمتي الآن
          </button>
        `}
        <div style="margin-top:12px;font-size:11px;color:var(--txt3);text-align:center;line-height:1.7">
          <i class="fas fa-shield-alt" style="color:var(--green)"></i>
          البصمة مشفرة ومحلية على جهازك — آمنة تماماً
        </div>`}
    </div>
  </div>`;
  document.body.appendChild(mo);
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _registerStudentBioSelf() {
  const student = STATE._studentUser;
  if (!student) return;
  const btn = document.getElementById('stuBioBtnReg') || document.querySelector('#stuBioSelfMo .btn.bp, #stuBioSelfMo .btn.bs');
  if (btn) { btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> ضع إصبعك على المستشعر...'; }
  try {
    await BIO.register(student);
    toast('✓ تم تسجيل بصمتك بنجاح', 'success');
    // تحديث الـ modal
    const mo = document.getElementById('stuBioSelfMo');
    if (mo) mo.classList.remove('open');
    setTimeout(() => mo?.remove(), 300);
    openStudentBioSelf();
  } catch(e) {
    toast(e.message||'فشل التسجيل', 'error');
    if (btn) { btn.disabled=false; btn.innerHTML='<i class="fas fa-fingerprint" style="font-size:20px;margin-left:8px"></i> تسجيل بصمتي الآن'; }
  }
}
