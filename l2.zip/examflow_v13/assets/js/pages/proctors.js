// proctors.js v10 — المراقبون: تصميم احترافي متطور

let _proctSearchQ    = '';
let _proctDeptFilter = '';
let _proctSortBy     = 'points_desc';

// ═══════════════════════════════════════════════════════════════
//  renderProctors — نقطة الدخول الرئيسية
// ═══════════════════════════════════════════════════════════════
function renderProctors() {
  const isAr = I18N.isAr();
  if (!canEdit() && !isProctor()) {
    setHTML('proctorContent', emptyState('fa-lock', 'غير مصرح'));
    return;
  }
  if (isProctor()) { _renderProctorSelfProfile(); return; }

  let proctors = STATE.profiles.filter(p => p.role === 'proctor');
  if (isDeptHead()) proctors = proctors.filter(p => p.dept_id === STATE.currentUser?.dept_id);
  if (isCoord()) setHTML('proctorsActs','');

  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const load = {};
  semExams.forEach(e => (e.proctor_ids||[]).forEach(pid => { load[pid] = (load[pid]||0)+1; }));

  const sorted      = [...proctors].sort((a,b) => (b.points||0)-(a.points||0));
  const totalPoints = proctors.reduce((s,p) => s+(p.points||0), 0);
  const avgPoints   = proctors.length ? Math.round(totalPoints/proctors.length) : 0;
  const activeCnt   = proctors.filter(p => p.active).length;
  const noConflict  = proctors.filter(p => _proctorHasNoConflict(p,semExams)).length;
  const maxPts      = sorted[0]?.points || 1;

  setHTML('proctorsActs', `
    <div style="display:flex;gap:8px">
      <button class="btn bo btn-sm" onclick="exportProctorsCSV()">
        <i class="fas fa-file-csv"></i> تصدير CSV
      </button>
      <button class="btn bo btn-sm" onclick="exportProctorsPDF()">
        <i class="fas fa-file-pdf" style="color:var(--red2)"></i> PDF
      </button>
    </div>`);

  setHTML('proctorContent', `

    <!-- ── Hero Stats ─────────────────────────────────────── -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
      ${_statCard2(activeCnt, 'مراقب نشط', 'fa-user-tie', '#8b5cf6', '#ede9fe')}
      ${_statCard2(totalPoints, 'مجموع النقاط', 'fa-star', '#f59e0b', '#fef3c7')}
      ${_statCard2(avgPoints, 'متوسط النقاط', 'fa-chart-line', '#3b82f6', '#dbeafe')}
      ${_statCard2(noConflict, 'بدون تعارض', 'fa-check-shield', '#10b981', '#d1fae5')}
    </div>

    <!-- ── Podium أفضل 3 ────────────────────────────────── -->
    ${sorted.length >= 3 ? _buildPodium(sorted, load, isAr) : ''}

    <!-- ── بطاقة البحث والفلتر ──────────────────────────── -->
    <div class="card" style="margin-bottom:16px;overflow:visible">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">

        <!-- فلاتر ذكية -->
        <div style="display:flex;flex-wrap:wrap;gap:7px;margin-bottom:14px">
          ${[
            {key:'all',       label:'الكل',          icon:'fa-list',              color:'var(--txt2)'},
            {key:'no_conflict',label:'بدون تعارض',   icon:'fa-check-circle',      color:'var(--green2)'},
            {key:'top10',      label:'أعلى 10',       icon:'fa-trophy',            color:'var(--gold)'},
            {key:'low_load',   label:'حمل خفيف',      icon:'fa-feather-alt',       color:'var(--teal)'},
            {key:'active_only',label:'نشطون',         icon:'fa-circle',            color:'var(--primary2)'},
            {key:'conflicts',  label:'لديهم تعارض',   icon:'fa-exclamation-triangle', color:'var(--red2)'},
          ].map(f => `<button onclick="applyProctorSuggestion('${f.key}')"
            class="proct-filter-btn"
            style="display:flex;align-items:center;gap:5px;padding:6px 12px;border:1.5px solid ${f.color}30;
            border-radius:20px;background:${f.color}08;color:${f.color};font-size:12px;font-weight:700;
            cursor:pointer;transition:all .15s;font-family:inherit"
            onmouseover="this.style.background='${f.color}20';this.style.borderColor='${f.color}'"
            onmouseout="this.style.background='${f.color}08';this.style.borderColor='${f.color}30'">
            <i class="fas ${f.icon}" style="font-size:11px"></i> ${f.label}
          </button>`).join('')}
          <button onclick="applyProctorSuggestion('reset')"
            style="display:flex;align-items:center;gap:5px;padding:6px 12px;border:1.5px solid var(--border);
            border-radius:20px;background:var(--bg);color:var(--txt3);font-size:12px;font-weight:700;
            cursor:pointer;transition:all .15s;font-family:inherit"
            onmouseover="this.style.background='var(--card)'" onmouseout="this.style.background='var(--bg)'">
            <i class="fas fa-undo" style="font-size:11px"></i> مسح الفلتر
          </button>
        </div>

        <!-- شريط البحث والترتيب -->
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <div class="sbar" style="flex:1;min-width:200px">
            <i class="fas fa-search" style="opacity:.6"></i>
            <input type="text" id="proctSrch" placeholder="بحث بالاسم أو الرقم الوظيفي..."
              oninput="_proctSearchQ=this.value;filterProctors()" style="font-size:13px">
          </div>
          <select id="proctDeptF" onchange="_proctDeptFilter=this.value;filterProctors()"
            style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;min-width:140px;background:var(--surface)">
            <option value="">كل الأقسام</option>
            ${STATE.departments.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}
          </select>
          <select id="proctSortF" onchange="_proctSortBy=this.value;filterProctors()"
            style="height:36px;border:1.5px solid var(--border);border-radius:8px;padding:0 10px;font-size:12.5px;min-width:140px;background:var(--surface)">
            <option value="points_desc">⭐ الأعلى نقاطاً</option>
            <option value="points_asc">📉 الأقل نقاطاً</option>
            <option value="load_desc">📋 الأكثر مراقبة</option>
            <option value="load_asc">🕊️ الأقل مراقبة</option>
            <option value="name">🔤 الاسم أبجدياً</option>
          </select>
        </div>
      </div>
      <div id="proctList"></div>
    </div>

    <!-- ── Analytics ────────────────────────────────────── -->
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-chart-bar" style="color:var(--purple2)"></i> تحليلات المراقبين</h3>
        <span style="font-size:12px;color:var(--txt3)">${proctors.length} مراقب</span>
      </div>
      <div style="padding:18px 20px">
        ${_buildProctorAnalytics(proctors, semExams, load, isAr)}
      </div>
    </div>`);

  _renderProctList(proctors, semExams, load, maxPts);
}

// ── بطاقة إحصاء صغيرة ────────────────────────────────────────
function _statCard2(val, lbl, icon, color, bg) {
  return `<div style="padding:16px 14px;border-radius:14px;background:${bg};border:1px solid ${color}20;display:flex;align-items:center;gap:12px">
    <div style="width:44px;height:44px;border-radius:12px;background:${color}25;display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <i class="fas ${icon}" style="color:${color};font-size:18px"></i>
    </div>
    <div>
      <div style="font-size:24px;font-weight:900;color:${color};line-height:1">${val}</div>
      <div style="font-size:11px;color:${color}90;font-weight:700;margin-top:3px">${lbl}</div>
    </div>
  </div>`;
}

// ── منصة التتويج — أفضل 3 ────────────────────────────────────
function _buildPodium(sorted, load, isAr) {
  const medals = [
    {rank:2,pos:sorted[1],  emoji:'🥈', h:70,  bg:'linear-gradient(135deg,#94a3b8,#64748b)', color:'#94a3b8'},
    {rank:1,pos:sorted[0],  emoji:'🥇', h:100, bg:'linear-gradient(135deg,#f59e0b,#d97706)', color:'#f59e0b'},
    {rank:3,pos:sorted[2],  emoji:'🥉', h:50,  bg:'linear-gradient(135deg,#cd7c2f,#a0622a)', color:'#cd7c2f'},
  ];

  return `<div style="margin-bottom:20px">
    <div style="text-align:center;font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:16px">
      <i class="fas fa-trophy" style="color:var(--gold);margin-left:6px"></i>قائمة المتصدرين — الفصل الحالي
    </div>
    <div style="display:flex;align-items:flex-end;justify-content:center;gap:10px;direction:ltr">
      ${medals.map(m => {
        const p = m.pos; if (!p) return '';
        const myLoad = load[p.id]||0;
        const dept = STATE.departments.find(d=>d.id===p.dept_id);
        return `<div style="display:flex;flex-direction:column;align-items:center;cursor:pointer;min-width:110px"
          onclick="openUserProfile('${p.id}')">
          <div style="font-size:28px;margin-bottom:6px" title="المركز ${m.rank}">${m.emoji}</div>
          ${userAvatar(p,46)}
          <div style="font-weight:800;font-size:12.5px;margin-top:8px;text-align:center;max-width:110px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${esc(p.name?.split(' ').slice(0,2).join(' '))}
          </div>
          ${dept?`<div style="font-size:10px;color:${dept.color||'var(--txt3)'};font-weight:700;margin-top:2px">${esc(dept.name)}</div>`:''}
          <div style="height:${m.h}px;width:90px;${m.bg};border-radius:10px 10px 0 0;margin-top:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;box-shadow:0 4px 16px rgba(0,0,0,.15)">
            <div style="font-size:24px;font-weight:900;color:white">${p.points||0}</div>
            <div style="font-size:10px;color:rgba(255,255,255,.8)">${myLoad} امتحان</div>
          </div>
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

// ── عرض قائمة المراقبين ──────────────────────────────────────
function _proctorHasNoConflict(proctor, semExams) {
  const myExams = semExams.filter(e => (e.proctor_ids||[]).includes(proctor.id));
  for (let i=0; i<myExams.length; i++) {
    for (let j=i+1; j<myExams.length; j++) {
      const a=myExams[i], b=myExams[j];
      if (a.date!==b.date) continue;
      const aS=new Date(`${a.date}T${a.time}`), aE=new Date(aS.getTime()+(a.duration||60)*60000);
      const bS=new Date(`${b.date}T${b.time}`), bE=new Date(bS.getTime()+(b.duration||60)*60000);
      if (aS<bE && bS<aE) return false;
    }
  }
  return true;
}

function applyProctorSuggestion(type) {
  let allProctors = STATE.profiles.filter(p => p.role === 'proctor');
  if (isDeptHead()) allProctors = allProctors.filter(p => p.dept_id === STATE.currentUser?.dept_id);
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const load = {};
  semExams.forEach(e => (e.proctor_ids||[]).forEach(pid => { load[pid]=(load[pid]||0)+1; }));

  let filtered = [...allProctors];
  let msg = '';
  switch(type) {
    case 'no_conflict':  filtered = allProctors.filter(p=>_proctorHasNoConflict(p,semExams)); msg='بدون تعارض'; break;
    case 'conflicts':    filtered = allProctors.filter(p=>!_proctorHasNoConflict(p,semExams)); msg='لديهم تعارض'; break;
    case 'top10':        filtered = [...allProctors].sort((a,b)=>(b.points||0)-(a.points||0)).slice(0,10); msg='أعلى 10 نقاطاً'; break;
    case 'low_load':     filtered = allProctors.filter(p=>(load[p.id]||0)<=2); msg='حمل خفيف'; break;
    case 'active_only':  filtered = allProctors.filter(p=>p.active); msg='نشطون فقط'; break;
    case 'reset':        _proctSearchQ=''; _proctDeptFilter=''; _proctSortBy='points_desc';
                         filtered = allProctors; msg='تم مسح الفلتر'; break;
    default:             filtered = allProctors;
  }
  const maxPts = [...allProctors].sort((a,b)=>(b.points||0)-(a.points||0))[0]?.points || 1;
  _renderProctList(filtered, semExams, load, maxPts);
  if (msg) toast(`✓ ${msg} · ${filtered.length} مراقب`, 'success');
}

function filterProctors() {
  const q    = (document.getElementById('proctSrch')?.value||'').toLowerCase();
  const dept = document.getElementById('proctDeptF')?.value||'';
  const sort = document.getElementById('proctSortF')?.value||'points_desc';
  _proctSearchQ=q; _proctDeptFilter=dept; _proctSortBy=sort;

  const semExams = STATE.exams.filter(e=>e.semester===STATE.currentSem);
  const load={};
  semExams.forEach(e=>(e.proctor_ids||[]).forEach(pid=>{load[pid]=(load[pid]||0)+1;}));

  let f = STATE.profiles.filter(p=>p.role==='proctor');
  if (isDeptHead()) f = f.filter(p=>p.dept_id===STATE.currentUser?.dept_id);
  if (q)    f = f.filter(p=>p.name?.toLowerCase().includes(q)||p.emp_id?.toLowerCase().includes(q));
  if (dept) f = f.filter(p=>String(p.dept_id)===dept);

  switch(sort) {
    case 'points_desc': f.sort((a,b)=>(b.points||0)-(a.points||0)); break;
    case 'points_asc':  f.sort((a,b)=>(a.points||0)-(b.points||0)); break;
    case 'load_desc':   f.sort((a,b)=>(load[b.id]||0)-(load[a.id]||0)); break;
    case 'load_asc':    f.sort((a,b)=>(load[a.id]||0)-(load[b.id]||0)); break;
    case 'name':        f.sort((a,b)=>(a.name||'').localeCompare(b.name||'')); break;
  }
  const maxPts = STATE.profiles.filter(p=>p.role==='proctor').reduce((m,p)=>Math.max(m,p.points||0),1);
  _renderProctList(f, semExams, load, maxPts);
}

// ── بناء قائمة المراقبين الاحترافية ──────────────────────────
function _renderProctList(proctors, semExams, load, maxPts=1) {
  const el = document.getElementById('proctList');
  if (!el) return;
  if (!proctors.length) {
    el.innerHTML = `<div style="padding:40px;text-align:center;color:var(--txt3)">
      <i class="fas fa-search" style="font-size:32px;opacity:.2;display:block;margin-bottom:12px"></i>
      <div style="font-weight:700;margin-bottom:4px">لا يوجد مراقبون مطابقون</div>
      <div style="font-size:13px">جرّب تغيير فلتر البحث</div>
    </div>`;
    return;
  }

  el.innerHTML = proctors.map((p, i) => {
    const dept       = STATE.departments.find(d => d.id === p.dept_id);
    const myLoad     = load?.[p.id] || 0;
    const hasConflict= !_proctorHasNoConflict(p, semExams);
    const loadPct    = Math.min(100, (myLoad/8)*100);
    const ptsPct     = Math.min(100, ((p.points||0)/maxPts)*100);
    const rankMedal  = i===0?'🥇':i===1?'🥈':i===2?'🥉':'';
    const rankColor  = i===0?'#f59e0b':i===1?'#94a3b8':i===2?'#cd7c2f':'var(--txt3)';
    const myExams    = semExams.filter(e=>(e.proctor_ids||[]).includes(p.id));
    const completed  = myExams.filter(e=>examStatus(e)==='completed').length;

    return `<div style="display:flex;align-items:center;gap:13px;padding:14px 20px;border-bottom:1px solid var(--border);
        transition:background .15s;cursor:pointer;position:relative"
      onmouseover="this.style.background='var(--bg)';this.querySelector('.proct-actions').style.opacity='1'"
      onmouseout="this.style.background='';this.querySelector('.proct-actions').style.opacity='0'"
      onclick="openUserProfile('${p.id}')">

      <!-- الترتيب -->
      <div style="min-width:36px;text-align:center;flex-shrink:0">
        ${rankMedal
          ? `<span style="font-size:22px">${rankMedal}</span>`
          : `<span style="font-size:13px;font-weight:800;color:var(--txt3)">${i+1}</span>`}
      </div>

      <!-- الأفاتار -->
      ${userAvatar(p, 44)}

      <!-- المعلومات الرئيسية -->
      <div style="flex:1;min-width:0">
        <div style="font-weight:800;font-size:14px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:3px">
          ${esc(p.name?.split(' ').slice(0,3).join(' '))}
          ${hasConflict?`<span class="badge b-red" style="font-size:9px"><i class="fas fa-exclamation-triangle"></i> تعارض</span>`:`<span style="font-size:11px;color:var(--green2)" title="لا يوجد تعارض"><i class="fas fa-check-circle"></i></span>`}
          ${!p.active?`<span class="badge b-gray" style="font-size:9px">موقوف</span>`:''}
        </div>
        <div style="font-size:11.5px;color:var(--txt2);display:flex;gap:10px;flex-wrap:wrap;margin-bottom:6px">
          ${p.emp_id?`<span><i class="fas fa-id-badge" style="opacity:.5;margin-left:3px"></i>${esc(p.emp_id)}</span>`:''}
          ${dept?`<span style="color:${dept.color||'var(--primary2)'};font-weight:700"><i class="fas fa-sitemap" style="opacity:.6;margin-left:3px;font-size:9px"></i>${esc(dept.name)}</span>`:''}
          <span><i class="fas fa-file-alt" style="opacity:.5;margin-left:3px"></i>${myLoad} امتحان · ${completed} مكتمل</span>
        </div>
        <!-- شريطا التقدم -->
        <div style="display:flex;flex-direction:column;gap:4px">
          <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:10px;color:var(--txt3);min-width:32px">حمل</span>
            <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
              <div style="height:100%;width:${loadPct}%;background:${loadPct>75?'var(--red2)':loadPct>50?'var(--gold)':'var(--primary2)'};border-radius:3px;transition:width .6s ease"></div>
            </div>
            <span style="font-size:10px;color:var(--txt3);min-width:24px">${myLoad}</span>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:10px;color:var(--txt3);min-width:32px">نقاط</span>
            <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
              <div style="height:100%;width:${ptsPct}%;background:var(--gold);border-radius:3px;transition:width .6s ease"></div>
            </div>
            <span style="font-size:10px;color:var(--txt3);min-width:24px">${p.points||0}</span>
          </div>
        </div>
      </div>

      <!-- النقاط والتقييم -->
      <div style="text-align:center;min-width:68px;flex-shrink:0">
        <div style="font-size:26px;font-weight:900;color:${rankColor};line-height:1">${p.points||0}</div>
        <div style="font-size:9.5px;color:var(--txt3);margin-top:1px">نقطة</div>
        <div style="display:flex;gap:1px;justify-content:center;margin-top:4px">${_buildStars(p.avg_rating||0)}</div>
      </div>

      <!-- أزرار الإجراءات -->
      <div class="proct-actions" style="display:flex;flex-direction:column;gap:5px;flex-shrink:0;opacity:0;transition:opacity .15s" onclick="event.stopPropagation()">
        <button class="btn bo btn-xs" style="border-radius:8px" onclick="openUserProfile('${p.id}')" title="البروفايل">
          <i class="fas fa-id-card" style="color:var(--primary2)"></i>
        </button>
        ${isAdmin()?`<button class="btn bo btn-xs" style="border-radius:8px" onclick="openEditUser('${p.id}')" title="تعديل">
          <i class="fas fa-edit"></i>
        </button>`:''}
        ${(isAdmin()||isDeptHead())?`<button class="btn bo btn-xs" style="border-radius:8px;border-color:var(--gold)30" onclick="openRateProctor('${p.id}')" title="تقييم">
          <i class="fas fa-star" style="color:var(--gold)"></i>
        </button>`:''}
      </div>
    </div>`;
  }).join('');
}


function _buildProctorAnalytics(proctors, semExams, load, isAr) {
  if (!proctors.length) return `<p style="color:var(--txt3);font-size:13px">${isAr ? 'لا توجد بيانات' : 'No data'}</p>`;

  const ranges = [
    { label: isAr ? '0-5 نقطة' : '0-5 pts',   count: proctors.filter(p => (p.points||0) <= 5).length },
    { label: isAr ? '6-15 نقطة' : '6-15 pts',  count: proctors.filter(p => (p.points||0) > 5  && (p.points||0) <= 15).length },
    { label: isAr ? '16-30 نقطة' : '16-30 pts', count: proctors.filter(p => (p.points||0) > 15 && (p.points||0) <= 30).length },
    { label: isAr ? '30+ نقطة' : '30+ pts',    count: proctors.filter(p => (p.points||0) > 30).length },
  ];
  const maxRange = Math.max(...ranges.map(r => r.count), 1);

  const loadRanges = [
    { label: isAr ? '0 امتحانات' : '0 exams',   count: proctors.filter(p => (load[p.id]||0) === 0).length },
    { label: isAr ? '1-3 امتحانات' : '1-3 exams', count: proctors.filter(p => (load[p.id]||0) >= 1 && (load[p.id]||0) <= 3).length },
    { label: isAr ? '4-6 امتحانات' : '4-6 exams', count: proctors.filter(p => (load[p.id]||0) >= 4 && (load[p.id]||0) <= 6).length },
    { label: isAr ? '7+ امتحانات' : '7+ exams',  count: proctors.filter(p => (load[p.id]||0) >= 7).length },
  ];
  const maxLoad = Math.max(...loadRanges.map(r => r.count), 1);

  const conflictCount = proctors.filter(p => !_proctorHasNoConflict(p, semExams)).length;

  return `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:16px">
      <div>
        <div style="font-size:12px;font-weight:800;color:var(--txt2);margin-bottom:12px"><i class="fas fa-star" style="color:var(--gold);margin-inline-end:6px"></i>${isAr ? 'توزيع النقاط' : 'Points Distribution'}</div>
        ${ranges.map(r => `
          <div style="margin-bottom:8px">
            <div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px">
              <span style="font-weight:600">${r.label}</span>
              <span style="color:var(--txt3)">${r.count} ${isAr ? 'مراقب' : ''}</span>
            </div>
            <div style="background:var(--bg);border-radius:4px;height:8px;overflow:hidden">
              <div style="width:${(r.count/maxRange*100).toFixed(0)}%;height:100%;background:var(--gold);border-radius:4px"></div>
            </div>
          </div>`).join('')}
      </div>
      <div>
        <div style="font-size:12px;font-weight:800;color:var(--txt2);margin-bottom:12px"><i class="fas fa-file-alt" style="color:var(--primary2);margin-inline-end:6px"></i>${isAr ? 'توزيع الامتحانات' : 'Exam Load'}</div>
        ${loadRanges.map(r => `
          <div style="margin-bottom:8px">
            <div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px">
              <span style="font-weight:600">${r.label}</span>
              <span style="color:var(--txt3)">${r.count} ${isAr ? 'مراقب' : ''}</span>
            </div>
            <div style="background:var(--bg);border-radius:4px;height:8px;overflow:hidden">
              <div style="width:${(r.count/maxLoad*100).toFixed(0)}%;height:100%;background:var(--primary2);border-radius:4px"></div>
            </div>
          </div>`).join('')}
      </div>
    </div>
    <div style="padding:12px 14px;background:var(--gold-bg);border-radius:10px;border:1px solid rgba(234,179,8,.2)">
      <div style="font-size:11.5px;font-weight:800;color:var(--gold);margin-bottom:8px"><i class="fas fa-lightbulb"></i> ${isAr ? 'مقترحات ذكية' : 'Smart Suggestions'}</div>
      <div style="font-size:12px;color:var(--txt2);line-height:2">
        ${proctors.filter(p=>!p.active).length > 0 ? `• ${proctors.filter(p=>!p.active).length} ${isAr ? 'مراقب موقوف — راجع حالتهم' : 'inactive proctors need review'}<br>` : ''}
        ${proctors.filter(p=>(load[p.id]||0)===0).length > 0 ? `• ${proctors.filter(p=>(load[p.id]||0)===0).length} ${isAr ? 'مراقب لم يُعيَّن لأي امتحان هذا الفصل' : 'proctors have no assignments'}<br>` : ''}
        ${proctors.filter(p=>(load[p.id]||0)>6).length > 0 ? `• ${proctors.filter(p=>(load[p.id]||0)>6).length} ${isAr ? 'مراقب لديهم أكثر من 6 امتحانات (حمل ثقيل)' : 'proctors with 6+ exams (heavy load)'}<br>` : ''}
        ${conflictCount > 0
          ? `• <span style="color:var(--red);font-weight:700">${conflictCount} ${isAr ? 'مراقب لديهم تعارض في المواعيد!' : 'proctors have scheduling conflicts!'}</span><br>`
          : `• <span style="color:var(--green);font-weight:700">${isAr ? '✓ لا يوجد تعارضات في الجدول' : '✓ No scheduling conflicts detected'}</span><br>`}
      </div>
    </div>`;
}

function exportProctorsCSV() {
  const isAr = I18N.isAr();
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const load = {};
  semExams.forEach(e => (e.proctor_ids||[]).forEach(pid => { load[pid]=(load[pid]||0)+1; }));
  const rows = [['الاسم','الرقم الوظيفي','البريد','القسم','النقاط','عدد الامتحانات','الحالة','تعارض']];
  STATE.profiles.filter(p=>p.role==='proctor').forEach(p => {
    const dept = STATE.departments.find(d=>d.id===p.dept_id);
    rows.push([p.name,p.emp_id||'',p.email||'',dept?.name||'',p.points||0,load[p.id]||0,p.active?'نشط':'موقوف',_proctorHasNoConflict(p,semExams)?'لا':'نعم']);
  });
  const csv = rows.map(r=>r.map(v=>`"${v}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});
  const a = Object.assign(document.createElement('a'),{href:URL.createObjectURL(blob),download:'proctors.csv'});
  document.body.appendChild(a);a.click();a.remove();
  toast(isAr ? '✓ تم تصدير بيانات المراقبين' : '✓ Proctors exported','success');
}

function exportProctorsPDF() {
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem);
  const load = {};
  semExams.forEach(e => (e.proctor_ids||[]).forEach(pid => { load[pid]=(load[pid]||0)+1; }));
  const proctors = [...STATE.profiles.filter(p=>p.role==='proctor')].sort((a,b)=>(b.points||0)-(a.points||0));
  const w = window.open('','_blank','width=900,height=700');
  w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>تقرير المراقبين</title>
  <style>body{font-family:Arial,sans-serif;padding:32px;color:#111}h1{color:#7c3aed;text-align:center}
  table{border-collapse:collapse;width:100%}td,th{padding:8px 12px;border:1px solid #ddd;font-size:12px}
  th{background:#f1f5f9;font-weight:700}tr:nth-child(even){background:#faf5ff}
  .g{color:green}.r{color:red}.conf{color:orange}</style></head><body>
  <h1>👔 تقرير المراقبين</h1>
  <p style="text-align:center;color:#666">الفصل الدراسي: ${STATE.currentSem} · الإجمالي: ${proctors.length} مراقب</p>
  <table><tr><th>#</th><th>الاسم</th><th>الرقم الوظيفي</th><th>القسم</th><th>النقاط</th><th>الامتحانات</th><th>الحالة</th><th>تعارض</th></tr>
  ${proctors.map((p,i)=>{
    const dept=STATE.departments.find(d=>d.id===p.dept_id);
    const hasC=!_proctorHasNoConflict(p,semExams);
    return `<tr><td>${i+1}</td><td>${p.name}</td><td>${p.emp_id||'—'}</td><td>${dept?.name||'—'}</td><td><b>${p.points||0}</b></td><td>${load[p.id]||0}</td><td class="${p.active?'g':'r'}">${p.active?'نشط':'موقوف'}</td><td class="${hasC?'conf':'g'}">${hasC?'⚠ نعم':'✓ لا'}</td></tr>`;
  }).join('')}
  </table><script>window.onload=()=>{window.print()}<\/script></body></html>`);
  w.document.close();
}

// ═══════════════════════════════════════════════════════════════
//  FEATURE 3: نظام تقييم المراقبين المرتبط بالأداء الفعلي
// ═══════════════════════════════════════════════════════════════

function _buildStars(rating) {
  const r = Math.round(rating * 2) / 2;
  let html = '';
  for (let i = 1; i <= 5; i++) {
    if (r >= i) html += '<i class="fas fa-star" style="color:var(--gold);font-size:9px"></i>';
    else if (r >= i - 0.5) html += '<i class="fas fa-star-half-alt" style="color:var(--gold);font-size:9px"></i>';
    else html += '<i class="far fa-star" style="color:var(--txt3);font-size:9px"></i>';
  }
  return html;
}

function openRateProctor(proctorId) {
  const p = getProfile(proctorId);
  if (!p) return;

  // حساب الأداء الفعلي من البيانات
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(proctorId));
  const completedExams = semExams.filter(e => examStatus(e) === 'completed');
  const avgAtt = completedExams.length > 0 ? (() => {
    let total = 0, present = 0;
    completedExams.forEach(e => {
      const att = STATE.attendance[e.id] || {};
      Object.values(att).forEach(s => { total++; if (s==='present'||s==='late') present++; });
    });
    return total > 0 ? Math.round(present/total*100) : 0;
  })() : 0;

  const currentRating = p.avg_rating || 0;
  const currentPts    = p.points || 0;

  const mo = document.getElementById('rateProctMo') || (() => {
    const m = document.createElement('div'); m.className='mo'; m.id='rateProctMo'; document.body.appendChild(m); return m;
  })();

  mo.innerHTML = `<div class="md" style="max-width:480px">
    <div class="md-hd">
      <h2><i class="fas fa-star" style="color:var(--gold)"></i> تقييم أداء المراقب</h2>
      <button class="md-close" onclick="closeMo('rateProctMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <!-- بيانات المراقب -->
      <div style="display:flex;align-items:center;gap:14px;padding:14px;background:var(--bg);border-radius:12px;margin-bottom:18px">
        ${userAvatar(p, 48)}
        <div>
          <div style="font-weight:800;font-size:15px">${p.name}</div>
          <div style="font-size:12px;color:var(--txt2)">${p.emp_id||p.email||'—'}</div>
          <div style="display:flex;gap:6px;margin-top:4px;align-items:center">
            <span style="font-size:12px;color:var(--txt3)">${semExams.length} امتحان هذا الفصل</span>
            <span style="font-size:12px;color:var(--teal)">· نسبة حضور ${avgAtt}%</span>
          </div>
        </div>
      </div>

      <!-- مؤشرات الأداء التلقائية -->
      <div style="margin-bottom:18px">
        <div style="font-size:12px;font-weight:800;color:var(--txt3);margin-bottom:10px;letter-spacing:.5px">مؤشرات الأداء الفعلية</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
          <div style="text-align:center;padding:12px 8px;background:var(--card);border-radius:10px;border:1.5px solid var(--border)">
            <div style="font-size:20px;font-weight:900;color:var(--blue)">${completedExams.length}</div>
            <div style="font-size:10px;color:var(--txt3)">امتحانات أُنجزت</div>
          </div>
          <div style="text-align:center;padding:12px 8px;background:var(--card);border-radius:10px;border:1.5px solid var(--border)">
            <div style="font-size:20px;font-weight:900;color:${avgAtt>=80?'var(--green)':avgAtt>=60?'var(--gold)':'var(--red)'}">${avgAtt}%</div>
            <div style="font-size:10px;color:var(--txt3)">متوسط حضور الطلاب</div>
          </div>
          <div style="text-align:center;padding:12px 8px;background:var(--card);border-radius:10px;border:1.5px solid var(--border)">
            <div style="font-size:20px;font-weight:900;color:var(--gold)">${currentPts}</div>
            <div style="font-size:10px;color:var(--txt3)">النقاط الحالية</div>
          </div>
        </div>
      </div>

      <!-- التقييم بالنجوم -->
      <div style="margin-bottom:16px">
        <label class="field-lbl">تقييم الأداء العام</label>
        <div style="display:flex;gap:8px;margin-top:8px" id="starRatingRow">
          ${[1,2,3,4,5].map(n=>`
            <div onclick="_setStarRating(${n})" data-star="${n}" style="cursor:pointer;font-size:32px;transition:transform .15s"
                 onmouseover="this.style.transform='scale(1.2)'" onmouseout="this.style.transform=''">
              <i class="${n <= Math.round(currentRating) ? 'fas' : 'far'} fa-star" style="color:${n <= Math.round(currentRating) ? 'var(--gold)' : 'var(--txt3)'}"></i>
            </div>`).join('')}
          <span id="starLabel" style="font-size:13px;color:var(--txt2);align-self:center;margin-right:8px">
            ${['','ضعيف','مقبول','جيد','جيد جداً','ممتاز'][Math.round(currentRating)]||'اختر تقييماً'}
          </span>
        </div>
        <input type="hidden" id="ratingVal" value="${Math.round(currentRating)}">
      </div>

      <!-- النقاط اليدوية -->
      <div class="g2">
        <div class="field">
          <label class="field-lbl">نقاط إضافية / خصم</label>
          <input type="number" id="ratingPtsDelta" value="0" min="-50" max="50" style="height:40px">
          <div style="font-size:10.5px;color:var(--txt3);margin-top:3px">موجب لإضافة، سالب للخصم</div>
        </div>
        <div class="field">
          <label class="field-lbl">ملاحظة</label>
          <input type="text" id="ratingNote" placeholder="اختياري..." style="height:40px">
        </div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('rateProctMo')">إلغاء</button>
      <button class="btn bp" style="background:var(--gold);border-color:var(--gold)" onclick="submitProctorRating('${proctorId}')">
        <i class="fas fa-save"></i> حفظ التقييم
      </button>
    </div>
  </div>`;

  showMo('rateProctMo');
}

let _currentStarRating = 0;
function _setStarRating(n) {
  _currentStarRating = n;
  document.getElementById('ratingVal').value = n;
  const labels = ['','ضعيف','مقبول','جيد','جيد جداً','ممتاز'];
  const lbl = document.getElementById('starLabel');
  if (lbl) lbl.textContent = labels[n] || '';
  document.querySelectorAll('#starRatingRow [data-star]').forEach(el => {
    const star = parseInt(el.dataset.star);
    const icon = el.querySelector('i');
    if (icon) {
      icon.className = star <= n ? 'fas fa-star' : 'far fa-star';
      icon.style.color = star <= n ? 'var(--gold)' : 'var(--txt3)';
    }
  });
}

async function submitProctorRating(proctorId) {
  const rating   = parseInt(document.getElementById('ratingVal')?.value || 0);
  const delta    = parseInt(document.getElementById('ratingPtsDelta')?.value || 0);
  const note     = document.getElementById('ratingNote')?.value?.trim() || '';

  if (!rating) { toast('اختر تقييماً بالنجوم أولاً','warning'); return; }

  const p = getProfile(proctorId);
  if (!p) return;

  try {
    // حساب المتوسط التراكمي للتقييم
    const prevRatings = p.ratings || [];
    prevRatings.push({ rating, delta, note, date: new Date().toISOString(), by: STATE.currentUser?.name });
    const avgRating = prevRatings.reduce((s,r) => s + r.rating, 0) / prevRatings.length;

    // النقاط: كل نجمة = 3 نقاط + الدلتا اليدوي
    const autoPoints = rating * 3;
    const newPoints  = Math.max(0, (p.points||0) + autoPoints + delta);

    // حفظ في sem_x كـ fallback إذا لم تكن أعمدة التقييم موجودة
    const ratingData = {
      points: newPoints,
    };
    try { ratingData.avg_rating = Math.round(avgRating * 10) / 10; } catch{}
    try { ratingData.ratings = prevRatings; } catch{}
    
    await SB.update('profiles', proctorId, ratingData, 'id');

    // تحديث الحالة المحلية
    const idx = STATE.profiles.findIndex(u => u.id === proctorId);
    if (idx >= 0) {
      STATE.profiles[idx].avg_rating = Math.round(avgRating * 10) / 10;
      STATE.profiles[idx].points     = newPoints;
      STATE.profiles[idx].ratings    = prevRatings;
    }

    await addLog('تقييم مراقب', 'proctor', `${p.name} — ${rating} نجوم، ${delta >= 0 ? '+' : ''}${delta} نقطة`);
    closeMo('rateProctMo');
    renderProctors();
    toast(`✓ تم تقييم ${p.name?.split(' ')[0]} — ${rating} نجوم · ${autoPoints + delta >= 0 ? '+' : ''}${autoPoints+delta} نقطة`, 'success');
  } catch(e) { toast('خطأ: ' + e.message, 'error'); }
}

// ══ ملف المراقب الشخصي المتطور ════════════════════════════════
function _renderProctorSelfProfile() {
  const me  = STATE.currentUser;
  const uid = me?.id;
  setHTML('proctorsActs', '');

  // المواد المُضافة للمراقب مباشرةً (staff_ids)
  const mySubjectsLinked = STATE.subjects.filter(s => (s.staff_ids||[]).includes(uid));

  // الشعب الحالية (فقط الفصل الحالي)
  const mySections = STATE.sections.filter(s =>
    s.semester === STATE.currentSem &&
    mySubjectsLinked.some(subj => subj.id === s.subject_id)
  );

  // إذا لم توجد شعب في الفصل الحالي لا تُظهر المادة
  const subjectsWithCurrentSem = mySubjectsLinked.filter(subj =>
    mySections.some(s => s.subject_id === subj.id)
  );

  // الامتحانات المعلقة (تنتظر قبولي)
  const pendingExams = STATE.exams.filter(e =>
    (e.proctor_ids||[]).includes(uid) &&
    (e.proctor_statuses||{})[uid] === 'pending' &&
    e.semester === STATE.currentSem
  );

  // كل امتحانات الفصل الحالي (تاريخ المراقبة)
  const semExams = STATE.exams.filter(e =>
    e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(uid)
  );
  const historyExams = STATE.exams.filter(e =>
    e.semester !== STATE.currentSem && (e.proctor_ids||[]).includes(uid)
  ).sort((a,b) => new Date(`${b.date}T${b.time}`) - new Date(`${a.date}T${a.time}`));

  const dept = STATE.departments.find(d => d.id === me?.dept_id);

  setHTML('proctorContent', `
    <!-- Hero Card -->
    <div class="card" style="padding:24px;margin-bottom:16px;background:linear-gradient(135deg,var(--primary)08,var(--purple2)05);border:none;overflow:hidden;position:relative">
      <div style="position:absolute;top:-20px;right:-20px;width:180px;height:180px;border-radius:50%;background:var(--primary2)06;pointer-events:none"></div>
      <div style="display:flex;align-items:center;gap:18px;flex-wrap:wrap">
        ${userAvatar(me, 68)}
        <div style="flex:1">
          <div style="font-size:20px;font-weight:900;margin-bottom:4px">${esc(me.name||'—')}</div>
          <div style="font-size:13px;color:var(--txt2);margin-bottom:8px">${esc(me.email||'')} ${dept ? `· <span style="color:${dept.color||'var(--primary2)'}">${esc(dept.name)}</span>` : ''}</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <span class="badge b-green">${semExams.length} امتحان هذا الفصل</span>
            <span class="badge b-gold">${me.points||0} نقطة</span>
            ${me.rating ? `<span class="badge b-purple">⭐ ${me.rating.toFixed(1)}</span>` : ''}
            ${subjectsWithCurrentSem.length ? `<span class="badge b-blue">${subjectsWithCurrentSem.length} مقرر نشط</span>` : ''}
          </div>
        </div>
        <button class="btn bo" onclick="openProfile()"><i class="fas fa-user-edit"></i> تعديل الملف</button>
      </div>
    </div>

    <!-- طلبات المراقبة المعلقة -->
    ${pendingExams.length ? `
    <div class="card" style="margin-bottom:16px;border-right:4px solid var(--red2)">
      <div class="card-h">
        <h3><i class="fas fa-bell" style="color:var(--red2)"></i> طلبات مراقبة معلقة
          <span class="badge b-red">${pendingExams.length}</span>
        </h3>
      </div>
      <div class="card-b" style="padding:12px 16px">
        ${pendingExams.map(e => {
          const sub = getSubject(e.subject_id);
          const rp  = e.room_proctors || {};
          const myRid = (e.room_ids||[]).find(rid => {
            const assigned = rp[String(rid)];
            return assigned && assigned.includes(uid);
          });
          const myRoomName = myRid ? getRoom(myRid)?.name : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join('، ');
          return `<div style="padding:14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--red2)30;margin-bottom:10px">
            <div style="font-weight:800;font-size:14px;margin-bottom:6px">${sub?.name||'—'}</div>
            <div style="font-size:12px;color:var(--txt2);margin-bottom:8px;display:flex;gap:12px;flex-wrap:wrap">
              <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)}</span>
              <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)} (${e.duration}د)</span>
              ${myRoomName?`<span><i class="fas fa-door-open" style="color:var(--teal)"></i> ${myRoomName}</span>`:''}
            </div>
            <div style="display:flex;gap:8px">
              <button class="btn btn-sm" style="flex:1;background:var(--green2);color:white;border:none" onclick="proctorAcceptAssignment(${e.id})">
                <i class="fas fa-check"></i> قبول
              </button>
              <button class="btn btn-sm" style="flex:1;background:var(--red2)15;color:var(--red2);border:1px solid var(--red2)50" onclick="proctorRejectAssignment(${e.id})">
                <i class="fas fa-times"></i> رفض
              </button>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>` : ''}

    <!-- المحتوى الرئيسي -->
    <div style="display:grid;grid-template-columns:1fr 320px;gap:16px;align-items:start">
      <div>
        <!-- مقرراتي هذا الفصل -->
        <div class="card" style="margin-bottom:16px">
          <div class="card-h">
            <h3><i class="fas fa-book" style="color:var(--gold)"></i> مقرراتي وشعبي هذا الفصل</h3>
            <button class="btn bo btn-xs" onclick="UI.showPage('subjects')">المواد →</button>
          </div>
          <div class="card-b" style="padding:0">
            ${subjectsWithCurrentSem.length ? subjectsWithCurrentSem.map(subj => {
              const subSecs = mySections.filter(s => s.subject_id === subj.id);
              const studCount = subSecs.reduce((acc,s) => acc + (s.student_ids||[]).length, 0);
              const subjDept = STATE.departments.find(d => d.id === subj.dept_id);
              return `<div style="padding:14px 16px;border-bottom:1px solid var(--border)">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
                  <div style="width:36px;height:36px;border-radius:10px;background:${subjDept?.color||'var(--gold)'}15;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                    <i class="fas fa-book" style="color:${subjDept?.color||'var(--gold)'}"></i>
                  </div>
                  <div style="flex:1">
                    <div style="font-weight:800;font-size:13.5px">${esc(subj.name)}</div>
                    <div style="font-size:11px;color:var(--txt3)">${subj.code||''} · ${studCount} طالب في ${subSecs.length} شعبة</div>
                  </div>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:6px">
                  ${subSecs.map(s => {
                    const cnt = (s.student_ids||[]).length;
                    return `<div style="padding:6px 10px;background:var(--bg);border-radius:8px;border:1px solid var(--border);cursor:pointer" onclick="_openSectionStudents(${s.id},'${esc(s.name)}')">
                      <div style="font-size:12px;font-weight:700">${esc(s.name)}</div>
                      <div style="font-size:10.5px;color:var(--txt3)">${cnt} طالب</div>
                    </div>`;
                  }).join('')}
                </div>
              </div>`;
            }).join('') : `<div style="padding:24px;text-align:center;color:var(--txt3)"><i class="fas fa-book" style="font-size:24px;opacity:.3;display:block;margin-bottom:8px"></i>لا توجد مقررات نشطة لك هذا الفصل</div>`}
          </div>
        </div>

        <!-- امتحاناتي الحالية -->
        <div class="card">
          <div class="card-h">
            <h3><i class="fas fa-file-alt" style="color:var(--purple2)"></i> امتحاناتي هذا الفصل</h3>
            <button class="btn bo btn-xs" onclick="UI.showPage('exams')">الكل →</button>
          </div>
          <div class="card-b" style="padding:0">
            ${semExams.length ? semExams.sort((a,b)=>new Date(`${a.date}T${a.time}`)-new Date(`${b.date}T${b.time}`)).map(e => {
              const sub = getSubject(e.subject_id);
              const st  = examStatus(e);
              const rp  = e.room_proctors||{};
              const myRid = (e.room_ids||[]).find(rid=>{const a=rp[String(rid)];return a&&a.includes(uid);});
              const myRoomName = myRid ? getRoom(myRid)?.name : (e.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean).join('، ');
              const rsSecs = myRid ? ((e.room_sections||{})[String(myRid)] || []) : (e.section_ids||[]);
              const studCount = rsSecs.reduce((acc,sid)=>{const s=getSection(sid);return acc+(s?.student_ids||[]).length;},0);
              return `<div style="display:flex;align-items:start;gap:12px;padding:14px 16px;border-bottom:1px solid var(--border)">
                <div style="min-width:0;flex:1">
                  <div style="font-weight:800;font-size:13.5px;margin-bottom:5px">${sub?.name||'—'}</div>
                  <div style="font-size:12px;color:var(--txt2);display:flex;gap:10px;flex-wrap:wrap">
                    <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(e.date)}</span>
                    <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(e.time)}</span>
                    ${myRoomName?`<span><i class="fas fa-door-open" style="color:var(--teal)"></i> ${myRoomName}</span>`:''}
                    ${studCount>0?`<span><i class="fas fa-users" style="color:var(--primary2)"></i> ${studCount} طالب</span>`:''}
                  </div>
                </div>
                ${getStatusBadge(st)}
              </div>`;
            }).join('') : `<div style="padding:30px;text-align:center;color:var(--txt3)">لا توجد امتحانات مجدولة</div>`}
          </div>
        </div>
      </div>

      <!-- العمود الجانبي -->
      <div style="display:flex;flex-direction:column;gap:14px">
        <!-- إحصائياتي -->
        <div class="card" style="padding:14px">
          <div style="font-weight:800;font-size:13px;margin-bottom:12px;display:flex;align-items:center;gap:7px">
            <i class="fas fa-chart-bar" style="color:var(--primary2)"></i> إحصائياتي
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
            <div style="padding:10px;background:var(--bg);border-radius:9px;text-align:center">
              <div style="font-size:20px;font-weight:900;color:var(--primary2)">${semExams.length}</div>
              <div style="font-size:10.5px;color:var(--txt2)">هذا الفصل</div>
            </div>
            <div style="padding:10px;background:var(--bg);border-radius:9px;text-align:center">
              <div style="font-size:20px;font-weight:900;color:var(--gold)">${me.points||0}</div>
              <div style="font-size:10.5px;color:var(--txt2)">نقطة</div>
            </div>
            <div style="padding:10px;background:var(--bg);border-radius:9px;text-align:center">
              <div style="font-size:20px;font-weight:900;color:var(--teal)">${subjectsWithCurrentSem.length}</div>
              <div style="font-size:10.5px;color:var(--txt2)">مقرر نشط</div>
            </div>
            <div style="padding:10px;background:var(--bg);border-radius:9px;text-align:center">
              <div style="font-size:20px;font-weight:900;color:var(--purple2)">${historyExams.length}</div>
              <div style="font-size:10.5px;color:var(--txt2)">تاريخي</div>
            </div>
          </div>
        </div>

        <!-- سجل المراقبة التاريخي -->
        <div class="card" style="padding:14px">
          <div style="font-weight:800;font-size:13px;margin-bottom:10px;display:flex;align-items:center;gap:7px">
            <i class="fas fa-history" style="color:var(--txt2)"></i> سجل المراقبة
          </div>
          ${historyExams.slice(0,8).length ? historyExams.slice(0,8).map(e => {
            const sub = getSubject(e.subject_id);
            const sem = STATE.semesters.find(s => s.code === e.semester);
            const c   = {final:'#3b82f6',midterm:'#f59e0b',quiz:'#10b981',makeup:'#8b5cf6'}[e.type]||'#64748b';
            return `<div style="display:flex;gap:8px;padding:8px 0;border-bottom:1px solid var(--border)">
              <div style="width:3px;border-radius:2px;background:${c};flex-shrink:0;align-self:stretch"></div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${sub?.name||'—'}</div>
                <div style="font-size:10.5px;color:var(--txt3)">${fmtDate(e.date)} · ${sem?.label||e.semester}</div>
              </div>
              <span class="badge" style="font-size:9px;background:${c}15;color:${c}">${getTypeLabel(e.type)}</span>
            </div>`;
          }).join('') : `<div style="font-size:12px;color:var(--txt3);text-align:center;padding:10px">لا يوجد سجل سابق</div>`}
        </div>
      </div>
    </div>`);
}

// نافذة طلاب الشعبة مع نشاط الطالب
function _openSectionStudents(secId, secName) {
  const sec = getSection(secId);
  if (!sec) return;
  const students = (sec.student_ids||[]).map(sid => STATE.students.find(s=>s.id===sid)).filter(Boolean);
  const semExams = STATE.exams.filter(e => e.semester === STATE.currentSem && (e.section_ids||[]).includes(secId));

  let mo = document.getElementById('sectionStudMo');
  if (!mo) { mo=document.createElement('div'); mo.className='mo'; mo.id='sectionStudMo'; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:600px">
    <div class="md-hd">
      <h2><i class="fas fa-layer-group" style="color:var(--gold)"></i> ${esc(secName)} — قائمة الطلاب</h2>
      <button class="md-close" onclick="closeMo('sectionStudMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:14px 20px">
      <div style="margin-bottom:12px;font-size:12.5px;color:var(--txt2)">${students.length} طالب · ${semExams.length} امتحان هذا الفصل</div>
      <div style="display:flex;flex-direction:column;gap:8px;max-height:460px;overflow-y:auto">
        ${students.map(st => {
          const atts = semExams.map(e => {
            const a = (STATE.attendance[e.id]||{})[st.id];
            return { examName: getSubject(e.subject_id)?.name||'—', date: e.date, att: a };
          });
          const present = atts.filter(a => a.att==='present'||a.att==='late').length;
          const absent  = atts.filter(a => a.att==='absent').length;
          const unmark  = atts.filter(a => !a.att).length;
          const pct     = atts.length ? Math.round(present/atts.length*100) : null;
          return `<div style="padding:12px 14px;background:var(--bg);border-radius:12px;border:1.5px solid var(--border);cursor:pointer" onclick="_openStudentHistory(${st.id},'${esc(st.name||'')}')" onmouseover="this.style.borderColor='var(--primary2)40'" onmouseout="this.style.borderColor='var(--border)'">
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:38px;height:38px;border-radius:10px;background:var(--primary)15;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:900;color:var(--primary2)">
                ${(st.name||'?').charAt(0)}
              </div>
              <div style="flex:1">
                <div style="font-weight:700;font-size:13px">${esc(st.name||'—')}</div>
                <div style="font-size:11px;color:var(--txt3)">${esc(st.stud_id||'')} ${st.email?`· ${esc(st.email)}`:''}</div>
              </div>
              ${pct!==null ? `<div style="text-align:center">
                <div style="font-size:16px;font-weight:900;color:${pct>=70?'var(--green2)':pct>=50?'var(--gold)':'var(--red2)'}">${pct}%</div>
                <div style="font-size:10px;color:var(--txt3)">حضور</div>
              </div>` : ''}
              <div style="display:flex;gap:5px">
                ${present?`<span class="badge b-green" style="font-size:10px">${present} حاضر</span>`:''}
                ${absent?`<span class="badge b-red" style="font-size:10px">${absent} غائب</span>`:''}
              </div>
            </div>
          </div>`;
        }).join('') || '<div style="text-align:center;color:var(--txt3);padding:20px">لا يوجد طلاب</div>'}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('sectionStudMo')"><i class="fas fa-arrow-right"></i> إغلاق</button>
    </div>
  </div>`;
  showMo('sectionStudMo');
}

// عرض سجل الطالب
function _openStudentHistory(studId, studName) {
  const st = STATE.students.find(s => s.id === studId);
  if (!st) return;
  const allExams = STATE.exams.filter(e => {
    const mySecs = getProctorScopeSections();
    return mySecs.some(sec => (e.section_ids||[]).includes(sec.id));
  });
  const examRecords = allExams.map(e => {
    const att = (STATE.attendance[e.id]||{})[studId];
    const sub = getSubject(e.subject_id);
    const sem = STATE.semesters.find(s => s.code === e.semester);
    return { exam: e, att, sub, sem };
  }).sort((a,b) => new Date(`${b.exam.date}T${b.exam.time}`) - new Date(`${a.exam.date}T${a.exam.time}`));

  const present = examRecords.filter(r => r.att==='present'||r.att==='late').length;
  const absent  = examRecords.filter(r => r.att==='absent').length;
  const unmarked= examRecords.filter(r => !r.att).length;
  const pct     = examRecords.length ? Math.round(present/examRecords.length*100) : 0;

  let mo = document.getElementById('studHistMo');
  if (!mo) { mo=document.createElement('div'); mo.className='mo'; mo.id='studHistMo'; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:560px">
    <div class="md-hd">
      <h2><i class="fas fa-user-graduate" style="color:var(--teal)"></i> سجل ${esc(studName)}</h2>
      <button class="md-close" onclick="closeMo('studHistMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:14px 20px">
      <!-- إحصاءات الطالب -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px">
        <div style="padding:10px;background:var(--bg);border-radius:9px;text-align:center">
          <div style="font-size:18px;font-weight:900;color:var(--primary2)">${examRecords.length}</div>
          <div style="font-size:10px;color:var(--txt3)">إجمالي</div>
        </div>
        <div style="padding:10px;background:var(--green2)12;border-radius:9px;text-align:center">
          <div style="font-size:18px;font-weight:900;color:var(--green2)">${present}</div>
          <div style="font-size:10px;color:var(--txt3)">حضر</div>
        </div>
        <div style="padding:10px;background:var(--red2)12;border-radius:9px;text-align:center">
          <div style="font-size:18px;font-weight:900;color:var(--red2)">${absent}</div>
          <div style="font-size:10px;color:var(--txt3)">غائب</div>
        </div>
        <div style="padding:10px;background:var(--gold)12;border-radius:9px;text-align:center">
          <div style="font-size:18px;font-weight:900;color:var(--gold)">${pct}%</div>
          <div style="font-size:10px;color:var(--txt3)">حضور</div>
        </div>
      </div>
      <!-- شريط الحضور -->
      <div style="margin-bottom:14px;padding:10px 14px;background:var(--bg);border-radius:10px">
        <div style="font-size:11px;color:var(--txt3);margin-bottom:6px">نسبة الحضور</div>
        <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden">
          <div style="height:100%;width:${pct}%;background:${pct>=70?'var(--green2)':pct>=50?'var(--gold)':'var(--red2)'};border-radius:4px;transition:width .6s"></div>
        </div>
      </div>
      <!-- السجل التفصيلي -->
      <div style="max-height:350px;overflow-y:auto">
        ${examRecords.map(r => {
          const attColor = r.att==='present'?'var(--green2)':r.att==='absent'?'var(--red2)':r.att==='late'?'var(--gold)':'var(--txt3)';
          const attIcon  = r.att==='present'?'fa-check-circle':r.att==='absent'?'fa-times-circle':r.att==='late'?'fa-clock':'fa-question-circle';
          const attLabel = r.att==='present'?'حاضر':r.att==='absent'?'غائب':r.att==='late'?'متأخر':'لم يُسجَّل';
          return `<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
            <i class="fas ${attIcon}" style="color:${attColor};font-size:18px;flex-shrink:0"></i>
            <div style="flex:1">
              <div style="font-weight:700;font-size:12.5px">${r.sub?.name||'—'}</div>
              <div style="font-size:11px;color:var(--txt3)">${fmtDate(r.exam.date)} · ${fmtTime(r.exam.time)} · ${r.sem?.label||r.exam.semester}</div>
            </div>
            <span class="badge" style="background:${attColor}15;color:${attColor};font-size:11px">${attLabel}</span>
          </div>`;
        }).join('') || '<div style="text-align:center;color:var(--txt3);padding:20px">لا يوجد سجل</div>'}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('studHistMo')"><i class="fas fa-arrow-right"></i> رجوع</button>
    </div>
  </div>`;
  showMo('studHistMo');
}
