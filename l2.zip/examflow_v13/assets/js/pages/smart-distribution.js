// ═══════════════════════════════════════════════════════════════
//  smart-distribution.js — توزيع المراقبين الذكي v2
//  خوارزمية: Weighted scoring + Constraint propagation + Load balancing
// ═══════════════════════════════════════════════════════════════

const SmartDist = (() => {

  // أوزان النموذج — قابلة للتعديل من settings
  const W = {
    fairness:   40,   // عدالة التوزيع (الأقل نقاط = أولوية)
    availability: 30, // متاح فعلاً (لا تعارض)
    departmentMatch: 15, // نفس قسم المادة
    rating:      8,   // التقييم
    seniority:   4,   // الأقدمية
    randomness:  3    // كسر التعادل
  };

  // ── الدالة الرئيسية ─────────────────────────────────────────
  function distribute(exam, options = {}) {
    const needed = options.count || _calcNeeded(exam);
    const candidates = _candidates(exam);
    if (!candidates.length) return { assigned: [], errors: ['لا يوجد مراقبون متاحون'] };

    // قيود
    const conflicts = candidates.filter(c => _hasConflict(c, exam));
    const available = candidates.filter(c => !_hasConflict(c, exam));

    if (available.length < needed) {
      return {
        assigned: [],
        errors: [`المتاحون ${available.length} والمطلوب ${needed}`],
        conflicts: conflicts.map(c => ({ id:c.id, name:c.name }))
      };
    }

    // تقييم
    const scored = available.map(p => ({
      profile: p,
      score: _score(p, exam),
      breakdown: _breakdown(p, exam)
    })).sort((a,b) => b.score - a.score);

    // اختيار أعلى N + ضمان توازن
    const chosen = _balance(scored, needed, exam);

    return {
      assigned: chosen.map(c => c.profile.id),
      details:  chosen,
      score:    chosen.reduce((s,c)=>s+c.score,0) / Math.max(1,chosen.length),
      conflicts: conflicts.length
    };
  }

  // ── حساب العدد المطلوب ──────────────────────────────────────
  function _calcNeeded(exam) {
    if (exam.proctors_needed) return exam.proctors_needed;
    const studentCount = (exam.section_ids||[]).reduce((sum, sid) => {
      return sum + (getSection(sid)?.student_ids?.length || 0);
    }, 0);
    const ratio = STATE.settings?.proctors_per_students || 25;
    return Math.max(1, Math.ceil(studentCount / ratio));
  }

  // ── المرشحون: مراقبين + منسقين نشطين ─────────────────────────
  function _candidates(exam) {
    return STATE.profiles.filter(p =>
      ['proctor','coordinator','dept_head'].includes(p.role) && p.active !== false
    );
  }

  // ── فحص التعارض ─────────────────────────────────────────────
  function _hasConflict(profile, exam) {
    // مكلف بامتحان آخر متداخل؟
    const examConflict = STATE.exams.some(e => {
      if (e.id === exam.id) return false;
      if (!(e.proctor_ids||[]).includes(profile.id)) return false;
      return _examsOverlap(e, exam);
    });
    if (examConflict) return true;

    // محجوز في القاعة (جدول دراسي)؟
    const examEnd = _addMin(exam.time, (exam.duration||0) + (exam.extra_time||0));
    const myBookings = (STATE.userBookings||[]).filter(ub => ub.user_id === profile.id);
    return myBookings.some(ub => {
      const b = STATE.bookings.find(bk => bk.id === ub.booking_id);
      if (!b || b.date !== exam.date) return false;
      return b.start_time < examEnd && b.end_time > exam.time;
    });
  }

  // ── دالة التقييم ────────────────────────────────────────────
  function _score(p, exam) {
    const f = _fairness(p);
    const a = 1; // قد فُلتر بالفعل
    const dm = _deptMatch(p, exam);
    const r = (p.avg_rating || 0) / 5;
    const sn = Math.min(1, (p.points || 0) / 100);
    const rnd = Math.random();
    return W.fairness*f + W.availability*a + W.departmentMatch*dm
         + W.rating*r + W.seniority*sn + W.randomness*rnd;
  }

  function _breakdown(p, exam) {
    return {
      fairness: _fairness(p).toFixed(2),
      deptMatch: _deptMatch(p, exam),
      semCount: p.sem_x?.[STATE.currentSem] || 0,
      rating: (p.avg_rating||0).toFixed(1)
    };
  }

  // عدالة: الأقل نقاطاً يحصل على درجة أعلى
  function _fairness(p) {
    const me = p.sem_x?.[STATE.currentSem] || 0;
    const all = STATE.profiles.filter(x => ['proctor','coordinator'].includes(x.role));
    const max = Math.max(1, ...all.map(x => x.sem_x?.[STATE.currentSem] || 0));
    return 1 - (me / (max + 1));
  }

  function _deptMatch(p, exam) {
    const sub = getSubject(exam.subject_id);
    if (!sub?.dept_id || !p.dept_id) return 0;
    return p.dept_id === sub.dept_id ? 1 : 0;
  }

  // توازن: تجنب اختيار نفس الأشخاص دائماً
  function _balance(scored, needed, exam) {
    const out = [];
    const usedDepts = new Map();
    for (const c of scored) {
      if (out.length >= needed) break;
      const d = c.profile.dept_id || 0;
      const cnt = usedDepts.get(d) || 0;
      // لا أكثر من نصف المراقبين من نفس القسم
      if (cnt >= Math.ceil(needed/2) && scored.length > needed) continue;
      out.push(c);
      usedDepts.set(d, cnt+1);
    }
    // تكميل لو ناقص
    for (const c of scored) {
      if (out.length >= needed) break;
      if (!out.includes(c)) out.push(c);
    }
    return out;
  }

  // ── Helpers ─────────────────────────────────────────────────
  function _examsOverlap(a, b) {
    if (a.date !== b.date) return false;
    const aS = a.time, aE = _addMin(a.time, (a.duration||0)+(a.extra_time||0));
    const bS = b.time, bE = _addMin(b.time, (b.duration||0)+(b.extra_time||0));
    return aS < bE && aE > bS;
  }
  function _addMin(t, m) {
    const [h,mn] = (t||'00:00').split(':').map(Number);
    const d = new Date(2000,0,1,h,mn+m);
    return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  }

  // ── توزيع جماعي على عدة امتحانات (يحل الأكثر تقييداً أولاً) ─
  function distributeBatch(examIds, options) {
    const exams = examIds.map(id => getExam(id)).filter(Boolean);
    // الأقل مراقبين متاحين أولاً (Most Constrained Variable)
    const order = exams.map(e => ({
      e, free: _candidates(e).filter(c => !_hasConflict(c, e)).length
    })).sort((a,b) => a.free - b.free);

    const results = [];
    for (const { e } of order) {
      const r = distribute(e, options);
      results.push({ examId: e.id, ...r });
      // محاكاة الإسناد لمنع التعارض في الجولة التالية
      if (r.assigned?.length) {
        e.proctor_ids = [...(e.proctor_ids||[]), ...r.assigned];
      }
    }
    return results;
  }

  function setWeights(w) { Object.assign(W, w); }

  return { distribute, distributeBatch, setWeights };
})();
