// ═══════════════════════════════════════════════════════════════
//  cross-dept-requests.js v2 — طلبات المراقبة بين الأقسام
//  تدفق الموافقة الجديد:
//  1) طلب من مراقب/منسق → رئيس القسم المستهدف
//  2) رئيس القسم يوافق ويختار مراقباً
//  3) المراقب المختار يقبل/يرفض التعيين
// ═══════════════════════════════════════════════════════════════

function renderCrossDeptRequests() {
  const me = STATE.currentUser;
  if (!me) return;

  // تحديد نطاق عرض الطلبات حسب الدور
  let requests;
  if (isAdmin()) {
    requests = STATE.crossDeptRequests;
  } else if (isCoord()) {
    // المنسق: الطلبات الصادرة من قسمه + الواردة إليه (إن وُجد)
    requests = STATE.crossDeptRequests.filter(r =>
      r.requesting_dept_id === me.dept_id || r.target_dept_id === me.dept_id
    );
  } else if (isDeptHead()) {
    // رئيس القسم: الطلبات الواردة لقسمه فقط
    requests = STATE.crossDeptRequests.filter(r => r.target_dept_id === me.dept_id);
  } else {
    setHTML('crossDeptContent', emptyState('fa-lock', 'غير مصرح'));
    return;
  }

  const pending      = requests.filter(r => r.status === 'pending');
  const deptApproved = requests.filter(r => r.status === 'dept_approved'); // بانتظار المراقب
  const approved     = requests.filter(r => r.status === 'approved');
  const rejected     = requests.filter(r => r.status === 'rejected');

  const canReqNew = isAdmin() || isCoord();
  const canApprove = isDeptHead() || isAdmin();

  setHTML('crossDeptActs', `
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      ${pending.length + deptApproved.length > 0
        ? `<span class="badge b-gold" style="font-size:12px"><i class="fas fa-bell"></i> ${pending.length + deptApproved.length} معلق</span>`
        : ''}
      ${canReqNew
        ? `<button class="btn bp btn-sm" onclick="openCrossRequest()"><i class="fas fa-plus"></i> طلب مراقب من قسم آخر</button>`
        : ''}
    </div>
  `);

  const buildCard = (r, showActions) => {
    const exam       = getExam(r.exam_id);
    const sub        = getSubject(exam?.subject_id);
    const reqDept    = getDept(r.requesting_dept_id);
    const tgtDept    = getDept(r.target_dept_id);
    const requester  = getProfile(r.requested_by);
    const assignedP  = r.assigned_proctor_id ? getProfile(r.assigned_proctor_id) : null;

    // بناء مراحل الموافقة
    const step1Done = r.status !== 'pending';
    const step2Done = r.status === 'approved';
    const step1Pending = r.status === 'pending';
    const step2Pending = r.status === 'dept_approved';

    const statusMap = {
      pending:      { cls:'b-gold',   lbl:'بانتظار رئيس القسم',         icon:'fa-clock' },
      dept_approved:{ cls:'b-blue',   lbl:'بانتظار تأكيد المراقب',       icon:'fa-user-clock' },
      approved:     { cls:'b-green',  lbl:'مكتمل',                       icon:'fa-check-circle' },
      rejected:     { cls:'b-red',    lbl:'مرفوض',                        icon:'fa-times-circle' }
    };
    const si = statusMap[r.status] || { cls:'b-gray', lbl:r.status, icon:'fa-info' };

    return `
      <div style="padding:16px 20px;border-bottom:1px solid var(--border);transition:background .15s"
           onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
        <div style="display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap">
          <div style="width:44px;height:44px;border-radius:12px;background:var(--purple2)18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fas fa-people-arrows" style="color:var(--purple2);font-size:18px"></i>
          </div>
          <div style="flex:1;min-width:160px">
            <div style="font-weight:800;font-size:13.5px">${esc(sub?.name||'امتحان')}</div>
            <div style="font-size:12px;color:var(--txt2);margin-top:3px">
              <i class="fas fa-calendar" style="color:var(--primary2);margin-left:3px"></i>${exam?.date||'—'}
              <i class="fas fa-clock" style="color:var(--gold);margin-right:8px;margin-left:3px"></i>${exam?.time?.slice(0,5)||'—'}
            </div>
            <div style="font-size:11.5px;color:var(--txt3);margin-top:5px;display:flex;flex-wrap:wrap;gap:8px">
              <span><i class="fas fa-arrow-right" style="color:var(--teal);margin-left:3px"></i>من: <strong>${esc(reqDept?.name||'—')}</strong></span>
              <span><i class="fas fa-arrow-left" style="color:var(--orange,#f97316);margin-left:3px"></i>إلى: <strong>${esc(tgtDept?.name||'—')}</strong></span>
              <span><i class="fas fa-user" style="margin-left:3px"></i>${esc(requester?.name?.split(' ').slice(0,2).join(' ')||'—')}</span>
            </div>

            <!-- مراحل الموافقة -->
            <div style="display:flex;gap:5px;margin-top:10px;align-items:center;flex-wrap:wrap">
              <!-- المرحلة 1: رئيس القسم -->
              <div class="approval-step ${step1Done?'done':step1Pending?'pending':'waiting'}" style="font-size:10.5px;gap:6px;flex-shrink:0">
                <div class="approval-step-num">1</div>
                <div>
                  <div style="font-weight:700">رئيس القسم</div>
                  <div style="font-size:9.5px;opacity:.7">${step1Done?'وافق':'بانتظار الموافقة'}</div>
                </div>
                ${step1Done||step2Pending||step2Done?`<i class="fas fa-${step1Done?'check':'clock'}" style="font-size:10px;color:${step1Done?'var(--green2)':'var(--gold)'}"></i>`:''}
              </div>
              <i class="fas fa-chevron-left" style="color:var(--txt3);font-size:9px"></i>
              <!-- المرحلة 2: المراقب المختار -->
              <div class="approval-step ${step2Done?'done':step2Pending?'pending':'waiting'}" style="font-size:10.5px;gap:6px;flex-shrink:0">
                <div class="approval-step-num">2</div>
                <div>
                  <div style="font-weight:700">${assignedP?esc(assignedP.name?.split(' ').slice(0,2).join(' ')):'المراقب المختار'}</div>
                  <div style="font-size:9.5px;opacity:.7">${step2Done?'قبل التعيين':step2Pending?'بانتظار القبول':'يُعيَّن لاحقاً'}</div>
                </div>
                ${step2Pending||step2Done?`<i class="fas fa-${step2Done?'check':'clock'}" style="font-size:10px;color:${step2Done?'var(--green2)':'var(--gold)'}"></i>`:''}
              </div>
            </div>

            ${r.notes ? `<div style="margin-top:8px;font-size:11px;color:var(--txt3);background:var(--bg);padding:5px 10px;border-radius:6px;border:1px solid var(--border)">
              <i class="fas fa-note-sticky" style="margin-left:4px;color:var(--gold)"></i>${esc(r.notes)}
            </div>` : ''}
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">
            <span class="badge ${si.cls}" style="font-size:10.5px">
              <i class="fas ${si.icon}" style="margin-left:4px"></i>${si.lbl}
            </span>
            ${showActions && r.status === 'pending' && canApprove ? `
              <button class="btn bp btn-sm" onclick="openAssignProctor(${r.id})" style="font-size:11px">
                <i class="fas fa-user-plus"></i> موافقة وتعيين مراقب
              </button>
              <button class="btn btn-sm" style="background:var(--red2)15;color:var(--red2);border:1px solid var(--red2)30;font-size:11px"
                onclick="rejectCrossDeptRequest(${r.id})">
                <i class="fas fa-times"></i> رفض
              </button>` : ''}
            ${r.status === 'dept_approved' && (isAdmin() || (isCoord() && r.target_dept_id === me.dept_id)) ? `
              <button class="btn bo btn-sm" style="font-size:11px" onclick="_viewCrossDeptProctorStatus(${r.id})">
                <i class="fas fa-user-clock"></i> متابعة المراقب
              </button>` : ''}
          </div>
        </div>
      </div>`;
  };

  setHTML('crossDeptContent', `
    ${pending.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--gold)">
      <div class="card-h" style="background:var(--gold)06">
        <h3><i class="fas fa-clock" style="color:var(--gold)"></i> بانتظار موافقة رئيس القسم
          <span class="badge b-gold">${pending.length}</span>
        </h3>
      </div>
      ${pending.map(r => buildCard(r, true)).join('')}
    </div>` : ''}

    ${deptApproved.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--primary2)">
      <div class="card-h" style="background:var(--primary)06">
        <h3><i class="fas fa-user-clock" style="color:var(--primary2)"></i> بانتظار تأكيد المراقب
          <span class="badge b-blue">${deptApproved.length}</span>
        </h3>
      </div>
      ${deptApproved.map(r => buildCard(r, true)).join('')}
    </div>` : ''}

    ${approved.length ? `
    <div class="card" style="margin-bottom:14px;border-right:4px solid var(--green2)">
      <div class="card-h">
        <h3><i class="fas fa-check-circle" style="color:var(--green2)"></i> مكتملة
          <span class="badge b-green">${approved.length}</span>
        </h3>
      </div>
      ${approved.map(r => buildCard(r, false)).join('')}
    </div>` : ''}

    ${rejected.length ? `
    <div class="card" style="border-right:4px solid var(--red2)">
      <div class="card-h">
        <h3><i class="fas fa-times-circle" style="color:var(--red2)"></i> مرفوضة
          <span class="badge b-red">${rejected.length}</span>
        </h3>
      </div>
      ${rejected.map(r => buildCard(r, false)).join('')}
    </div>` : ''}

    ${!requests.length ? emptyState('fa-people-arrows', 'لا توجد طلبات', 'لا توجد طلبات مراقبة بين الأقسام حتى الآن') : ''}
  `);
}

// ── طلب مراقب من قسم آخر ────────────────────────────────────
function openCrossRequest() {
  const mo = _getMo('crossReqMo');
  const me = STATE.currentUser;
  const myDept = me?.dept_id;
  const otherDepts = STATE.departments.filter(d => d.id !== myDept);

  // الامتحانات القادمة ضمن نطاق المستخدم
  const scopeExams = STATE.exams.filter(e => {
    const st = examStatus(e);
    return (st === 'upcoming') && (!myDept || getSubject(e.subject_id)?.dept_id === myDept || isAdmin());
  });

  mo.innerHTML = `<div class="md" style="max-width:520px">
    <div class="md-hd">
      <h2><i class="fas fa-people-arrows" style="color:var(--purple2)"></i> طلب مراقب من قسم آخر</h2>
      <button class="md-close" onclick="closeMo('crossReqMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px 22px">
      <div style="background:var(--primary)08;border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:12.5px;color:var(--txt2);border:1px solid var(--primary2)20">
        <i class="fas fa-info-circle" style="color:var(--primary2);margin-left:5px"></i>
        سيُرسَل الطلب لرئيس القسم المستهدف للموافقة وتعيين المراقب. ثم يحتاج المراقب لتأكيد قبوله.
      </div>
      <div class="field">
        <label class="field-lbl">الامتحان <span class="req">*</span></label>
        <select id="crExam" style="height:46px">
          <option value="">— اختر امتحاناً —</option>
          ${scopeExams.map(e => {
            const sub = getSubject(e.subject_id);
            return `<option value="${e.id}">${esc(sub?.name||'—')} · ${fmtDate(e.date)} ${fmtTime(e.time)}</option>`;
          }).join('')}
        </select>
      </div>
      <div class="field">
        <label class="field-lbl">القسم المستهدف <span class="req">*</span></label>
        <select id="crTargetDept" style="height:46px">
          <option value="">— اختر قسماً —</option>
          ${otherDepts.map(d => `<option value="${d.id}">${esc(d.name)}</option>`).join('')}
        </select>
      </div>
      <div class="field">
        <label class="field-lbl">ملاحظات / متطلبات</label>
        <textarea id="crNotes" rows="3" placeholder="مثال: يُفضَّل مراقب متاح كل الوقت..." style="resize:vertical"></textarea>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('crossReqMo')">إلغاء</button>
      <button class="btn bp" onclick="saveCrossRequest()"><i class="fas fa-paper-plane"></i> إرسال الطلب</button>
    </div>
  </div>`;
  showMo('crossReqMo');
}

async function saveCrossRequest() {
  const examId     = parseInt(document.getElementById('crExam')?.value);
  const targetDept = parseInt(document.getElementById('crTargetDept')?.value);
  const notes      = document.getElementById('crNotes')?.value?.trim() || '';
  const me         = STATE.currentUser;

  if (!examId || !targetDept) return toast('اختر الامتحان والقسم المستهدف', 'warning');

  try {
    const row = await dbInsert('cross_dept_requests', {
      exam_id:             examId,
      requesting_dept_id:  me.dept_id,
      target_dept_id:      targetDept,
      requested_by:        me.id,
      status:              'pending',
      notes,
      created_at:          new Date().toISOString()
    });
    STATE.crossDeptRequests.push(row);

    // إشعار لرئيس القسم المستهدف
    const deptHeads = STATE.profiles.filter(p =>
      (p.role === 'dept_head' || p.role === 'coordinator') && p.dept_id === targetDept
    );
    if (deptHeads.length) {
      const exam = getExam(examId);
      const sub  = getSubject(exam?.subject_id);
      const reqDeptName = getDept(me.dept_id)?.name || '—';
      await addNotif(deptHeads.map(p=>p.id), '📨 طلب مراقب خارجي',
        `قسم ${reqDeptName} يطلب مراقباً لامتحان "${sub?.name||'—'}" · ${exam?.date||'—'}`, 'swap');
    }

    await addLog('طلب مراقب خارجي', 'cross_dept', `من قسم ${getDept(me.dept_id)?.name||'—'} إلى قسم ${getDept(targetDept)?.name||'—'}`);
    toast('تم إرسال الطلب ✓', 'success');
    closeMo('crossReqMo');
    renderCrossDeptRequests();
  } catch(ex) { toast(ex.message, 'error'); }
}

// ── تعيين مراقب (لرئيس القسم — المرحلة الأولى) ──────────────
function openAssignProctor(requestId) {
  const req = STATE.crossDeptRequests.find(r => r.id === requestId);
  if (!req) return;

  const me = STATE.currentUser;
  const targetDeptId = req.target_dept_id;
  const deptProctors = STATE.profiles.filter(p =>
    p.role === 'proctor' && p.dept_id === targetDeptId && p.active
  );
  const exam = getExam(req.exam_id);
  const sub  = getSubject(exam?.subject_id);
  const reqDept = getDept(req.requesting_dept_id);

  const mo = _getMo('assignProcMo');
  mo.innerHTML = `<div class="md" style="max-width:500px">
    <div class="md-hd">
      <h2><i class="fas fa-user-plus" style="color:var(--primary2)"></i> موافقة وتعيين مراقب</h2>
      <button class="md-close" onclick="closeMo('assignProcMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px 22px">
      <!-- بطاقة تفاصيل الطلب -->
      <div style="padding:12px 14px;background:var(--purple2)08;border-radius:12px;margin-bottom:16px;border:1px solid var(--purple2)20">
        <div style="font-weight:800;font-size:14px;margin-bottom:5px">${esc(sub?.name||'—')}</div>
        <div style="font-size:12px;color:var(--txt2);display:flex;gap:12px;flex-wrap:wrap">
          <span><i class="fas fa-calendar" style="color:var(--primary2)"></i> ${fmtDate(exam?.date||'')}</span>
          <span><i class="fas fa-clock" style="color:var(--gold)"></i> ${fmtTime(exam?.time||'')}</span>
          <span style="color:var(--teal)"><i class="fas fa-sitemap"></i> ${esc(reqDept?.name||'—')} ← طلب</span>
        </div>
      </div>
      <div style="padding:8px 12px;background:var(--gold)10;border-radius:9px;border:1px solid var(--gold)20;font-size:12px;margin-bottom:14px">
        <i class="fas fa-info-circle" style="color:var(--gold);margin-left:5px"></i>
        بعد موافقتك وتعيين المراقب، سيصل إليه إشعار لقبول أو رفض التعيين.
      </div>
      <div class="field">
        <label class="field-lbl">اختر المراقب من قسمك <span class="req">*</span></label>
        ${deptProctors.length ? `
          <div style="max-height:280px;overflow-y:auto;border:1.5px solid var(--border);border-radius:10px;padding:6px">
            ${deptProctors.map(p => {
              const sc     = STATE.exams.filter(e=>(e.proctor_ids||[]).includes(p.id)&&e.semester===STATE.currentSem).length;
              const hasConf = exam ? (typeof hasUserConflict==='function' && hasUserConflict(p.id,exam.date,exam.time?.slice(0,5)||'','',null)) : false;
              return `<label style="display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:9px;cursor:pointer;${hasConf?'opacity:.45;pointer-events:none':''}"
                onmouseover="if(!${hasConf})this.style.background='var(--bg)'" onmouseout="this.style.background=''">
                <input type="radio" name="apProctor" value="${p.id}" ${hasConf?'disabled':''}>
                ${userAvatar(p, 34)}
                <div style="flex:1;min-width:0">
                  <div style="font-size:13px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(p.name)}</div>
                  <div style="font-size:10.5px;color:var(--txt3)">${sc} امتحان/الفصل ${hasConf?'<span style="color:var(--red2)">· تعارض</span>':''}</div>
                </div>
                <span class="badge ${sc>=3?'b-red':sc>=2?'b-gold':'b-green'}" style="font-size:9.5px">${sc}/3</span>
              </label>`;
            }).join('')}
          </div>` : `<div style="padding:20px;text-align:center;color:var(--txt3);border:1.5px dashed var(--border);border-radius:10px">
            <i class="fas fa-user-slash" style="font-size:24px;opacity:.3;display:block;margin-bottom:8px"></i>
            لا يوجد مراقبون متاحون في قسمك
          </div>`}
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('assignProcMo')">إلغاء</button>
      <button class="btn bs" onclick="confirmAssignProctor(${requestId})">
        <i class="fas fa-check"></i> تأكيد الموافقة وتعيين المراقب
      </button>
    </div>
  </div>`;
  showMo('assignProcMo');
}

async function confirmAssignProctor(requestId) {
  const sel = document.querySelector('input[name="apProctor"]:checked');
  if (!sel) return toast('اختر مراقباً من قسمك', 'warning');
  const proctorId = sel.value;
  const req = STATE.crossDeptRequests.find(r => r.id === requestId);
  if (!req) return;

  try {
    // ✓ المرحلة الأولى: رئيس القسم وافق واختار مراقباً
    // الحالة تصبح dept_approved — بانتظار قبول المراقب
    const updated = await dbUpdate('cross_dept_requests', requestId, {
      status:              'dept_approved',
      assigned_proctor_id: proctorId,
      dept_head_approved_by: STATE.currentUser?.id,
      updated_at:          new Date().toISOString()
    });
    const idx = STATE.crossDeptRequests.findIndex(r => r.id === requestId);
    if (idx >= 0) {
      STATE.crossDeptRequests[idx] = {
        ...STATE.crossDeptRequests[idx],
        status: 'dept_approved',
        assigned_proctor_id: proctorId
      };
    }

    // إضافة المراقب للامتحان بحالة pending
    const exam = getExam(req.exam_id);
    if (exam) {
      const updProctorIds = [...new Set([...(exam.proctor_ids||[]), proctorId])];
      const updStatuses   = { ...(exam.proctor_statuses||{}), [proctorId]: 'pending' };
      await dbUpdate('exams', req.exam_id, {
        proctor_ids:      updProctorIds,
        proctor_statuses: updStatuses
      });
      exam.proctor_ids      = updProctorIds;
      exam.proctor_statuses = updStatuses;
    }

    const sub      = getSubject(exam?.subject_id);
    const reqDept  = getDept(req.requesting_dept_id);

    // إشعار للمراقب المختار
    await addNotif([proctorId], '⚡ طلب مراقبة من قسم آخر',
      `تم ترشيحك من قِبَل رئيس قسم ${getDept(req.target_dept_id)?.name||'—'} للمراقبة في "${sub?.name||'—'}" بتاريخ ${exam?.date||'—'} (طلب من قسم ${reqDept?.name||'—'}). يرجى الرد من صفحة الطلبات.`,
      'exam');

    // إشعار للمنسق الطالب بأن رئيس القسم وافق وبانتظار المراقب
    await addNotif([req.requested_by], '✓ وافق رئيس القسم — بانتظار المراقب',
      `رئيس قسم ${getDept(req.target_dept_id)?.name||'—'} وافق على طلبك وعيَّن مراقباً. سيُبلَّغ الطلب بمجرد قبول المراقب.`,
      'swap');

    await addLog('موافقة رئيس القسم على طلب خارجي', 'cross_dept', `الطلب #${requestId} — المراقب المختار: ${getProfile(proctorId)?.name||'—'}`);

    toast('تمت الموافقة — أُرسل إشعار للمراقب لقبول التعيين ✓', 'success');
    closeMo('assignProcMo');
    renderCrossDeptRequests();
  } catch(ex) { toast(ex.message, 'error'); }
}

// ── عرض حالة المراقب في طلب dept_approved ────────────────────
function _viewCrossDeptProctorStatus(requestId) {
  const req = STATE.crossDeptRequests.find(r => r.id === requestId);
  if (!req) return;
  const proctor = req.assigned_proctor_id ? getProfile(req.assigned_proctor_id) : null;
  const exam    = getExam(req.exam_id);
  const sub     = getSubject(exam?.subject_id);
  const pst     = proctor ? (exam?.proctor_statuses||{})[proctor.id] : null;

  const mo = _getMo('crossProcStatusMo');
  mo.innerHTML = `<div class="md" style="max-width:420px">
    <div class="md-hd">
      <h2><i class="fas fa-user-clock" style="color:var(--primary2)"></i> متابعة موافقة المراقب</h2>
      <button class="md-close" onclick="closeMo('crossProcStatusMo')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:18px 22px">
      <div style="text-align:center;padding:20px">
        ${proctor ? userAvatar(proctor, 60) : ''}
        <div style="font-weight:800;font-size:16px;margin-top:10px">${esc(proctor?.name||'—')}</div>
        <div style="font-size:12.5px;color:var(--txt2);margin-top:4px">${esc(sub?.name||'—')} · ${fmtDate(exam?.date||'')}</div>
        <div style="margin-top:14px">
          ${pst === 'accepted'
            ? `<span class="badge b-green" style="font-size:14px;padding:8px 18px"><i class="fas fa-check-circle"></i> قبل التعيين</span>`
            : pst === 'rejected'
            ? `<span class="badge b-red" style="font-size:14px;padding:8px 18px"><i class="fas fa-times-circle"></i> رفض التعيين</span>`
            : `<span class="badge b-gold" style="font-size:14px;padding:8px 18px"><i class="fas fa-hourglass"></i> لم يرد بعد</span>`}
        </div>
        ${pst === 'pending' ? `
        <div style="margin-top:14px;font-size:12px;color:var(--txt3)">يُمكنك إرسال تذكير للمراقب</div>
        <button class="btn bo btn-sm" style="margin-top:8px" onclick="_remindCrossDeptProctor('${proctor?.id}','${requestId}');closeMo('crossProcStatusMo')">
          <i class="fas fa-bell"></i> إرسال تذكير
        </button>` : ''}
      </div>
    </div>
  </div>`;
  showMo('crossProcStatusMo');
}

async function _remindCrossDeptProctor(proctorId, requestId) {
  const req  = STATE.crossDeptRequests.find(r => r.id == requestId);
  const exam = getExam(req?.exam_id);
  const sub  = getSubject(exam?.subject_id);
  await addNotif([proctorId], '🔔 تذكير: طلب مراقبة ينتظر ردك',
    `لا يزال طلب المراقبة لامتحان "${sub?.name||'—'}" ينتظر ردك. يرجى الدخول لصفحة الطلبات.`, 'exam');
  toast('تم إرسال التذكير للمراقب ✓', 'success');
}

// ── رفض الطلب ───────────────────────────────────────────────
async function rejectCrossDeptRequest(requestId) {
  if (!confirm('هل تريد رفض هذا الطلب؟')) return;
  const req = STATE.crossDeptRequests.find(r => r.id === requestId);
  if (!req) return;
  try {
    await dbUpdate('cross_dept_requests', requestId, {
      status: 'rejected', updated_at: new Date().toISOString()
    });
    const idx = STATE.crossDeptRequests.findIndex(r => r.id === requestId);
    if (idx >= 0) STATE.crossDeptRequests[idx].status = 'rejected';

    // إزالة المراقب من الامتحان إن كان قد أُضيف
    if (req.assigned_proctor_id) {
      const exam = getExam(req.exam_id);
      if (exam) {
        exam.proctor_ids = (exam.proctor_ids||[]).filter(id => id !== req.assigned_proctor_id);
        const newSt = { ...(exam.proctor_statuses||{}) };
        delete newSt[req.assigned_proctor_id];
        await dbUpdate('exams', req.exam_id, {
          proctor_ids: exam.proctor_ids, proctor_statuses: newSt
        });
        exam.proctor_statuses = newSt;
      }
    }

    // إشعار للمنسق الطالب
    const exam = getExam(req.exam_id);
    const sub  = getSubject(exam?.subject_id);
    await addNotif([req.requested_by], '❌ رفض طلب المراقبة الخارجية',
      `تم رفض طلبك من قسم ${getDept(req.target_dept_id)?.name||'—'} لامتحان "${sub?.name||'—'}" · ${exam?.date||'—'}`, 'swap');

    toast('تم رفض الطلب وإشعار الطالب ✓', 'success');
    renderCrossDeptRequests();
  } catch(ex) { toast(ex.message, 'error'); }
}

// ── مزامنة: عند قبول المراقب لتعيين cross_dept → تحديث الطلب إلى approved ──
// هذا يُستدعى من proctorAcceptAssignment في swaps.js
async function _onCrossDeptProctorAccepted(proctorId, examId) {
  const req = STATE.crossDeptRequests.find(r =>
    r.assigned_proctor_id === proctorId &&
    r.exam_id === examId &&
    r.status === 'dept_approved'
  );
  if (!req) return;
  try {
    await dbUpdate('cross_dept_requests', req.id, { status: 'approved' });
    req.status = 'approved';
    const sub = getSubject(getExam(examId)?.subject_id);
    await addNotif([req.requested_by], '✅ المراقب قبل التعيين',
      `${getProfile(proctorId)?.name?.split(' ')[0]||'المراقب'} قبل مراقبة "${sub?.name||'—'}"`, 'exam');
  } catch {}
}
