// ═══════════════════════════════════════════════════════════════
//  state.js v8 — حالة التطبيق المركزية (محدّث)
// ═══════════════════════════════════════════════════════════════

const STATE = {
  currentUser: null,
  profiles:    [],
  semesters:   [],
  subjects:    [],
  rooms:       [],
  sections:    [],
  students:    [],
  exams:       [],
  departments: [],
  schedules:   [],
  bookings:    [],
  userBookings: [],          // 🆕 حجوزات المستخدم الشخصية
  crossDeptRequests: [],     // 🆕 طلبات المراقبة من أقسام أخرى
  semesterSchedules: [],     // 🆕 جدول الفصل العام
  swapRequests:        [],
  supervisionRequests: [],
  attendance:  {},
  notifications: [],
  examNotifications: [],
  monitorNotifications: [],
  auditLog:    [],
  settings:    null,
  currentSem:  APP_CONFIG.DEFAULT_SEM,
  currentPage: null,
  // UI state
  _editExamId:   null,
  _editSubjId:   null,
  _editRoomId:   null,
  _editStudentId: null,
  _editDeptId:   null,
  _editScheduleId: null,
  _editBookingId: null,
  _secStudMoId:  null,
  _monExamId:    null,
  _monRoomId:    null,   // ✅ القاعة المحددة في شاشة المراقبة
  _monInterval:  null,
  _ctRunning:    false,
  _ctRemaining:  7200,
  _ctInterval:   null,
  _ctHalfNotified: false,
  _ct10Notified:   false,
  // Student portal
  _studentUser:  null,
  _studentAttendance: {},
  _monRefreshCounter: 0
};

const getProfile  = id => STATE.profiles.find(u => u.id === id);
const getExam     = id => STATE.exams.find(e => e.id === id);
const getRoom     = id => STATE.rooms.find(r => r.id === id);
const getSubject  = id => STATE.subjects.find(s => s.id === id);
const getSection  = id => STATE.sections.find(s => s.id === id);
const getStudent  = id => STATE.students.find(s => s.id === id);
const getDept     = id => STATE.departments.find(d => d.id === id);
const getSemLabel = code => STATE.semesters.find(s => s.code === code)?.label || code;

// ── صلاحيات ─────────────────────────────────────────────────────
const isAdmin         = () => STATE.currentUser?.role === 'admin';
const isCoord         = () => STATE.currentUser?.role === 'coordinator';
const isDeptHead      = () => STATE.currentUser?.role === 'dept_head';
const isProctor       = () => STATE.currentUser?.role === 'proctor';
const isDean          = () => STATE.currentUser?.role === 'dean';
const isAssistantDean = () => STATE.currentUser?.role === 'assistant_dean';
const isReadOnly      = () => isDean() || isAssistantDean();
const isStudent       = () => !!STATE._studentUser;
const isAdminOrCoord  = () => isAdmin() || isCoord();
const isFacultyWide   = () => ['admin','coordinator','dean','assistant_dean']
                              .includes(STATE.currentUser?.role);
const isDeptScoped    = () => ['dept_head','proctor'].includes(STATE.currentUser?.role);

/** هل المستخدم الحالي يستطيع تعديل البيانات؟ Dean/AssistantDean = لا */
function canModify() {
  const r = STATE.currentUser?.role;
  if (!r) return false;
  if (isReadOnly()) return false;
  return APP_CONFIG.CAN_EDIT_ROLES.includes(r);
}

/** قسم المستخدم الحالي (null إذا لم يكن مرتبطاً بقسم) */
function getMyDeptId() {
  return STATE.currentUser?.dept_id || null;
}

/** كل أقسام الكلية (لمستخدمي الرؤية الكاملة) أو قسم المستخدم */
function getMyScopeDeptIds() {
  if (isFacultyWide() || isAdmin()) {
    return STATE.departments.map(d => d.id);
  }
  const dept = getMyDeptId();
  return dept ? [dept] : [];
}

/** كل المواد ضمن نطاق رؤية المستخدم */
function getMyScopeSubjectIds() {
  const deptIds = getMyScopeDeptIds();
  if (!deptIds.length) return STATE.subjects.map(s => s.id);
  return STATE.subjects.filter(s => deptIds.includes(s.dept_id)).map(s => s.id);
}

/** كل الامتحانات ضمن نطاق رؤية المستخدم */
function getMyScopeExams() {
  const subjIds = new Set(getMyScopeSubjectIds());
  return STATE.exams.filter(e => subjIds.has(e.subject_id));
}

/** كل المراقبين ضمن نطاق رؤية المستخدم */
function getMyScopeProctors() {
  if (isFacultyWide()) return STATE.profiles.filter(p => p.role === 'proctor');
  const myDept = getMyDeptId();
  if (!myDept) return [];
  return STATE.profiles.filter(p => p.role === 'proctor' && p.dept_id === myDept);
}

/** كل الطلاب ضمن نطاق رؤية المستخدم — الطالب يُربط بالقسم عبر مواده/شُعبه */
function getMyScopeStudents() {
  if (isFacultyWide()) return STATE.students;
  const subjIds = new Set(getMyScopeSubjectIds());
  if (!subjIds.size) return [];
  return STATE.students.filter(s => {
    // إذا كان الطالب مرتبطاً بأي مادة من نطاق المستخدم
    const mySubj = (s.subject_ids || []).some(id => subjIds.has(id));
    if (mySubj) return true;
    // أو شعبة من نطاق المستخدم
    return STATE.sections.some(sec =>
      subjIds.has(sec.subject_id) && (sec.student_ids || []).includes(s.id)
    );
  });
}

/** الأقسام المرتبطة بطالب (للعرض فقط — متعددة لأن الطالب يسجل في مواد أقسام مختلفة) */
function getStudentDeptIds(student) {
  if (!student) return [];
  const subjIds = new Set();
  (student.subject_ids || []).forEach(id => subjIds.add(id));
  STATE.sections.forEach(sec => {
    if ((sec.student_ids || []).includes(student.id)) subjIds.add(sec.subject_id);
  });
  const deptIds = new Set();
  subjIds.forEach(sid => {
    const subj = STATE.subjects.find(s => s.id === sid);
    if (subj?.dept_id) deptIds.add(subj.dept_id);
  });
  return [...deptIds];
}

// ── نظام الصلاحيات الذكي ─────────────────────────────────────
function canAdd(section) {
  const u = STATE.currentUser; if (!u) return false;
  // العميد ومساعد العميد: قراءة فقط — لا إضافة
  if (APP_CONFIG.READ_ONLY_ROLES?.includes(u.role)) return false;
  if (u.role === 'admin') return true;
  const perms = u.permissions;
  if (perms?.can_add) return perms.can_add.includes(section);
  return APP_CONFIG.CAN_EDIT_ROLES.includes(u.role);
}

function canDel(section) {
  const u = STATE.currentUser; if (!u) return false;
  if (APP_CONFIG.READ_ONLY_ROLES?.includes(u.role)) return false;
  if (u.role === 'admin') return true;
  const perms = u.permissions;
  if (perms?.can_delete) return perms.can_delete.includes(section);
  return APP_CONFIG.CAN_DELETE_ROLES.includes(u.role);
}

const canEdit   = (section) => canAdd(section || 'exams');
const canDelete = (section) => canDel(section || 'exams');

// ✅ صلاحية إنشاء الامتحانات: المسؤول والمنسق فقط
const canCreateExam = () => isAdmin() || isCoord();

// ✅ صلاحية مراجعة الامتحانات (موافقة/رفض على الامتحانات المعلقة): المسؤول فقط
const canReviewExam = () => isAdmin();

function canSeePage(pageId) {
  const u = STATE.currentUser; if (!u) return false;
  if (u.role === 'admin') return true;
  const perms = u.permissions;
  if (perms?.pages) return perms.pages.includes(pageId);
  return true;
}

// ── صلاحيات خاصة بالأدوار ════════════════════════════════════

/** المراقب: يرى صفحاته الخاصة فقط */
function proctorCanSeePage(pageId) {
  const allowed = [
    'my-dashboard','calendar','my-calendar','exams','swaps',
    'analytics','notifications','subjects','students',
    'live'   // ✅ المراقب يرى شاشة المراقبة الحية (قاعته فقط تلقائياً)
    // ❌ settings: مُزالة — للمسؤول/المنسق فقط
  ];
  return allowed.includes(pageId);
}

/** المواد التي يراقبها المراقب الحالي (من staff_ids أو من شعب مرتبطة به مباشرة) */
/**
 * المواد التي تعود للمراقب كمُدرِّس (staff_ids فقط) — لا علاقة بتعييناته كمراقب
 * هذا يضمن أن المراقب لا يرى طلاب المواد التي راقب فيها فحسب
 */
function getProctorScopeSubjects() {
  const uid = STATE.currentUser?.id;
  if (!uid) return [];

  // المواد التي يظهر فيه المراقب في staff_ids على مستوى المادة
  const directLinked = STATE.subjects.filter(s => (s.staff_ids || []).includes(uid));

  // المواد التي لها شعب يظهر فيها المراقب في staff_ids على مستوى الشعبة
  const fromSections = STATE.sections
    .filter(s => (s.staff_ids||[]).includes(uid))
    .map(s => s.subject_id);

  // الدمج
  const allSubjIds = new Set([...directLinked.map(s=>s.id), ...fromSections]);
  return STATE.subjects.filter(s => allSubjIds.has(s.id));
  // ⚠️ لا يوجد fallback من الامتحانات — المراقبة تعييناً لا تمنح صلاحية رؤية الطلاب
}

/**
 * الشعب التي يدرّسها/يرتبط بها المراقب فعلياً
 * ✅ شعبة تظهر إذا:
 *    (أ) المراقب في staff_ids للشعبة نفسها (ربط على مستوى الشعبة)
 *    (ب) أو المراقب في staff_ids للمادة (يمنحه كل شعب تلك المادة)
 * هذا يضمن أن المراقب يرى موادّه سواء رُبط بمستوى المادة أو بمستوى الشعبة.
 */
function getProctorScopeSections() {
  const uid = STATE.currentUser?.id;
  if (!uid) return [];
  // المواد المربوطة بالمراقب على مستوى المادة
  const subjLevelLinked = new Set(
    STATE.subjects.filter(s => (s.staff_ids||[]).includes(uid)).map(s => s.id)
  );
  return STATE.sections.filter(s =>
    (s.staff_ids||[]).includes(uid) ||         // ربط مباشر للشعبة
    subjLevelLinked.has(s.subject_id)          // ربط على مستوى المادة → كل شعبها
  );
}

/**
 * الشعب التي دُرِّس فيها المراقب كـ staff (لا علاقة بالمراقبة)
 */
function getProctorTeachingSections() {
  return getProctorScopeSections();
}

/** الامتحانات التي عُيِّن فيها المراقب (للسجل والطلبات) */
function getMyAssignedExams() {
  const uid = STATE.currentUser?.id;
  if (!uid) return [];
  return STATE.exams.filter(e => (e.proctor_ids||[]).includes(uid));
}

/** الامتحانات ضمن نطاق المراقب = امتحاناته المعيَّن فيها فقط */
function getProctorScopeExams() {
  return getMyAssignedExams();
}

/**
 * طلاب المراقب الحالي — فقط من مواده كمُدرِّس (staff_ids)
 * لا يشمل طلاب المواد التي راقب فيها فحسب
 */
function getProctorScopeStudents() {
  const secs = getProctorScopeSections(); // شعب التدريس فقط
  const secIds = new Set(secs.map(s => s.id));
  return STATE.students.filter(s =>
    (s.section_ids || []).some(id => secIds.has(id)) ||
    secs.some(sec => (sec.student_ids || []).includes(s.id))
  );
}

/**
 * هل المراقب مرتبط بمادة معينة كمُدرِّس (staff_ids)?
 * يُستخدم لتحديد ما إذا كان يستطيع رؤية طلاب الامتحان
 */
function proctorLinkedToSubject(proctorId, subjectId) {
  const subj = STATE.subjects.find(s => s.id == subjectId);
  if (!subj) return false;
  // ربط مباشر على مستوى المادة
  if ((subj.staff_ids || []).includes(proctorId)) return true;
  // ربط عبر شعبة
  return STATE.sections.some(sec =>
    sec.subject_id == subjectId && (sec.staff_ids||[]).includes(proctorId)
  );
  // لا يُعطى ربط بسبب المراقبة وحدها
}

/** رئيس القسم: يرى تقويم أعضاء القسم + امتحانات قسمه + طلبات المراقبة الواردة */
function deptHeadCanSeePage(pageId) {
  const allowed = ['dashboard','my-calendar','dept-calendar',
                   'exams','live','swaps','rooms','bookings',
                   'departments','subjects','proctors','students','analytics',
                   'cross-dept-requests','notifications','class-compare','ai-engine'];
  return allowed.includes(pageId);
}

/** العميد ومساعد العميد: قراءة فقط — يرون كل شيء عدا الإعدادات */
function deanCanSeePage(pageId) {
  const allowed = ['dashboard','calendar','exams','live','rooms','bookings',
                   'departments','subjects','proctors','students','analytics',
                   'class-compare','notifications'];
  return allowed.includes(pageId);
}

/** المنسق: مثل العميد لكن يرى الجميع — لا قسم محدد */
function coordinatorCanSeePage(pageId) {
  const allowed = ['dashboard','my-calendar','exams','live','swaps',
                   'cross-dept-requests','rooms','bookings','departments',
                   'subjects','proctors','students','analytics','notifications',
                   'class-compare','ai-engine','digital-seal','settings'];
  return allowed.includes(pageId);
}

/** الطالب: يرى بوابته وتقويمه الشخصي وإشعاراته */
function studentCanSeePage(pageId) {
  const allowed = ['student-portal', 'my-calendar', 'notifications'];
  return allowed.includes(pageId);
}

// 🆕 هل يمكن للمراقب رؤية بيانات مستخدم معين؟
function canViewUserData(targetUserId) {
  if (!isProctor()) return true; // غير المراقب يرى الجميع
  return targetUserId === STATE.currentUser?.id; // المراقب يرى نفسه فقط
}

// 🆕 هل يوجد تعارض في جدول مستخدم معين لوقت معين؟
function hasUserConflict(userId, date, startTime, endTime, excludeBookingId = null) {
  // فحص الحجوزات الشخصية
  const bookingConflict = STATE.userBookings.some(ub => {
    if (ub.user_id !== userId) return false;
    const b = STATE.bookings.find(bk => bk.id === ub.booking_id);
    if (!b || b.id === excludeBookingId) return false;
    if (b.date !== date) return false;
    return b.start_time < endTime && b.end_time > startTime;
  });
  if (bookingConflict) return true;

  // فحص الامتحانات
  const examConflict = STATE.exams.some(e => {
    if (!(e.proctor_ids || []).includes(userId)) return false;
    if (e.date !== date) return false;
    const eStart = e.time?.slice(0, 5) || '00:00';
    const eEnd = new Date(new Date(`${date}T${eStart}`).getTime() +
      ((e.duration || 60) + (e.extra_time || 0)) * 60000);
    const eEndStr = `${String(eEnd.getHours()).padStart(2,'0')}:${String(eEnd.getMinutes()).padStart(2,'0')}`;
    return eStart < endTime && eEndStr > startTime;
  });
  return examConflict;
}

// 🆕 حجوزات مستخدم معين (جدوله الشخصي)
function getUserBookings(userId) {
  const myBkIds = STATE.userBookings
    .filter(ub => ub.user_id === userId)
    .map(ub => ub.booking_id);
  return STATE.bookings.filter(b => myBkIds.includes(b.id));
}

// 🆕 الامتحانات المرتبطة بمراقب معين
function getUserExams(userId) {
  return STATE.exams.filter(e =>
    (e.proctor_ids || []).includes(userId)
  );
}

// 🆕 حالة قبول المراقب للامتحان
function getProctorStatus(examId, userId) {
  const exam = getExam(examId);
  if (!exam) return null;
  const statuses = exam.proctor_statuses || {};
  return statuses[userId] || 'pending';
}

// 🆕 عدد طلبات المراقبة المعلقة لقسم
function pendingCrossDeptCount(deptId) {
  return STATE.crossDeptRequests.filter(r =>
    r.target_dept_id === deptId && r.status === 'pending'
  ).length;
}

function examStatus(e) {
  if (!e) return 'unknown';
  const now   = new Date();
  const start = new Date(`${e.date}T${e.time}`);
  if (e.end_override) {
    const manualEnd = new Date(e.end_override);
    if (now >= manualEnd) return 'completed';
  }
  const end = new Date(start.getTime() + (e.duration + (e.extra_time||0)) * 60000);
  if (now < start)               return 'upcoming';
  if (now >= start && now < end) return 'active';
  return 'completed';
}

function calcPoints(e) {
  if (!e) return 1;
  const time = e.time || '09:00';
  const h = parseInt(String(time).split(':')[0]) || 9;
  const s = STATE.settings || {};

  const ptsMorning   = parseFloat(s.pts_morning   ?? 1);
  const ptsAfternoon = parseFloat(s.pts_afternoon ?? 1.5);
  const ptsEvening   = parseFloat(s.pts_evening   ?? 2);
  const ptsHoliday   = parseFloat(s.pts_holiday   ?? 1);
  const ptsLong      = parseFloat(s.pts_long      ?? 0.5);
  const ptsFinal     = parseFloat(s.pts_final_bonus ?? 0.5);

  let pts = h < 14 ? ptsMorning : h < 18 ? ptsAfternoon : ptsEvening;
  if (e.is_holiday)             pts += ptsHoliday;
  if ((e.duration||0) > 120)    pts += ptsLong;
  if (e.type === 'final')       pts += ptsFinal;
  // تقريب لرقم عشري واحد
  return Math.round(pts * 10) / 10;
}

const Hydrate = {
  profile: r => ({
    ...r,
    sem_x:       tryJSON(r.sem_x, {}),
    ratings:     tryJSON(r.ratings, []),
    active:      r.active === true || r.active === 'true',
    avg_rating:  parseFloat(r.avg_rating) || 0,
    points:      parseFloat(r.points) || 0,
    dept_id:     r.dept_id || null,
    signature:   r.signature || null,
    lang_pref:   r.lang_pref || 'ar',
    permissions: r.permissions ? (typeof r.permissions === 'string' ? tryJSON(r.permissions, null) : r.permissions) : null
  }),
  subject: r => ({
    ...r,
    staff_ids: tryJSON(r.staff_ids, [])
  }),
  exam: r => ({
    ...r,
    room_ids:        tryJSON(r.room_ids, []),
    proctor_ids:     tryJSON(r.proctor_ids, []),
    section_ids:     tryJSON(r.section_ids, []),
    room_sections:   tryJSON(r.room_sections, {}),
    room_proctors:   tryJSON(r.room_proctors, {}),
    exam_notes:      tryJSON(r.exam_notes, null),
    proctor_statuses: tryJSON(r.proctor_statuses, {}),  // 🆕
    is_holiday:      r.is_holiday === true,
    time: typeof r.time === 'string' ? r.time.slice(0,5) : r.time,
    // ✅ حقول المراجعة
    approval_status: r.approval_status || 'approved',
    approval_by:     r.approval_by    || null,
    approval_at:     r.approval_at    || null,
    approval_notes:  r.approval_notes || ''
  }),
  section: r => ({
    ...r,
    student_ids: tryJSON(r.student_ids, []),
    staff_ids:   tryJSON(r.staff_ids,   [])   // 🆕 مرتبطو الشعبة
  }),
  student: r => ({
    ...r,
    active: r.active !== false,
    banned: r.banned === true,
    subject_ids:  tryJSON(r.subject_ids, []),
    section_ids:  tryJSON(r.section_ids, [])
  }),
  settings: r => r ? {
    ...r,
    exam_instructions: tryJSON(r.exam_instructions, [])
  } : null,
  schedule: r => ({ ...r }),
  booking:  r => ({
    ...r,
    exam_id: r.exam_id||null,
    // ✅ يحتفظ بالنص الأصلي إن كان غير JSON (مثل "weekly", "daily")
    recurrence: (() => {
      if (!r.recurrence) return null;
      if (typeof r.recurrence !== 'string') return r.recurrence;
      const t = r.recurrence.trim();
      if (t.startsWith('{') || t.startsWith('[')) return tryJSON(t, t);
      return t;  // مجرد كلمة مفتاحية
    })(),
    is_course_booking: r.is_course_booking === true
  }),
  userBooking: r => ({ ...r }),                   // 🆕
  crossDeptRequest: r => ({ ...r }),               // 🆕
  semesterSchedule: r => ({ ...r })               // 🆕
};

const Serialize = {
  exam: e => ({
    subject_id:       e.subject_id,
    semester:         e.semester,
    date:             e.date,
    time:             e.time,
    duration:         e.duration,
    type:             e.type,
    room_ids:         e.room_ids     || [],
    proctor_ids:      e.proctor_ids  || [],
    section_ids:      e.section_ids  || [],
    room_sections:    e.room_sections || {},
    room_proctors:    e.room_proctors || {},
    extra_time:       e.extra_time   || 0,
    is_holiday:       !!e.is_holiday,
    max_grade:        e.max_grade    || 100,
    notes:            e.notes        || '',
    exam_notes:       e.exam_notes   || null,
    proctor_statuses: e.proctor_statuses || {},
    // ✅ حقول المراجعة
    approval_status:  e.approval_status || 'approved',
    approval_by:      e.approval_by    || null,
    approval_at:      e.approval_at    || null,
    approval_notes:   e.approval_notes || ''
  }),
  profile: p => ({
    name:      p.name,
    emp_id:    p.emp_id    || '',
    phone:     p.phone     || '',
    color:     p.color     || '#1a56db',
    points:    p.points    || 0,
    sem_x:     p.sem_x     || {},
    active:    !!p.active,
    dept_id:   p.dept_id   || null,
    signature: p.signature || ''
  }),
  student: s => ({
    stud_id:  s.stud_id,
    name:     s.name,
    batch:    s.batch  || 2024,
    email:    s.email  || '',
    phone:    s.phone  || '',
    active:   !!s.active,
    banned:   !!s.banned
  }),
  section: s => ({
    name:        s.name,
    subject_id:  s.subject_id,
    coord_id:    s.coord_id   || null,
    semester:    s.semester,
    student_ids: s.student_ids || [],
    staff_ids:   s.staff_ids   || []   // 🆕
  }),
  schedule: sc => ({
    subject_id:    sc.subject_id,
    section_id:    sc.section_id  || null,
    room_id:       sc.room_id     || null,
    instructor_id: sc.instructor_id || null,
    semester:      sc.semester,
    day_of_week:   sc.day_of_week,
    start_time:    sc.start_time,
    end_time:      sc.end_time,
    type:          sc.type        || 'lecture',
    is_recurring:  sc.is_recurring !== false,
    notes:         sc.notes       || '',
    color:         sc.color       || '#2563eb'
  }),
  booking: b => ({
    room_id:              b.room_id,
    booked_by:            b.booked_by,
    title:                b.title,
    purpose:              b.purpose   || 'lecture',
    date:                 b.date,
    start_time:           b.start_time,
    end_time:             b.end_time,
    status:               b.status    || 'confirmed',
    notes:                b.notes     || '',
    subject_id:           b.subject_id || null,
    section_id:           b.section_id || null,
    recurrence:           b.recurrence || null,
    recurrence_group:     b.recurrence_group || null,
    is_course_booking:    !!b.is_course_booking
  }),
  semesterSchedule: s => ({                           // 🆕
    semester:       s.semester,
    subject_id:     s.subject_id || null,
    section_id:     s.section_id || null,
    room_id:        s.room_id    || null,
    instructor_id:  s.instructor_id || null,
    day_of_week:    s.day_of_week,
    start_time:     s.start_time,
    end_time:       s.end_time,
    type:           s.type   || 'lecture',
    notes:          s.notes  || '',
    auto_book:      s.auto_book !== false,
    is_active:      s.is_active !== false
  })
};

function tryJSON(val, fallback) {
  if (val === null || val === undefined) return fallback;
  if (typeof val === 'object') return val;
  try { return JSON.parse(val); } catch { return fallback; }
}

function incSem(profileId) {
  const u = getProfile(profileId);
  if (!u) return;
  if (!u.sem_x) u.sem_x = {};
  u.sem_x[STATE.currentSem] = (u.sem_x[STATE.currentSem] || 0) + 1;
}
function decSem(profileId) {
  const u = getProfile(profileId);
  if (!u) return;
  if (!u.sem_x) u.sem_x = {};
  u.sem_x[STATE.currentSem] = Math.max(0,(u.sem_x[STATE.currentSem] || 0) - 1);
}
function semCount(profileId) {
  return getProfile(profileId)?.sem_x?.[STATE.currentSem] || 0;
}
