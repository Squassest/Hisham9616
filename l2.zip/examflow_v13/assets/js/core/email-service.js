// ═══════════════════════════════════════════════════════════════
//  email-service.js — خدمة إرسال الإيميلات عبر EmailJS / Webhook
// ═══════════════════════════════════════════════════════════════

const EmailService = (() => {

  function _cfg() { return STATE.settings?.email_config || {}; }

  // ── إرسال بريد عبر EmailJS أو Webhook ──────────────────────
  async function send({ to, subject, html, text }) {
    const cfg = _cfg();
    if (!cfg.enabled) return false;

    // EmailJS mode
    if (cfg.provider === 'emailjs') {
      if (!cfg.service_id || !cfg.user_id) return false;
      const params = { to_email: Array.isArray(to) ? to.join(',') : to, subject, message: html || text };
      try {
        await fetch(`https://api.emailjs.com/api/v1.0/email/send`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            service_id:  cfg.service_id,
            template_id: cfg.template_id || 'template_examflow',
            user_id:     cfg.user_id,
            template_params: params
          })
        });
        return true;
      } catch(e) { console.error('[EmailJS]', e); return false; }
    }

    // Webhook/n8n/Zapier mode
    if (cfg.provider === 'webhook' && cfg.webhook_url) {
      try {
        await fetch(cfg.webhook_url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ to, subject, html, text })
        });
        return true;
      } catch(e) { console.error('[Webhook Email]', e); return false; }
    }

    return false;
  }

  // ── قالب تقرير الامتحان ──────────────────────────────────────
  function examReportHTML(exam) {
    const sub     = getSubject(exam.subject_id);
    const rooms   = (exam.room_ids||[]).map(id=>getRoom(id)?.name).filter(Boolean);
    const procts  = (exam.proctor_ids||[]).map(id=>getProfile(id)).filter(Boolean);
    const secs    = (exam.section_ids||[]).map(id=>getSection(id)).filter(Boolean);
    const att     = STATE.attendance[exam.id] || {};
    const studIds = new Set();
    secs.forEach(s=>(s.student_ids||[]).forEach(id=>studIds.add(id)));
    const total   = studIds.size;
    const present = [...studIds].filter(id=>att[id]==='present'||att[id]==='late').length;
    const absent  = total - present;
    const uni     = STATE.settings?.university_name || 'كلية التمريض';

    return `
<!DOCTYPE html><html dir="rtl" lang="ar">
<head><meta charset="UTF-8">
<style>
  body{font-family:Arial,sans-serif;background:#f0f4f8;margin:0;padding:20px;direction:rtl}
  .container{max-width:680px;margin:0 auto;background:white;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.1)}
  .header{background:linear-gradient(135deg,#1e40af,#3b82f6);color:white;padding:32px;text-align:center}
  .header h1{margin:0 0 8px;font-size:24px}
  .header p{margin:0;opacity:.8;font-size:14px}
  .body{padding:28px}
  .stat-row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0}
  .stat{background:#f8fafc;border-radius:12px;padding:16px;text-align:center;border:1.5px solid #e2e8f0}
  .stat-val{font-size:28px;font-weight:900;color:#1e40af}
  .stat-lbl{font-size:12px;color:#64748b;margin-top:4px}
  .section{margin:16px 0;padding:16px;background:#f8fafc;border-radius:10px;border-right:4px solid #3b82f6}
  .section-title{font-weight:700;font-size:13px;color:#374151;margin-bottom:8px}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th{background:#f1f5f9;padding:10px 12px;text-align:right;font-weight:700;color:#374151}
  td{padding:9px 12px;border-bottom:1px solid #e2e8f0}
  tr:last-child td{border:none}
  .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700}
  .b-green{background:#d1fae5;color:#065f46}
  .b-red{background:#fee2e2;color:#991b1b}
  .b-gold{background:#fef3c7;color:#92400e}
  .footer{background:#f8fafc;padding:16px 28px;font-size:12px;color:#94a3b8;text-align:center}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>🎓 تقرير امتحان</h1>
    <p>${uni}</p>
  </div>
  <div class="body">
    <div class="section">
      <div class="section-title">📋 تفاصيل الامتحان</div>
      <table>
        <tr><th>المادة</th><td>${sub?.name||'—'} <small style="color:#64748b">(${sub?.code||''})</small></td></tr>
        <tr><th>النوع</th><td>${exam.type==='final'?'نهائي':exam.type==='midterm'?'منتصف الفصل':exam.type==='quiz'?'اختبار قصير':'إعادة'}</td></tr>
        <tr><th>التاريخ</th><td>${exam.date}</td></tr>
        <tr><th>الوقت</th><td>${exam.time?.slice(0,5)} — المدة: ${exam.duration} دقيقة${exam.extra_time?` + ${exam.extra_time} إضافية`:''}</td></tr>
        <tr><th>القاعات</th><td>${rooms.join('، ') || '—'}</td></tr>
        <tr><th>الشعب</th><td>${secs.map(s=>s.name).join('، ') || '—'}</td></tr>
      </table>
    </div>

    <div class="stat-row">
      <div class="stat"><div class="stat-val">${total}</div><div class="stat-lbl">إجمالي الطلاب</div></div>
      <div class="stat"><div class="stat-val" style="color:#059669">${present}</div><div class="stat-lbl">حاضرون</div></div>
      <div class="stat"><div class="stat-val" style="color:#dc2626">${absent}</div><div class="stat-lbl">غائبون</div></div>
    </div>

    <div class="section">
      <div class="section-title">👨‍💼 المراقبون (${procts.length})</div>
      ${procts.length ? procts.map(p=>`<div style="padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:13px">👤 ${p.name} <small style="color:#64748b">${p.email||''}</small></div>`).join('') : '<div style="color:#94a3b8;font-size:13px">لم يتم تعيين مراقبين</div>'}
    </div>

    ${exam.notes ? `<div class="section">
      <div class="section-title">📝 ملاحظات</div>
      <p style="margin:0;font-size:13px;color:#374151">${exam.notes}</p>
    </div>` : ''}
  </div>
  <div class="footer">
    تم إنشاء هذا التقرير تلقائياً من نظام ExamFlow · ${new Date().toLocaleString('ar-SA')}
  </div>
</div>
</body></html>`;
  }

  // ── قالب إشعار إنشاء امتحان جديد ──────────────────────────
  function newExamHTML(exam) {
    const sub  = getSubject(exam.subject_id);
    const secs = (exam.section_ids||[]).map(id=>getSection(id)).filter(Boolean);
    const uni  = STATE.settings?.university_name || 'كلية التمريض';

    return `
<!DOCTYPE html><html dir="rtl" lang="ar">
<head><meta charset="UTF-8">
<style>
  body{font-family:Arial,sans-serif;background:#f0f4f8;margin:0;padding:20px;direction:rtl}
  .container{max-width:600px;margin:0 auto;background:white;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.1)}
  .header{background:linear-gradient(135deg,#7c3aed,#a78bfa);color:white;padding:32px;text-align:center}
  .body{padding:28px}
  .info-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #e2e8f0;font-size:14px}
  .info-lbl{color:#64748b;font-weight:700}
  .info-val{color:#1e293b;font-weight:600}
  .footer{background:#f8fafc;padding:14px 28px;font-size:12px;color:#94a3b8;text-align:center}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1 style="margin:0 0 8px;font-size:22px">📅 امتحان جديد</h1>
    <p style="margin:0;opacity:.8">${uni}</p>
  </div>
  <div class="body">
    <p style="font-size:15px;margin-bottom:20px">تم جدولة امتحان جديد — التفاصيل أدناه:</p>
    <div class="info-row"><span class="info-lbl">المادة</span><span class="info-val">${sub?.name||'—'} (${sub?.code||''})</span></div>
    <div class="info-row"><span class="info-lbl">التاريخ</span><span class="info-val">${exam.date}</span></div>
    <div class="info-row"><span class="info-lbl">الوقت</span><span class="info-val">${exam.time?.slice(0,5)}</span></div>
    <div class="info-row"><span class="info-lbl">المدة</span><span class="info-val">${exam.duration} دقيقة</span></div>
    <div class="info-row"><span class="info-lbl">الشعب</span><span class="info-val">${secs.map(s=>s.name).join('، ')||'—'}</span></div>
    <div class="info-row"><span class="info-lbl">النوع</span><span class="info-val">${exam.type==='final'?'نهائي':exam.type==='midterm'?'منتصف فصل':exam.type==='quiz'?'اختبار':exam.type}</span></div>
  </div>
  <div class="footer">نظام ExamFlow · ${new Date().toLocaleDateString('ar-SA')}</div>
</div></body></html>`;
  }

  // ── إرسال تقرير بعد انتهاء الامتحان ───────────────────────
  async function sendExamReport(examId) {
    const exam = getExam(examId); if (!exam) return;
    const sub  = getSubject(exam.subject_id);
    const html = examReportHTML(exam);
    const subject = `تقرير امتحان: ${sub?.name||''} — ${exam.date}`;

    // جمع المستلمين: المراقبون + رئيس القسم + المسؤول
    const recipients = new Set();
    (exam.proctor_ids||[]).forEach(id => { const p=getProfile(id); if(p?.email) recipients.add(p.email); });

    // رئيس القسم
    const deptSubj = getSubject(exam.subject_id);
    if (deptSubj?.dept_id) {
      const dept = STATE.departments.find(d=>d.id===deptSubj.dept_id);
      if (dept?.head_id) { const h=getProfile(dept.head_id); if(h?.email) recipients.add(h.email); }
    }
    // المسؤولون
    STATE.profiles.filter(p=>p.role==='admin'&&p.email).forEach(p=>recipients.add(p.email));

    if (!recipients.size) return;
    const ok = await send({ to: [...recipients], subject, html });
    if (ok) console.log('[EmailService] Exam report sent to', [...recipients]);
    return ok;
  }

  // ── إرسال إشعار إنشاء امتحان جديد ─────────────────────────
  async function sendNewExamNotif(exam) {
    const sub     = getSubject(exam.subject_id);
    const html    = newExamHTML(exam);
    const subject = `امتحان جديد: ${sub?.name||''} — ${exam.date}`;

    const recipients = new Set();
    (exam.proctor_ids||[]).forEach(id=>{ const p=getProfile(id); if(p?.email) recipients.add(p.email); });
    STATE.profiles.filter(p=>(p.role==='admin'||p.role==='coordinator')&&p.email).forEach(p=>recipients.add(p.email));
    const deptSubj = getSubject(exam.subject_id);
    if (deptSubj?.dept_id) {
      const dept = STATE.departments.find(d=>d.id===deptSubj.dept_id);
      if (dept?.head_id) { const h=getProfile(dept.head_id); if(h?.email) recipients.add(h.email); }
    }

    if (!recipients.size) return;
    await send({ to: [...recipients], subject, html });
  }

  return { send, sendExamReport, sendNewExamNotif, examReportHTML, newExamHTML };
})();
