// ═══════════════════════════════════════════════════════════════
//  theme.js — تبديل بين الوضع الفاتح/الداكن (مع حفظ التفضيل)
// ═══════════════════════════════════════════════════════════════

const THEME = (() => {
  const KEY = 'ef_theme';

  function get() {
    return localStorage.getItem(KEY) || _system();
  }
  function _system() {
    return matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  function apply(t) {
    document.documentElement.setAttribute('data-theme', t);
    document.body?.classList.toggle('theme-dark', t === 'dark');
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = t === 'dark' ? '#050a14' : '#1a56db';
  }
  function set(t) {
    localStorage.setItem(KEY, t);
    apply(t);
  }
  function toggle() {
    set(get() === 'dark' ? 'light' : 'dark');
  }
  function init() {
    apply(get());
    matchMedia?.('(prefers-color-scheme: dark)')
      .addEventListener?.('change', e => {
        if (!localStorage.getItem(KEY)) apply(e.matches ? 'dark' : 'light');
      });
  }
  return { get, set, toggle, init };
})();

// تطبيق فوري قبل بناء الواجهة لتجنب فلاش
THEME.init();

// زر علوي قابل للحقن في أي شريط
function renderThemeToggle() {
  const t = THEME.get();
  return `<button class="theme-toggle" onclick="THEME.toggle()" title="تبديل الوضع">
    <i class="fas fa-${t === 'dark' ? 'sun' : 'moon'}"></i>
  </button>`;
}
