// ═══════════════════════════════════════════════════════════════
//  geolocation.js — تحقق جغرافي للحضور
// ═══════════════════════════════════════════════════════════════

const GEO = (() => {

  function getCurrent(opts = {}) {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('GPS غير مدعوم'));
      navigator.geolocation.getCurrentPosition(
        p => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }),
        e => reject(new Error(_err(e.code))),
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 0, ...opts }
      );
    });
  }

  // مسافة Haversine بالمتر
  function distance(a, b) {
    const R = 6371000;
    const φ1 = a.lat * Math.PI/180, φ2 = b.lat * Math.PI/180;
    const Δφ = (b.lat - a.lat) * Math.PI/180;
    const Δλ = (b.lng - a.lng) * Math.PI/180;
    const x = Math.sin(Δφ/2)**2 + Math.cos(φ1)*Math.cos(φ2)*Math.sin(Δλ/2)**2;
    return 2 * R * Math.asin(Math.sqrt(x));
  }

  function inRadius(target, current, radiusM = 50) {
    if (!target?.lat || !current?.lat) return true;
    return distance(target, current) <= radiusM;
  }

  function _err(code) {
    return { 1:'تم رفض إذن الموقع', 2:'تعذر الحصول على الموقع', 3:'انتهت المهلة' }[code] || 'خطأ GPS';
  }

  // بصمة جهاز خفيفة (لمنع التزوير المتعدد)
  async function deviceHash() {
    const s = [navigator.userAgent, navigator.language, screen.width+'x'+screen.height,
               new Date().getTimezoneOffset(), navigator.hardwareConcurrency||0].join('|');
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
    return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('').slice(0,32);
  }

  return { getCurrent, distance, inRadius, deviceHash };
})();
