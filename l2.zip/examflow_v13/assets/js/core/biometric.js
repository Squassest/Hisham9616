// ═══════════════════════════════════════════════════════════════
//  biometric.js v3 — WebAuthn (بصمة/Face ID) للموظفين والطلاب
//  - يدعم تسجيل البصمة للموظفين (staff_credentials) والطلاب (student_credentials)
//  - يدعم تسجيل الدخول التلقائي بالبصمة بدون إدخال ID
//  - تخزين credential_id + public_key في Supabase
//  - _db() يعمل قبل وبعد تهيئة SB (أثناء شاشة الدخول)
// ═══════════════════════════════════════════════════════════════

const BIO = (() => {

  const RP_NAME = 'ExamFlow';
  const _RP_ID  = () => location.hostname;

  // ── Supabase client آمن: يعمل قبل وبعد SB.init() ────────────
  function _db() {
    // 1. بعد تهيئة التطبيق — SB كاملاً جاهز
    if (typeof SB !== 'undefined' && SB.getClient && SB.getClient()) {
      return SB.getClient();
    }
    // 2. أثناء شاشة الدخول — main.js يضعه في window._efSB مباشرة بعد إنشائه
    if (window._efSB) return window._efSB;
    // 3. لم يُهيَّأ بعد (لن يحدث في الممارسة العادية)
    throw new Error('تعذّر الاتصال بقاعدة البيانات — يرجى تحديث الصفحة');
  }

  const _b64u = {
    enc: (buf) => {
      if (!buf) throw new Error('getPublicKey() returned null — authenticator not supported');
      return btoa(String.fromCharCode(...new Uint8Array(buf)))
             .replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    },
    dec: (str) => {
      str = (str+'').replace(/-/g,'+').replace(/_/g,'/');
      while (str.length % 4) str += '=';
      const bin = atob(str);
      const out = new Uint8Array(bin.length);
      for (let i=0;i<bin.length;i++) out[i] = bin.charCodeAt(i);
      return out.buffer;
    }
  };

  function _rand(len=32) {
    const a = new Uint8Array(len);
    crypto.getRandomValues(a);
    return a.buffer;
  }

  async function isAvailable() {
    if (!window.PublicKeyCredential) return false;
    try {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch { return false; }
  }

  // ═══════════════════════════════════════════════════════════════
  //  STUDENT CREDENTIALS
  // ═══════════════════════════════════════════════════════════════

  async function register(student) {
    if (!await isAvailable()) throw new Error('جهازك لا يدعم البصمة. استخدم هاتف به Touch/Face ID');
    const userId = new TextEncoder().encode('student_'+String(student.id)).buffer;
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge: _rand(),
        rp: { name: RP_NAME, id: _RP_ID() },
        user: { id: userId, name: student.stud_id||('s'+student.id), displayName:(student.name||'')+'(طالب)' },
        pubKeyCredParams: [{type:'public-key',alg:-7},{type:'public-key',alg:-257}],
        authenticatorSelection: { authenticatorAttachment:'platform', userVerification:'required', residentKey:'preferred' },
        timeout: 60000, attestation: 'none'
      }
    });
    if (!cred) throw new Error('تم إلغاء التسجيل');
    const credentialId = _b64u.enc(cred.rawId);
    const pkBuf = cred.response.getPublicKey ? cred.response.getPublicKey() : null;
    const publicKey = _b64u.enc(pkBuf || cred.response.attestationObject);
    const deviceLabel = navigator.userAgent.match(/(iPhone|iPad|Android|Mac|Windows|Linux)/)?.[0]||'device';
    const { error } = await _db().from('student_credentials').insert({ student_id:student.id, credential_id:credentialId, public_key:publicKey, device_label:deviceLabel });
    if (error) throw new Error(error.message);
    return { credentialId };
  }

  async function authenticate(student) {
    const { data:creds, error } = await _db().from('student_credentials').select('credential_id').eq('student_id', student.id);
    if (error) throw error;
    if (!creds?.length) throw new Error('لا توجد بصمة مسجلة لهذا الطالب');
    const allow = creds.map(c => ({ type:'public-key', id:_b64u.dec(c.credential_id), transports:['internal'] }));
    const assertion = await navigator.credentials.get({ publicKey: { challenge:_rand(), rpId:_RP_ID(), allowCredentials:allow, userVerification:'required', timeout:60000 } });
    if (!assertion) throw new Error('فشل التحقق');
    await _db().from('student_credentials').update({ last_used_at:new Date().toISOString() }).eq('credential_id', _b64u.enc(assertion.rawId));
    return { credentialId: _b64u.enc(assertion.rawId) };
  }

  async function authenticateStudentAuto() {
    const assertion = await navigator.credentials.get({ publicKey: { challenge:_rand(), rpId:_RP_ID(), allowCredentials:[], userVerification:'required', timeout:60000 } });
    if (!assertion) throw new Error('فشل التحقق');
    const credId = _b64u.enc(assertion.rawId);
    const { data, error } = await _db().from('student_credentials').select('student_id').eq('credential_id', credId).maybeSingle();
    if (error||!data) throw new Error('بيانات البصمة غير موجودة في النظام');
    await _db().from('student_credentials').update({ last_used_at:new Date().toISOString() }).eq('credential_id', credId);
    return { studentId:data.student_id, credentialId:credId };
  }

  async function unregister(studentId) {
    const { error } = await _db().from('student_credentials').delete().eq('student_id', studentId);
    if (error) throw error;
  }

  async function listForStudent(studentId) {
    const { data } = await _db().from('student_credentials').select('*').eq('student_id', studentId);
    return data||[];
  }

  // ═══════════════════════════════════════════════════════════════
  //  STAFF CREDENTIALS
  // ═══════════════════════════════════════════════════════════════

  async function registerStaff(user) {
    if (!await isAvailable()) throw new Error('جهازك لا يدعم البصمة. استخدم هاتف به Touch/Face ID');
    const userId = new TextEncoder().encode('staff_'+String(user.id)).buffer;
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge: _rand(),
        rp: { name: RP_NAME, id: _RP_ID() },
        user: { id:userId, name:user.email||('u'+user.id), displayName:(user.name||'')+'(موظف)' },
        pubKeyCredParams: [{type:'public-key',alg:-7},{type:'public-key',alg:-257}],
        authenticatorSelection: { authenticatorAttachment:'platform', userVerification:'required', residentKey:'preferred' },
        timeout: 60000, attestation: 'none'
      }
    });
    if (!cred) throw new Error('تم إلغاء التسجيل');
    const credentialId = _b64u.enc(cred.rawId);
    const pkBuf = cred.response.getPublicKey ? cred.response.getPublicKey() : null;
    const publicKey = _b64u.enc(pkBuf || cred.response.attestationObject);
    const deviceLabel = navigator.userAgent.match(/(iPhone|iPad|Android|Mac|Windows|Linux)/)?.[0]||'device';
    const { error } = await _db().from('staff_credentials').insert({ user_id:user.id, credential_id:credentialId, public_key:publicKey, device_label:deviceLabel });
    if (error) throw new Error(error.message);
    return { credentialId };
  }

  async function authenticateStaff(user) {
    const { data:creds, error } = await _db().from('staff_credentials').select('credential_id').eq('user_id', user.id);
    if (error) throw error;
    if (!creds?.length) throw new Error('لا توجد بصمة مسجلة لهذا المستخدم');
    const allow = creds.map(c => ({ type:'public-key', id:_b64u.dec(c.credential_id), transports:['internal'] }));
    const assertion = await navigator.credentials.get({ publicKey: { challenge:_rand(), rpId:_RP_ID(), allowCredentials:allow, userVerification:'required', timeout:60000 } });
    if (!assertion) throw new Error('فشل التحقق');
    await _db().from('staff_credentials').update({ last_used_at:new Date().toISOString() }).eq('credential_id', _b64u.enc(assertion.rawId));
    return { credentialId: _b64u.enc(assertion.rawId) };
  }

  async function authenticateStaffAuto() {
    const assertion = await navigator.credentials.get({ publicKey: { challenge:_rand(), rpId:_RP_ID(), allowCredentials:[], userVerification:'required', timeout:60000 } });
    if (!assertion) throw new Error('فشل التحقق');
    const credId = _b64u.enc(assertion.rawId);
    const { data, error } = await _db().from('staff_credentials').select('user_id').eq('credential_id', credId).maybeSingle();
    if (error||!data) throw new Error('بيانات البصمة غير موجودة في النظام');
    await _db().from('staff_credentials').update({ last_used_at:new Date().toISOString() }).eq('credential_id', credId);
    return { userId:data.user_id, credentialId:credId };
  }

  async function unregisterStaff(userId) {
    const { error } = await _db().from('staff_credentials').delete().eq('user_id', userId);
    if (error) throw error;
  }

  async function listForStaff(userId) {
    const { data } = await _db().from('staff_credentials').select('*').eq('user_id', userId);
    return data||[];
  }

  // ═══════════════════════════════════════════════════════════════
  //  AUTO-DISCOVER — يعرف تلقائياً موظف أو طالب
  // ═══════════════════════════════════════════════════════════════
  async function authenticateAny() {
    const assertion = await navigator.credentials.get({
      publicKey: { challenge:_rand(), rpId:_RP_ID(), allowCredentials:[], userVerification:'required', timeout:60000 }
    });
    if (!assertion) throw new Error('فشل التحقق');
    const credId = _b64u.enc(assertion.rawId);

    // ابحث في staff أولاً
    const { data:sd } = await _db().from('staff_credentials').select('user_id').eq('credential_id', credId).maybeSingle();
    if (sd?.user_id) {
      await _db().from('staff_credentials').update({ last_used_at:new Date().toISOString() }).eq('credential_id', credId);
      return { type:'staff', userId:sd.user_id, credentialId:credId };
    }

    // ابحث في students
    const { data:stData } = await _db().from('student_credentials').select('student_id').eq('credential_id', credId).maybeSingle();
    if (stData?.student_id) {
      await _db().from('student_credentials').update({ last_used_at:new Date().toISOString() }).eq('credential_id', credId);
      return { type:'student', studentId:stData.student_id, credentialId:credId };
    }

    throw new Error('بيانات البصمة غير موجودة في النظام. سجّل بصمتك أولاً.');
  }

  return {
    isAvailable,
    register, authenticate, authenticateStudentAuto, unregister, listForStudent,
    registerStaff, authenticateStaff, authenticateStaffAuto, unregisterStaff, listForStaff,
    authenticateAny
  };
})();

// تأكيد التوفر عبر window لأن const لا يُضاف تلقائياً لـ window
window.BIO = BIO;
