// utils.js — أدوات مساعدة

// ── سجل الإشعارات الدائم ─────────────────────────────────────
window._toastLog = window._toastLog || [];

function toast(msg, type='info', dur=3500) {
  const icons = { success:'fa-check-circle', error:'fa-times-circle', warning:'fa-exclamation-triangle', info:'fa-info-circle' };

  // ① حفظ في السجل الدائم
  window._toastLog.unshift({ msg, type, time: new Date(), icon: icons[type]||icons.info });
  if (window._toastLog.length > 50) window._toastLog.pop();
  _updateToastBadge();

  // ② عرض Toast المؤقت
  let c = document.getElementById('toastContainer');
  if (!c) {
    c = document.createElement('div');
    c.id = 'toastContainer';
    c.style.cssText = 'position:fixed;bottom:20px;inset-inline-end:20px;z-index:999999;display:flex;flex-direction:column;gap:8px;pointer-events:none;max-width:360px;';
    document.body.appendChild(c);
  }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.style.cssText = `--dur:${dur/1000}s;pointer-events:auto;z-index:999999;position:relative;`;
  el.innerHTML = `<i class="fas ${icons[type]||icons.info}"></i><span>${msg}</span>`;
  c.appendChild(el);
  setTimeout(() => { el.style.opacity='0'; el.style.transform='translateX(100%)'; setTimeout(()=>el.remove(),350); }, dur);
}

function _updateToastBadge() {
  const badge = document.getElementById('toastLogBadge');
  if (badge) {
    badge.textContent = window._toastLog.length;
    badge.style.display = 'flex';
  }
}

function openToastLog() {
  const moId = 'toastLogMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  const clrMap = { success:'var(--green2)', error:'var(--red2)', warning:'var(--gold)', info:'var(--primary)' };
  const bgMap  = { success:'var(--green-bg)', error:'var(--red-bg,#fef2f2)', warning:'var(--gold-bg,#fef9c3)', info:'var(--primary-bg)' };

  const rows = window._toastLog.length
    ? window._toastLog.map(n => {
        const t = n.time instanceof Date ? n.time : new Date(n.time);
        const timeStr = t.toLocaleTimeString('ar-SA',{hour:'2-digit',minute:'2-digit'});
        return `<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border)">
          <div style="width:32px;height:32px;border-radius:8px;flex-shrink:0;
            background:${bgMap[n.type]||'var(--bg2)'};color:${clrMap[n.type]||'var(--txt2)'};
            display:flex;align-items:center;justify-content:center;font-size:14px">
            <i class="fas ${n.icon}"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:13px;font-weight:600;color:${clrMap[n.type]||'var(--txt)'}">${esc(n.msg)}</div>
            <div style="font-size:11px;color:var(--txt3);margin-top:2px">${timeStr}</div>
          </div>
        </div>`;
      }).join('')
    : `<div style="padding:32px;text-align:center;color:var(--txt3)">
         <i class="fas fa-bell-slash" style="font-size:28px;opacity:.3;display:block;margin-bottom:8px"></i>
         لا توجد إشعارات مؤخراً
       </div>`;

  mo.innerHTML = `
    <div class="md" style="max-width:420px;max-height:80vh;display:flex;flex-direction:column">
      <div class="md-hd">
        <h2><i class="fas fa-history" style="color:var(--primary)"></i> سجل الإشعارات</h2>
        <div style="display:flex;gap:8px;align-items:center">
          <button onclick="window._toastLog=[];_updateToastBadge();openToastLog()"
            style="font-size:11px;padding:4px 10px;border-radius:6px;border:1px solid var(--border);
              background:var(--bg2);color:var(--txt2);cursor:pointer;font-family:inherit">
            <i class="fas fa-trash"></i> مسح
          </button>
          <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
        </div>
      </div>
      <div style="flex:1;overflow-y:auto">${rows}</div>
    </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

// ── Modals ──────────────────────────────────────────────────
// Stack counter for nested modals
let _moStack = 0;
function showMo(id) {
  const el = document.getElementById(id);
  if (!el) return;
  _moStack++;
  el.style.zIndex = String(50000 + _moStack * 10);
  requestAnimationFrame(() => el.classList.add('open'));
}
const openMo = showMo; // alias
function closeMo(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.remove('open'); _moStack = Math.max(0, _moStack-1); }
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('mo')) {
    // حماية النوافذ المقيّدة — لا تُغلَق إلا بزر الإغلاق
    if (e.target.dataset.protected === '1') return;
    e.target.classList.remove('open');
    _moStack = Math.max(0, _moStack - 1);
  }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.mo.open').forEach(m => {
      if (m.dataset.protected === '1') return; // نوافذ محمية لا تُغلق بـ Escape
      m.classList.remove('open');
      _moStack = Math.max(0, _moStack - 1);
    });
  }
});

// ── DOM helpers ─────────────────────────────────────────────
function setHTML(id, html) { const el=document.getElementById(id); if(el) el.innerHTML=html; }
function esc(str) { return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// ── Date/Time ───────────────────────────────────────────────
function fmtDate(d) {
  if (!d) return '—';
  return new Date(d+'T00:00:00').toLocaleDateString('ar-OM',{weekday:'short',day:'numeric',month:'short'});
}
function fmtTime(t) {
  if (!t) return '—';
  const [h,m] = t.split(':').map(Number);
  const ampm = h < 12 ? 'ص' : 'م';
  const h12  = h%12||12;
  return `${h12}:${String(m).padStart(2,'0')} ${ampm}`;
}
function fmtDateTime(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleString('ar-OM',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
}

// ── Avatar ──────────────────────────────────────────────────
function getInitials(name) {
  if (!name) return '؟';
  const parts = name.trim().split(' ').filter(Boolean);
  if (parts.length >= 2) return parts[0][0] + parts[1][0];
  return parts[0]?.slice(0,2) || '؟';
}

function getRoleAvatarIcon(role) {
  if (role==='dept_head') return 'fa-chalkboard-teacher';
  const icons = {
    admin:       'fa-user-shield',
    coordinator: 'fa-user-tie',
    proctor:     'fa-user-check',
    student:     'fa-user-graduate'
  };
  return icons[role] || 'fa-user';
}

function userAvatar(u, size=36) {
  const color = u?.color || APP_CONFIG.ROLE_COLORS?.[u?.role] || '#2563eb';
  const icon  = getRoleAvatarIcon(u?.role);
  return `<div style="width:${size}px;height:${size}px;border-radius:${Math.round(size*.28)}px;background:${color};display:flex;align-items:center;justify-content:center;flex-shrink:0;" title="${u?.name||''}">
    <i class="fas ${icon}" style="color:white;font-size:${Math.round(size*.42)}px"></i>
  </div>`;
}

// ── Badges ──────────────────────────────────────────────────
function getStatusBadge(status) {
  const map = { active:'b-green', upcoming:'b-blue', completed:'b-gray' };
  const lbl = { active:'جارٍ', upcoming:'قادم', completed:'منتهى' };
  return `<span class="badge ${map[status]||'b-gray'}">${lbl[status]||status}</span>`;
}
function getTypeBadge(type) {
  const map = { final:'b-red', midterm:'b-gold', quiz:'b-blue', makeup:'b-purple' };
  const lbl = { final:'نهائي', midterm:'منتصف', quiz:'اختبار', makeup:'إعادة' };
  return `<span class="badge ${map[type]||'b-gray'}">${lbl[type]||type}</span>`;
}
function getRoleBadge(role) {
  const map = {
    admin:'b-blue', coordinator:'b-teal', dept_head:'b-purple', proctor:'b-green',
    dean:'b-red', assistant_dean:'b-red', student:'b-blue'
  };
  return `<span class="badge ${map[role]||'b-gray'}">${APP_CONFIG.ROLES[role]||role}</span>`;
}
function getTypeLabel(type) {
  return {final:'نهائي',midterm:'منتصف الفصل',quiz:'اختبار',makeup:'إعادة'}[type]||type;
}
function roleIcon(role) {
  return APP_CONFIG.ROLE_ICONS[role] || 'fa-user';
}
function getRoleLabel(role) { return APP_CONFIG.ROLES[role]||role; }

// ── Empty State ─────────────────────────────────────────────
function emptyState(icon, title, sub='') {
  return `<div class="empty-state"><i class="fas ${icon}"></i><p>${title}</p>${sub?`<span>${sub}</span>`:''}</div>`;
}

// ── Confirm Delete ──────────────────────────────────────────
// _confirmCallbacks يحفظ الـ cb مباشرة بدون toString (يحل مشكلة فقدان closure)
const _confirmCallbacks = {};
function confirmDelete(msg, cb) {
  const key = 'k' + Date.now();
  _confirmCallbacks[key] = cb;
  const mo = document.createElement('div');
  mo.className = 'mo';
  mo.id = 'confirmDel_' + key;
  mo.innerHTML = `<div class="md" style="max-width:380px;text-align:center">
    <div class="md-bd" style="padding:32px">
      <div style="width:64px;height:64px;border-radius:50%;background:var(--red2)15;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;border:2px solid var(--red2)30">
        <i class="fas fa-trash" style="color:var(--red2);font-size:24px"></i>
      </div>
      <h3 style="font-family:'Tajawal',sans-serif;margin-bottom:8px;font-size:18px">تأكيد الحذف</h3>
      <p style="color:var(--txt2);font-size:13.5px;margin-bottom:24px;line-height:1.6">${msg}</p>
      <div style="display:flex;gap:10px">
        <button class="btn bo" style="flex:1;height:44px" onclick="this.closest('.mo').remove()"><i class="fas fa-times"></i> إلغاء</button>
        <button class="btn bd" style="flex:1;height:44px" id="cdb_${key}"><i class="fas fa-trash"></i> تأكيد الحذف</button>
      </div>
    </div>
  </div>`;
  document.body.appendChild(mo);
  requestAnimationFrame(() => {
    mo.classList.add('open');
    const btn = document.getElementById('cdb_' + key);
    if (btn) btn.addEventListener('click', async () => {
      mo.remove();
      const fn = _confirmCallbacks[key];
      delete _confirmCallbacks[key];
      if (fn) await fn();
    });
  });
}

// ── Password helpers ────────────────────────────────────────
function checkPassStrength(inputId, barId, lblId) {
  const val = document.getElementById(inputId)?.value || '';
  let score = 0;
  if (val.length >= 8) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^a-zA-Z0-9]/.test(val)) score++;

  const bar = document.getElementById(barId);
  const lbl = document.getElementById(lblId);
  const colors = ['#ef4444','#f59e0b','#3b82f6','#10b981'];
  const labels = ['ضعيفة جداً','مقبولة','قوية','قوية جداً'];
  if (bar) { bar.style.width = `${score*25}%`; bar.style.background = colors[score-1]||'var(--border2)'; }
  if (lbl) { lbl.textContent = val ? (labels[score-1]||'') : ''; lbl.style.color = colors[score-1]||''; }
}

function checkPassMatch(id1, id2, matchId) {
  const v1 = document.getElementById(id1)?.value;
  const v2 = document.getElementById(id2)?.value;
  const el = document.getElementById(matchId);
  if (!el || !v2) return;
  if (v1 === v2) { el.textContent = '✓ كلمة المرور متطابقة'; el.style.color = 'var(--green)'; }
  else { el.textContent = '✗ كلمة المرور غير متطابقة'; el.style.color = 'var(--red)'; }
}

function togglePassEye(inputId, iconEl) {
  const input = document.getElementById(inputId); if (!input) return;
  const isPass = input.type === 'password';
  input.type = isPass ? 'text' : 'password';
  if (iconEl) { iconEl.classList.toggle('fa-eye', !isPass); iconEl.classList.toggle('fa-eye-slash', isPass); }
}

// ── Exam status/calc ────────────────────────────────────────
function examStatus(e) {
  if (!e) return 'unknown';
  // ✅ إصلاح: احترام end_override عند إنهاء الامتحان يدوياً
  if (e.end_override) return 'completed';
  const now   = new Date();
  const start = new Date(`${e.date}T${e.time}`);
  const end   = new Date(start.getTime() + (e.duration + (e.extra_time||0)) * 60000);
  if (now < start) return 'upcoming';
  if (now >= start && now < end) return 'active';
  return 'completed';
}
function semCount(profileId) {
  // عدد مرات المراقبة الحقيقية في الفصل الحالي
  return STATE.exams?.filter(e =>
    e.semester === STATE.currentSem && (e.proctor_ids||[]).includes(profileId)
  ).length || 0;
}
function calcPoints(e) {
  if (!e) return 1;
  const time = e.time || '09:00';
  const h = parseInt(String(time).split(':')[0]) || 9;
  const s = STATE.settings || {};

  const ptsMorning   = parseFloat(s.pts_morning   ?? 1);
  const ptsAfternoon = parseFloat(s.pts_afternoon ?? 1.5);
  const ptsEvening   = parseFloat(s.pts_evening   ?? 2);
  const ptsHoliday   = parseFloat(s.pts_holiday   ?? 1);
  const ptsLong      = parseFloat(s.pts_long      ?? 0.5);
  const ptsFinal     = parseFloat(s.pts_final_bonus ?? 0.5);

  // اكتشاف تلقائي للعطلة (الجمعة/السبت) أو الخاصية المحفوظة
  const isHol = e.is_holiday ?? (()=>{ const d=new Date((e.date||'2024-01-01')+'T12:00:00'); return d.getDay()===5||d.getDay()===6; })();

  let pts = h < 14 ? ptsMorning : h < 18 ? ptsAfternoon : ptsEvening;
  if (isHol)                  pts += ptsHoliday;
  if ((e.duration||0) > 120)  pts += ptsLong;
  if (e.type === 'final')     pts += ptsFinal;
  return Math.round(pts * 10) / 10;
}

// ── Profile Modal (global) ──────────────────────────────────
function openProfile() {
  // الطالب: يفتح نافذة تغيير كلمة المرور الخاصة به
  if (STATE._studentUser) { openStudentProfile(); return; }
  UI.showPage('settings');
}

// ── نافذة بروفايل الطالب ─────────────────────────────────────
function openStudentProfile() {
  const student = STATE._studentUser;
  if (!student) return;

  const moId = 'stuProfileMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className = 'mo'; mo.id = moId; document.body.appendChild(mo); }

  mo.innerHTML = `
    <div class="md" style="max-width:440px">
      <div class="md-hd">
        <h2><i class="fas fa-user-graduate" style="color:var(--primary2)"></i> حسابي</h2>
        <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
      </div>
      <div class="md-bd" style="padding:20px;display:flex;flex-direction:column;gap:16px">

        <!-- بيانات شخصية (للعرض فقط) -->
        <div style="background:var(--bg2);border-radius:12px;padding:14px;border:1px solid var(--border)">
          <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">
            <i class="fas fa-id-card" style="margin-left:6px"></i>البيانات الشخصية (للعرض فقط)
          </div>
          <div style="display:flex;flex-direction:column;gap:8px">
            ${[
              { lbl:'الاسم', val: student.name, icon:'fa-user' },
              { lbl:'الرقم الجامعي', val: student.stud_id, icon:'fa-id-badge' },
              { lbl:'البريد الإلكتروني', val: student.email || '—', icon:'fa-envelope' },
              { lbl:'رقم الجوال', val: student.phone || '—', icon:'fa-phone' },
            ].map(f => `
              <div style="display:flex;align-items:center;gap:10px;font-size:13px">
                <i class="fas ${f.icon}" style="width:16px;color:var(--primary);opacity:.7;flex-shrink:0"></i>
                <span style="color:var(--txt2);font-size:12px;min-width:110px">${f.lbl}:</span>
                <span style="font-weight:700;flex:1">${esc(String(f.val))}</span>
              </div>`).join('')}
          </div>
        </div>

        <!-- تغيير كلمة المرور -->
        <div style="background:var(--bg2);border-radius:12px;padding:14px;border:1px solid var(--border)">
          <div style="font-size:11px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">
            <i class="fas fa-key" style="margin-left:6px;color:var(--gold)"></i>تغيير كلمة المرور
          </div>
          <div class="field" style="margin-bottom:10px">
            <label class="field-lbl">كلمة المرور الحالية</label>
            <div class="pass-wrap">
              <input type="password" id="spOldPass" placeholder="••••••••">
              <i class="fas fa-eye pass-eye" onclick="togglePassEye('spOldPass',this)"></i>
            </div>
          </div>
          <div class="field" style="margin-bottom:10px">
            <label class="field-lbl">كلمة المرور الجديدة</label>
            <div class="pass-wrap">
              <input type="password" id="spNewPass" placeholder="••••••••"
                oninput="checkPassStrength('spNewPass','spPassStr','spPassLbl')">
              <i class="fas fa-eye pass-eye" onclick="togglePassEye('spNewPass',this)"></i>
            </div>
            <div class="pass-strength">
              <div class="pass-bar"><div class="pass-bar-fill" id="spPassStr"></div></div>
              <div class="pass-lbl" id="spPassLbl"></div>
            </div>
          </div>
          <div class="field" style="margin-bottom:14px">
            <label class="field-lbl">تأكيد كلمة المرور الجديدة</label>
            <div class="pass-wrap">
              <input type="password" id="spNewPass2" placeholder="••••••••"
                oninput="checkPassMatch('spNewPass','spNewPass2','spPassMatch')">
              <i class="fas fa-eye pass-eye" onclick="togglePassEye('spNewPass2',this)"></i>
            </div>
            <div class="pass-match" id="spPassMatch"></div>
          </div>
          <div id="spPassErr" style="display:none;margin-bottom:10px;padding:8px 12px;background:var(--red-bg,#fef2f2);border:1px solid var(--red);border-radius:8px;font-size:12.5px;color:var(--red2)"></div>
          <button class="btn bp" style="width:100%" onclick="_doStudentChangePass()">
            <i class="fas fa-key"></i> تغيير كلمة المرور
          </button>
        </div>

      </div>
    </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _doStudentChangePass() {
  const student = STATE._studentUser;
  if (!student) return;

  const oldPass = document.getElementById('spOldPass')?.value;
  const newPass = document.getElementById('spNewPass')?.value;
  const newPass2 = document.getElementById('spNewPass2')?.value;
  const errEl = document.getElementById('spPassErr');

  const _err = msg => {
    if (errEl) { errEl.textContent = msg; errEl.style.display = msg ? 'block' : 'none'; }
  };

  _err('');
  if (!oldPass)  { _err('أدخل كلمة المرور الحالية'); return; }
  if (!newPass)  { _err('أدخل كلمة المرور الجديدة'); return; }
  if (newPass.length < 4) { _err('كلمة المرور يجب أن تكون 4 أحرف على الأقل'); return; }
  if (newPass !== newPass2) { _err('كلمتا المرور غير متطابقتين'); return; }
  if (oldPass === newPass)  { _err('كلمة المرور الجديدة يجب أن تختلف عن الحالية'); return; }

  const btn = document.querySelector('#stuProfileMo .btn.bp');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جارٍ التحديث...'; }

  try {
    const db = SB.getClient();

    // جلب كلمة المرور المخزنة
    const { data: row, error: fetchErr } = await db
      .from('students')
      .select('id,password')
      .eq('id', student.id)
      .maybeSingle();

    if (fetchErr || !row) throw new Error('خطأ في جلب بيانات الحساب');

    // التحقق: plain text أولاً، ثم SHA-256 هاش
    const stored = row.password || '';
    let passOk = (stored === oldPass);
    if (!passOk && typeof AUTH !== 'undefined' && AUTH.hashPassword) {
      const hashed = await AUTH.hashPassword(oldPass);
      passOk = (stored === hashed);
    }
    if (!passOk) throw new Error('كلمة المرور الحالية غير صحيحة');

    // تحديث كلمة المرور (plain text — نفس آلية studentLogin)
    const { error: updErr } = await db
      .from('students')
      .update({ password: newPass })
      .eq('id', student.id);

    if (updErr) throw new Error(updErr.message);

    // تحديث الجلسة المحفوظة بالصيغة الجديدة
    if (typeof AUTH !== 'undefined' && AUTH.saveStudentSession) {
      AUTH.saveStudentSession({ ...student });
    }

    toast('✓ تم تغيير كلمة المرور بنجاح', 'success');
    closeMo('stuProfileMo');

    ['spOldPass','spNewPass','spNewPass2'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
  } catch(e) {
    _err(e.message);
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-key"></i> تغيير كلمة المرور'; }
  }
}
window.openStudentProfile   = openStudentProfile;
window._doStudentChangePass = _doStudentChangePass;

// ── Notifications ───────────────────────────────────────────
function renderNotifications() {
  const el = document.getElementById('notifList'); if (!el) return;

  // ── للطالب: عرض مختلف يعتمد على toast log + امتحاناته ──────
  if (STATE._studentUser) {
    _renderStudentNotifications(el);
    return;
  }

  // نوحّد حقل read / is_read
  const notifs = [...STATE.notifications]
    .map(n => ({ ...n, read: !!(n.read || n.is_read) }))
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const dot = document.getElementById('notifDot');
  if (dot) dot.classList.toggle('show', notifs.some(n => !n.read));

  const typeIcon = t => ({swap:'fa-exchange-alt',exam:'fa-file-alt',warning:'fa-exclamation-triangle',success:'fa-check-circle',info:'fa-info-circle'})[t||'info'] || 'fa-bell';
  const typeColor = (t, read) => {
    if (read) return 'var(--txt3)';
    return ({swap:'var(--primary2)',exam:'var(--purple2)',warning:'var(--gold)',success:'var(--green)',info:'var(--primary2)'})[t||'info'] || 'var(--primary2)';
  };

  // ── أزرار الإجراءات ──
  const adminBar = (isAdmin() || isCoord()) ? `
    <div style="padding:12px 20px;border-bottom:1px solid var(--border);background:var(--bg2);display:flex;gap:8px;align-items:center">
      <button class="btn bp btn-sm" onclick="openSendNotification()" style="gap:6px">
        <i class="fas fa-paper-plane"></i> إرسال إشعار
      </button>
      <button class="btn bo btn-sm" onclick="markAllRead()" style="gap:6px">
        <i class="fas fa-check-double"></i> تعليم الكل مقروء
      </button>
      <span style="font-size:12px;color:var(--txt3);margin-right:auto">
        ${notifs.filter(n=>!n.read).length} غير مقروء
      </span>
    </div>` : `
    <div style="padding:10px 20px;border-bottom:1px solid var(--border);background:var(--bg2);display:flex;justify-content:flex-end">
      <button class="btn bo btn-sm" onclick="markAllRead()">
        <i class="fas fa-check-double"></i> تعليم الكل مقروء
      </button>
    </div>`;

  const rows = notifs.map(n => `
    <div style="display:flex;gap:12px;padding:14px 20px;background:${n.read?'':'var(--primary-bg)'};border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s"
      onclick="markRead(${n.id},this)" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
      <div style="width:36px;height:36px;border-radius:10px;background:${n.read?'var(--bg2)':'var(--primary)20'};display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fas ${typeIcon(n.type)}" style="color:${typeColor(n.type,n.read)};font-size:14px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:${n.read?'600':'800'};font-size:13.5px">${esc(n.title)}</div>
        ${n.body ? `<div style="font-size:12px;color:var(--txt2);margin-top:2px">${esc(n.body)}</div>` : ''}
        <div style="font-size:10.5px;color:var(--txt3);margin-top:4px">${fmtDateTime(n.created_at)}</div>
      </div>
      ${!n.read ? `<div style="width:8px;height:8px;border-radius:50%;background:var(--primary2);flex-shrink:0;margin-top:8px"></div>` : ''}
    </div>`).join('') || `<div style="padding:40px;text-align:center;color:var(--txt3)"><i class="fas fa-bell-slash" style="font-size:32px;opacity:.3;display:block;margin-bottom:10px"></i>لا توجد إشعارات</div>`;

  el.innerHTML = adminBar + rows;
}

// ── إشعارات صفحة الطالب ──────────────────────────────────────
function _renderStudentNotifications(el) {
  const student  = STATE._studentUser;
  const sem      = STATE.currentSem;
  const now      = new Date();

  // بناء قائمة إشعارات من امتحانات الطالب
  const items = [];

  if (typeof _getStudentSemData === 'function') {
    try {
      const { myExams } = _getStudentSemData(student, sem);

      // امتحانات جارية
      myExams.filter(e => examStatus(e) === 'active').forEach(e => {
        const sub = STATE.subjects?.find(s => s.id === e.subject_id);
        items.push({
          icon: 'fa-circle',
          color: 'var(--red)',
          bg: 'var(--red)20',
          title: `امتحان جارٍ الآن: ${sub?.name || '—'}`,
          body: `${fmtDate(e.date)} · ${fmtTime(e.time)} · ${e.duration} دقيقة`,
          time: new Date(`${e.date}T${e.time}`),
          urgent: true
        });
      });

      // امتحانات قادمة خلال 7 أيام
      myExams.filter(e => {
        if (examStatus(e) !== 'upcoming') return false;
        const ms = new Date(`${e.date}T${e.time}`) - now;
        return ms > 0 && ms <= 7 * 86400000;
      }).sort((a,b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`))
      .forEach(e => {
        const sub  = STATE.subjects?.find(s => s.id === e.subject_id);
        const ms   = new Date(`${e.date}T${e.time}`) - now;
        const hrs  = Math.round(ms / 3600000);
        const when = hrs < 24 ? `خلال ${hrs} ساعة` : hrs < 48 ? 'غداً' : `خلال ${Math.ceil(hrs/24)} أيام`;
        items.push({
          icon: 'fa-calendar-alt',
          color: hrs < 24 ? 'var(--red)' : hrs < 48 ? 'var(--gold)' : 'var(--primary)',
          bg: hrs < 24 ? 'var(--red)20' : hrs < 48 ? 'var(--gold)20' : 'var(--primary)20',
          title: `امتحان قادم: ${sub?.name || '—'}`,
          body: `${fmtDate(e.date)} · ${fmtTime(e.time)} · ${when}`,
          time: new Date(`${e.date}T${e.time}`)
        });
      });
    } catch {}
  }

  // إشعارات النظام من toast log
  (window._toastLog || []).slice(0, 10).forEach(n => {
    const iconMap = { success:'fa-check-circle', error:'fa-times-circle', warning:'fa-exclamation-triangle', info:'fa-info-circle' };
    const colMap  = { success:'var(--green)', error:'var(--red)', warning:'var(--gold)', info:'var(--primary)' };
    items.push({
      icon:  iconMap[n.type] || 'fa-bell',
      color: colMap[n.type]  || 'var(--primary)',
      bg:    colMap[n.type]  ? colMap[n.type] + '20' : 'var(--primary)20',
      title: n.msg,
      body:  '',
      time:  n.time instanceof Date ? n.time : new Date(n.time)
    });
  });

  const dot = document.getElementById('notifDot');
  if (dot) dot.classList.toggle('show', items.some(i => i.urgent));

  if (!items.length) {
    el.innerHTML = `<div style="padding:50px;text-align:center;color:var(--txt3)">
      <i class="fas fa-bell-slash" style="font-size:36px;opacity:.25;display:block;margin-bottom:12px"></i>
      <div style="font-size:14px;font-weight:700">لا توجد إشعارات حالياً</div>
      <div style="font-size:12px;margin-top:6px">ستظهر هنا تذكيرات امتحاناتك القادمة</div>
    </div>`;
    return;
  }

  el.innerHTML = `
    <div style="padding:10px 20px 10px;border-bottom:1px solid var(--border);background:var(--bg2)">
      <span style="font-size:12px;color:var(--txt3)">${items.length} إشعار</span>
    </div>
    ${items.map(n => `
      <div style="display:flex;gap:12px;padding:14px 20px;border-bottom:1px solid var(--border);${n.urgent?'background:var(--red)06':''}">
        <div style="width:38px;height:38px;border-radius:10px;background:${n.bg};display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas ${n.icon}" style="color:${n.color};font-size:15px${n.urgent?';animation:pulse 1.5s infinite':''}"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:800;font-size:13.5px;${n.urgent?'color:'+n.color:''}">${esc(n.title)}</div>
          ${n.body ? `<div style="font-size:12px;color:var(--txt2);margin-top:3px">${esc(n.body)}</div>` : ''}
          <div style="font-size:10.5px;color:var(--txt3);margin-top:4px">${n.time ? fmtDateTime(n.time.toISOString()) : ''}</div>
        </div>
        ${n.urgent ? `<div style="width:10px;height:10px;border-radius:50%;background:var(--red);flex-shrink:0;margin-top:6px;animation:pulse 1.5s infinite"></div>` : ''}
      </div>`).join('')}`;
}
async function markRead(id, row) {
  if (row) row.style.background = '';
  try { await SB.getClient().from('notifications').update({ is_read: true }).eq('id', id); } catch {}
  const n = STATE.notifications.find(n => n.id === id);
  if (n) { n.read = true; n.is_read = true; }
  const dot = document.getElementById('notifDot');
  if (dot) dot.classList.toggle('show', STATE.notifications.some(n => !n.read && !n.is_read));
}
async function markAllRead() {
  STATE.notifications.forEach(n => { n.read = true; n.is_read = true; });
  try {
    await SB.getClient().from('notifications').update({ is_read: true }).eq('user_id', STATE.currentUser?.id);
  } catch {}
  renderNotifications();
  const dot = document.getElementById('notifDot');
  if (dot) dot.classList.remove('show');
  toast('تم تعليم كل الإشعارات كمقروءة', 'success');
}

// ── Log ─────────────────────────────────────────────────────
function renderLog() {
  const me = STATE.currentUser;
  let logs = STATE.auditLog || [];

  // رئيس القسم: يرى سجل قسمه وسجل المنسقين فقط
  if (isDeptHead()) {
    const myDeptId = me?.dept_id;
    const myDeptUserIds = new Set(
      STATE.profiles
        .filter(p => p.dept_id === myDeptId || p.role === 'coordinator' || p.role === 'admin')
        .map(p => p.id)
    );
    logs = logs.filter(l => myDeptUserIds.has(l.user_id) || !l.user_id);
  }

  const total = logs.length;
  logs = logs.slice(0, 80);

  const typeColors = {
    exam: 'var(--primary2)', swap: 'var(--orange,#f97316)', proctor: 'var(--purple2)',
    subjects: 'var(--gold)', rooms: 'var(--teal)', students: 'var(--green2)',
    cross_dept: 'var(--purple2)', coordinator: 'var(--teal)', default: 'var(--txt3)'
  };

  setHTML('logContent', `
    <div class="card">
      <div class="card-h">
        <h3><i class="fas fa-history" style="color:var(--txt2)"></i>
          ${isDeptHead() ? 'سجل نشاط القسم' : `آخر ${total} نشاط`}
        </h3>
        <span class="badge b-blue" style="font-size:11px">${total} سجل</span>
      </div>
      <div style="max-height:650px;overflow-y:auto">
        ${logs.map(l => {
          const actor = getProfile(l.user_id);
          const tColor = typeColors[l.entity_type||'default'] || typeColors.default;
          return `
          <div style="display:flex;align-items:start;gap:12px;padding:12px 20px;border-bottom:1px solid var(--border);transition:background .15s"
               onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
            ${actor ? userAvatar(actor, 32) : `<div style="width:32px;height:32px;border-radius:9px;background:${tColor}15;display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fas fa-cog" style="color:${tColor};font-size:12px"></i></div>`}
            <div style="flex:1;min-width:0">
              <div style="font-weight:700;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(l.action||'—')}${l.entity_label?' — '+esc(l.entity_label):''}</div>
              <div style="font-size:11px;color:var(--txt3);margin-top:2px">
                <span style="color:var(--txt2)">${esc(actor?.name?.split(' ').slice(0,2).join(' ')||l.user_name||'النظام')}</span>
                ${l.entity_type?` · <span style="color:${tColor}">${esc(l.entity_type)}</span>`:''}
                · ${fmtDateTime(l.created_at)}
              </div>
            </div>
          </div>`;
        }).join('') || emptyState('fa-history','لا توجد سجلات')}
      </div>
    </div>`);
}

// ── addNotif: إرسال إشعار لمستخدمين ─────────────────────────
async function addNotif(userIds, title, message, type) {
  if (!userIds?.length) return;
  const uid = STATE.currentUser?.id;
  const now = new Date().toISOString();
  const rows = userIds.map(id => ({
    user_id: id, title, message: message||'', type: type||'info',
    is_read: false, created_at: now
  }));
  try {
    const client = SB.getClient?.();
    if (client) {
      // إدراج جميع الإشعارات دفعة واحدة
      const { data } = await client.from('notifications').insert(rows).select();
      // إذا كان المستخدم الحالي في القائمة، أضف للذاكرة مباشرةً
      if (data) {
        data.forEach(n => {
          if (n.user_id === uid) STATE.notifications.unshift(n);
        });
      }
    }
  } catch {
    // fallback: أضف في الذاكرة فقط للمستخدم الحالي
    rows.forEach(r => {
      if (r.user_id === uid) STATE.notifications.unshift({ ...r, id: Date.now(), read: false });
    });
  }
  // تحديث شارة الإشعارات إذا كان المستخدم الحالي في القائمة
  if (userIds.includes(uid)) UI.updateNotifBadge?.();
}
