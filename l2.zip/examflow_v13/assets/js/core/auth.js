// ═══════════════════════════════════════════════════════════════
//  auth.js v14 — مصادقة مباشرة من قاعدة البيانات
//  ✓ بدون Supabase Auth تماماً
//  ✓ كلمات مرور SHA-256 مخزّنة في profiles + students
//  ✓ الجلسة في localStorage بصلاحية 24 ساعة
//  ✓ شاشة موحدة للموظفين والطلاب
// ═══════════════════════════════════════════════════════════════

const AUTH = (() => {
  let _sb = null;
  const SESSION_KEY = '_ef_session';
  const SESSION_TTL = 7 * 24 * 60 * 60 * 1000; // 7 أيام

  // ── تهيئة (لا حاجة لـ onAuthStateChange) ────────────────────
  function setup(client) {
    _sb = client;
  }

  // ✅ getter آمن: يضمن وجود client حتى لو لم يُستدعَ setup() لأي سبب
  function _client() {
    if (_sb) return _sb;
    // Fallback 1: client محفوظ في window._efSB من main.js
    if (typeof window !== 'undefined' && window._efSB) {
      _sb = window._efSB;
      return _sb;
    }
    // Fallback 2: client من SB module
    if (typeof SB !== 'undefined' && SB.getClient) {
      const c = SB.getClient();
      if (c) { _sb = c; return _sb; }
    }
    // Fallback 3: إنشاء client جديد من APP_CONFIG (وضع طوارئ)
    if (typeof window !== 'undefined' && window.supabase && typeof APP_CONFIG !== 'undefined') {
      try {
        _sb = window.supabase.createClient(
          APP_CONFIG.SUPABASE_URL,
          APP_CONFIG.SUPABASE_ANON_KEY,
          { auth: { persistSession: false, autoRefreshToken: false } }
        );
        window._efSB = _sb;
        return _sb;
      } catch(e) {
        console.error('[AUTH] emergency client creation failed:', e.message);
      }
    }
    throw new Error('تعذّر الاتصال بقاعدة البيانات — يرجى تحديث الصفحة');
  }

  // ── انتظار استعادة الجلسة (يقرأ من localStorage) ─────────────
  async function waitForSession() {
    const timeout = new Promise(res =>
      setTimeout(() => res({ user: null, timedOut: true }), 10000) // 10 ثوانٍ بدلاً من 5
    );
    return Promise.race([_restoreSession(), timeout]);
  }

  async function _restoreSession() {
    // ── 1. قراءة الجلسة من localStorage ─────────────────────────
    let session = _loadSession();

    // ── 2. Fallback: جلسة الطالب بالصيغة القديمة ─────────────────
    if (!session) {
      try {
        const raw = localStorage.getItem('_studentSession');
        if (raw) {
          const legacy = JSON.parse(raw);
          const s   = legacy?.student;
          const age = Date.now() - (legacy?.timestamp || 0);
          if (s?.id && age < SESSION_TTL) {
            session = { type: 'student', user: { id: s.id, email: s.email || '', name: s.name || '' } };
          } else {
            localStorage.removeItem('_studentSession');
          }
        }
      } catch {}
    }

    if (!session) return { user: null };

    // ── 3. استعادة الموظف ──────────────────────────────────────────
    if (session.type === 'staff') {
      try {
        const { data, error } = await _client()
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle();

        // خطأ شبكي أو DB — لا نمسح الجلسة، فقط نستخدم البيانات المحفوظة
        if (error) {
          console.warn('[Auth] profiles query error (keeping session):', error.message);
          // استخدام البيانات المخزنة كـ fallback مؤقت
          STATE.currentUser = {
            id:    session.user.id,
            email: session.user.email || '',
            name:  session.user.name  || '',
            role:  session.user.role  || 'proctor',
            active: true
          };
          return { user: STATE.currentUser };
        }

        // الحساب محذوف من DB فعلاً → امسح الجلسة
        if (!data) { _clearSession(); return { user: null }; }

        // الحساب موقوف → امسح الجلسة
        if (data.active === false) { _clearSession(); return { user: null, error: 'الحساب موقوف' }; }

        STATE.currentUser = Hydrate.profile(data);
        if (data.lang_pref && typeof I18N !== 'undefined') I18N.setLang(data.lang_pref);
        // تجديد الجلسة في كل مرة ناجحة
        _saveSession('staff', STATE.currentUser);
        return { user: STATE.currentUser };
      } catch (e) {
        // استثناء غير متوقع — احتفظ بالجلسة وأعد البيانات المخزنة
        console.warn('[Auth] staff restore exception (keeping session):', e.message);
        STATE.currentUser = {
          id:    session.user.id,
          email: session.user.email || '',
          name:  session.user.name  || '',
          role:  session.user.role  || 'proctor',
          active: true
        };
        return { user: STATE.currentUser };
      }
    }

    // ── 4. استعادة الطالب ──────────────────────────────────────────
    if (session.type === 'student') {
      try {
        const { data, error } = await _client()
          .from('students')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle();

        // خطأ شبكي — لا نمسح الجلسة، نستخدم البيانات المخزنة
        if (error) {
          console.warn('[Auth] students query error (keeping session):', error.message);
          STATE._studentUser = {
            id:       session.user.id,
            email:    session.user.email   || '',
            name:     session.user.name    || '',
            stud_id:  session.user.stud_id || '',
            active:   true,
            banned:   false
          };
          return { user: STATE._studentUser };
        }

        // الحساب محذوف من DB → امسح الجلسة
        if (!data) { _clearSession(); return { user: null }; }

        // الحساب موقوف أو محظور → امسح الجلسة
        if (data.banned || data.active === false) {
          _clearSession();
          return { user: null, error: 'الحساب موقوف' };
        }

        STATE._studentUser = Hydrate.student(data);
        // تجديد الجلسة وترقيتها للصيغة الجديدة
        _saveSession('student', STATE._studentUser);
        return { user: STATE._studentUser };
      } catch (e) {
        console.warn('[Auth] student restore exception (keeping session):', e.message);
        STATE._studentUser = {
          id:       session.user.id,
          email:    session.user.email   || '',
          name:     session.user.name    || '',
          stud_id:  session.user.stud_id || '',
          active:   true,
          banned:   false
        };
        return { user: STATE._studentUser };
      }
    }

    return { user: null };
  }

  // ── تسجيل دخول الموظف ─────────────────────────────────────────
  async function signIn(email, password) {
    const hash = await _hash(password);
    const { data, error } = await _client()
      .from('profiles')
      .select('*')
      .eq('email', email.trim().toLowerCase())
      .eq('password', hash)
      .maybeSingle();

    if (error) throw new Error('خطأ في الاتصال بقاعدة البيانات');
    if (!data) throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    if (!data.active) throw new Error('الحساب موقوف. تواصل مع مسؤول النظام.');

    STATE.currentUser = Hydrate.profile(data);
    _saveSession('staff', STATE.currentUser);
    if (data.lang_pref && typeof I18N !== 'undefined') I18N.setLang(data.lang_pref);
    return data;
  }

  // ── تسجيل دخول الطالب ─────────────────────────────────────────
  async function signInStudent(email, password) {
    const hash = await _hash(password);
    const { data, error } = await _client()
      .from('students')
      .select('*')
      .eq('email', email.trim().toLowerCase())
      .eq('password', hash)
      .maybeSingle();

    if (error) throw new Error('خطأ في الاتصال بقاعدة البيانات');
    if (!data) throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    if (data.banned) throw new Error('تم إيقاف هذا الحساب. تواصل مع الإدارة.');
    if (!data.active) throw new Error('الحساب غير نشط. تواصل مع منسق الكلية.');

    STATE._studentUser = Hydrate.student(data);
    _saveSession('student', STATE._studentUser);
    return data;
  }

  // ── تسجيل الخروج ──────────────────────────────────────────────
  async function signOut() {
    _clearSession();
    STATE.currentUser  = null;
    STATE._studentUser = null;
  }

  // ── تغيير كلمة مرور الموظف الحالي ────────────────────────────
  async function changePassword(newPassword) {
    const userId = STATE.currentUser?.id;
    if (!userId) throw new Error('لا يوجد مستخدم حالي');
    const hash = await _hash(newPassword);
    const { error } = await _client().from('profiles').update({ password: hash }).eq('id', userId);
    if (error) throw new Error('فشل تحديث كلمة المرور: ' + error.message);
  }

  // ── تغيير كلمة مرور موظف آخر (للمسؤول فقط) ──────────────────
  async function setPasswordForUser(userId, newPassword) {
    const hash = await _hash(newPassword);
    const { error } = await _client().from('profiles').update({ password: hash }).eq('id', userId);
    if (error) throw new Error('فشل تحديث كلمة المرور: ' + error.message);
  }

  // ── تغيير كلمة مرور طالب ─────────────────────────────────────
  async function setPasswordForStudent(studentId, newPassword) {
    const hash = await _hash(newPassword);
    const { error } = await _client().from('students').update({ password: hash }).eq('id', studentId);
    if (error) throw new Error('فشل تحديث كلمة المرور: ' + error.message);
  }

  // ── هاش SHA-256 ───────────────────────────────────────────────
  async function _hash(password) {
    const encoder = new TextEncoder();
    const data    = encoder.encode(password);
    const hashBuf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuf))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  // ── إدارة الجلسة (localStorage) ──────────────────────────────
  function _saveSession(type, user) {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify({
        type,
        user: {
          id:      user.id,
          email:   user.email   || '',
          name:    user.name    || '',
          role:    user.role    || (type === 'student' ? 'student' : 'proctor'),
          stud_id: user.stud_id || ''
        },
        timestamp: Date.now(),
        expires:   Date.now() + SESSION_TTL
      }));
    } catch {}
  }

  function _loadSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const session = JSON.parse(raw);
      // منتهية الصلاحية → لا نمسحها فوراً، نُعيدها null فقط (حماية من أخطاء الساعة)
      if (session.expires && Date.now() > session.expires) {
        return null;
      }
      return session;
    } catch { return null; }
  }

  function _clearSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch {}
    // تنظيف جلسة الطالب القديمة أيضاً (توافق مع v13)
    try { localStorage.removeItem('_studentSession'); } catch {}
  }

  // hashPassword: للاستخدام من users.js و students.js
  async function hashPassword(p) { return _hash(p); }

  // isSessionValid: فحص سريع بدون اتصال
  function isSessionValid() {
    const s = _loadSession();
    return !!(s && s.user);
  }

  // ── مرجع آمن لـ BIO (const لا يُضاف لـ window تلقائياً) ────────
  function _getBIO() {
    return window.BIO || (typeof BIO !== 'undefined' ? BIO : null);
  }

  // ── تسجيل دخول بالبصمة (موظف أو طالب تلقائياً) ─────────────
  async function signInWithBiometric() {
    const _bio = _getBIO();
    if (!_bio) throw new Error('خدمة البصمة غير متاحة — تأكد من دعم المتصفح لـ WebAuthn');
    let result;
    try {
      result = await _bio.authenticateAny();
    } catch(e) {
      throw new Error(e.message || 'فشل تسجيل الدخول بالبصمة');
    }
    if (result.type === 'staff') {
      const { data, error } = await _client().from('profiles').select('*').eq('id', result.userId).single();
      if (error||!data) throw new Error('مستخدم غير موجود');
      if (!data.active) throw new Error('الحساب موقوف.');
      STATE.currentUser = Hydrate.profile(data);
      _saveSession('staff', STATE.currentUser);
      if (data.lang_pref && typeof I18N!=='undefined') I18N.setLang(data.lang_pref);
      return { type:'staff', data };
    }
    if (result.type === 'student') {
      const { data, error } = await _client().from('students').select('*').eq('id', result.studentId).single();
      if (error||!data) throw new Error('طالب غير موجود');
      if (data.banned||!data.active) throw new Error('الحساب موقوف أو غير نشط.');
      STATE._studentUser = Hydrate.student(data);
      _saveSession('student', STATE._studentUser);
      return { type:'student', data };
    }
    throw new Error('نوع مستخدم غير معروف');
  }

  // ── تسجيل دخول الطالب بالبصمة ───────────────────────────────
  async function signInStudentWithBiometric() {
    const _bio = _getBIO();
    if (!_bio) throw new Error('خدمة البصمة غير متاحة — تأكد من دعم المتصفح لـ WebAuthn');
    const result = await _bio.authenticateStudentAuto();
    const { data, error } = await _client().from('students').select('*').eq('id', result.studentId).single();
    if (error||!data) throw new Error('طالب غير موجود');
    if (data.banned||!data.active) throw new Error('الحساب موقوف.');
    STATE._studentUser = Hydrate.student(data);
    _saveSession('student', STATE._studentUser);
    return data;
  }

  // ── حفظ جلسة الطالب (للاستخدام من signature-student.js) ──────
  function saveStudentSession(studentData) {
    _saveSession('student', {
      id:    studentData.id,
      email: studentData.email || '',
      name:  studentData.name  || '',
      stud_id: studentData.stud_id || ''
    });
  }

  return {
    setup, waitForSession, signIn, signInStudent,
    signInWithBiometric, signInStudentWithBiometric,
    signOut, changePassword, setPasswordForUser, setPasswordForStudent,
    hashPassword, isSessionValid, saveStudentSession
  };
})();
