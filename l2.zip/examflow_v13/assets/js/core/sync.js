// sync.js v14 — مزامنة البيانات مع Supabase (بدون Supabase Auth)
const SB = (() => {
  let _client = null;
  let _ready   = false;

  async function init(supabaseClient) {
    _client = supabaseClient;
    _setSyncUI('ing', 'جارٍ تحميل البيانات...');
    try {
      await _loadAll();
      _ready = true;
      _setSyncUI('ok', 'متصل ✓');
      _startRealtime();
      UI?.renderSidebar?.();
      UI?.renderCurrentPage?.();
    } catch (e) {
      console.error('[SB] init error:', e.message);
      _setSyncUI('err', 'خطأ في الاتصال — ' + e.message);
    }
  }

  async function _loadAll() {
    const uid  = STATE.currentUser?.id;
    const role = STATE.currentUser?.role;
    const isStudentMode = !!STATE._studentUser && !STATE.currentUser;

    const baseQueries = [
      _fetch('profiles', 'id,email,name,role,emp_id,phone,color,points,sem_x,active,signature,dept_id,lang_pref,avg_rating,ratings,permissions,is_inactive'),
      _fetch('semesters', 'code,label,is_active,is_closed'),
      _fetch('subjects', 'id,name,code,level,hours,dept_id,staff_ids'),
      _fetch('rooms', 'id,name,building,floor,cap,type,notes'),
      _fetch('sections', 'id,name,subject_id,semester,coord_id,student_ids'),
      _fetch('students', 'id,stud_id,name,batch,email,phone,active,banned,subject_ids,section_ids'),
      _fetch('exams', '*'),
      _fetch('departments', 'id,name,name_en,code,head_id,color,description'),
      _fetch('swap_requests'),
      _fetch('supervision_requests'),
      uid ? _fetch('notifications', '*', `user_id=eq.${uid}`) : Promise.resolve([]),
      _fetchOne('app_settings'),
      (!isStudentMode && (isAdmin() || isCoord() || isDeptHead()))
        ? _fetch('audit_log', '*', '', 'created_at', 50)
        : Promise.resolve([]),
      _fetch('schedules', '*'),
      _fetch('bookings', '*'),
      uid ? _fetchUserBookings(uid, role) : Promise.resolve([]),
      uid ? _fetchCrossDeptRequests(uid, role) : Promise.resolve([]),
      _fetch('semester_schedules', '*')
    ];

    const [
      profiles, semesters, subjects, rooms, sections,
      students, exams, departments, swaps, supervision,
      notifs, settings, audit, schedules, bookings,
      userBookings, crossDeptRequests, semesterSchedules
    ] = await Promise.all(baseQueries);

    STATE.profiles             = (profiles    || []).map(Hydrate.profile);
    STATE.semesters            = semesters    || [];
    STATE.subjects             = (subjects || []).map(Hydrate.subject);
    STATE.rooms                = rooms        || [];
    STATE.sections             = (sections    || []).map(Hydrate.section);
    STATE.students             = (students    || []).map(Hydrate.student);
    STATE.exams                = (exams       || []).map(Hydrate.exam);
    STATE.departments          = departments  || [];
    STATE.swapRequests         = swaps        || [];
    STATE.supervisionRequests  = supervision  || [];
    STATE.notifications        = notifs       || [];
    STATE.settings             = Hydrate.settings(settings);
    STATE.auditLog             = audit        || [];
    STATE.schedules            = (schedules   || []).map(Hydrate.schedule);
    STATE.bookings             = (bookings    || []).map(Hydrate.booking);
    STATE.userBookings         = (userBookings      || []).map(Hydrate.userBooking);
    STATE.crossDeptRequests    = (crossDeptRequests || []).map(Hydrate.crossDeptRequest);
    STATE.semesterSchedules    = (semesterSchedules || []).map(Hydrate.semesterSchedule);

    // تحميل الحضور
    const attRows = await _fetch('attendance', '*');
    STATE.attendance = {};
    (attRows || []).forEach(r => {
      if (!STATE.attendance[r.exam_id]) STATE.attendance[r.exam_id] = {};
      STATE.attendance[r.exam_id][r.student_id] = r.status;
    });

    // تحميل حضور الطالب الحالي إذا كان في وضع الطالب
    if (STATE._studentUser && !STATE.currentUser) {
      STATE._studentAttendance = {};
      (attRows || [])
        .filter(r => Number(r.student_id) === Number(STATE._studentUser.id))
        .forEach(r => { STATE._studentAttendance[Number(r.exam_id)] = r.status; });
    }

    // الفصل الحالي
    const activeSem = STATE.semesters.find(s => s.is_active);
    if (activeSem) STATE.currentSem = activeSem.code;
  }

  async function _fetchUserBookings(uid, role) {
    if (!uid) return [];
    if (role === 'proctor') return _fetch('user_bookings', '*', `user_id=eq.${uid}`);
    return _fetch('user_bookings', '*');
  }

  async function _fetchCrossDeptRequests(uid, role) {
    if (!uid) return [];
    if (role === 'admin' || role === 'coordinator') return _fetch('cross_dept_requests', '*');
    if (role === 'dept_head') {
      const u = STATE.currentUser;
      if (!u?.dept_id) return [];
      return _fetch('cross_dept_requests', '*', `target_dept_id=eq.${u.dept_id}`);
    }
    return _fetch('cross_dept_requests', '*', `assigned_proctor_id=eq.${uid}`);
  }

  // ── Generic fetch ─────────────────────────────────────────────
  async function _fetch(table, select = '*', filter = '', order = '', limit = 0) {
    let q = _client.from(table).select(select);
    if (filter) {
      const eqIdx = filter.indexOf('=eq.');
      if (eqIdx > -1) {
        const col = filter.substring(0, eqIdx);
        const val = filter.substring(eqIdx + 4);
        q = q.eq(col, val);
      }
    }
    if (order) q = q.order(order, { ascending: false });
    if (limit) q = q.limit(limit);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  }

  async function _fetchOne(table) {
    const { data, error } = await _client.from(table).select('*').limit(1).maybeSingle();
    if (error) throw error;
    return data;
  }

  // ── CRUD ──────────────────────────────────────────────────────
  async function insert(table, data) {
    const { data: res, error } = await _client.from(table).insert(data).select().single();
    if (error) throw error;
    return res;
  }

  async function update(table, id, data, col) {
    const colName = col || 'id';
    const { data: res, error } = await _client.from(table).update(data).eq(colName, id).select().single();
    if (error) throw error;
    return res;
  }

  async function del(table, id, col) {
    const colName = col || 'id';
    const { error } = await _client.from(table).delete().eq(colName, id);
    if (error) throw error;
  }

  async function upsert(table, data, onConflict) {
    const opts = onConflict ? { onConflict } : {};
    const { data: res, error } = await _client.from(table).upsert(data, opts).select();
    if (error) throw error;
    return res;
  }

  async function rpc(fn, params) {
    const { data, error } = await _client.rpc(fn, params);
    if (error) throw error;
    return data;
  }

  async function addUsersToBooking(bookingId, userIds) {
    if (!userIds?.length) return;
    const rows = userIds.map(uid => ({ user_id: uid, booking_id: bookingId }));
    const { error } = await _client.from('user_bookings').upsert(rows, { onConflict: 'user_id,booking_id' });
    if (error) throw error;
    rows.forEach(r => {
      if (!STATE.userBookings.find(ub => ub.user_id === r.user_id && ub.booking_id === r.booking_id)) {
        STATE.userBookings.push(r);
      }
    });
  }

  async function removeUserFromBooking(bookingId, userId) {
    const { error } = await _client.from('user_bookings')
      .delete().eq('booking_id', bookingId).eq('user_id', userId);
    if (error) throw error;
    STATE.userBookings = STATE.userBookings.filter(
      ub => !(ub.booking_id === bookingId && ub.user_id === userId)
    );
  }

  async function updateProctorStatus(examId, userId, status) {
    const exam = STATE.exams.find(e => e.id === examId);
    if (!exam) return;
    const statuses = { ...(exam.proctor_statuses || {}), [userId]: status };

    // ✅ لا نستخدم .select() بعد UPDATE حتى لا يتعارض مع صلاحيات RLS للمراقب
    // المراقب يملك صلاحية UPDATE فقط على سجله، لا SELECT على كل الامتحانات
    const { error } = await _client
      .from('exams')
      .update({ proctor_statuses: statuses })
      .eq('id', examId);

    if (error) throw new Error(error.message);

    // تحديث الحالة محلياً فوراً
    exam.proctor_statuses = statuses;
    return exam;
  }

  // ── Logging ───────────────────────────────────────────────────
  async function logAction(action, table, detail) {
    try {
      await _client.from('audit_log').insert({
        user_id:    STATE.currentUser?.id || null,
        user_name:  STATE.currentUser?.name || STATE._studentUser?.name || '',
        action,
        entity_type: table || '',
        entity_label: detail || '',
        type:        'info',
        created_at:  new Date().toISOString()
      });
    } catch {}
  }

  // ── إنشاء مستخدم جديد (مباشرة في profiles) ───────────────────
  async function createUser(email, password, meta) {
    const hash = await AUTH.hashPassword(password);
    const newId = crypto.randomUUID();
    const profileData = {
      id:       newId,
      email:    email.trim().toLowerCase(),
      name:     meta?.name  || email.split('@')[0],
      role:     meta?.role  || 'proctor',
      password: hash,
      active:   true
    };
    const { data, error } = await _client.from('profiles').insert(profileData).select().single();
    if (error) throw error;
    return data;
  }

  // ── حذف مستخدم من profiles فقط ───────────────────────────────
  async function deleteAuthUser(userId) {
    await del('profiles', userId, 'id');
  }

  // ── تحديث كلمة مرور مستخدم ───────────────────────────────────
  async function updateAuthPassword(userId, password) {
    await AUTH.setPasswordForUser(userId, password);
  }

  // ── تحديث بريد مستخدم ────────────────────────────────────────
  async function updateAuthEmail(userId, email) {
    await update('profiles', userId, { email: email.trim().toLowerCase() }, 'id');
  }

  // ── Realtime ──────────────────────────────────────────────────
  function _startRealtime() {
    const channel = _client.channel('examflow-rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'exams' },      _onExamsChange)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' },   _onBookingsChange)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'user_bookings' }, _onUBChange)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'cross_dept_requests' }, _onCDRChange)
      // ✅ جداول إضافية لتحديث فوري عبر الصفحات
      .on('postgres_changes', { event: '*', schema: 'public', table: 'subjects' },    _onGenericChange('subjects', Hydrate.subject))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'sections' },    _onGenericChange('sections', Hydrate.section))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'students' },    _onGenericChange('students', Hydrate.student))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' },    _onGenericChange('profiles', Hydrate.profile))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms' },       _onGenericChange('rooms'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'departments' }, _onGenericChange('departments'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'swap_requests' }, _onGenericChange('swapRequests'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'app_settings' }, _onSettingsChange);

    const uid = STATE.currentUser?.id;
    if (uid) {
      channel.on('postgres_changes', {
        event: '*', schema: 'public', table: 'notifications',
        filter: `user_id=eq.${uid}`
      }, _onNotifChange);
    }
    channel.subscribe();
  }

  /** مُحدِّث عام للجداول البسيطة */
  function _onGenericChange(stateKey, hydrator) {
    return (payload) => {
      const { eventType, new: r, old } = payload;
      const arr = STATE[stateKey];
      if (!Array.isArray(arr)) return;
      const idCol = old?.id !== undefined ? 'id' : (old?.code !== undefined ? 'code' : 'id');
      const hyd = hydrator ? (row) => hydrator(row) : (row) => row;
      if (eventType === 'INSERT') {
        arr.push(hyd(r));
      } else if (eventType === 'UPDATE') {
        const i = arr.findIndex(x => x[idCol] === r[idCol]);
        if (i >= 0) arr[i] = hyd(r);
      } else if (eventType === 'DELETE') {
        STATE[stateKey] = arr.filter(x => x[idCol] !== old[idCol]);
      }
      UI?.renderCurrentPage?.();
    };
  }

  function _onSettingsChange(payload) {
    if (payload.new) {
      STATE.settings = Hydrate.settings(payload.new);
      UI?.renderCurrentPage?.();
    }
  }

  function _onExamsChange(payload) {
    const { eventType, new: r, old } = payload;
    if (eventType === 'INSERT') STATE.exams.push(Hydrate.exam(r));
    else if (eventType === 'UPDATE') { const i = STATE.exams.findIndex(e => e.id === r.id); if (i >= 0) STATE.exams[i] = Hydrate.exam(r); }
    else if (eventType === 'DELETE') STATE.exams = STATE.exams.filter(e => e.id !== old.id);
    UI?.renderCurrentPage?.();
    // ✅ تحديث شارة الامتحانات المعلّقة
    if (typeof _updateExamReviewBadge === 'function') {
      try { _updateExamReviewBadge(); } catch {}
    }
  }

  function _onBookingsChange(payload) {
    const { eventType, new: r, old } = payload;
    if (eventType === 'INSERT') STATE.bookings.push(Hydrate.booking(r));
    else if (eventType === 'UPDATE') { const i = STATE.bookings.findIndex(b => b.id === r.id); if (i >= 0) STATE.bookings[i] = Hydrate.booking(r); }
    else if (eventType === 'DELETE') STATE.bookings = STATE.bookings.filter(b => b.id !== old.id);
    // ✅ تحديث فوري بدون تقييد بالصفحة الحالية
    UI?.renderCurrentPage?.();
  }

  function _onUBChange(payload) {
    const { eventType, new: r, old } = payload;
    if (eventType === 'INSERT') STATE.userBookings.push(r);
    else if (eventType === 'DELETE') STATE.userBookings = STATE.userBookings.filter(ub => ub.id !== old.id);
    if (STATE.currentPage === 'my-calendar') UI?.renderCurrentPage?.();
  }

  function _onCDRChange(payload) {
    const { eventType, new: r, old } = payload;
    if (eventType === 'INSERT') STATE.crossDeptRequests.push(r);
    else if (eventType === 'UPDATE') { const i = STATE.crossDeptRequests.findIndex(x => x.id === r.id); if (i >= 0) STATE.crossDeptRequests[i] = r; }
    else if (eventType === 'DELETE') STATE.crossDeptRequests = STATE.crossDeptRequests.filter(x => x.id !== old.id);
    if (STATE.currentPage === 'cross-dept-requests') UI?.renderCurrentPage?.();
    _updateNavBadges();
  }

  function _onNotifChange(payload) {
    const { eventType, new: r } = payload;
    if (eventType === 'INSERT' && r?.user_id === STATE.currentUser?.id) {
      STATE.notifications.unshift({ ...r, read: false, is_read: false });
      _flashNotifBell();
      // إظهار إشعار toast فوري
      if (typeof toast === 'function') {
        const icon = { exam:'📋', warning:'⚠️', success:'✅', info:'ℹ️' }[r.type] || '🔔';
        toast(`${icon} ${r.title}`, r.type || 'info', 6000);
      }
    }
    _updateNavBadges();
    if (typeof renderNotifications === 'function' && STATE.currentPage === 'notifications') {
      renderNotifications();
    }
  }

  function _flashNotifBell() {
    const bell = document.getElementById('notifBell');
    if (bell) { bell.classList.add('ring'); setTimeout(() => bell.classList.remove('ring'), 2000); }
  }

  function _updateNavBadges() {
    if (isDeptHead()) {
      const cnt = pendingCrossDeptCount(STATE.currentUser?.dept_id);
      const badge = document.getElementById('crossDeptBadge');
      if (badge) badge.textContent = cnt || '';
    }
  }

  function _setSyncUI(type, msg) {
    const el = document.getElementById('syncStatus');
    if (!el) return;
    const colors = { ing: 'var(--gold)', ok: 'var(--green)', err: 'var(--red)' };
    el.style.color = colors[type] || 'var(--txt3)';
    el.textContent = msg;
  }

  function getClient()  { return _client; }
  function isReady()    { return _ready; }

  async function manualSync() {
    if (!_client) return;
    _setSyncUI('ing', 'جارٍ التحديث...');
    try {
      await _loadAll();
      _setSyncUI('ok', 'متصل ✓');
      UI?.renderCurrentPage?.();
      if (typeof toast === 'function') toast('✓ تم التحديث', 'success', 2000);
    } catch (e) {
      _setSyncUI('err', 'خطأ: ' + e.message);
    }
  }

  async function refreshTable(table) {
    const rows = await _fetch(table);
    switch (table) {
      case 'exams':              STATE.exams             = rows.map(Hydrate.exam);     break;
      case 'profiles':           STATE.profiles          = rows.map(Hydrate.profile);  break;
      case 'students':           STATE.students          = rows.map(Hydrate.student);  break;
      case 'subjects':           STATE.subjects          = rows;                       break;
      case 'rooms':              STATE.rooms             = rows;                       break;
      case 'sections':           STATE.sections          = rows.map(Hydrate.section);  break;
      case 'departments':        STATE.departments       = rows;                       break;
      case 'schedules':          STATE.schedules         = rows.map(Hydrate.schedule); break;
      case 'bookings':           STATE.bookings          = rows.map(Hydrate.booking);  break;
      case 'semesters':          STATE.semesters         = rows;                       break;
      case 'semester_schedules': STATE.semesterSchedules = rows.map(Hydrate.semesterSchedule); break;
      case 'user_bookings':      STATE.userBookings      = rows.map(Hydrate.userBooking);      break;
    }
  }

  async function fetchTable(table, select, filter, order, limit) {
    return _fetch(table, select, filter, order, limit);
  }

  // initAsync: نسخة قابلة للـ await من init
  async function initAsync(supabaseClient) {
    _client = supabaseClient;
    _setSyncUI('ing', 'جارٍ تحميل البيانات...');
    await _loadAll();
    _ready = true;
    _setSyncUI('ok', 'متصل ✓');
    _startRealtime();
    UI?.renderSidebar?.();
  }

  return {
    init, initAsync, insert, update, del, upsert, rpc, logAction,
    addUsersToBooking, removeUserFromBooking, updateProctorStatus,
    createUser, deleteAuthUser, updateAuthPassword, updateAuthEmail,
    getClient, isReady, manualSync, refreshTable, fetchTable
  };
})();

// ── Compatibility shims ─────────────────────────────────────────
async function dbSave(table, data)           { return SB.upsert(table, data); }
async function dbInsert(table, data)         { return SB.insert(table, data); }
async function dbUpdate(table, id, data, col){ return SB.update(table, id, data, col || 'id'); }
async function dbDelete(table, id, col)      { return SB.del(table, id, col || 'id'); }
async function addLog(action, type, label)   { return SB.logAction(action, type, label); }
