// ═══════════════════════════════════════════════════════════════
//  app-html.js — بناء هيكل HTML للتطبيق
// ═══════════════════════════════════════════════════════════════

function buildAppShell() {
  const appEl = document.getElementById('app');
  if (!appEl) return;

  appEl.innerHTML = `
<!-- ═══ Sidebar ═══ -->
<div class="sidebar" id="sidebar">
  <!-- Brand -->
  <div class="sb-top">
    <div class="sb-brand">
      <div class="sb-icon">
        <img src="https://www.squ.edu.om/Portals/24/asset/Squ_logo.png"
             alt="SQU" onerror="this.style.display='none'">
      </div>
      <div class="sb-brand-txt">
        <h2>ExamFlow</h2>
        <p id="uniSubtitle">${APP_CONFIG.APP_SUBTITLE}</p>
      </div>
    </div>
    <!-- Semester bar -->
    <div class="sb-sem" onclick="openSemesterPicker && openSemesterPicker()" id="sbSemBar">
      <div class="sb-sem-dot"></div>
      <div class="sb-sem-lbl" id="sbSemLbl">—</div>
      <i class="fas fa-chevron-down sb-sem-arr"></i>
    </div>
  </div>

  <!-- User card -->
  <div class="sb-user">
    <div class="sb-user-card">
      <div class="sb-uav" id="sbUserAv" onclick="openProfile()"></div>
      <div class="sb-uname" id="sbUserName" onclick="openProfile()" style="cursor:pointer">
        <strong>—</strong>
        <span>—</span>
      </div>
      <button class="sb-logout" title="تسجيل الخروج" onclick="_appLogout()">
        <i class="fas fa-sign-out-alt"></i>
      </button>
    </div>
  </div>

  <!-- Navigation -->
  <nav class="sb-nav" id="sbNav"></nav>

  <!-- Sync bar -->
  <div class="sb-sync">
    <div class="sync-bar">
      <div class="sync-dot ok" id="syncDot"></div>
      <div class="sync-lbl"><span id="syncStatus">جارٍ الاتصال...</span></div>
      <button class="sync-btn" onclick="SB.manualSync()">
        <i class="fas fa-sync-alt"></i>
      </button>
      <button class="sync-btn" id="langToggleBtn"
        onclick="I18N.setLang(I18N.getLang()==='ar'?'en':'ar')" style="margin-right:4px">
        <i class="fas fa-language"></i> EN
      </button>
    </div>
  </div>
</div>

<!-- Mobile Overlay -->
<div id="sbOverlay" onclick="UI.closeSidebar()"></div>

<!-- Mobile Toggle -->
<button class="sb-mobile-toggle" id="sbToggle" onclick="UI.toggleSidebar()">
  <i class="fas fa-bars"></i>
</button>

<!-- ═══ Topbar ═══ -->
<div class="topbar" id="topbar">
  <div class="tb-title">
    <h2 id="dashTitleH" tabindex="-1"> </h2>
    <span id="tbTitle" style="display:none"></span>
    <p id="tbSubTitle" style="font-size:11px;color:var(--txt3)"> </p>
  </div>
  <div class="tb-acts" style="display:flex;align-items:center;gap:8px">
    <!-- Page-specific actions get injected here via setHTML('examsActs',...) etc -->
    <div id="pageActsBar" style="display:flex;gap:6px;align-items:center"></div>

    <!-- Toast log button -->
    <button class="tb-icon-btn" onclick="openToastLog()" title="سجل الإشعارات" style="position:relative">
      <i class="fas fa-history" style="font-size:13px"></i>
      <span id="toastLogBadge" style="display:none;position:absolute;top:4px;right:4px;width:16px;height:16px;border-radius:50%;background:var(--red2);color:white;font-size:9px;font-weight:800;align-items:center;justify-content:center">0</span>
    </button>

    <!-- Notifications bell -->
    <button class="tb-icon-btn" id="notifBell"
      onclick="UI.showPage('notifications')" title="الإشعارات">
      <i class="fas fa-bell" style="font-size:14px"></i>
      <span class="notif-dot" id="notifDot"></span>
    </button>

    <!-- Theme toggle -->
    <button class="tb-icon-btn" onclick="THEME?.toggle()" title="تبديل الثيم" id="themeToggleBtn">
      <i class="fas fa-moon" style="font-size:13px"></i>
    </button>
  </div>
</div>

<!-- ═══ Main Content ═══ -->
<main class="main" id="mainContent">

  <!-- ── Dashboard (admin/coord/dean) ── -->
  <div class="page" id="dashboardPage">
    <div id="dashWelcome" style="font-size:18px;font-weight:800;margin-bottom:16px"></div>
    <div class="stats-grid" id="dashStats" style="margin-bottom:16px"></div>
    <div id="dashActs" style="margin-bottom:16px"></div>
    <div id="dashGrid"></div>
    <div id="dashWidgetGrid" style="display:flex;flex-direction:column;gap:14px"></div>
  </div>

  <!-- ── My Dashboard (proctor) ── -->
  <div class="page" id="my-dashboardPage">
    <div id="myWelcome" style="font-size:18px;font-weight:800;margin-bottom:16px"></div>
    <div class="stats-grid" id="myStats" style="margin-bottom:16px"></div>
    <div id="myGrid"></div>
  </div>

  <!-- ── Student Portal ── -->
  <div class="page" id="student-portalPage">
    <div id="studWelcome" style="font-size:18px;font-weight:800;margin-bottom:16px"></div>
    <div class="stats-grid" id="studStats" style="margin-bottom:16px"></div>
    <div id="studGrid"></div>
    <div id="student-portalContent"></div>
  </div>

  <!-- ── Calendar ── -->
  <div class="page" id="calendarPage">
    <div id="calendarActs" style="margin-bottom:12px"></div>
    <div id="calendarContent"></div>
  </div>

  <!-- ── My Calendar (personal) ── -->
  <div class="page" id="my-calendarPage">
    <div id="myCalendarContent"></div>
  </div>

  <!-- ── Live Monitor ── -->
  <div class="page" id="livePage">
    <div id="liveActs" style="margin-bottom:12px"></div>
    <div id="liveContent"></div>
  </div>

  <!-- ── Exams ── -->
  <div class="page" id="examsPage">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
      <input type="search" id="examSrch" placeholder="بحث في الامتحانات..."
        oninput="renderExams && renderExams()"
        style="flex:1;min-width:0;height:36px;border:1.5px solid var(--border);border-radius:9px;padding:0 12px;font-size:13px;background:var(--surface)">
      <div id="examsActs"></div>
    </div>
    <div class="tabs" id="examTabs" style="margin-bottom:14px">
      <div class="tab active" onclick="setEF('all',this)">الكل</div>
      <div class="tab" onclick="setEF('upcoming',this)">قادمة</div>
      <div class="tab" onclick="setEF('active',this)">جارية</div>
      <div class="tab" onclick="setEF('completed',this)">منتهية</div>
    </div>
    <div id="examsList"></div>
  </div>

  <!-- ── Proctors ── -->
  <div class="page" id="proctorsPage">
    <div id="proctorsActs" style="margin-bottom:12px"></div>
    <div id="proctorContent"></div>
  </div>

  <!-- ── Rooms ── -->
  <div class="page" id="roomsPage">
    <div id="roomsActs" style="margin-bottom:12px"></div>
    <div id="roomsGrid"></div>
  </div>

  <!-- ── Bookings ── -->
  <div class="page" id="bookingsPage">
    <div id="bookingsActs" style="margin-bottom:12px"></div>
    <div id="bookingsContent"></div>
  </div>

  <!-- ── Departments ── -->
  <div class="page" id="departmentsPage">
    <div id="deptsActs" style="margin-bottom:12px"></div>
    <div id="deptsContent"></div>
  </div>

  <!-- ── Subjects ── -->
  <div class="page" id="subjectsPage">
    <div id="subjActs" style="margin-bottom:12px"></div>
    <div id="subjectsContent"></div>
  </div>

  <!-- ── Students ── -->
  <div class="page" id="studentsPage">
    <div id="studentsActs" style="margin-bottom:12px"></div>
    <div id="studentsContent"></div>
  </div>

  <!-- ── Users ── -->
  <div class="page" id="usersPage">
    <div id="usersActs" style="margin-bottom:12px"></div>
    <div id="usersContent"></div>
  </div>

  <!-- ── Analytics ── -->
  <div class="page" id="analyticsPage">
    <div id="anaActs" style="margin-bottom:12px"></div>
    <div id="anaContent">
      <div id="anaTabContent"></div>
    </div>
  </div>

  <!-- ── Notifications ── -->
  <div class="page" id="notificationsPage">
    <div class="card" style="overflow:hidden">
      <div class="card-h">
        <h3><i class="fas fa-bell" style="color:var(--primary2)"></i> الإشعارات</h3>
      </div>
      <div id="notifList"></div>
    </div>
  </div>

  <!-- ── Log ── -->
  <div class="page" id="logPage">
    <div id="logContent"></div>
  </div>

  <!-- ── Settings ── -->
  <div class="page" id="settingsPage">
    <div id="settingsContent"></div>
  </div>

  <!-- ── Swaps / Requests ── -->
  <div class="page" id="swapsPage">
    <div id="swapsContent"></div>
  </div>

  <!-- ── Cross Dept Requests ── -->
  <div class="page" id="cross-dept-requestsPage">
    <div id="crossDeptActs" style="margin-bottom:12px"></div>
    <div id="crossDeptContent"></div>
  </div>

  <!-- ── Digital Seal ── -->
  <div class="page" id="digital-sealPage">
    <div id="sealActs" style="margin-bottom:12px"></div>
    <div id="sealContent"></div>
  </div>

  <!-- ── Class Compare ── -->
  <div class="page" id="class-comparePage">
    <div id="classCompareContent"></div>
  </div>

  <!-- ── AI Engine ── -->
  <div class="page" id="ai-enginePage">
    <div id="aiActs" style="margin-bottom:12px"></div>
    <div id="aiContent"></div>
  </div>

</main>

<!-- ═══ Fullscreen Monitor Overlay ═══ -->
<div id="ctOv">
  <div id="monWrap" style="width:100%;flex:1;display:flex;flex-direction:column"></div>
</div>
`;

  // تحديث عنوان الفصل الدراسي
  _updateSbSem();
}

function _updateSbSem() {
  const lbl = document.getElementById('sbSemLbl');
  if (!lbl) return;
  const sem = STATE.semesters?.find(s => s.code === STATE.currentSem);
  lbl.textContent = sem?.label || STATE.currentSem || '—';
}

function _appLogout() {
  if (STATE._studentUser) {
    APP.studentLogout?.();
  } else {
    APP.logout?.();
  }
}
