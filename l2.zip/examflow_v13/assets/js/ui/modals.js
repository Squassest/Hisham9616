// ═══════════════════════════════════════════════════════════════
//  modals.js — نافذة تبديل الفصل الدراسي + مساعدات عامة
// ═══════════════════════════════════════════════════════════════

// ── Send Notification (admin/coord) ──────────────────────────
function openSendNotification() {
  const moId = 'sendNotifMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  const users = STATE.profiles.filter(p => p.active);

  mo.innerHTML = `<div class="md" style="max-width:440px">
    <div class="md-hd">
      <h2><i class="fas fa-paper-plane" style="color:var(--gold)"></i> إرسال إشعار</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field">
        <label class="field-lbl">الموجَّه إلى</label>
        <select id="nfTarget" style="width:100%">
          <option value="all">جميع المستخدمين (${users.length})</option>
          <option value="proctors">المراقبون فقط</option>
          <option value="dept_heads">رؤساء الأقسام فقط</option>
        </select>
      </div>
      <div class="field">
        <label class="field-lbl">عنوان الإشعار <span class="req">*</span></label>
        <input type="text" id="nfTitle" placeholder="اكتب العنوان...">
      </div>
      <div class="field">
        <label class="field-lbl">نص الرسالة (اختياري)</label>
        <textarea id="nfBody" rows="3" placeholder="تفاصيل الإشعار..."></textarea>
      </div>
      <div class="field">
        <label class="field-lbl">النوع</label>
        <select id="nfType">
          <option value="info">معلومة</option>
          <option value="warning">تنبيه</option>
          <option value="success">نجاح</option>
          <option value="exam">امتحان</option>
        </select>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" style="background:var(--gold);border-color:var(--gold)" onclick="_doSendNotification('${moId}')">
        <i class="fas fa-paper-plane"></i> إرسال
      </button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _doSendNotification(moId) {
  const target = document.getElementById('nfTarget')?.value || 'all';
  const title  = document.getElementById('nfTitle')?.value?.trim();
  const body   = document.getElementById('nfBody')?.value?.trim();
  const type   = document.getElementById('nfType')?.value || 'info';

  if (!title) { toast('أدخل عنوان الإشعار','error'); return; }

  let users = STATE.profiles.filter(p => p.active);
  if (target === 'proctors')   users = users.filter(p => p.role === 'proctor');
  if (target === 'dept_heads') users = users.filter(p => p.role === 'dept_head');

  const userIds = users.map(u => u.id);

  try {
    await addNotif(userIds, title, body || '', type);
    closeMo(moId);
    toast(`✓ أُرسل الإشعار لـ ${userIds.length} مستخدم`, 'success');
    await addLog('إرسال إشعار جماعي', 'info', title);
  } catch(e) {
    toast('خطأ: ' + e.message, 'error');
  }
}

// ── Change Password (current user) ────────────────────────────
function openChangePassword() {
  const moId = 'chPassMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  mo.innerHTML = `<div class="md" style="max-width:380px">
    <div class="md-hd">
      <h2><i class="fas fa-key" style="color:var(--gold)"></i> تغيير كلمة المرور</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd">
      <div class="field">
        <label class="field-lbl">كلمة المرور الجديدة <span class="req">*</span></label>
        <div class="pass-wrap">
          <input type="password" id="cpPass" placeholder="••••••••"
            oninput="checkPassStrength('cpPass','cpStr','cpLbl')">
          <i class="fas fa-eye pass-eye" onclick="togglePassEye('cpPass',this)"></i>
        </div>
        <div class="pass-strength">
          <div class="pass-bar"><div class="pass-bar-fill" id="cpStr"></div></div>
          <div class="pass-lbl" id="cpLbl"></div>
        </div>
      </div>
      <div class="field">
        <label class="field-lbl">تأكيد كلمة المرور <span class="req">*</span></label>
        <div class="pass-wrap">
          <input type="password" id="cpPass2" placeholder="••••••••"
            oninput="checkPassMatch('cpPass','cpPass2','cpMatch')">
          <i class="fas fa-eye pass-eye" onclick="togglePassEye('cpPass2',this)"></i>
        </div>
        <div class="pass-match" id="cpMatch"></div>
      </div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إلغاء</button>
      <button class="btn bp" onclick="_doChangeMyPass('${moId}')">
        <i class="fas fa-save"></i> حفظ
      </button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

async function _doChangeMyPass(moId) {
  const p1 = document.getElementById('cpPass')?.value;
  const p2 = document.getElementById('cpPass2')?.value;
  if (!p1 || p1.length < 4) { toast('كلمة المرور يجب أن تكون 4 أحرف على الأقل','error'); return; }
  if (p1 !== p2) { toast('كلمتا المرور غير متطابقتين','error'); return; }
  try {
    await AUTH.changePassword(p1);
    closeMo(moId);
    toast('✓ تم تغيير كلمة المرور','success');
  } catch(e) {
    toast('خطأ: ' + e.message, 'error');
  }
}

// ── QR Exam Modal ──────────────────────────────────────────────
function openExamQR(examId) {
  const e = getExam(examId);
  if (!e) return;
  const sub = getSubject(e.subject_id);

  const moId = 'examQrMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  // رابط حضور مبسط
  const url = `${location.origin}${location.pathname}?exam=${examId}&mode=qr`;

  mo.innerHTML = `<div class="md" style="max-width:360px;text-align:center">
    <div class="md-hd">
      <h2><i class="fas fa-qrcode" style="color:var(--primary)"></i> QR تسجيل الحضور</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:24px">
      <div style="font-weight:700;margin-bottom:12px">${esc(sub?.name||'—')}</div>
      <div style="font-size:12px;color:var(--txt2);margin-bottom:16px">${fmtDate(e.date)} · ${fmtTime(e.time)}</div>
      <div id="examQrCanvas" style="display:flex;justify-content:center;margin-bottom:16px">
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(url)}"
             alt="QR" style="width:200px;height:200px;border-radius:10px;border:3px solid var(--border)">
      </div>
      <div style="font-size:11px;color:var(--txt3);word-break:break-all;padding:8px;background:var(--bg);border-radius:8px">${url}</div>
    </div>
    <div class="md-ft">
      <button class="btn bo" onclick="closeMo('${moId}')">إغلاق</button>
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}
