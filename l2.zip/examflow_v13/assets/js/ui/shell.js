// ═══════════════════════════════════════════════════════════════
//  shell.js — UI controller: navigation, pages, sidebar
// ═══════════════════════════════════════════════════════════════

const UI = (() => {

  // ── تعريف الصفحات ────────────────────────────────────────────
  const PAGES = {
    'dashboard':             { icon:'fa-home',           label:'لوحة التحكم',       render: () => renderDashboard?.()        },
    'my-dashboard':          { icon:'fa-home',           label:'لوحتي',             render: () => renderMyDashboard?.()      },
    'student-portal':        { icon:'fa-user-graduate',  label:'بوابتي',            render: () => renderStudentPortal?.()    },
    'calendar':              { icon:'fa-calendar-alt',   label:'التقويم',           render: () => renderCalendar?.()         },
    'my-calendar':           { icon:'fa-calendar-user',  label:'تقويمي',            render: () => renderMyCalendar?.()       },
    'live':                  { icon:'fa-tv',             label:'المراقبة الحية',    render: () => renderMonitor?.()          },
    'exams':                 { icon:'fa-file-alt',       label:'الامتحانات',        render: () => renderExams?.()            },
    'proctors':              { icon:'fa-user-check',     label:'المراقبون',         render: () => renderProctors?.()         },
    'rooms':                 { icon:'fa-door-open',      label:'القاعات',           render: () => renderRooms?.()            },
    'bookings':              { icon:'fa-calendar-check', label:'حجز القاعات',       render: () => renderBookings?.()         },
    'departments':           { icon:'fa-sitemap',        label:'الأقسام',           render: () => renderDepartments?.()      },
    'subjects':              { icon:'fa-book',           label:'المواد والشعب',     render: () => renderSubjects?.()         },
    'students':              { icon:'fa-user-graduate',  label:'الطلاب',            render: () => renderStudents?.()         },
    'users':                 { icon:'fa-users',          label:'المستخدمون',        render: () => renderUsers?.()            },
    'analytics':             { icon:'fa-chart-bar',      label:'التحليلات',         render: () => renderAnalytics?.()        },
    'swaps':                 { icon:'fa-exchange-alt',   label:'الطلبات',           render: () => renderSwaps?.()            },
    'cross-dept-requests':   { icon:'fa-handshake',      label:'طلبات التعاون',     render: () => renderCrossDeptRequests?.()},
    'notifications':         { icon:'fa-bell',           label:'الإشعارات',         render: () => renderNotifications?.()    },
    'log':                   { icon:'fa-history',        label:'سجل النشاط',        render: () => renderLog?.()              },
    'settings':              { icon:'fa-cog',            label:'الإعدادات',         render: () => renderSettings?.()         },
    'digital-seal':          { icon:'fa-stamp',          label:'الختم الرقمي',      render: () => renderDigitalSeal?.()      },
    'class-compare':         { icon:'fa-balance-scale',  label:'مقارنة الشعب',      render: () => renderClassCompare?.()     },
    'ai-engine':             { icon:'fa-robot',          label:'محرك الذكاء',       render: () => renderAIEngine?.()         },
  };

  // ── هيكل القائمة حسب الدور ───────────────────────────────────
  const NAV_ADMIN = [
    { section: 'الرئيسية',   items: ['dashboard','live','calendar'] },
    { section: 'الامتحانات', items: ['exams','proctors','swaps','cross-dept-requests'] },
    { section: 'الأكاديمية', items: ['departments','subjects','students','rooms','bookings'] },
    { section: 'الإدارة',    items: ['users','analytics','digital-seal','class-compare','ai-engine'] },
    { section: 'النظام',     items: ['notifications','log','settings'] },
  ];
  const NAV_COORD = [
    { section: 'الرئيسية',   items: ['dashboard','live','my-calendar','calendar'] },
    { section: 'الامتحانات', items: ['exams','proctors','swaps','cross-dept-requests'] },
    { section: 'الأكاديمية', items: ['departments','subjects','students','rooms','bookings'] },
    { section: 'الأدوات',    items: ['analytics','digital-seal','class-compare','ai-engine'] },
    { section: 'النظام',     items: ['notifications','settings'] },
  ];
  const NAV_DEPT_HEAD = [
    { section: 'الرئيسية',   items: ['dashboard','live','my-calendar'] },
    { section: 'الامتحانات', items: ['exams','swaps','cross-dept-requests'] },
    { section: 'الأكاديمية', items: ['departments','subjects','proctors','students','rooms','bookings'] },
    { section: 'الأدوات',    items: ['analytics','class-compare','ai-engine'] },
    { section: 'النظام',     items: ['notifications'] },
  ];
  const NAV_DEAN = [
    { section: 'الرئيسية',   items: ['dashboard','live','calendar'] },
    { section: 'الامتحانات', items: ['exams'] },
    { section: 'الأكاديمية', items: ['departments','subjects','proctors','students','rooms'] },
    { section: 'التقارير',   items: ['analytics','notifications'] },
  ];
  const NAV_PROCTOR = [
    { section: 'الرئيسية',   items: ['my-dashboard','live','my-calendar'] },
    { section: 'امتحاناتي',  items: ['exams','swaps'] },
    { section: 'المعلومات',  items: ['subjects','students','analytics'] },
    { section: 'النظام',     items: ['notifications'] },
  ];
  const NAV_STUDENT = [
    { section: 'بوابتي', items: ['student-portal','my-calendar','notifications'] },
  ];

  // ── بناء القائمة الجانبية ──────────────────────────────────
  function buildNav() {
    const nav = document.getElementById('sbNav');
    if (!nav) return;

    const role = STATE.currentUser?.role || (STATE._studentUser ? 'student' : null);
    let navDef;
    switch (role) {
      case 'admin':          navDef = NAV_ADMIN;    break;
      case 'coordinator':    navDef = NAV_COORD;    break;
      case 'dept_head':      navDef = NAV_DEPT_HEAD;break;
      case 'dean':
      case 'assistant_dean': navDef = NAV_DEAN;     break;
      case 'proctor':        navDef = NAV_PROCTOR;  break;
      case 'student':        navDef = NAV_STUDENT;  break;
      default:               navDef = NAV_PROCTOR;  break;
    }

    const isAr = typeof I18N !== 'undefined' ? I18N.isAr() : true;
    const cur  = STATE.currentPage;

    let html = '';
    navDef.forEach(group => {
      html += `<div class="nav-section-lbl">${group.section}</div>`;
      group.items.forEach(pid => {
        const pg = PAGES[pid];
        if (!pg) return;

        // فحص صلاحية الرؤية
        if (!_canSeePage(pid, role)) return;

        const active = cur === pid ? 'active' : '';
        const label  = pg.label;

        // شارات خاصة
        let badge = '';
        if (pid === 'swaps') {
          const uid = STATE.currentUser?.id;
          const pendingSwaps = (STATE.swapRequests||[]).filter(r=>r.target_id===uid&&r.status==='pending').length;
          const pendingAssign = (STATE.exams||[]).filter(e=>
            e.semester===STATE.currentSem &&
            (e.proctor_ids||[]).includes(uid) &&
            (e.proctor_statuses||{})[uid]==='pending'
          ).length;
          const tot = pendingSwaps + pendingAssign;
          if (tot > 0) badge = `<span class="nav-badge">${tot}</span>`;
        }
        if (pid === 'cross-dept-requests') {
          const cnt = STATE.currentUser?.dept_id
            ? (STATE.crossDeptRequests||[]).filter(r=>r.target_dept_id===STATE.currentUser.dept_id&&r.status==='pending').length
            : 0;
          if (cnt > 0) badge = `<span class="nav-badge" id="crossDeptBadge">${cnt}</span>`;
          else badge = `<span id="crossDeptBadge"></span>`;
        }
        if (pid === 'notifications') {
          const unread = (STATE.notifications||[]).filter(n=>!n.read&&!n.is_read).length;
          if (unread > 0) badge = `<span class="nav-badge">${unread}</span>`;
        }
        if (pid === 'live') {
          const activeCnt = (STATE.exams||[]).filter(e=>
            e.semester===STATE.currentSem && examStatus(e)==='active'
          ).length;
          if (activeCnt > 0) {
            badge = `<span style="width:7px;height:7px;border-radius:50%;background:var(--green2);animation:pulse 1s infinite;display:inline-block"></span>`;
          }
        }

        html += `<div class="nav-item ${active}" onclick="UI.showPage('${pid}')" id="nav_${pid}">
          <div class="nav-ic"><i class="fas ${pg.icon}"></i></div>
          <span>${label}</span>
          ${badge}
        </div>`;
      });
    });

    nav.innerHTML = html;
  }

  // ── فحص صلاحية رؤية صفحة ──────────────────────────────────
  function _canSeePage(pid, role) {
    if (!role) return false;
    if (role === 'admin') return true;
    if (role === 'student') return studentCanSeePage?.(pid) ?? false;
    if (role === 'proctor') return proctorCanSeePage?.(pid) ?? false;
    if (role === 'dept_head') return deptHeadCanSeePage?.(pid) ?? false;
    if (role === 'dean' || role === 'assistant_dean') return deanCanSeePage?.(pid) ?? false;
    // coordinator
    return coordinatorCanSeePage?.(pid) ?? true;
  }

  // ── بناء الـ Sidebar (user info + nav) ─────────────────────
  function renderSidebar() {
    const u = STATE.currentUser || STATE._studentUser;
    if (!u) return;

    // اسم المستخدم وصلاحيته
    const role     = u.role || (STATE._studentUser ? 'student' : 'proctor');
    const roleLbl  = APP_CONFIG.ROLES?.[role] || role;
    const color    = APP_CONFIG.ROLE_COLORS?.[role] || '#2563eb';
    const icon     = APP_CONFIG.ROLE_ICONS?.[role]  || 'fa-user';

    const avEl   = document.getElementById('sbUserAv');
    const nameEl = document.getElementById('sbUserName');
    if (avEl) {
      avEl.style.background = color;
      avEl.innerHTML = `<i class="fas ${icon}" style="color:white;font-size:14px"></i>`;
    }
    if (nameEl) {
      const firstName = (u.name||'').split(' ').slice(0,2).join(' ');
      nameEl.innerHTML = `<strong>${esc(firstName)}</strong><span>${esc(roleLbl)}</span>`;
    }

    // الفصل الدراسي
    _updateSbSem?.();

    // بناء القائمة
    buildNav();

    // تحديث ثيم بوتن
    _updateThemeBtn();
  }

  function _updateThemeBtn() {
    const btn = document.getElementById('themeToggleBtn');
    if (!btn) return;
    const isDark = document.body.classList.contains('dark') ||
                   document.documentElement.dataset.theme === 'dark';
    btn.innerHTML = `<i class="fas fa-${isDark ? 'sun' : 'moon'}" style="font-size:13px"></i>`;
  }

  // ── عرض صفحة ──────────────────────────────────────────────
  function showPage(pageId) {
    // حفظ الصفحة الأخيرة
    const uid = STATE.currentUser?.id || STATE._studentUser?.id;
    if (uid) try { localStorage.setItem('ef_lastPage_' + uid, pageId); } catch {}

    // إخفاء كل الصفحات
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

    // إظهار الصفحة المطلوبة
    const pageEl = document.getElementById(pageId + 'Page');
    if (pageEl) pageEl.classList.add('active');

    // تحديث عنوان الصفحة
    STATE.currentPage = pageId;
    const pg = PAGES[pageId];
    if (pg) {
      const h  = document.getElementById('dashTitleH');
      const tb = document.getElementById('tbTitle');
      if (h)  h.textContent  = pg.label;
      if (tb) tb.textContent = pg.label;
    }

    // تحديث القائمة
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.id === 'nav_' + pageId);
    });

    // تحديث شريط الأكشن (مسح القديم)
    _clearPageActs(pageId);

    // رسم محتوى الصفحة
    const render = pg?.render;
    if (render) {
      try { render(); } catch(e) { console.error('[showPage] render error:', pageId, e); }
    }

    // إغلاق السايدبار في الموبايل
    closeSidebar();

    // الانتقال لأعلى الصفحة
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // ── مسح أزرار الصفحة السابقة ──────────────────────────────
  function _clearPageActs(newPage) {
    const actIds = [
      'dashActs','examsActs','proctorsActs','roomsActs','schedActs',
      'deptsActs','subjActs','studentsActs','usersActs','anaActs',
      'liveActs','crossDeptActs','sealActs','aiActs','bookingsActs'
    ];
    // نمسح فقط الأكشن bars وليس المحتوى
    // كل render fn ستضع قيمتها بنفسها
  }

  // ── إعادة رسم الصفحة الحالية ──────────────────────────────
  function renderCurrentPage() {
    if (!STATE.currentPage) return;
    const pg = PAGES[STATE.currentPage];
    if (pg?.render) {
      try { pg.render(); } catch(e) { console.warn('[renderCurrentPage]', e); }
    }
    // تحديث شارات القائمة
    buildNav();
  }

  // ── تحديث شارة الإشعارات ──────────────────────────────────
  function updateNotifBadge() {
    const dot = document.getElementById('notifDot');
    if (!dot) return;
    const unread = (STATE.notifications||[]).filter(n=>!n.read&&!n.is_read).length;
    dot.classList.toggle('show', unread > 0);
  }

  // ── موبايل sidebar ──────────────────────────────────────────
  function toggleSidebar() {
    const sb  = document.getElementById('sidebar');
    const ov  = document.getElementById('sbOverlay');
    const tog = document.getElementById('sbToggle');
    if (!sb) return;
    const open = sb.classList.toggle('sb-open');
    if (ov)  ov.style.display  = open ? 'block' : 'none';
    if (tog) tog.innerHTML = open
      ? '<i class="fas fa-times"></i>'
      : '<i class="fas fa-bars"></i>';
  }

  function closeSidebar() {
    const sb  = document.getElementById('sidebar');
    const ov  = document.getElementById('sbOverlay');
    const tog = document.getElementById('sbToggle');
    if (sb)  sb.classList.remove('sb-open');
    if (ov)  ov.style.display = 'none';
    if (tog) tog.innerHTML = '<i class="fas fa-bars"></i>';
  }

  return {
    buildNav, renderSidebar, showPage,
    renderCurrentPage, updateNotifBadge,
    toggleSidebar, closeSidebar,
    _updateThemeBtn
  };
})();

// ── Semester Picker ──────────────────────────────────────────
function openSemesterPicker() {
  // بسيط: قائمة منسدلة بالفصول
  const moId = 'semPickerMo';
  let mo = document.getElementById(moId);
  if (!mo) { mo = document.createElement('div'); mo.className='mo'; mo.id=moId; document.body.appendChild(mo); }

  const sems = STATE.semesters || [];
  mo.innerHTML = `<div class="md" style="max-width:340px">
    <div class="md-hd">
      <h2><i class="fas fa-calendar" style="color:var(--primary)"></i> الفصل الدراسي</h2>
      <button class="md-close" onclick="closeMo('${moId}')"><i class="fas fa-times"></i></button>
    </div>
    <div class="md-bd" style="padding:14px">
      ${sems.length ? sems.map(s => `
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-radius:10px;margin-bottom:6px;cursor:pointer;background:${s.code===STATE.currentSem?'var(--primary-bg)':'var(--bg)'};border:1.5px solid ${s.code===STATE.currentSem?'var(--primary)':'var(--border)'}"
          onclick="STATE.currentSem='${s.code}';document.getElementById('sbSemLbl').textContent='${esc(s.label)}';closeMo('${moId}');UI.renderCurrentPage();">
          <div>
            <div style="font-weight:700;font-size:13.5px">${esc(s.label)}</div>
            <div style="font-size:11px;color:var(--txt3)">${s.is_active?'● الفصل الحالي':s.is_closed?'مغلق':''}</div>
          </div>
          ${s.code===STATE.currentSem?'<i class="fas fa-check" style="color:var(--primary)"></i>':''}
        </div>`).join('') : '<div style="text-align:center;padding:20px;color:var(--txt3)">لا توجد فصول</div>'}
    </div>
  </div>`;
  requestAnimationFrame(() => mo.classList.add('open'));
}

// ── CSS للموبايل (sidebar toggle) ─────────────────────────────
(function() {
  const style = document.createElement('style');
  style.textContent = `
    @media (max-width: 768px) {
      .sidebar { transform: translateX(100%); transition: transform .3s ease; }
      .sidebar.sb-open { transform: translateX(0); }
      .sb-mobile-toggle { display: flex; align-items: center; justify-content: center; }
      .main { margin-right: 0 !important; }
      .topbar { right: 0 !important; }
      #sbOverlay { display: none; }
    }
    @media (min-width: 769px) {
      .sb-mobile-toggle { display: none !important; }
    }
    @keyframes pulse {
      0%,100% { opacity:1; transform:scale(1); }
      50%      { opacity:.6; transform:scale(.9); }
    }
    @keyframes fadeIn {
      from { opacity:0; transform:translateY(8px); }
      to   { opacity:1; transform:none; }
    }
  `;
  document.head.appendChild(style);
})();
