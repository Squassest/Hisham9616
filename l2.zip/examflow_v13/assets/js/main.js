// ═══════════════════════════════════════════════════════════════
//  main.js v14 — بوت موحّد بدون Supabase Auth
//  ✓ تسجيل دخول الموظف والطالب من نفس الشاشة
//  ✓ استعادة الجلسة من localStorage
//  ✓ يكتشف نوع المستخدم تلقائياً
// ═══════════════════════════════════════════════════════════════

const APP = (() => {
  let _sb      = null;
  let _started = false;

  // ── تهيئة التطبيق ─────────────────────────────────────────────
  async function boot() {
    try {
      // ── 1. التأكد من توفر مكتبة Supabase ──
      if (typeof window.supabase === 'undefined' || !window.supabase.createClient) {
        throw new Error('مكتبة Supabase لم تُحمَّل — تحقق من اتصال الإنترنت ثم حدّث الصفحة');
      }

      // ── 2. إنشاء Supabase client (للاستعلام فقط — بدون Auth) ──
      _sb = window.supabase.createClient(
        APP_CONFIG.SUPABASE_URL,
        APP_CONFIG.SUPABASE_ANON_KEY,
        { auth: { persistSession: false, autoRefreshToken: false } }
      );
      if (!_sb) throw new Error('فشل إنشاء عميل Supabase');

      // نشارك الـ client مع BIO و AUTH عالمياً قبل أي تسجيل دخول
      window._efSB = _sb;

      // ── 3. تهيئة AUTH ──
      if (typeof AUTH === 'undefined' || !AUTH.setup) {
        throw new Error('وحدة AUTH غير محمّلة');
      }
      AUTH.setup(_sb);

      // ── 4. استعادة الجلسة من localStorage ──
      const { user, error, timedOut } = await AUTH.waitForSession();

      if (timedOut)  { console.warn('[boot] timeout'); _showLogin(); return; }
      if (error)     { console.warn('[boot] error:', error); _showLogin(); return; }
      if (user)      { await _startApp(); }
      else           { _showLogin(); }

    } catch (e) {
      console.error('[boot]', e.message);
      // حتى لو فشل boot، نضمن وجود client عالمي للوحدات اللاحقة
      try {
        if (!window._efSB && window.supabase && APP_CONFIG) {
          window._efSB = window.supabase.createClient(
            APP_CONFIG.SUPABASE_URL,
            APP_CONFIG.SUPABASE_ANON_KEY,
            { auth: { persistSession: false, autoRefreshToken: false } }
          );
          if (typeof AUTH !== 'undefined' && AUTH.setup) AUTH.setup(window._efSB);
        }
      } catch {}
      _showLogin();
    }
  }

  // ── تسجيل دخول الموظف ──────────────────────────────────────────
  async function login() {
    const emailEl = document.getElementById('lEmail');
    const passEl  = document.getElementById('lPass');
    const btnEl   = document.getElementById('loginBtn');

    const email = emailEl?.value?.trim() || '';
    const pass  = passEl?.value || '';

    if (!email || !pass) { _setErr('يرجى إدخال البريد وكلمة المرور'); return; }

    _setBtnLoading(btnEl, true);
    _setErr('');

    try {
      await AUTH.signIn(email, pass);
      if (!STATE.currentUser) throw new Error('تعذّر تحميل بيانات المستخدم');
      await _startApp();
    } catch (e) {
      _setBtnLoading(btnEl, false);
      _setErr(e.message);
      const lr = document.querySelector('.lr');
      if (lr) { lr.classList.add('shake'); setTimeout(() => lr.classList.remove('shake'), 400); }
    }
  }

  // ── تسجيل الخروج (موظف) ───────────────────────────────────────
  async function logout() {
    _started = false;
    // حذف مفتاح الجلسة من sessionStorage
    const _sid = STATE.currentUser?.id || '';
    if (_sid) sessionStorage.removeItem('_wShown_' + _sid);
    try { await AUTH.signOut(); } catch { /* silent */ }
    STATE.currentUser  = null;
    STATE._studentUser = null;
    try { document.getElementById('app').innerHTML = ''; } catch {}
    _showLogin({ tab: 'staff' });
  }

  // ── خروج الطالب ──────────────────────────────────────────────
  async function studentLogout() {
    _started = false;
    const _sid = STATE._studentUser?.stud_id || '';
    if (_sid) sessionStorage.removeItem('_wShown_' + _sid);
    try { await AUTH.signOut(); } catch { /* silent */ }
    STATE._studentUser     = null;
    STATE.currentUser      = null;
    STATE._studentAttendance = {};
    try { document.getElementById('app').innerHTML = ''; } catch {}
    _showLogin({ tab: 'student' });
  }

  // ── بدء التطبيق ────────────────────────────────────────────────
  async function _startApp() {
    if (_started) return;
    _started = true;

    const ls  = document.getElementById('loadingScreen');
    const txt = document.getElementById('lsLoadTxt');
    if (txt) txt.textContent = 'جارٍ تحميل البيانات...';

    buildAppShell();
    UI.buildNav();
    UI.renderSidebar();

    // ── تحميل البيانات ────────────────────────────────────────────
    if (STATE._studentUser && !STATE.currentUser) {
      // وضع الطالب: تحميل البيانات الضرورية أولاً
      if (typeof _loadStudentData === 'function') {
        try {
          await _loadStudentData(STATE._studentUser);
        } catch (e) {
          console.warn('[_startApp] _loadStudentData failed:', e.message);
          // محاولة بديلة عبر SB الكامل
          try { await SB.initAsync(_sb); } catch { SB.init(_sb); }
        }
      } else {
        try { await SB.initAsync(_sb); } catch { SB.init(_sb); }
      }
    } else {
      // وضع الموظف: SB.init يُحمّل كل البيانات ثم يُعيد رسم الصفحة
      SB.init(_sb);
    }

    if (ls) ls.remove();
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('app').style.display = 'block';

    const defaults = {
      admin:          'dashboard',
      coordinator:    'dashboard',
      dept_head:      'dashboard',
      dean:           'dashboard',
      assistant_dean: 'dashboard',
      proctor:        'my-dashboard',
      student:        'student-portal'
    };
    const currentRole = STATE._studentUser
      ? 'student'
      : (STATE.currentUser?.role || 'proctor');
    const uid       = STATE.currentUser?.id || STATE._studentUser?.id;
    const saved     = uid ? localStorage.getItem('ef_lastPage_' + uid) : null;
    const startPage = saved || defaults[currentRole] || 'dashboard';

    UI.showPage(startPage);

    // ── ترحيب — يظهر مرة واحدة لكل جلسة دخول فعلية فقط ──
    const _sid = STATE.currentUser?.id || STATE._studentUser?.stud_id || '';
    const _wKey = '_wShown_' + _sid;
    if (!sessionStorage.getItem(_wKey)) {
      sessionStorage.setItem(_wKey, '1');
      const firstName = (STATE._studentUser?.name || STATE.currentUser?.name || '').split(' ')[0];
      if (firstName) toast(`مرحباً ${firstName} 👋`, 'success', 3000);
    }

    // ── تذكيرات الامتحانات بعد تسجيل الدخول ──
    setTimeout(() => {
      if (typeof _showExamReminders === 'function') _showExamReminders();
    }, 2000);

    setTimeout(() => {
      if (typeof checkSignatureRequired === 'function') checkSignatureRequired();
    }, 1500);
  }

  // ── إظهار شاشة الدخول ─────────────────────────────────────────
  function _showLogin(opts = {}) {
    _started = false;
    const ls      = document.getElementById('loadingScreen');
    const loginEl = document.getElementById('loginScreen');
    const appEl   = document.getElementById('app');
    if (ls)      ls.remove();
    if (loginEl) loginEl.style.display = 'flex';
    if (appEl)   appEl.style.display   = 'none';

    ['lPass', 'lEmail', 'studPassInput', 'studEmailInput'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    _setErr('');
    _setStudErr('');

    const sb = document.getElementById('loginBtn');
    if (sb) { sb.disabled = false; sb.innerHTML = '<i class="fas fa-sign-in-alt"></i> دخول'; }
    const stb = document.getElementById('studLoginBtn');
    if (stb) { stb.disabled = false; stb.innerHTML = '<i class="fas fa-sign-in-alt"></i> دخول'; }

    if (typeof window.switchLoginTab === 'function') {
      window.switchLoginTab(opts.tab || 'staff');
    }
  }

  function _setErr(msg) {
    const el = document.getElementById('loginErr');
    if (!el) return;
    el.textContent   = msg;
    el.style.display = msg ? 'block' : 'none';
  }

  function _setStudErr(msg) {
    const el = document.getElementById('studLoginErr');
    if (!el) return;
    el.textContent   = msg || '';
    el.style.display = msg ? 'block' : 'none';
  }

  function _setBtnLoading(btn, loading) {
    if (!btn) return;
    btn.disabled  = loading;
    btn.innerHTML = loading
      ? '<i class="fas fa-spinner fa-spin"></i> جارٍ الدخول...'
      : '<i class="fas fa-sign-in-alt"></i> دخول';
  }

  // نصدّر _startApp للاستخدام من studentLogin
  return { boot, login, logout, studentLogout, _startApp, _setStudErr, _setBtnLoading, _showLogin };
})();

// ─────────────────────────────────────────────────────────────────
//  تسجيل دخول الطالب (دالة عامة — مستدعاة من HTML)
// ─────────────────────────────────────────────────────────────────
async function studentLogin() {
  const emailEl = document.getElementById('studEmailInput');
  const passEl  = document.getElementById('studPassInput');
  const btnEl   = document.getElementById('studLoginBtn');

  const email = emailEl?.value?.trim() || '';
  const pass  = passEl?.value || '';

  if (!email || !pass) {
    APP._setStudErr('يرجى إدخال البريد وكلمة المرور');
    return;
  }

  APP._setBtnLoading(btnEl, true);
  APP._setStudErr('');

  try {
    await AUTH.signInStudent(email, pass);
    if (!STATE._studentUser) throw new Error('تعذّر تحميل بيانات الطالب');
    await APP._startApp();
  } catch (e) {
    APP._setBtnLoading(btnEl, false);
    APP._setStudErr(e.message);
    const lr = document.querySelector('.lr');
    if (lr) { lr.classList.add('shake'); setTimeout(() => lr.classList.remove('shake'), 400); }
  }
}

// ── تشغيل ──────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => APP.boot());

// تحديث دوري للصفحات الحية
setInterval(() => {
  if (STATE.currentPage &&
      ['live', 'my-dashboard', 'dashboard', 'my-calendar', 'student-portal']
        .includes(STATE.currentPage)) {
    UI.renderCurrentPage?.();
  }
}, 30000);

// ── PWA Install ─────────────────────────────────────────────────
let _deferredInstall = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  _deferredInstall = e;
  setTimeout(() => {
    if (!_deferredInstall) return;
    const banner = document.createElement('div');
    banner.id = 'installBanner';
    banner.innerHTML = `<i class="fas fa-download"></i> تثبيت التطبيق على جهازك
      <button onclick="installPWA()" style="background:white;color:var(--primary2);border:none;border-radius:20px;padding:4px 14px;font-weight:700;cursor:pointer;margin-right:6px">تثبيت</button>
      <span onclick="this.parentElement.remove()" style="opacity:.7;cursor:pointer">✕</span>`;
    document.body.appendChild(banner);
  }, 5000);
});

async function installPWA() {
  if (!_deferredInstall) return;
  _deferredInstall.prompt();
  const { outcome } = await _deferredInstall.userChoice;
  if (outcome === 'accepted') toast('✓ تم تثبيت التطبيق بنجاح', 'success');
  _deferredInstall = null;
  document.getElementById('installBanner')?.remove();
}

// ── استعادة جلسة الطالب (توافق مع v13 القديم) ──────────────────
function restoreStudentSession() {
  try {
    const raw = localStorage.getItem('_studentSession');
    if (!raw) return null;
    const s = JSON.parse(raw);
    if (s?.student) return s.student;
  } catch {}
  return null;
}
