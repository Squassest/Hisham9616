// ═══════════════════════════════════════════════════════════════
//  i18n.js — Arabic / English Language Support  v6
// ═══════════════════════════════════════════════════════════════

const I18N = (() => {
  let _lang = localStorage.getItem('ef_lang') || 'ar';

  const T = {
    ar: {
      // System
      appName: 'ExamFlow',
      appSubtitle: 'كلية التمريض · جامعة السلطان قابوس',
      loading: 'جارٍ تحميل النظام...',
      // Nav
      dashboard: 'لوحة التحكم', calendar: 'التقويم', analytics: 'التحليلات',
      exams: 'الامتحانات', live: 'المراقبة الحية', swaps: 'الطلبات',
      proctors: 'المراقبون', students: 'الطلاب', subjects: 'المواد والشعب',
      rooms: 'القاعات', users: 'المستخدمون', settings: 'الإعدادات',
      log: 'سجل النشاط', notifications: 'الإشعارات', myDashboard: 'لوحتي',
      studentPortal: 'بوابتي',
      // Actions
      add: 'إضافة', edit: 'تعديل', delete: 'حذف', save: 'حفظ',
      cancel: 'إلغاء', close: 'إغلاق', search: 'بحث', import: 'استيراد',
      export: 'تصدير', download: 'تنزيل', refresh: 'تحديث', confirm: 'تأكيد',
      // Roles
      admin: 'مسؤول النظام', coordinator: 'منسق الكلية',
      proctor: 'مراقب امتحانات', student: 'طالب',
      // Exam types
      final: 'نهائي', midterm: 'منتصف الفصل', quiz: 'اختبار', makeup: 'إعادة',
      // Status
      active: 'جارٍ', upcoming: 'قادم', completed: 'منتهى',
      present: 'حاضر', absent: 'غائب', late: 'متأخر', excused: 'معذور',
      // Messages
      noData: 'لا توجد بيانات',
      deleteConfirm: 'تأكيد الحذف',
      deleteMsg: 'هل أنت متأكد من الحذف؟ لا يمكن التراجع.',
      saved: '✓ تم الحفظ',
      deleted: 'تم الحذف',
      error: 'خطأ',
      // Fields
      name: 'الاسم', email: 'البريد الإلكتروني', phone: 'الهاتف',
      password: 'كلمة المرور', role: 'الصلاحية', date: 'التاريخ',
      time: 'الوقت', duration: 'المدة', notes: 'ملاحظات',
      semester: 'الفصل الدراسي', batch: 'الدفعة', subject: 'المادة',
      room: 'القاعة', capacity: 'السعة', section: 'الشعبة',
      studentId: 'الرقم الجامعي', employeeId: 'الرقم الوظيفي',
      // Login
      loginTitle: 'تسجيل الدخول',
      loginSubtitle: 'أدخل بريدك الإلكتروني وكلمة المرور للدخول',
      loginBtn: 'دخول',
      // Months
      months: ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
      days: ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],
    },
    en: {
      // System
      appName: 'ExamFlow',
      appSubtitle: 'College of Nursing · Sultan Qaboos University',
      loading: 'Loading system...',
      // Nav
      dashboard: 'Dashboard', calendar: 'Calendar', analytics: 'Analytics',
      exams: 'Exams', live: 'Live Monitor', swaps: 'Requests',
      proctors: 'Proctors', students: 'Students', subjects: 'Subjects & Sections',
      rooms: 'Rooms', users: 'Users', settings: 'Settings',
      log: 'Activity Log', notifications: 'Notifications', myDashboard: 'My Dashboard',
      studentPortal: 'My Portal',
      // Actions
      add: 'Add', edit: 'Edit', delete: 'Delete', save: 'Save',
      cancel: 'Cancel', close: 'Close', search: 'Search', import: 'Import',
      export: 'Export', download: 'Download', refresh: 'Refresh', confirm: 'Confirm',
      // Roles
      admin: 'System Admin', coordinator: 'College Coordinator',
      proctor: 'Exam Proctor', student: 'Student',
      // Exam types
      final: 'Final', midterm: 'Midterm', quiz: 'Quiz', makeup: 'Makeup',
      // Status
      active: 'Active', upcoming: 'Upcoming', completed: 'Completed',
      present: 'Present', absent: 'Absent', late: 'Late', excused: 'Excused',
      // Messages
      noData: 'No data available',
      deleteConfirm: 'Confirm Delete',
      deleteMsg: 'Are you sure you want to delete? This cannot be undone.',
      saved: '✓ Saved successfully',
      deleted: 'Deleted',
      error: 'Error',
      // Fields
      name: 'Name', email: 'Email', phone: 'Phone',
      password: 'Password', role: 'Role', date: 'Date',
      time: 'Time', duration: 'Duration', notes: 'Notes',
      semester: 'Semester', batch: 'Batch', subject: 'Subject',
      room: 'Room', capacity: 'Capacity', section: 'Section',
      studentId: 'Student ID', employeeId: 'Employee ID',
      // Login
      loginTitle: 'Sign In',
      loginSubtitle: 'Enter your email and password to continue',
      loginBtn: 'Sign In',
      // Months
      months: ['January','February','March','April','May','June','July','August','September','October','November','December'],
      days: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
    }
  };

  function t(key) {
    return T[_lang]?.[key] ?? T['ar'][key] ?? key;
  }

  function setLang(lang) {
    _lang = lang;
    localStorage.setItem('ef_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir  = lang === 'ar' ? 'rtl' : 'ltr';
    _updateLangBtn();

    // تحديث الملصق في تبديل اللغة
    const btn = document.getElementById('langToggleBtn');
    if (btn) btn.innerHTML = `<i class="fas fa-language"></i> ${lang === 'ar' ? 'EN' : 'عر'}`;

    // تحديث صفحة تسجيل الدخول إذا كانت ظاهرة
    const loginTitleTxt = document.getElementById('loginTitleTxt');
    if (loginTitleTxt) loginTitleTxt.textContent = T[lang]?.loginTitle || T.ar.loginTitle;
    const loginSubTxt = document.getElementById('loginSubTxt');
    if (loginSubTxt) loginSubTxt.textContent = T[lang]?.loginSubtitle || T.ar.loginSubtitle;
    const loginBtnTxt = document.getElementById('loginBtnTxt');
    if (loginBtnTxt) loginBtnTxt.textContent = T[lang]?.loginBtn || T.ar.loginBtn;
    const lblEmail = document.getElementById('lblEmail');
    if (lblEmail) lblEmail.textContent = lang === 'ar' ? 'البريد الإلكتروني' : 'Email Address';
    const lblPass = document.getElementById('lblPass');
    if (lblPass) lblPass.textContent = lang === 'ar' ? 'كلمة المرور' : 'Password';
    const langTxtBottom = document.getElementById('langTxtBottom');
    if (langTxtBottom) langTxtBottom.textContent = lang === 'ar' ? 'EN' : 'عر';

    // إعادة بناء الواجهة الكاملة إذا كان التطبيق مفتوحاً
    if (typeof UI !== 'undefined' && typeof STATE !== 'undefined' && STATE?.currentUser) {
      // إعادة بناء القائمة الجانبية
      UI.buildNav?.();
      UI.renderSidebar?.();

      // تحديث عنوان الصفحة الحالية
      const meta = {
        dashboard:   { ar:'لوحة التحكم',       en:'Dashboard'       },
        calendar:    { ar:'التقويم',            en:'Calendar'        },
        analytics:   { ar:'التحليلات',          en:'Analytics'       },
        exams:       { ar:'الامتحانات',         en:'Exams'           },
        live:        { ar:'المراقبة الحية',     en:'Live Monitor'    },
        swaps:       { ar:'الطلبات',            en:'Requests'        },
        schedule:    { ar:'الجدول الدراسي',     en:'Schedule'        },
        bookings:    { ar:'حجز القاعات',        en:'Room Bookings'   },
        departments: { ar:'الأقسام الأكاديمية', en:'Departments'    },
        proctors:    { ar:'المراقبون',           en:'Proctors'       },
        students:    { ar:'الطلاب',             en:'Students'        },
        subjects:    { ar:'المواد والشعب',      en:'Subjects'        },
        rooms:       { ar:'القاعات',            en:'Rooms'           },
        users:       { ar:'المستخدمون',         en:'Users'           },
        settings:    { ar:'الإعدادات',          en:'Settings'        },
        log:         { ar:'سجل النشاط',         en:'Activity Log'    },
        notifications:{ ar:'الإشعارات',         en:'Notifications'  },
        'my-dashboard':{ ar:'لوحتي',            en:'My Dashboard'   },
        'student-portal':{ ar:'بوابتي',         en:'My Portal'      },
      };
      const pageMeta = meta[STATE.currentPage];
      const tbTitle = document.getElementById('tbTitle');
      if (tbTitle && pageMeta) tbTitle.textContent = pageMeta[lang] || pageMeta.ar;

      // إعادة رسم الصفحة الحالية لتطبيق اللغة الجديدة
      UI.renderCurrentPage?.();
    }
    // تحديث العنوان في الشريط الجانبي
    const sub = document.getElementById('uniSubtitle');
    if (sub) sub.textContent = T[lang]?.appSubtitle || T.ar.appSubtitle;
  }

  function getLang() { return _lang; }
  function isAr()    { return _lang === 'ar'; }

  function _updateLangBtn() {
    const btn = document.getElementById('langToggleBtn');
    if (btn) {
      btn.innerHTML = _lang === 'ar'
        ? `<i class="fas fa-language"></i> EN`
        : `<i class="fas fa-language"></i> عر`;
    }
  }

  function init() {
    document.documentElement.lang = _lang;
    document.documentElement.dir  = _lang === 'ar' ? 'rtl' : 'ltr';
    setTimeout(_updateLangBtn, 200);
  }

  return { t, setLang, getLang, isAr, init };
})();

// Shorthand helper
function t(key) { return I18N.t(key); }
