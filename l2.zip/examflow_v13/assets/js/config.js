// ═══════════════════════════════════════════════════════════════
//  ExamFlow v14 — Configuration
//  ✓ DB-Auth: تسجيل الدخول مباشرة من قاعدة البيانات (بدون auth.users)
//  ✓ لا حاجة لـ Service Key أو Edge Functions
// ═══════════════════════════════════════════════════════════════

const APP_CONFIG = {
  SUPABASE_URL:      'https://bkqzxkgrxtvejrrbwxca.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJrcXp4a2dyeHR2ZWpycmJ3eGNhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyOTY2MzIsImV4cCI6MjA4ODg3MjYzMn0.91PWONT7A8oH5BMZofhu1-UWHK19d8EpwyQ3an0fQXw',

  APP_NAME:     'ExamFlow',
  APP_VERSION:  '14.0',
  APP_SUBTITLE: 'كلية التمريض · جامعة السلطان قابوس',

  DEFAULT_SEM: '2024-2',

  ROLES: {
    admin:          'مسؤول النظام',
    dean:           'العميد',
    assistant_dean: 'مساعد العميد',
    coordinator:    'منسق الكلية',
    dept_head:      'رئيس القسم',
    proctor:        'مراقب امتحانات',
    student:        'طالب'
  },
  ROLES_EN: {
    admin:          'System Admin',
    dean:           'Dean',
    assistant_dean: 'Assistant Dean',
    coordinator:    'Coordinator',
    dept_head:      'Dept. Head',
    proctor:        'Proctor',
    student:        'Student'
  },
  ROLE_COLORS: {
    admin:          '#2563eb',
    dean:           '#b91c1c',
    assistant_dean: '#dc2626',
    coordinator:    '#0891b2',
    dept_head:      '#7c3aed',
    proctor:        '#059669',
    student:        '#0ea5e9'
  },
  ROLE_ICONS: {
    admin:          'fa-shield-alt',
    dean:           'fa-crown',
    assistant_dean: 'fa-user-shield',
    coordinator:    'fa-user-cog',
    dept_head:      'fa-chalkboard-teacher',
    proctor:        'fa-user-tie',
    student:        'fa-user-graduate'
  },

  // أدوار للقراءة فقط (Dean / Assistant Dean = Read-Only)
  READ_ONLY_ROLES:  ['dean','assistant_dean'],
  CAN_EDIT_ROLES:   ['admin','coordinator','dept_head'],
  CAN_DELETE_ROLES: ['admin','coordinator'],
  ADMIN_ONLY:       ['admin'],
  // أدوار ترى بيانات الكلية كاملة بلا قسم محدد
  FACULTY_WIDE_ROLES: ['admin','coordinator','dean','assistant_dean'],

  DAYS_AR: ['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],
  DAYS_EN: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],

  SCHEDULE_TYPES: {
    lecture:  { label:'محاضرة',  color:'#2563eb', icon:'fa-chalkboard' },
    lab:      { label:'مختبر',   color:'#059669', icon:'fa-flask' },
    tutorial: { label:'تمريني',  color:'#d97706', icon:'fa-book-open' },
    seminar:  { label:'ندوة',    color:'#7c3aed', icon:'fa-users' }
  },

  BOOKING_PURPOSES: {
    lecture:  { label:'محاضرة',    color:'#2563eb' },
    exam:     { label:'امتحان',    color:'#dc2626' },
    lab:      { label:'مختبر',     color:'#059669' },
    seminar:  { label:'ندوة',      color:'#7c3aed' },
    meeting:  { label:'اجتماع',    color:'#0891b2' },
    event:    { label:'فعالية',    color:'#d97706' },
    other:    { label:'أخرى',      color:'#64748b' }
  },

  ROOM_TYPES: {
    lecture:    { label:'قاعة محاضرات', icon:'fa-chalkboard', color:'#2563eb' },
    lab_comp:   { label:'مختبر حاسوب', icon:'fa-desktop',     color:'#059669' },
    lab_sci:    { label:'مختبر علمي',  icon:'fa-flask',       color:'#7c3aed' },
    classroom:  { label:'فصل دراسي',   icon:'fa-door-open',   color:'#0891b2' },
    hall:       { label:'قاعة كبرى',   icon:'fa-building',    color:'#d97706' },
    seminar:    { label:'قاعة ندوات',  icon:'fa-users',       color:'#dc2626' },
    simulation: { label:'محاكاة',      icon:'fa-vr-cardboard', color:'#ea580c' },
    other:      { label:'أخرى',        icon:'fa-cube',        color:'#64748b' }
  },

  ATT_METHODS: {
    manual:    { label:'يدوي',  icon:'fa-hand-pointer', color:'#64748b' },
    qr:        { label:'QR',    icon:'fa-qrcode',       color:'#2563eb' },
    biometric: { label:'بصمة',  icon:'fa-fingerprint',  color:'#059669' },
    rfid:      { label:'RFID',  icon:'fa-id-card',      color:'#7c3aed' },
    face:      { label:'وجه',   icon:'fa-face-smile',   color:'#d97706' }
  }
};

Object.freeze(APP_CONFIG);
